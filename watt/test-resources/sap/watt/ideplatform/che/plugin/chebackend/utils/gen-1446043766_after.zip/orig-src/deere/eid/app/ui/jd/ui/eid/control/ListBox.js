(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ListBox");

    /**
     * Constructor for a new ListBox.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>enableMandatorySelection : boolean (default: true) True if one value always has to be selected, false otherwise.</li>
     * <li>enableSimpleSelect : boolean (default: false) True if select/deselect by single click should be enabled, false otherwise.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The ListBox control provides basic extensions to the standard ListBox control as listed below.
     *        <ul>
     *        <li> MandatorySelection: The extension allows for making a selection mandatory. Once an item has been selected, exactly one item will
     *        always be selected. This only works when allowMultiSelect is set to false.</li>
     *        <li> Simple Multi Select: The extension allows for selecting an additional item by a simple click and without pressing the ctrl or shift
     *        key. This only works when allowMultiSelect is set to true.</li>
     *        </ul>
     * @extends sap.ui.commons.ListBox
     * @name jd.ui.eid.control.ListBox
     */
    sap.ui.commons.ListBox.extend("jd.ui.eid.control.ListBox", /** @lends jd.ui.eid.control.ListBox */
    {
        metadata : {
            properties : {
                enableMandatorySelection : {
                    type : "boolean",
                    defaultValue : false,
                },
                enableSimpleMultiSelect : {
                    type : "boolean",
                    defaultValue : true
                },
                enableSimpleSelect : {
                    type : "boolean",
                    defaultValue : false
                }
            }
        },

        /**
         * Sets the enableSimpleMultiSelect property.
         * 
         * @deprecated Use enableSimpleSelect property instead.
         * @param {boolean}
         *            bValue the value
         * @returns {jd.ui.eia.control.ListBox} this for method chaining.
         */
        setEnableSimpleMultiSelect : function(bValue) {
            this.setProperty("enableSimpleMultiSelect", bValue);
            this.setProperty("enableSimpleSelect", bValue);
            return this;
        },

        /**
         * Event handler called when an item is clicked.
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            if (this.getEnableSimpleSelect()) {
                if (!this.getEnableMandatorySelection()) {
                    // If simple multi selection is enabled and there's no mandatory selection, we just pretend that the ctrl key was
                    // pressed and let the standard implementation do all the rest.
                    oEvent.ctrlKey = true;
                } else {
                    // If simple select is enabled and mandatory selection is enabled, too, it's a little bit more tricky...
                    if (this.getSelectedIndices().length >= 2) {
                        // If there are two or more items selected currently, we don't need to care whether with this click handling, we're selecting
                        // or deselecting an item.
                        oEvent.ctrlKey = true;
                    } else {
                        // Else in this case means that there's currently one item selected (zero can't be, it would be an invalid state).
                        var iItemIndex = $(oEvent.target).data("sapUiLbxIndex") || $(oEvent.target.parentElement).data("sapUiLbxIndex");
                        if (this.isIndexSelected(iItemIndex)) {
                            // So we need to check whether the control that we just clicked on is currently selected. Because then we would actually
                            // try to deselect it. As we don't want to do this, we will just abort the method...
                            return;
                        } else {
                            // We clicked a different item, so again, we jsut pretend we're trying to add the item
                            oEvent.ctrlKey = true;
                        }
                    }
                }
            } else if (!this.getAllowMultiSelect() && this.getEnableMandatorySelection()) {
                // Only one value can be selected but also, one value has to be selected. So in
                // order to disable 'unselect', we always tell the control that the ctrl key hasn't
                // been pressed.
                oEvent.ctrlKey = false;
            }
            sap.ui.commons.ListBox.prototype.onclick.apply(this, arguments);
        },

        /* Point to the default renderer as there is no custom rendering required */
        renderer : "sap.ui.commons.ListBoxRenderer"
    });
})();