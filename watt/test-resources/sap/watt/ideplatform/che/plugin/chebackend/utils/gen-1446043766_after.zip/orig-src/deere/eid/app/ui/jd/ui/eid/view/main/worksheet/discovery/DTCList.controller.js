(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.FilterAreaFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WorkSheetFormatter");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCTableController");
    jd.ui.eid.require("jd.ui.eid.common.TableHelper");

    /**
     * @class
     * <p>
     * The controller displays a list of DTC by incorporating the {@link jd.ui.eid.view.main.shared.DTCTableController} and the read only filter area.
     * From the list of DTCs, the details view can be opened in a separate overlay (see {@link #.openDTCDetailsOverlay}).
     * </p>
     * <p>
     * The view uses the following <strong>delegates</strong>:
     * <ul>
     * <li>{@link jd.ui.eid.common.delegate.DTCFilterAreaDelegate} : the responsible delegate for the filter area fragment.</li>
     * </ul>
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#EvidencePackage::editDTCFilter} : Raised while changing the DTC filter</li>
     * </ul>
     * </p>
     * <p>
     * The view handles the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} : When navigating to the view, the DTC list is refreshed.</li>
     * <li>{@link jd.ui.eid.Events#EvidencePackage::newDTCFiltersApplied} : Refreshes the DTC list.</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @augments jd.ui.eid.view.main.shared.DTCTableController
     * @name jd.ui.eid.view.main.worksheet.discovery.DTCList
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.discovery.DTCList", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.DTCTableController, /** @lends jd.ui.eid.view.main.worksheet.discovery.DTCList */
            {

                _bRefresh : true,
                _oFilterAreaDelegate : null,
                _oOverlay : null,
                _oView : null,
                _sViewName : "jd.ui.eid.view.main.worksheet.discovery.DTCList",

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 */
                onInit : function() {
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewWorksheetDiscoveryDTCList");
                    this._oView.addStyleClass("jdUiEidScrollLayout jdUiEidScrollLayoutHorizontal jdUiEidScrollLayoutScrollBarOutside");

                    // Config
                    this.mDTCTableControllerConfig.mFetchDTCList.sFilterSelectionPath = "/EvidencePackageDetails/Header/DTCFilterSelection";
                    this.mDTCTableControllerConfig.sSearchFieldId = "dtcSearchField";

                    // Subscribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.subscribe("Navigation", "navigating", this._handleNavigating, this);
                    oEventBus.subscribe("EvidencePackage", "newDTCFiltersApplied", this.handleNewDTCFiltersApplied, this);

                    // Init filter area
                    var sFilterAreaFragmentId = this.createId("FilterArea");
                    this._oFilterAreaDelegate = new jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate({
                        fragmentId : sFilterAreaFragmentId,
                        selectionPath : "/EvidencePackageDetails/Header/DTCFilterSelection",
                        filterStatePath : "/EvidencePackageDetails/Header/DTCFilterState",
                        editFilterArea : [this.handleEditFilterArea, this]
                    });
                    var oFilterArea = jd.ui.eid.xmlfragment(sFilterAreaFragmentId, "jd.ui.eid.fragment.filter.DTCFilterAreaReadOnly",
                            this._oFilterAreaDelegate);
                    this._oFilterAreaDelegate.setFilterArea(oFilterArea);
                    this.byId("FilterAreaPlaceholder").addContent(oFilterArea);

                    // Init merged controllers
                    this.initDTCTableController();
                },

                /**
                 * Called before the view is rendered.
                 */
                onBeforeRendering : function() {
                    this.onDTCTableControllerBeforeRendering();
                },

                /**
                 * Called after the view is rendered and triggers a data fetch if the refresh flag is set to true.
                 */
                onAfterRendering : function() {
                    this.onDTCTableControllerAfterRendering();

                    if (this._bRefresh) {
                        this.fetchDTCList();
                        this._bRefresh = false;
                    }
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 */
                onExit : function() {
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.unsubscribe('Navigation', 'navigating', this._handleNavigating, this);
                    oEventBus.unsubscribe('EvidencePackage', 'newDTCFiltersApplied', this.fetchDTCList, this);

                    // Destroy merged controllers
                    this.exitDTCTableController();

                    // Destroy delegates
                    this._oFilterAreaDelegate.destroy();

                    // Detroy controls
                    if (this._oOverlay) {
                        this._oOverlay.destroy();
                    }

                    // Set properties to null
                    this._oOverlay = null;
                    this._oView = null;
                    this.mDTCTableControllerConfig = null;
                },

                /**
                 * Opens the DTC details in an overlay container and adjusts the dashboard UI (chart/table size, etc.) The counterpart is
                 * {@link #.closeDTCDetailsOverlay}.
                 * 
                 * @param {string}
                 *            sDTCID the DTC ID
                 */
                openDTCDetailsOverlay : function(sDTCID) {
                    if (this._oOverlay == null) {
                        this._oOverlay = jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayRegular();
                    }
                    this._oOverlay.setContext(sDTCID);// = jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayRegular(sDTCID);

                    if (!this._oOverlay.isOpen()) {
                        this._oOverlay.open();
                    }
                },

                /**
                 * Closes the DTC details view displayed in an overlay (if open) and adjusts the dashboard UI (chart/table size, etc.) The counterpart
                 * is {@link #.openDTCDetailsOverlay}.
                 */
                closeDTCDetailsOverlay : function() {
                    if (this._oOverlay && this._oOverlay.isOpen()) {
                        this._oOverlay.close();
                    }
                },

                /**
                 * Hook method called before fetching the DTC list. Returns true to fetch the DTC list if the view is visible or if the
                 * controller-internal refresh flag is set. This happens e.g. when the view opens and the <code>navigating</code> event is fired.
                 * 
                 * @see jd.ui.eid.view.main.shared.DTCTableController.fetchDTCList
                 * 
                 * @return {boolean} True to fetch the DTC list, false otherwise.
                 */
                fetchDTCListHookBefore : function() {
                    return this.isVisible() || this._bRefresh;
                },

                /**
                 * Hook function for additional checks regarding the visibility in the classes.
                 */
                _isVisible : function() {
                    if (jd.ui.eid.common.OverlayHelper.getWorksheetOverlay().isOpen()
                            && !jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay().isOpen()) {
                        return true;
                    } else {
                        return false;
                    }
                },

                /**
                 * Handles the <code>navigating</code> event from channel <code>Navigation</code>. If navigating to the DTC list view, the data
                 * fetch flag is set so that the DTC list is refreshed.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                _handleNavigating : function(sChannelId, sEvent, oData) {
                    if (oData.target == this._sViewName) {
                        // Navigating back to dtc list, so we want to refresh the data.
                        this._bRefresh = true;
                    }
                },

                /**
                 * Event handler for editing the DTC Filter Area in Read Only Mode
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event
                 */
                handleEditFilterArea : function(oEvent) {
                    // we let handle the event by the worksheet controller
                    sap.ui.getCore().getEventBus().publish('EvidencePackage', 'editDTCFilter', oEvent);
                },

                /**
                 * Event handler for clicking a DTC inside the DTC List
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event
                 */
                handleOpenDTCDetails : function(oEvent) {
                    var oSelectedDTCListItem = oEvent.getSource().getBindingContext().getProperty();
                    jd.ui.eid.model.EidModel.TransformationHelper.bufferExpensiveDTCListItemDataToDTCDetails(oSelectedDTCListItem);
                    this.openDTCDetailsOverlay(oSelectedDTCListItem.DTCID);
                },

                /**
                 * This function handles the event that is triggered by clicking on "Add to Evidence Package" button
                 * 
                 * @param {object}
                 *            oEvent event triggered by clicking on "Add to Evidence Package"
                 */
                handleAddToEvidencePackage : function(oEvent) {
                    var mDTC = oEvent.getSource().getBindingContext().getProperty();
                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTC(mDTC);
                },

                /**
                 * This function handles the search event and triggers the data fetch using the specified search term
                 */
                handleSearch : function() {
                    this.fetchDTCList();
                    this._resetTableSelection();
                },

                /**
                 * Hook for {@link jd.ui.eid.view.main.shared.DTCTableController#handleKPISelectionChange} and resets the selection on the table.
                 */
                handleKPISelectionChangeHookAfter : function() {
                    this._resetTableSelection();
                },

                /**
                 * This function triggers an DTC update after the DTC filtes have been changed
                 */
                handleNewDTCFiltersApplied : function() {
                    this.fetchDTCList(false);
                },

                /**
                 * Resets the selected row of the DTC table.
                 */
                _resetTableSelection : function() {
                    this.byId("DTCListTable").setSelectedIndex(-1);
                }

            }));
})();