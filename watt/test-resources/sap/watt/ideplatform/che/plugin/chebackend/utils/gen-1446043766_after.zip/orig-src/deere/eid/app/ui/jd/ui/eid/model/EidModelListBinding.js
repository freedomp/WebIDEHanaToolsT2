(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("sap.ui.model.json.JSONListBinding");

    /**
     * Constructor for a new EidModelListBinding.
     * 
     * @param {jd.ui.eid.model.EidModel}
     *            oModel the model reference.
     * @param {string}
     *            sPath the path for the list binding.
     * @param {sap.ui.model.Context}
     *            [oContext] the context of the list binding.
     * 
     * @class
     * <p>
     * Eid (emerging issues detection) model listbinding class.
     * </p>
     * @see jd.ui.eid.model.EidModel
     * @extends sap.ui.model.json.JSONListBinding
     * @name jd.ui.eid.model.EidModelListBinding
     */
    sap.ui.model.json.JSONListBinding.extend("jd.ui.eid.model.EidModelListBinding", /** @lends jd.ui.eid.model.EidModelListBinding */
    {
        _oJdUiEidContext : null,
        _sJdUiEidPath : null,
        _oJdUiEidModel : null,
        _iJdUiEidChunkSize : 100,

        /**
         * @constructor
         * @param oModel
         * @param sPath
         * @param oContext
         */
        constructor : function(oModel, sPath, oContext) {
            // call parent constructor
            sap.ui.model.json.JSONListBinding.apply(this, arguments);

            this._oJdUiEidModel = oModel;
            this._oJdUiEidContext = oContext;
            this._sJdUiEidPath = sPath;

            // set default top value -> Indicates the default amount of data that is requested from
            // the backend by default
            this.iDefaultTop = 100;
        },

        /**
         * Override function to filter the list.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @param {sap.ui.model.Filter[]}
         *            aFilters Array of filter objects
         * @param {sap.ui.model.FilterType}
         *            sFilterType Type of the filter which should be adjusted, if it is not given, the standard behaviour applies.
         * 
         * @override
         * @public
         */
        filter : function(aFilters, sFilterType) {

            $.sap.log.debug("jd.ui.eid.model.EidModelListBinding->filter()");

            // Set filtering values
            this.aFilters = aFilters;

            // Fire event "listBindingChanged" to notify the service framework about filtering on
            // data
            this._fireListBindingChanged();
            this._fireChange({
                reason : sap.ui.model.ChangeReason.Filter
            });
        },

        /**
         * Function is used by the parent class, but shouldn't have an effect. The work will be done by the service framework
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @override
         * @public
         */
        applyFilter : function() {
        },

        /**
         * Override function to sort the list.
         * 
         * @see sap.ui.model.ListBinding.prototype.sort
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @param {sap.ui.model.Sorter[]}
         *            aSorters Array of sorting objects
         * 
         * @override
         * @public
         */
        sort : function(aSorters) {

            $.sap.log.debug("jd.ui.eid.model.EidModelListBinding->sort()");

            // Set sorting values
            this.aSorters = aSorters;

            // Fire event "listBindingChanged" to notify the service framework about sorting on data
            this._fireListBindingChanged();
            this._fireChange({
                reason : sap.ui.model.ChangeReason.Sort
            });
        },

        /**
         * Function is used by the parent class, but shouldn't have an effect. The work will be done by the service framework.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @override
         * @public
         */
        applySort : function() {
        },

        _iJdUiEidLength : -1,

        /**
         * Override function to return the complete data count/length, which is provided by the backend.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @returns {int} The total count of data in the backend
         * 
         * @override
         * @public
         */
        getLength : function() {
            if (this._iJdUiEidLength == -1) {
                // temoprary fix
                return this.iLength;
            }
            return this._iJdUiEidLength;
        },

        /**
         * Override function to set the complete data count/length, which is send by the backend.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @param {int}
         *            iLength The total count of data in the backend
         * 
         * @override
         * @public
         */
        setLength : function(iLength) {
            this.iLength = iLength;
            this._iJdUiEidLength = iLength; // Save the complete data size (This is the amount of data,
            // which the server still provides and has to be explicitly
            // requested by client if needed)
        },

        _jdUiEidGetContext : function() {
            if (this.getContext) {
                return this.getContext();
            } else if (this.oContext) {
                return this.oContext
            } else {
                $.sap.log.fatal("Unable to find context for list binding.", null, "jd.ui.eid.model.EidModelListBinding");
                return undefined;
            }
        },

        /**
         * Override function to return contexts for the list or a specified subset of contexts. This function also checks if further data needs to be
         * received from the backend service while paging is applied and if so the function calls the event dataRequested.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @param {int}
         *            [iStartIndex=0] the startIndex determines where to start the retrieval of contexts.
         * @param {int}
         *            [iLength=length of the list] determines how many contexts to retrieve beginning from the start index. Default is the whole list
         *            length.
         * @param {int}
         *            [_iJdUiEidThreshold=100] determines how many contexts should be prefetched.
         * @returns {Array} the contexts array
         * 
         * @override
         * @protected
         */
        getContexts : function(iStartIndex, iLength, iThreshold) {
            // Remember the current parameters for later use
            this._iJdUiEidLastStartIndex = iStartIndex;
            this._iJdUiEidLastLength = iLength;

            // Determine the number of records that is already available on the client
            this._iJdUiEidTotalClientDataSize = this._jdUiEidGetListFromModel().length;
            // Determine the length (how many records entries should be returned)
            this._iJdUiEidThreshold = iThreshold || this._iJdUiEidChunkSize; // Indicates the amount of data, which should be
            // prefetched by the client

            if (!iStartIndex) {
                iStartIndex = 0;
            }

            if (!iLength) {
                iLength = Math.min(Math.max(this.getLength(), this._iJdUiEidTotalClientDataSize), Math.max(this._iJdUiEidChunkSize,
                        this._iJdUiEidTotalClientDataSize));
            }
            var iMaxEndIndex = Math.max(this.getLength(), this._iJdUiEidTotalClientDataSize);
            var iEndIndex = iStartIndex + iLength;
            if (iEndIndex > iMaxEndIndex) {
                iLength = iMaxEndIndex - iStartIndex;
            }
            // iLength = Math.min(iLength, iMaxLength);

            // Do the default procedure of sap.ui.model.json.JSONListBinding.getContexts()
            // var aContexts = sap.ui.model.json.JSONListBinding.prototype.getContexts.apply(this, arguments);

            // Get contexts
            var aContexts = this._jdUiEidGetContexts(iStartIndex, iLength);

            // Check whether next bunch of data needs to be loaded from server
            $.sap.log.debug("Total data size at DB: " + this.getLength());
            $.sap.log.debug("Current data size request: " + (this._iJdUiEidLastStartIndex + this._iJdUiEidLastLength));
            $.sap.log.debug("Data available at Client: " + this._iJdUiEidTotalClientDataSize);

            // Check whether further data needs to be requested by a new server request
            if (this._iJdUiEidTotalClientDataSize < this.getLength() // Check whether server has still some
                    // data
                    && (this._iJdUiEidLastStartIndex + this._iJdUiEidLastLength) > this._iJdUiEidTotalClientDataSize) // Check whether request
            // exceeded client
            // buffer
            {
                this._fireDataRequested(); // Fire "DataRequested" event to notify the service framework to load further data
            }

            return aContexts;
        },

        _jdUiEidGetListFromModel : function() {
            var sPrefix = this._jdUiEidResolve(this._sJdUiEidPath, this._jdUiEidGetContext());
            var aList = this._oJdUiEidModel.getProperty(sPrefix);
            if (!aList) {
                aList = [];
            }
            return aList;
        },

        _jdUiEidGetContexts : function(iStartIndex, iLength) {
            var sPrefix = this._jdUiEidResolve(this._sJdUiEidPath, this._jdUiEidGetContext());
            if (sPrefix && !jQuery.sap.endsWith(sPrefix, "/")) {
                sPrefix += "/";
            }

            var iEndIndex = iStartIndex + iLength;

            var aContexts = [], oContext;
            for ( var i = iStartIndex; i < iEndIndex; i++) {
                oContext = this.oModel.getContext(sPrefix + i);
                aContexts.push(oContext);
            }
            return aContexts;
        },

        /**
         * Define function to fire the event "listBindingChanged" (This is mainly used while sorting/filtering is active).
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @private
         */
        _fireListBindingChanged : function() {
            $.sap.log.debug("Event fired: listBindingChanged!");

            // Set top/skip values (Used by the BaseServiceFacade class for requesting the right
            // bunch of data)
            this.reset();

            // Notify all listeners about filtering on a specific binding (table)
            sap.ui.getCore().getEventBus().publish('EidModel', 'listBindingChanged', {
                oListBinding : this
            });
        },

        /**
         * Define function to fire the event "DataRequested" (This is mainly used while paging is active).
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @private
         */
        _fireDataRequested : function(bRefreshData) {
            $.sap.log.debug("Event fired: DataRequested!");

            // Set top/skip values (Used by the BaseServiceFacade class for requesting the right
            // bunch of data)
            var iTotalThreshold = (this._iJdUiEidTotalClientDataSize + this._iJdUiEidThreshold);
            var iDataRequest = (this._iJdUiEidLastStartIndex + this._iJdUiEidLastLength);
            this.iTop = 0;

            if (iDataRequest <= iTotalThreshold) {
                // Get default data bunch
                this.iTop = this._iJdUiEidThreshold;
            } else {
                // Don't ask for default threshold. More than that needed!
                this.iTop = iDataRequest - this._iJdUiEidTotalClientDataSize;
            }

            if (bRefreshData) {
                this.iSkip = 0;
                this.iTop = this._iJdUiEidTotalClientDataSize;
            } else {
                this.iSkip = this._iJdUiEidTotalClientDataSize;
            }

            // Notify all listeners that further data is requested for a specific binding (table)
            sap.ui.getCore().getEventBus().publish('EidModel', 'dataRequested', {
                oListBinding : this,
                iSkip : this.iSkip,
                iTop : this.iTop
            });
        },

        _jdUiEidResolve : function(sPath, oContext) {
            var bIsRelative = !jQuery.sap.startsWith(sPath, "/"), sResolvedPath = sPath, sContextPath;
            if (bIsRelative) {
                if (oContext) {
                    sContextPath = oContext.getPath();
                    sResolvedPath = sContextPath + (jQuery.sap.endsWith(sContextPath, "/") ? "" : "/") + sPath;
                } else {
                    // sResolvedPath = this.isLegacySyntax() ? "/" + sPath : undefined;
                }
            }

            // invariant: path never ends with a slash ... if root is requested we return /
            if (sResolvedPath && sResolvedPath !== "/" && jQuery.sap.endsWith(sResolvedPath, "/")) {
                sResolvedPath = sResolvedPath.substr(0, sResolvedPath.length - 1);
            }
            return sResolvedPath;
        },

        /**
         * Define function to reset listbinding.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @public
         */
        reset : function() {
            // Reset top/skip values for the server request
            this._setDefaultTop();
            this._setDefaultSkip();
        },

        /**
         * Refreshes the data related to the binding.
         */
        refreshData : function() {
            this._fireDataRequested(true);
        },

        /**
         * Define function to set the top value for the server request. This value indicates the amount of data the server should return in the next
         * request.
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @private
         */
        _setDefaultTop : function() {
            if (this._iJdUiEidThreshold !== undefined) {
                this.iTop = this._iJdUiEidThreshold;
            } else {
                this.iTop = this.iDefaultTop;
            }

        },

        /**
         * Define function to set the skip value for the server request. This value indicates the amount of data the server should skip in the next
         * request (the client already received this data).
         * 
         * @memberOf jd.ui.eid.model.EidModelListBinding
         * 
         * @private
         */
        _setDefaultSkip : function() {
            this.iSkip = 0;
        }

    });

})();