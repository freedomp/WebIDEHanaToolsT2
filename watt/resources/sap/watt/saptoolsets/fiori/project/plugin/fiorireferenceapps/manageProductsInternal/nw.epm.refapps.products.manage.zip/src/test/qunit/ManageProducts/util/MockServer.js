var gMockServer = {
    oModel : null,
    oMockServer : null,
    getModel : function(bV2) {
        if (!this.oMockServer) {
            jQuery.sap.require("sap.ui.core.util.MockServer");
            var sMockServerUrl = "/sap/opu/odata/sap/EPM_REF_APPS_PROD_MAN_SRV/";
            var sMockedDataSource = jQuery.sap.getModulePath("nw.epm.refapps.products.manage") + "/model/metadata.xml";
            this.oMockServer = new sap.ui.core.util.MockServer({
                rootUri : sMockServerUrl
            });
            this.oMockServer.simulate(sMockedDataSource, sMockedDataSource.replace(new RegExp("[^/]*$"), ""));
            this.oMockServer.start();

            this.oModel = bV2 ? new sap.ui.model.odata.v2.ODataModel(sMockServerUrl, true)
                    : new sap.ui.model.odata.ODataModel(sMockServerUrl, true);
        }
        return this.oModel;
    },

    stop : function() {
        if (this.oMockServer) {
            this.oMockServer.stop();
            this.oMockServer = null;
        }
    }
};
