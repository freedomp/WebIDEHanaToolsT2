(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ListBoxFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");

    /**
     * Constructor for a new ListBoxFilterItem.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>allowMultiSelect : boolean (default: false) True if multi select should be allowed, false otherwise.</li>
     * <li>booleanKey : boolean (default: false) The boolean value of the control, populated if the enableBooleanKey property is set to true.</li>
     * <li>enableBooleanKey : boolean (default: false) True if boolean keys should be enabled, false otherwise. Only works together with the
     * selectedKey property. True is mapped to the item with string key 1, false is mapped to the item with string key 0.</li>
     * <li>enableMandatorySelection : boolean (default: false) True if one value always has to be selected, false otherwise.</li>
     * <li>enableObjectSelection : boolean (default: false) True if a selected item should be represented by its entire object, false otherwise.</li>
     * <li>maxVisibleItems : integer (default: 5) The maximum number of visible items.</li>
     * <li>noData : string (default: '') Text to display if the list is empty.</li>
     * <li>objectSelectionKey : string (default: '') The property of a list item's context object which should be used as a represantative key.</li>
     * <li>selectedKey : string (default: '') The key of the selected item. This only works if multi select is disabled and useSelectedKey true.</li>
     * <li>useSelectedKey : boolean (default: false) True of the selectedKey property should be favored over the selection property, false otherwise.</li>
     * <li>visibleItems : integer (default: -1) The number of visible items before switchting to scroll mode.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>items : sap.ui.core.Item[] The items to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The ListBoxFilterItem control provides list of possible values which can be selected. The control can either handle an array of selected
     *        keys (selection property, has to be declared as object) or a single value (selectedKey property). For the selectedKey property to work
     *        correctly, allowMultiSelect has to be set to false and useSelectedKey has to be set to true. Otherwise, only the selection property will
     *        be used. If selectedKey is used, it is simply wrapped into an array with a single element and handed over to the selection property to
     *        leverage the existing logic.
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.ListBoxFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.ListBoxFilterItem",
    /** @lends jd.ui.eid.control.ListBoxFilterItem */
    {
        metadata : {
            properties : {
                allowMultiSelect : {
                    type : "boolean",
                    defaultValue : false
                },
                booleanKey : {
                    type : "boolean",
                    defaultValue : false
                },
                enableBooleanKey : {
                    type : "boolean",
                    defaultValue : false
                },
                enableMandatorySelection : {
                    type : "boolean",
                    defaultValue : false,
                },
                enableObjectSelection : {
                    type : "boolean",
                    defaultValue : false
                },
                maxVisibleItems : {
                    type : "integer",
                    defaultValue : 5
                },
                noData : {
                    type : "string",
                    defaultValue : ''
                },
                objectSelectionKey : {
                    type : "string",
                    defaultValue : ''
                },
                selectedKey : {
                    type : "string",
                    defaultValue : ''
                },
                useSelectedKey : {
                    type : "boolean",
                    defaultValue : false
                },
                visibleItems : {
                    type : "integer",
                    defaultValue : "-1"
                }
            },

            aggregations : {
                _listBox : {
                    type : "sap.ui.commons.ListBox",
                    multiple : false,
                    visibility : "false"
                },
                items : {
                    type : "sap.ui.core.Item",
                    multiple : true,
                    singularName : "item"
                }
            }
        },

        /**
         * Initialize the control, its internal aggregation and assign a custom style class.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the style class here so that we don't have to
            // do any unnecessary overwrites in
            // the renderer
            this.addStyleClass("jdUiEidListBoxFilterItem");

            var that = this;
            this.setAggregation("_listBox", new jd.ui.eid.control.ListBox({
                enableSimpleSelect : true,
                select : [this._handleSelect, this],
                visibleItems : 5
            }).addEventDelegate({
                onBeforeRendering : function() {
                    // If we reload the evidence package, it's possible that the selection is assigned before the domain values are actually bound. So
                    // for that case, the selection on the inner list box control would get lost. Thus, we check in onBeforeRendering.
                    if (that.getAggregation("_listBox").getSelectedIndices().length == 0 && that.getSelection().length != 0) {
                        that._updateListBoxSelection();
                        that._updateSelectionIndicator();
                    }
                }
            }));
        },

        /* Internal Event Handlers */

        /**
         * Updates the selection property based on the selected items.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        _handleSelect : function(oEvent) {
            // Update the selectedValues property if something
            // in the list box changed, so that the
            // control's internal state is maintained.
            var aKeys = this._getKeysFromIndices(oEvent.getParameter('selectedIndices'));

            // We call setProperty directly because the event is
            // coming from the internal list box
            // aggregation which doesn't need to be updated
            // again :)
            if (this.getEnableObjectSelection()) {
                var aSelectedItems = oEvent.getSource().getSelectedItems();
                var aObjectKeys = [];
                for ( var i = 0; i < aSelectedItems.length; i++) {
                    var oSelectedItem = aSelectedItems[i];
                    aObjectKeys.push(oSelectedItem.getBindingContext().getProperty());
                }
                this.setProperty("selection", aObjectKeys);
            } else {
                this.setProperty("selection", aKeys);
            }

            // And if useSelectedKey is set to true and
            // allowMultiSelect is set to false, then aKeys
            // should only have one element and we can update
            // the selectedKey property.
            if (this.getUseSelectedKey() === true && this.getAllowMultiSelect() === false) {
                var sKey = aKeys[0];
                if (this.getEnableBooleanKey()) {
                    this.setProperty("booleanKey", sKey == '1');
                }
                this.setProperty("selectedKey", sKey);
            }

            if (!this.fireValueChanged()) {
                oEvent.preventDefault();
            }

            this._updateSelectionIndicator();
        },

        /* Internal Helper Methods */

        _updateVisibleItems : function() {
            var iItems = this.getItems().length;
            var iMaxItems = this.getMaxVisibleItems();
            var iVisibleItems = -1;
            if (iItems > iMaxItems) {
                iVisibleItems = iMaxItems;
            }
            this.getAggregation("_listBox").setVisibleItems(iVisibleItems);
        },

        /**
         * Gets the item keys for the given item indices.
         * 
         * @param {array}
         *            aIndices an array with indices.
         * @return {array} an array with keys.
         */
        _getKeysFromIndices : function(aIndices) {
            var aKeys = [];
            var aItems = this.getAggregation("_listBox").getItems();
            for ( var i = 0; i < aIndices.length; i++) {
                var iIndex = aIndices[i];
                if (aItems[iIndex]) {
                    aKeys.push(aItems[iIndex].getKey());
                }
            }
            return aKeys;
        },

        /**
         * Updates the selection indicator property based on the current selection.
         */
        _updateSelectionIndicator : function() {
            var iTotal = this.getItems().length || 0;
            var iSelected = 0;
            if (this.getAggregation("_listBox").getSelectedIndices()) {
                iSelected = this.getAggregation("_listBox").getSelectedIndices().length;
            }
            this.setActive(iSelected != 0);
            this.setSelectionIndicator("(" + iSelected + "/" + iTotal + ")");
        },

        /**
         * Updates the selection of the inner list box control based on the current value of the selection property.
         */
        _updateListBoxSelection : function() {
            var aValues = this.getSelection();
            // Depending on when the binding is done, aValues
            // could be null or undefined, so we only want to
            // process that if it's actually an array.
            if (aValues) {
                if (this.getEnableObjectSelection()) {
                    var sKeyProperty = this.getObjectSelectionKey();
                    var aActualKeys = [];
                    for ( var i = 0; i < aValues.length; i++) {
                        var oValue = aValues[i];
                        aActualKeys.push('' + oValue[sKeyProperty]); // Convert to string as the key is of that type.
                    }
                    this.getAggregation("_listBox").setSelectedKeys(aActualKeys);
                } else {
                    this.getAggregation("_listBox").setSelectedKeys(aValues);
                }
            }
            this._updateSelectionIndicator();
        },

        /* Custom Getter & Setter */

        /**
         * @see sap.ui.commons.ListBox#setAllowMultiSelect
         */
        setAllowMultiSelect : function(sValue) {
            this.getAggregation("_listBox").setAllowMultiSelect(sValue);
            return this;
        },

        /**
         * @see sap.ui.commons.ListBox#getAllowMultiSelect
         */
        getAllowMultiSelect : function() {
            return this.getAggregation("_listBox").getAllowMultiSelect();
        },

        /**
         * @see jd.ui.eid.ListBox#setEnableMandatorySelection
         */
        setEnableMandatorySelection : function(sValue) {
            this.getAggregation("_listBox").setEnableMandatorySelection(sValue);
            return this;
        },

        /**
         * @see jd.ui.eid.ListBox#getEnableMandatorySelection
         */
        getEnableMandatorySelection : function() {
            return this.getAggregation("_listBox").getEnableMandatorySelection();
        },

        /**
         * @see sap.ui.commons.ListBox#setVisibleItems
         */
        setVisibleItems : function(iValue) {
            this.getAggregation("_listBox").setVisibleItems(iValue);
            return this;
        },

        /**
         * @see sap.ui.commons.ListBox#getVisibleItems
         */
        getVisibleItems : function() {
            return this.getAggregation("_listBox").getVisibleItems();
        },

        /**
         * Sets the booleanKey property.
         * 
         * @param {boolean}
         *            bValue the value.
         * @returns {jd.ui.eid.control.ListBoxFilterItem} this for method chaining.
         */
        setBooleanKey : function(bValue) {
            this.setProperty("booleanKey", bValue);

            if (this.getUseSelectedKey() === true && this.getAllowMultiSelect() === false && this.getEnableBooleanKey()) {
                // If boolean keys are enabled, we convert boolean true to key with string
                // value 1 and false to key with string value 0.
                var sValue = bValue === true ? "1" : "0";
                this.setSelection([sValue]);
            }

            return this;
        },

        /**
         * Sets the selectedKey property.
         * 
         * @param {string}
         *            sValue the value.
         * @returns {jd.ui.eid.control.ListBoxFilterItem} this for method chaining.
         */
        setSelectedKey : function(sValue) {
            this.setProperty("selectedKey", sValue);

            // The property only works if useSelectedKey is set
            // to true and allowMultiSelect is set
            // to false.
            // Then, we can just wrap the single selectedKey
            // into an array and set it to the
            // selection property and let it do the rest.
            if (this.getUseSelectedKey() === true && this.getAllowMultiSelect() === false) {
                this.setSelection([sValue]);
            }

            return this;
        },

        /**
         * Get the selectedKey property.
         * 
         * @returns {string|null}
         */
        getSelectedKey : function() {
            if (this.getUseSelectedKey() === true) {
                return this.getProperty("selectedKey");
            } else {
                return null;
            }
        },

        /**
         * Sets the selection property and updates the internal aggregations.
         * 
         * @param {array}
         *            aValues The array of selected keys.
         * @returns {jd.ui.eid.control.ListBoxFilterItem} this for method chaining.
         */
        setSelection : function(aValues) {
            this.setProperty('selection', aValues);
            this._updateListBoxSelection();
            return this;
        },

        /**
         * @see sap.ui.commons.ListBox#addItem
         */
        addItem : function(oItem) {
            this.getAggregation("_listBox").addItem(oItem);
            this._updateSelectionIndicator();
            this._updateVisibleItems();
            return this;
        },

        /**
         * @see sap.ui.commons.ListBox#destroyItems
         */
        destroyItems : function() {
            this.getAggregation("_listBox").destroyItems();
            this._updateSelectionIndicator();
            this._updateVisibleItems();
        },

        /**
         * @see sap.ui.commons.ListBox#getItems
         */
        getItems : function() {
            return this.getAggregation("_listBox").getItems();
        },

        /**
         * @see sap.ui.commons.ListBox#indexOfItem
         */
        indexOfItem : function(oItem) {
            return this.getAggregation("_listBox").indexOfItem(oItem);
        },

        /**
         * @see sap.ui.commons.ListBox#insertItem
         */
        insertItem : function(oItem, iIndex) {
            this.getAggregation("_listBox").insertItem(oItem, iIndex);
            this._updateSelectionIndicator();
            this._updateVisibleItems();
            return this;
        },

        /**
         * @see sap.ui.commons.ListBox#removeAllItems
         */
        removeAllItems : function() {
            this.getAggregation("_listBox").removeAllItems();
            this._updateSelectionIndicator();
            this._updateVisibleItems();
        },

        /**
         * @see sap.ui.commons.ListBox#removeItem
         */
        removeItem : function(vItem) {
            this.getAggregation("_listBox").removeItem(vItem);
            this._updateSelectionIndicator();
            this._updateVisibleItems();
        },

        /* Control Logic */

        /**
         * Sets the selection property to an empty array.
         */
        _clear : function() {

            if (this.getEnableBooleanKey()) {
                // If it's a boolean key, we have to handle this differently
                // Clear, in that case, should reset the selection to the first item.
                if (this.getAggregation("_listBox").isIndexSelected(0)) {
                    // The first item is already selected, so we don't need to clear anything
                    return false;
                } else {
                    // Well, then probably the second item is selected, so we need to change the selection to the first one.
                    // The first item might be true or false, but it's definitely the opposite of the current value, so let's make this simple:
                    this.setBooleanKey(!this.getBooleanKey());
                    return true;
                }
            } else if (this.getUseSelectedKey()) {
                // If it's a single selected key, we also need to handle it differently (but similar ot booleanKey)
                if (this.getAggregation("_listBox").getSelectedIndices().length == 0) {
                    // Nothing is selected
                    return false;
                } else {
                    this.setSelectedKey("");
                    return true;
                }
            } else {
                var aCurrentSelection = this.getSelection();
                var aEmptySelection = [];
                // If the filter item has enableMandatorySelection property set to true, it should not clear the selection but set it back to the
                // first
                // item.
                // So we simply tweak our emptySelection variable.
                if (this.getEnableMandatorySelection()) {
                    aEmptySelection = [this.getItems()[0].getKey()];
                }

                if (!$.sap.equal(aCurrentSelection, aEmptySelection)) {
                    this.setSelection(aEmptySelection);
                    return true;
                } else {
                    return false;
                }
            }
        },

        /**
         * Resets the selection property to the default keys.
         */
        _reset : function() {
            this.setSelection(this.getDefaultSelection());
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.ListBoxFilterItemRenderer"

    });

})();