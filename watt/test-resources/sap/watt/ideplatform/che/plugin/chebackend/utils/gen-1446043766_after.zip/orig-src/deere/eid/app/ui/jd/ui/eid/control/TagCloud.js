(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TagCloud");
    jd.ui.eid.require("jd.ui.eid.control.Tag");

    /**
     * The TagCloud control provides a cloud of tags, which can be selected.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>enabled : boolean (default: true) If true the tags are clickable otherwise false.</li>
     * <li>maxFontSize : int (default: 25) This property defines the maximal font size.</li>
     * <li>minFontSize : int (default: 10) This property defines the minimal font size.</li>
     * <li>noData : string (default: '') Text to display if no tags are provided.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>tags : jd.ui.eid.control.Tag[] The tags to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.TagCloud
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.TagCloud", /** @lends jd.ui.eid.control.TagCloud */
    {
        metadata : {
            properties : {
                enabled : {
                    type : "boolean",
                    defaultValue : true
                },
                maxFontSize : {
                    type : "int",
                    defaultValue : 18
                },
                minFontSize : {
                    type : "int",
                    defaultValue : 12
                },
                noData : {
                    type : "string",
                    defaultValue : ''
                }
            },

            aggregations : {
                tags : {
                    type : "jd.ui.eid.control.Tag",
                    multiple : true,
                    singularName : "tag"
                },
            },

            events : {
                select : {}
            },
        },

        /**
         * Called when the tagCloud was clicked
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            var oTarget = $(oEvent.target);

            if (oTarget.hasClass('jdUiEidTag')) {
                var selectedTagIndex = oTarget.data("jdUiEidTagid");
                var oTag = this.getAggregation("tags")[selectedTagIndex];
                this.fireSelect({
                    id : oTag.getId(),
                    tag : {
                        "Tag" : oTag.getText(),
                        "Score" : oTag.getWeight()
                    }
                });
            }
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.TagCloudRenderer"
    });

})();