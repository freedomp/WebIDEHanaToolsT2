(function() {
    "use strict";

    // Declare
    jQuery.sap.declare("jd.ui.eid.control.TableActionCell");

    /**
     * "TableActionCell" custom control
     * 
     * This control is meant to be used as template for cells of sap.ui.table.Table that need to show a set of buttons when the corresponding row is
     * hovered on.
     * 
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>actions : [sap.ui.commons.Image] An array of images to be rendered as actions in each TableActionCell</li>
     * <li>content : sap.ui.core.Control The control to be rendered in the content area of the cell.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @name jd.ui.eid.control.TableActionCell
     * @extends sap.ui.core.Control
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.TableActionCell", {
        metadata : {
            // The 'actionButtons' aggregation is for the buttons that need to be rendered in each
            // cell
            aggregations : {
                "actions" : {
                    singularName : "action",
                    type : "sap.ui.core.Control",
                    multiple : true
                },
                "content" : {
                    type : "sap.ui.core.Control",
                    multiple : false
                },
                "icon" : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            }
        },

        // Renderer for this control
        renderer : function(oRm, oControl) {
            // Start container DIV
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addClass("jdUiEidTableActionCell");
            oRm.writeClasses();
            oRm.write(">");

            // Render the icon
            var oIcon = oControl.getAggregation("icon");
            if (oIcon) {
                oRm.write("<div");
                oRm.addClass("jdUiEidTableActionCellIcon");
                oRm.writeClasses();
                oRm.write(">");
                oRm.renderControl(oIcon);
                oRm.write("</div>");
            }

            // Render the actions
            var aActions = oControl.getAggregation("actions");
            if (aActions) {
                oRm.write("<div");
                oRm.addClass("jdUiEidTableActionCellButtonGroup");
                oRm.writeClasses();
                oRm.write(">");
                $.each(aActions, function(i, oAction) {
                    oRm.write("<div");
                    oRm.addClass("jdUiEidTableActionCellButton");
                    oRm.writeClasses();
                    oRm.write(">");

                    // Render action button
                    oRm.renderControl(oAction);
                    oRm.write("</div>");
                });
                oRm.write("</div>");
            }

            // If a control was provided for 'content', then render it
            if (oControl.getAggregation("content")) {
                oRm.write("<div");
                oRm.addClass("jdUiEidTableActionCellContent");
                oRm.writeClasses();
                oRm.write(">");

                // Render content (if any)
                oRm.renderControl(oControl.getAggregation("content"));
                oRm.write("</div>");
            }

            // End container DIV
            oRm.write("</div>");
        }

    });
})();