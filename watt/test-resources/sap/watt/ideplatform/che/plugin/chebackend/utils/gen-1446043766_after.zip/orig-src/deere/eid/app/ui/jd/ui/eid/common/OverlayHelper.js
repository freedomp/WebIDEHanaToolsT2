(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.OverlayHelper");
    jd.ui.eid.require("jd.ui.eid.control.GripperWrapper");

    // Private variables
    var _oOverlayViewContainerDTACCaseDetails = null;
    var _oOverlayViewContainerDTCDetails = null;
    var _oOverlayViewContainerDTCDetailsDashboard = null;
    var _oOverlayViewContainerEvidencePackageDetails = null;
    var _oOverlayViewContainerWarrantyClaimPrimePart = null;
    var _oOverlayViewContainerWarrantyClaimDetails = null;
    var _oOverlayViewContainerWorksheet = null;
    var _sOverlayIdDTACCaseDetails = 'OverlayDTACCaseDetails';
    var _sOverlayIdDTCDetails = 'OverlayDTCDetails';
    var _sOverlayIdDTCDetailsDashboard = 'OverlayDTCDetailsDashboard';
    var _sOverlayIdEvidencePackageDetails = 'OverlayEvidencePackageDetails';
    var _sOverlayIdWarrantyClaimPrimePart = 'OverlayWarrantyClaimPrimePart';
    var _sOverlayIdWarrantyClaimDetails = 'OverlayWarrantyClaimDetails';
    var _sOverlayIdWorksheet = 'OverlayWorksheet';

    /**
     * @class This helper class provides access to all overlays in the application.
     * @static
     * @name jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper = {};

    /**
     * Returns instance of DTC Detail Overlay for Dashboard Mode including view. This method also does the magic to display the
     * {@link jd.ui.eid.control.GripperWrapper gripper} at the top of the DTC details view on the dashboard. When the content of the overlay is first
     * created, the GripperWrapper is placed between the CloseIconWrapper and the actual {@link jd.ui.eid.view.main.shared.DTCDetails content}. If
     * the gripper first the <code>gripped</code> event, a CSS class is toggled on the overlay to change the padding from the top of the window
     * (i.e. screen), so that the overlay appears expanded/collapsed. If the the overlay is closed, we remove the CSS class on the overlay and reset
     * the gripper so that when the overlay is opened the next time, it appears collapsed again. As
     * {@link jd.ui.eid.common.OverlayViewContainer#setContext} doesn't assume another control hierarchy between overlay and the view and since it
     * tires to call <code>getController</code> on the gripper, we also add a fake method to the gripper object (not prototype) and reroute the call
     * to the actual view.
     * 
     * @returns {jd.ui.eid.common.OverlayViewContainer} the Overlay Container reference for the Dashboard Mode
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayDashboard = function() {
        if (!_oOverlayViewContainerDTCDetailsDashboard) {
            _oOverlayViewContainerDTCDetailsDashboard = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdDTCDetailsDashboard,
                    "jd.ui.eid.view.main.shared.DTCDetails", "DTCDetailsViewDashboard", "DTCDetailsOverlayDashboard", {
                        sCssClasses : "jdUiEidDTCDetailsOverlayDashboard",
                        fnOverlayCreationCallback : function(oOverlay) {
                            // Reset overlay so that when it opens the next time, it appears small again.
                            sap.ui.getCore().getEventBus().subscribe("DTCDetailsOverlayDashboard", "closed", function() {
                                oOverlay.removeStyleClass("jdUiEidOverlayMaximized");
                                oOverlay.getContent()[0].getContent()[0].setCollapsed(true);
                            });
                        },
                        fnContentCreationCallback : function(oCloseIconWrapper, oView) {
                            // Hook the gripper in the control hierarchy.
                            oCloseIconWrapper.removeAllContent();
                            var oGripperWrapper = new jd.ui.eid.control.GripperWrapper({
                                collapseTooltip : "{i18n>GRIPPER_TOL_MINIMIZE}",
                                expandTooltip : "{i18n>GRIPPER_TOL_MAXIMIZE}",
                                content : oView,
                                gripped : function() {
                                    oCloseIconWrapper.getParent().toggleStyleClass("jdUiEidOverlayMaximized");
                                }
                            });
                            // Add a fake method to the gripper to reroute access to the controller of the view.
                            /**
                             * @ignore
                             */
                            var fnGetController = function() {
                                return oGripperWrapper.getContent()[0].getController();
                            };
                            oGripperWrapper.getController = fnGetController;
                            oCloseIconWrapper.addContent(oGripperWrapper);
                            oView.getController().setMode(jd.ui.eid.view.main.shared.DTCDetails.Mode.Dashboard);
                        }
                    });
        }
        return _oOverlayViewContainerDTCDetailsDashboard;
    };

    /**
     * Returns instance of DTC Detail Overlay for Regular Mode including view.
     * 
     * @returns {jd.ui.eid.common.OverlayViewContainer} the Overlay Container reference for the Regular Mode
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayRegular = function() {
        if (!_oOverlayViewContainerDTCDetails) {
            _oOverlayViewContainerDTCDetails = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdDTCDetails,
                    "jd.ui.eid.view.main.shared.DTCDetails", "DTCDetailsView", "DTCDetailsOverlay", {
                        sCssClasses : "jdUiEidUx3OCLevel2",
                        fnContentCreationCallback : function(oCloseIconWrapper, oView) {
                            oView.getController().setMode(jd.ui.eid.view.main.shared.DTCDetails.Mode.Regular);
                        }
                    });
        }
        return _oOverlayViewContainerDTCDetails;
    };

    /**
     * Returns an instance of DTAC Case Detail Overlay including view.
     * 
     * @returns {jd.ui.eid.common.OverlayViewContainer} the Overlay Container reference
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getDTACCaseDetailsOverlay = function() {
        if (!_oOverlayViewContainerDTACCaseDetails) {
            _oOverlayViewContainerDTACCaseDetails = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdDTACCaseDetails,
                    "jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails", "DTACCaseDetailsView", "DTACCaseDetailsOverlay", {
                        sCssClasses : "jdUiEidUx3OCLevel2"
                    });
        }
        return _oOverlayViewContainerDTACCaseDetails;
    };

    /**
     * Returns instance of Warranty Claim Overlay including including the Warranty Claim by Prime Part List view.
     * 
     * @returns {jd.ui.eid.common.OverlayViewContainer} the Overlay Container reference
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getWarrantyClaimPrimePartOverlay = function() {
        if (!_oOverlayViewContainerWarrantyClaimPrimePart) {
            _oOverlayViewContainerWarrantyClaimPrimePart = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdWarrantyClaimPrimePart,
                    "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart", "WarrantyClaimPrimePartView", "WarrantyClaimPrimePartOverlay", {
                        sCssClasses : "jdUiEidUx3OCLevel2"
                    });
        }
        return _oOverlayViewContainerWarrantyClaimPrimePart;
    };

    /**
     * Returns an instance of Warranty Claim Details Overlay including the Warranty Claim Details view.
     * 
     * @returns {jd.ui.eid.common.OverlayViewContainer} the Overlay Container reference
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getWarrantyClaimDetailsOverlay = function() {
        if (!_oOverlayViewContainerWarrantyClaimDetails) {
            _oOverlayViewContainerWarrantyClaimDetails = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdWarrantyClaimDetails,
                    "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails", "WarrantyClaimDetailsView", "WarrantyClaimDetailsOverlay", {
                        sCssClasses : "jdUiEidUx3OCLevel2"
                    });
        }
        return _oOverlayViewContainerWarrantyClaimDetails;
    };

    /**
     * Returns instance of Work sheet Overlay including view.
     * 
     * @returns {sap.ui.ux3.OverlayContainer} the Overlay Container reference
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getWorksheetOverlay = function() {
        if (!_oOverlayViewContainerWorksheet) {
            _oOverlayViewContainerWorksheet = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdWorksheet, "jd.ui.eid.view.main.Worksheet",
                    "WorksheetView", "WorksheetOverlay", {
                        bDefaultCloseBehavior : false,
                        fnContentCreationCallback : function(oCloseIconWrapper, oView) {
                            oCloseIconWrapper.attachCloseClicked(function() {
                                oView.getController().onCancel();
                            });
                        }
                    });
        }
        return _oOverlayViewContainerWorksheet;
    };

    /**
     * Returns the instance of Evidence Details Overly including view.
     * 
     * @returns {sap.ui.ux3.OverlayContainer} the Overlay Container reference
     * @memberOf jd.ui.eid.common.OverlayHelper
     */
    jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay = function() {
        // _oOverlayViewContainerEvidencePackageDetails
        if (!_oOverlayViewContainerEvidencePackageDetails) {
            var oEventBus = sap.ui.getCore().getEventBus();
            var fnClosedCallback = function() {
                _oOverlayViewContainerEvidencePackageDetails.destroy();
                oEventBus.unsubscribe("EvidencePackageOverlay", "closed", fnClosedCallback);
            }
            _oOverlayViewContainerEvidencePackageDetails = new jd.ui.eid.common.OverlayViewContainer(_sOverlayIdEvidencePackageDetails,
                    "jd.ui.eid.view.main.EvidencePackage", "EvidencePackageView", "EvidencePackageOverlay", {
                        bDefaultCloseBehavior : false,
                        fnOverlayCreationCallback : function(oOverlay) {
                            oOverlay.attachOpen(function() {
                                if (jd.ui.eid.common.OverlayHelper.getWorksheetOverlay().isOpen() && oOverlay.data("forceLevel1") !== true) {
                                    oOverlay.addStyleClass("jdUiEidUx3OCLevel2");
                                } else {
                                    oOverlay.data("forceLevel1", false);
                                    oOverlay.removeStyleClass("jdUiEidUx3OCLevel2");
                                }

                                sap.ui.getCore().getEventBus().publish("Navigation", "navigating", {
                                    origin : "", // we simply don't know, but it is not important anyway
                                    target : 'jd.ui.eid.view.main.EvidencePackage'
                                });
                            });
                        },
                        fnContentCreationCallback : function(oCloseIconWrapper, oView) {
                            oEventBus.subscribe("EvidencePackageOverlay", "closed", fnClosedCallback);
                            oCloseIconWrapper.attachCloseClicked(function() {
                                oView.getController().onCancel();
                            });
                        }
                    });
        }
        return _oOverlayViewContainerEvidencePackageDetails;
    };

    /**
     * Constructor of a new OverlayViewContainer.
     * 
     * @param {string}
     *            sOverlayId the id which will be assigned to the overlay container.
     * @param {string}
     *            sViewName the name of the xml view which should be displayed as content.
     * @param {string}
     *            sViewEventBusChannel the name of the channel used for the view.
     * @param {string}
     *            sOverlayEventBusChannel the name of the channel used for the overlay.
     * @param {object}
     *            [mParameters] parameter map
     * @param {boolean}
     *            [mParameters.bDefaultCloseBehavior=true] true if the overlay should be closed by the CloseIconWrapper directly, false otherwise
     *            (e.g. custom logic for closing the overlay).
     * @param {function}
     *            [mParameters.fnOverlayCreationCallback] a callback function invoked upon creation of the overlay. It receives
     *            <code>sap.ui.ux3.OverlayContainer</code> as parameters.
     * @param {function}
     *            [mParameters.fnContentCreationCallback] a callback function invoked upon creation of the overlay. It receives
     *            <code>jd.ui.eid.control.CloseIconWrapper</code> and <code>sap.ui.core.View</code> as parameters.
     * @param {string}
     *            [mParameters.sCssClasses] a string containing css class names that should be assigned to the overlay.
     * 
     * @class
     * <p>
     * The class serves as a container for an overlay with a view inside. The controls are not created unless really required.
     * </p>
     * <p>
     * Once the overlay is created, a callback is registered on the <code>close</code> event of the <code>sViewEventBusChannel</code>. This event
     * should be fired when e.g. handling the 'Close' button of the view inside the overlay. The callback calls the {@link #.close} method, which in
     * turn fires the <code>closed</code> event of the <code>sOverlayEventBusChannel</code>, which e.g. the opening controller should listen to
     * trigger any actions on the opening view.
     * </p>
     * <p>
     * The {@link #.setContext} method directly passes all parameters to the <code>setContext</code> method of the <code>sViewName</code>'s
     * controller.
     * </p>
     * @name jd.ui.eid.common.OverlayViewContainer
     * @extends sap.ui.base.Object
     */
    sap.ui.base.Object.extend("jd.ui.eid.common.OverlayViewContainer", /** @lends jd.ui.eid.common.OverlayViewContainer */
    {

        _mParameters : null,
        _oOverlay : null,
        _sOverlayEventBusChannel : null,
        _sOverlayId : null,
        _sViewEventBusChannel : null,
        _sViewName : null,

        /**
         * @constructor
         */
        constructor : function(sOverlayId, sViewName, sViewEventBusChannel, sOverlayEventBusChannel, mParameters) {
            // Init default values
            if (!mParameters) {
                mParameters = {};
            }
            if (mParameters.bDefaultCloseBehavior === undefined) {
                mParameters.bDefaultCloseBehavior = true;
            }

            this._mParameters = mParameters;
            this._sOverlayEventBusChannel = sOverlayEventBusChannel;
            this._sOverlayId = sOverlayId;
            this._sViewEventBusChannel = sViewEventBusChannel;
            this._sViewName = sViewName;
        },

        /**
         * Cleans up the wrapper.
         */
        destroy : function() {
            if (this._oOverlay) {
                this._oOverlay.destroy();
                this._oOverlay = null;
            }
        },

        /**
         * Opens the overlay.
         */
        open : function() {
            this._getOverlay().open();
        },

        /**
         * Checks whether the overlay is open.
         * 
         * @returns {boolean} true if the overlay is open, false otherwise.
         */
        isOpen : function() {
            if (!this._oOverlay) {
                return false;
            } else {
                return this._oOverlay.isOpen();
            }
        },

        /**
         * Closes the overlay and fires the <code>closed</code> event on the <code>sOverlayEventBusChannel</code> unless suppressed.
         * 
         * @param {boolean}
         *            bSuppressEvent true to suppress the event, false otherwise.
         */
        close : function(bSuppressEvent) {
            if (this._oOverlay) {
                this._getOverlay().close();
                if (!bSuppressEvent) {
                    sap.ui.getCore().getEventBus().publish(this._sOverlayEventBusChannel, 'closed');
                }
            }
        },

        /**
         * Sets the context by calling <code>setContext</code> on the <code>sViewName</code>'s controller.
         */
        setContext : function() {
            var oController = this._getOverlay().getContent()[0].getContent()[0].getController();
            oController.setContext.apply(oController, arguments);
        },

        /**
         * @see sap.ui.core.Element#data
         */
        data : function() {
            var oOverlay = this._getOverlay();
            return oOverlay.data.apply(oOverlay, arguments);
        },

        /**
         * Getter for the overlay. If the overlay will first be created if not existent yet.
         * 
         * @returns {sap.ui.ux3.OverlayContainer} the overlay container control.
         */
        _getOverlay : function() {
            if (!this._oOverlay) {
                var that = this;
                this._oOverlay = new sap.ui.ux3.OverlayContainer(this._sOverlayId, {
                    // content : oCloseIconWrapper,
                    closeButtonVisible : false,
                    openButtonVisible : false
                }).addStyleClass("jdUiUx3OC");

                // Invoke optional parameters for overlay
                if (this._mParameters.sCssClasses) {
                    this._oOverlay.addStyleClass(this._mParameters.sCssClasses);
                }
                if (this._mParameters.fnOverlayCreationCallback) {
                    this._mParameters.fnOverlayCreationCallback(this._oOverlay);
                }

                // Create overlay content
                var oView = new jd.ui.eid.xmlview(this._sViewName);
                var oCloseIconWrapper = new jd.ui.eid.control.CloseIconWrapper({
                    content : oView
                });
                this._oOverlay.addContent(oCloseIconWrapper);

                // Invoke optional parameters for overlay content
                if (this._mParameters.bDefaultCloseBehavior === true) {
                    oCloseIconWrapper.attachCloseClicked(function() {
                        // The default close handler simply closes the overlay and fires the close event afterwards. Semantically, the close event is
                        // more like a closed(!) event which is/should be fired if the overlay has been closed. However, the events doesn't seem to be
                        // fired by the close method itself.
                        that.close();
                    });
                }
                if (this._mParameters.fnContentCreationCallback) {
                    this._mParameters.fnContentCreationCallback(oCloseIconWrapper, oView);
                }

                // Subscribe to event bus
                sap.ui.getCore().getEventBus().subscribe(this._sViewEventBusChannel, 'close', function() {
                    that.close();
                });
            }
            return this._oOverlay;
        }
    });

})();