(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.EidBasket");

    /**
     * The EidBasket control provides a "count" and a "name" property to display a Basket item. The
     * basket can be mouse clicked by the user.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>name : string (default: '') The name of the process step in the left header area.</li>
     * <li>count : int (default: 0) The title of the evidence package, displayed in the center of
     * the header </li>
     * </li>
     * <li>Events
     * <ul>
     * <li>press : jQuery.Event The Event when the user presses the control </li>
     * </ul>
     * 
     * @class
     * @name jd.ui.eid.control.EidBasket
     * @extends sap.ui.core.Control
     */

    sap.ui.core.Control.extend("jd.ui.eid.control.EidBasket", /** @lends jd.ui.eid.control.EidBasket */
    {
        metadata : {
            properties : {
                name : {
                    type : "string",
                    defaultValue : ""
                },
                count : {
                    type : "string",
                    defaultValue : 0
                }
            },
            events : {
                "press" : {}
            }
        },

        /**
         * Fire Event if control is clicked by user
         * 
         * @param oEvent
         *            {jQuery.Event}
         */
        // 
        onclick : function(oEvent) {
            this.firePress();
        },

        /**
         * Renders control
         * 
         * @param {sap.ui.core.RenderManager}
         *            oRenderManager the RenderManager that can be used for writing to the
         *            Render-Output-Buffer
         * @param {sap.ui.core.Control}
         *            oCmb an object representation of the control that should be rendered
         */
        renderer : function(oRm, oControl) {

            oRm.write("<div");
            oRm.writeControlData(oControl);
            // set tooltip
            if (oControl.getTooltip_AsString()) {
                oRm.writeAttributeEscaped("title", oControl.getTooltip_AsString());
            }

            oRm.addClass("jdUiEidBasketTile");
            oRm.writeClasses();
            oRm.write(">");

            // Render the figure
            oRm.write("<div");
            oRm.addClass("jdUiEidBasketFigure");
            oRm.writeClasses();
            oRm.write(">");
            oRm.write(oControl.getCount());
            oRm.write("</div>");

            // Render the text
            oRm.write("<div");
            oRm.addClass("jdUiEidBasketText");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getName());
            oRm.write("</div>");

            oRm.write("</div>");
        }
    });
})();