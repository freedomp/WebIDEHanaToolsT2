(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTACCaseFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WorkSheetFormatter");

    /**
     * The controller for the DTACCaseDetails view
     * 
     * @class
     * <p>
     * The DTAC case detail view provides the functionality to display details of a DTAC case. It consists of a header area and a long text area.
     * Moreover the screen provides the functionality to add a DTAC case to an evidence package.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers
     * and set the required bindings.</li>
     * <li>{@link #.onExit} is called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.setDTACCaseID} is called while opening the view from the DTAC case list. It sets the selected DTAC case number and triggers a new
     * service call.</li>
     * <li>{@link #.fetchDTACCaseDetails} is called to trigger a new call to the service GetDTACCaseDetails.</li>>
     * <li>{@link #.isAlreadyInEvidencePackage} is called after receiving the data from the backend service. It enables/disables the add to evidence
     * package button by checking if the WarrantyClaim is already in the package. </li>
     * <li>{@link #.onActionSelected} is called while adding one Warranty Claim to the Evidence Package or closing the view.</li>
     * <li>{@link #.onBeforeRendering} is called after the view was loaded due fetch the data and to call isAlreadyInEvidencePackage. </li>
     * <ul>
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#DTACCaseDetailsView::close} : Notifies the overlay to close the view</li>
     * </ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails", jQuery.extend(true, {}, jd.ui.eid.view.BaseController, /** @lends jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails */
    {
        _iDTACCaseID : null,
        _oAddToPackageButton : null,
        _oDTACCaseService : null,
        _oView : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiEidViewWorksheetEvidenceDTACCaseDetails");
            this._oAddToPackageButton = this.byId("AddToPackage");

            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

            // bind context of the complete view to DTACCaseDetails
            this._oView.bindElement("/DTACCaseDetails");

            // Get references the instance of DTACCaseServiceFacade
            this._oDTACCaseService = this.getServiceFacade("DTACCase");
            this._oDTACCaseService.attachRequestFailed(this._onRequestFailed);

            // Set the dealer quickview binding
            var sDealerQuickViewId = this._oView.createId("DealerQuickView");
            var oDealerQuickView = sap.ui.core.Fragment.byId(sDealerQuickViewId, "DealerQuickView");
            oDealerQuickView.bindElement("/DTACCaseDetails");

            // Set the pin/machine quickview binding
            var sMachineQuickViewId = this._oView.createId("MachineQuickView");
            var oMachineQuickView = sap.ui.core.Fragment.byId(sMachineQuickViewId, "MachineQuickView");
            oMachineQuickView.bindElement("/DTACCaseDetails");

            // Set the FilterArea binding
            sap.ui.core.Fragment.byId(this.createId("DTACCaseFilters"), "FilterArea").bindElement("/DTACCaseFilters/FilterSelection");
        },

        /**
         * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered (NOT before the first rendering! onInit()
         * is used for that one!).
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
         */
        onBeforeRendering : function() {
            // Check if the DTAC Case has already been assigned to the Evidence Package
            var bFound = this.isAlreadyInEvidencePackage();
            // Disable the addToPackage button if the DTAC Case is already in the package
            this._oAddToPackageButton.setEnabled(!bFound);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
         */
        onExit : function() {
            // Unsubcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);

            // Unregister from events
            this._oDTACCaseService.detachRequestFailed(this._onRequestFailed);

            // Set properties to null
            this._oAddToPackageButton = null;
            this._oDTACCaseService = null;
            this._oView = null;
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for DTAC Case Details is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimList
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTACCaseDetails") {
                this._oView.getContent()[0].setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for DTAC Case Details has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimList
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTACCaseDetails") {
                this._oView.getContent()[0].setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Set the DTAC Case ID
         * 
         * @param {integer}
         *            iDTACCaseID the selected DTAC Case
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails
         */
        setContext : function(iDTACCaseID) {
            this._iDTACCaseID = iDTACCaseID;

            // Fetch the DTAC Case Details
            this.fetchDTACCaseDetails();
        },

        /**
         * Triggers a service call to get the DTAC Cases Details and update the model.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails
         */
        fetchDTACCaseDetails : function() {
            // Reset the old values
            var oModel = sap.ui.getCore().getModel();
            oModel.setProperty("/DTACCaseDetails", []);

            // Make the service call
            this._oDTACCaseService.getDTACCaseDetails(this._iDTACCaseID, null, this._onRequestFailed);
        },

        /**
         * Check whether the DTAC case is part of the evidence package
         * 
         * @returns {boolean} true if the DTAC Case was found else false
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseDetails
         */
        isAlreadyInEvidencePackage : function() {
            var oData = this._oView.getModel().getData();
            for ( var i = 0; i < oData.EvidencePackageDetails.Header.DTACCaseList.length; i++) {
                var iDTACCaseNumber = oData.EvidencePackageDetails.Header.DTACCaseList[i].DTACCaseNumber;
                if (iDTACCaseNumber == this._iDTACCaseID) {
                    return true;
                }
            };

            return false;
        },

        /**
         * Handles the 'Add to Evidence Package' button, adds the DTAC case to the package and closes the view.
         */
        handleAddToEvidencePackage : function() {
            var oData = this._oView.getModel().getData();

            // Add the DTAC Case to the evidence package
            var mDTACCase = oData.DTACCaseDetails;
            var mDTACCaseFilterSelection = oData.DTACCaseFilters.FilterSelection;
            var mDTACCaseFilterState = oData.DTACCaseFilters.FilterState;

            // Add DTAC Case to the evidence package
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTACCase(mDTACCase, mDTACCaseFilterSelection, mDTACCaseFilterState);

            // Close view by event call
            sap.ui.getCore().getEventBus().publish('DTACCaseDetailsView', 'close');
        },

        /**
         * Closes the view.
         */
        handleClose : function() {
            // Close view by event call
            sap.ui.getCore().getEventBus().publish('DTACCaseDetailsView', 'close');
        }
    }));

})();