(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.EvidencePackageFormatter");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EvidencePackageSaveController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EvidencePackageSummaryOverlayController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.WorksheetOverlayController");

    /**
     * The Evidence Package Details provides a Thing Viewer to display the details of Evidence Package
     * 
     * @class
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.EvidencePackage.EvidencePackageSummary
     */
    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.EvidencePackageSaveController, jd.ui.eid.view.main.shared.WorksheetOverlayController,
            jd.ui.eid.view.main.shared.EvidencePackageSummaryOverlayController,
            /** @lends jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary */
            {

                _oEPChartFacetContent : null,
                _oEPDTACFacetContent : null,
                _oEPDTCSFacetContent : null,
                _oEPMachineOptionCodeFacetContent : null,
                _oEPPINPopulationFacetContent : null,
                _oEPWarrantyClaimFacetContent : null,
                _oPrintFilterDialog : null,
                _oPrintPreviewDialog : null,
                _oView : null,
                _sEventBusPrintChannelId : "PrintEvidencePackage",
                _sEvidencePackageID : null,

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 * 
                 * @memberOf jd.ui.eid.view.main.EvidencePackage
                 */
                onInit : function() {
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewEvidencePackage");

                    // Config
                    this.mEvidencePackageSaveControllerConfig.aBusyControls = [this._oView.getContent()[0]];

                    // Subcribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
                    oEventBus.subscribe('Navigation', 'navigating', this.handleNavigation, this);
                    oEventBus.subscribe(this._sEventBusPrintChannelId, "requestInput", this.handlePrintApplicationRequestInput, this);
                    oEventBus.subscribe(this._sEventBusPrintChannelId, "ready", this.handlePrintApplicationReady, this);

                    // Initialize merge controllers
                    this.initEvidencePackageSummaryOverlayController();
                    this.initEvidencePackageSaveController();
                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 * 
                 * @memberOf jd.ui.eid.view.main.EvidencePackage
                 */
                onAfterRendering : function() {
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 * 
                 * @memberOf jd.ui.eid.view.main.EvidencePackage
                 */
                onExit : function() {
                    // Unsubcribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
                    oEventBus.unsubscribe(this._sEventBusPrintChannelId, "requestInput", this.handlePrintApplicationRequestInput, this);
                    oEventBus.unsubscribe(this._sEventBusPrintChannelId, "ready", this.handlePrintApplicationReady, this);

                    // Destroy merge controllers
                    this.exitEvidencePackageSaveController();

                    $.each([this._oEPChartFacetContent, this._oEPDTACFacetContent, this._oEPDTCSFacetContent, this._oEPMachineOptionCodeFacetContent,
                            this._oEPPINPopulationFacetContent, this._oEPWarrantyClaimFacetContent, this._oPrintFilterDialog,
                            this._oPrintPreviewDialog], function(iIdx, oManagedObject) {
                        if (oManagedObject) {
                            oManagedObject.destroy();
                        }
                    });
                },

                /**
                 * Called when user selects a Navigation Item
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event.
                 * 
                 * @memberOf jd.ui.eid.view.main.EvidencePackage
                 */
                onFacetSelected : function(oEvent) {
                    this._showFacet(oEvent.getParameter("key"));
                },

                /**
                 * Set the Evidence Package ID
                 * 
                 * @param{string} sEvidencePackageID the Evidence Package ID
                 * @memberOf jd.ui.eid.view.main.EvidencePackage
                 */
                setEvidencePackageID : function(sEvidencePackageID) {
                    this._sEvidencePackageID = sEvidencePackageID;
                },

                /**
                 * Handles the navigating event.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired
                 */
                handleNavigation : function(sChannelId, sEventId, oData) {

                    if (oData.target == 'jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary') {

                        var oModel = sap.ui.getCore().getModel();

                        var sCurrentEvidencePackageId = oModel.getProperty("/EvidencePackageDetails/Header/PackageID");

                        if ((this._sEvidencePackageID === sCurrentEvidencePackageId) || (this._sEvidencePackageID === null)) {
                            // New package
                            // Either we have already the current loaded evidence package in the memory or
                            // we have a new, never saved, evidence package in the memory.
                            // In both cases we just have to load the summary details from db
                            this._enableActions();
                            this._showFacet("SUMMARY");
                            this.loadEvidencePackageSummary();
                        } else {
                            this.loadEvidencePackageDetailsHeader(this._sEvidencePackageID);
                        }
                        // Notify all summary views that the evidence package context changed
                        sap.ui.getCore().getEventBus().publish('EvidencePackageView', 'contextChanged');
                    }
                },

                /**
                 * enable thing actions depending if user owns the package or not
                 * 
                 */
                _enableActions : function() {
                    var oActionBar = this.getView().byId('ActionBar');

                    // clean up first
                    oActionBar.removeAllBusinessActions();

                    // get the references
                    var oSaveSendLink = this.getView().byId('SaveSendLink');
                    var oSave = this.getView().byId('Save');
                    var oPrint = this.getView().byId('Print');
                    var oEdit = this.getView().byId('Edit');
                    var oSetClosed = this.getView().byId('SetClosed');
                    var oCancel = this.getView().byId('Cancel');

                    if (jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.IsPackageOwnedByCurrentUser()) {
                        // Write Mode
                        oActionBar.addBusinessAction(oSaveSendLink);
                        oActionBar.addBusinessAction(oSave);
                        oActionBar.addBusinessAction(oPrint);
                        oActionBar.addBusinessAction(oEdit);
                        oActionBar.addBusinessAction(oSetClosed);
                        oActionBar.addBusinessAction(oCancel);
                    } else {
                        // Read Mode
                        oActionBar.addBusinessAction(oPrint);
                        oActionBar.addBusinessAction(oCancel);
                    }
                },

                /**
                 * load the header data of the evidence package
                 * 
                 * @param {string}
                 *            sEvidencePackageID evidence package id
                 */
                loadEvidencePackageDetailsHeader : function(sEvidencePackageID) {
                    var that = this;
                    var oModel = sap.ui.getCore().getModel();
                    this.getView().getContent()[0].setBusy(true);
                    this.getServiceFacade("EvidencePackage").getEvidencePackageDetails(sEvidencePackageID,
                    // success
                    function() {
                        that._enableActions();
                        that._showFacet("SUMMARY");
                        that.loadEvidencePackageSummary();
                    },
                    // failed
                    function() {
                        that.getView().getContent()[0].setBusy(false);
                        oModel.setProperty("/EvidencePackageDetails/Header", {});
                        that._onRequestFailed.apply(that, arguments);
                    });
                },

                /**
                 * load the details of the selected Evidence Package
                 * 
                 * @param {string }
                 *            sEvidencePackageID the ID of evidence package
                 */
                loadEvidencePackageSummary : function() {
                    var that = this;
                    var oModel = sap.ui.getCore().getModel();
                    var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");

                    this.getView().getContent()[0].setBusy(true);
                    this.getServiceFacade("EvidencePackage").getEvidencePackageSummary(oEvidencePackageDetailsHeader, function() {
                        that.getView().getContent()[0].setBusy(false);
                    },
                    // failed
                    function() {
                        that.getView().getContent()[0].setBusy(false);
                        oModel.setProperty("/EvidencePackageDetails/Summary", {});
                        that._onRequestFailed.apply(that, arguments);
                    });
                },

                /**
                 * load the evidence package analysis data
                 * 
                 * @param{string} sEvidencePackageID evidence package id
                 */
                loadEvidencePackageAnalysisData : function(sEvidencePackageID) {
                    var that = this;
                    this.getView().setBusy(true);
                    var oModel = sap.ui.getCore().getModel();
                    var oDTCFilterSelection = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterSelection");
                    var aDTCIDList = oModel.getPropery("/EvidencePackageDetails/Header/DTCCodeList");
                    var aDTACCaseList = oModel.getProperty("/EvidencePackageDetails/Header/DTACCaseList");
                    var aWarrantyClaimList = oModel.getProperty("/EvidencePackageDetails/Header/WarrantyClaimList");

                    this.getServiceFacade("EvidencePackage").getEvidenceAnalysisData(sEvidencePackageID, oDTCFilterSelection, aDTCIDList,
                            aDTACCaseList, aWarrantyClaimList,
                            // success
                            function() {
                                that.getView().setBusy(false);
                            }, function() {
                                that.getView().setBusy(false);
                                oModel.setProperty("/EvidencePackageSummary/AnalysisData", {});
                                that._onRequestFailed.apply(that, arguments);
                            });
                },

                /**
                 * Show facet content for selected Navigation Item
                 * 
                 * @param {string}
                 *            sKey the key of the selected navigation item
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                _showFacet : function(sKey) {
                    var oThingViewer = this.byId("ThingViewer");
                    oThingViewer.removeAllFacetContent();

                    // Set Selected Facet in case of a clicked link
                    oThingViewer.setSelectedFacet(this.byId(sKey));

                    switch (sKey) {
                        case "SUMMARY" :
                            if (this._oEPChartFacetContent == null) {
                                this._oEPChartFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.EvidencePackageSummaryChart")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPChartFacetContent);
                            break;

                        case "DTACS" :
                            if (this._oEPDTACFacetContent == null) {
                                this._oEPDTACFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.DTACCaseSummary")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPDTACFacetContent);
                            break;

                        case "WARRANTY_CLAIMS" :
                            if (this._oEPWarrantyClaimFacetContent == null) {
                                this._oEPWarrantyClaimFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPWarrantyClaimFacetContent);
                            break;

                        case "DTCS" :
                            if (this._oEPDTCSFacetContent == null) {
                                this._oEPDTCSFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.EvidencePackageDTCs")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPDTCSFacetContent);
                            break;

                        case "MACHINE_OPTION_CODE" :

                            if (this._oEPMachineOptionCodeFacetContent == null) {
                                this._oEPMachineOptionCodeFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.MachineOptionSummary")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPMachineOptionCodeFacetContent);
                            break;

                        case "POPULATION" :
                            if (this._oEPPINPopulationFacetContent == null) {
                                this._oEPPINPopulationFacetContent = new sap.ui.ux3.ThingGroup({
                                    colspan : true,
                                    content : new sap.ui.xmlview("jd.ui.eid.view.main.evidencepackage.PINPopulationSummary")
                                });
                            }
                            oThingViewer.addFacetContent(this._oEPPINPopulationFacetContent);
                            break;
                    }
                },

                /**
                 * handle the action triggered by action buttons from Evidece Package Thing viewer
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                onActionSelected : function(oEvent) {
                    var sSourceId = oEvent.getParameter("id");
                    switch (sSourceId) {
                        case this.byId("Print").getId() :
                            this.openPrintFilterDialog();
                            break;
                        case this.byId("SaveSendLink").getId() :
                            this.saveAndSendLink();
                            break;
                        case this.byId("Save").getId() :
                            this.onSaveSelected();
                            break;
                        case this.byId("Cancel").getId() :
                            this.onCancelSelected();
                            break;
                        case this.byId("Edit").getId() :
                            this.onEditSelected();
                            break;
                        case this.byId("SetClosed").getId() :
                            this.onSetClosedSelected();
                            break;
                    }
                },

                /**
                 * Event handler for the 'Close package' button
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                onSetClosedSelected : function() {
                    var oModel = sap.ui.getCore().getModel();
                    var oEvidencePackageService = this.getServiceFacade("EvidencePackage");

                    // Get evidence package ID to be deleted
                    var sEvidencePackageID = oModel.getProperty("/EvidencePackageDetails/Header/PackageId");

                    // Callback to be executed when close fails
                    var fnOnCloseError = function() {
                        var sErrorMessage = jd.ui.eid.common.I18NHelper.getText("MAIN_SHELL_EVIDENCE_PACKAGE_LIST_MSG_ERROR_CLOSE");
                        this.getNotificationCenter().alert(sErrorMessage);
                    };

                    // Callback to be executed when close is successful
                    var fnOnCloseSuccess = function() {
                        // TODO! What now? closing?
                    };

                    // Callback to be executed if user confirms closing the
                    // package
                    var fnOnCloseConfirmation = function(bConfirmed) {
                        if (bConfirmed) {
                            oEvidencePackageService.closeEvidencePackage(sEvidencePackageID, fnOnCloseSuccess, fnOnCloseError);
                        }
                    };

                    // Get confirmation from user before closing
                    var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("MAIN_SHELL_EVIDENCE_PACKAGE_LIST_MSG_CONFIRM_CLOSE",
                            [sEvidencePackageID]);
                    this.getNotificationCenter().confirm(sConfirmationMessage, fnOnCloseConfirmation);
                },

                /**
                 * event handler to go editing the work sheet
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                onEditSelected : function(oEvent) {
                    // call EvidencePackageSummaryOverlayController
                    sap.ui.getCore().getEventBus().publish('EvidencePackageSummary', 'OverlayClosed');
                    this.editWorksheet();
                },

                /**
                 * event handler to cancel evidence package summary
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                onCancelSelected : function(oEvent) {
                    // fire event mainly for EvidencePackageSummaryOverlayController
                    sap.ui.getCore().getEventBus().publish('EvidencePackageSummary', 'OverlayClosed');
                },

                /**
                 * event handler to save Summary
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                onSaveSelected : function() {
                    this.saveEvidencePackage(jd.ui.eid.view.main.shared.EvidencePackageSaveController.EvidencePackageSaveDialogButton.Save);
                },

                /**
                 * event handler to save Summary and send link
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                 */
                saveAndSendLink : function(oEvent) {
                    this.saveEvidencePackage(
                            jd.ui.eid.view.main.shared.EvidencePackageSaveController.EvidencePackageSaveDialogButton.SaveAndSendLink,
                            this.openMailDialog);
                },

                /**
                 * Opens the local mail program and creates a new mail which includes a link to the current evidence package.
                 */
                openMailDialog : function() {
                    var sEvidencePackageID = sap.ui.getCore().getModel().oData.EvidencePackageDetails.Header.PackageID;
                    var sURL = "mailto:?subject=evidence package" + sEvidencePackageID + "&body="
                            + jd.ui.eid.common.URLHandler.EvidencePackage.generateURL(sEvidencePackageID);
                    window.location.href = sURL;
                },

                /**
                 * Opens the print filter dialog which allows the user to select what should be printed.
                 */
                openPrintFilterDialog : function() {
                    if (!this._oPrintFilterDialog) {
                        this._oPrintFilterDialog = jd.ui.eid.xmlfragment(this.createId("PrintFilterDialog"),
                                "jd.ui.eid.fragment.dialog.main.EvidencePackagePrintFilterDialog", this);
                    }

                    if (!this._oPrintFilterDialog.isOpen()) {
                        this._oPrintFilterDialog.open();
                    }
                },

                /**
                 * Opens the print preview dialog from where the user can trigger the browser's print functionality.
                 */
                openPrintPreviewDialog : function() {
                    var sFragmentId = this.createId("PrintPreviewDialog");
                    if (!this._oPrintPreviewDialog) {
                        this._oPrintPreviewDialog = jd.ui.eid.xmlfragment(sFragmentId,
                                "jd.ui.eid.fragment.dialog.main.EvidencePackagePrintPreviewDialog", this);
                        // Hook into on after rendering to set the url on the iframe
                        var that = this;
                        this._oPrintPreviewDialog.addEventDelegate({
                            onAfterRendering : function() {
                                setTimeout(function() {
                                    var sUrl = that._oPrintPreviewDialog.data("url");
                                    that._oPrintPreviewDialog.$().find("iframe").prop("src", sUrl);
                                }, 400);
                            }
                        });
                    }

                    sap.ui.core.Fragment.byId(sFragmentId, "AppContainer").setBusy(true);
                    sap.ui.core.Fragment.byId(sFragmentId, "BtnPrint").setEnabled(false);

                    // Create the url for the print view and attach it to the dialog so that it can be processed in onAfterRendering (see above).
                    // TODO fix for prod
                    var sUrl;
                    if (window.location.href.indexOf("_local") > -1) {
                        // local
                        sUrl = "./print/index_local.html?useTestData=true";
                    } else {
                        // server
                        sUrl = "./print/index.html";
                    }
                    this._oPrintPreviewDialog.data("url", sUrl);

                    if (!this._oPrintPreviewDialog.isOpen()) {
                        this._oPrintPreviewDialog.open();
                    }

                },

                /* SECTION - Print Filter Dialog Handling - START */

                /**
                 * Handles the cancel button of the print filter dialog and closes the dialog.
                 * 
                 * @param {sap.ui.base.Event}
                 *            the event fired cancel button.
                 */
                handleEvidencePackagePrintFilterDialogCancel : function(oEvent) {
                    if (this._oPrintFilterDialog.isOpen()) {
                        this._oPrintFilterDialog.close();
                    }
                },

                /**
                 * Handles the print preview button, closes the print filter dialog and opens the print preview dialog instead.
                 * 
                 * @param {sap.ui.base.Event}
                 *            the event fired by the print preview button.
                 */
                handleEvidencePackagePrintFilterDialogContinue : function(oEvent) {
                    this.openPrintPreviewDialog();

                    if (this._oPrintFilterDialog.isOpen()) {
                        this._oPrintFilterDialog.close();
                    }
                },

                /* SECTION - Print Filter Dialog Handling - END */

                /* SECTION - Print Preview Dialog Handling - START */

                /**
                 * Handles the print button of the print preview dialog and triggers the browser's print functionality.
                 * 
                 * @param {sap.ui.base.Event}
                 *            the event fired by the print button.
                 */
                handleEvidencePackagePrintPreviewDialogPrint : function(oEvent) {
                    // Get the iframe element from the dialog
                    var elIFrame = this._oPrintPreviewDialog.$().find("iframe")[0];
                    // Trigger the browser's print mechanism for that iframe
                    elIFrame.contentWindow.focus();
                    elIFrame.contentWindow.print();
                },

                /**
                 * Handles the cancel button of the print preview dialog and closes the dialog.
                 * 
                 * @param {sap.ui.base.Event}
                 *            the event fired cancel button.
                 */
                handleEvidencePackagePrintPreviewDialogCancel : function(oEvent) {
                    // Destroy print application
                    var elIframe = this._oPrintPreviewDialog.$().find("iframe")[0];
                    if (elIframe) {
                        elIframe.contentWindow.jd.ui.eid.application.Application.getInstance().destroy();
                    }
                    if (this._oPrintPreviewDialog.isOpen()) {
                        this._oPrintPreviewDialog.close();
                        this._oPrintPreviewDialog.destroy();
                        this._oPrintPreviewDialog = null;
                    }
                },

                /* SECTION - Print Preview Dialog Handling - START */

                /* SECTION - Communication with Print View - START */

                /**
                 * Handles the <code>requestInput</code> event from the print application. Sends the evidence package header back to the print
                 * application via the <code>inputShared</code> event.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            mData the parameter map.
                 */
                handlePrintApplicationRequestInput : function(sChannelId, sEvent, mData) {
                    // Get the evidence package header
                    var mEvidencePackageHeader = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");
                    var aKPIValues = sap.ui.getCore().getModel().getProperty("/KPIValues");

                    // Get the print filter options
                    var mPrintFilterOptions = this._getPrintFilterOptions();

                    sap.ui.getCore().getEventBus().publish(this._sEventBusPrintChannelId, "inputShared", {
                        EvidencePackageHeader : mEvidencePackageHeader,
                        PrintFilterOptions : mPrintFilterOptions,
                        KPIValues : aKPIValues
                    });
                },

                /**
                 * Handles the <code>ready</code> event from the print application.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            mData the parameter map.
                 */
                handlePrintApplicationReady : function(sChannelId, sEvent, mData) {
                    var sFragmentId = this.createId("PrintPreviewDialog");
                    sap.ui.core.Fragment.byId(sFragmentId, "AppContainer").setBusy(false);
                    sap.ui.core.Fragment.byId(sFragmentId, "BtnPrint").setEnabled(true);
                },

                /**
                 * Prepares and returns a map of the print filter options that the user has selected.
                 * 
                 * @returns {object} map with print filter options selected by the user
                 * @private
                 */
                _getPrintFilterOptions : function() {
                    // The checkboxes within the 'printFilterOptions' layout represent print options that need to be mapped against their custom
                    // attribute
                    // 'printFilterOptionName'
                    var mPrintOptions = {};
                    var aPrintFilterOptions = sap.ui.core.Fragment.byId(this.createId("PrintFilterDialog"), "printFilterOptions").getContent();
                    $.each(aPrintFilterOptions, function(i, oCheckbox) {
                        var sKey = oCheckbox.data("printFilterOptionName");
                        var bValue = !oCheckbox.getChecked(); // Adding a NOT, because 'checked' = 'hide', 'unchecked' = 'show' and this property
                        // will later
                        // be bound to the 'visible' property of panels
                        mPrintOptions[sKey] = bValue;
                    });

                    return mPrintOptions;
                },

                /* SECTION - Communication with Print View - END */

                /* SECTION - Event Bus Handling - START */

                /**
                 * Handles the event fired when data for the Evidence Package Summary is fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * @memberOf jd.ui.eid.view.main.shared.DTCDetails
                 */
                handleModelFetchingData : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/EvidencePackageDetails/Summary") {
                        this._oView.setBusy(true);
                    }
                },

                /**
                 * Handles the event fired when data for the the Evidence Package Summary has been fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * @memberOf jd.ui.eid.view.main.shared.DTCDetails
                 */
                handleModelDataFetched : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/EvidencePackageDetails/Summary") {
                        this._oView.setBusy(false);
                    }
                },

            /* SECTION - Event Bus Handling - END */
            }));
})();
