QUnit.module("formatImageURL");

QUnit.test("generates image URL based on the given guid", function(assert) {
    jQuery.sap.require("nw.epm.refapps.products.manage.util.formatter");
    var fnFormatImageURL = nw.epm.refapps.products.manage.util.formatter.formatImageURL;
    assert.deepEqual(fnFormatImageURL(null), "", "empty URL for input null");
    assert.deepEqual(fnFormatImageURL(""), "", "empty URL for empty string as input");
    assert.deepEqual(fnFormatImageURL(123), "", "empty URL for any other non-string");
    assert.deepEqual(fnFormatImageURL("xxx"),
            "/sap/opu/odata/sap/EPM_REF_APPS_PROD_MAN_SRV/ImageDrafts(guid'xxx')/$value",
            "server relative URL is generated");
});

QUnit.module("getImageUploadURL");

QUnit.test("generates image upload URL based on the given product draft id", function(assert) {
    jQuery.sap.require("nw.epm.refapps.products.manage.util.formatter");
    var fnGetImageUploadURL = nw.epm.refapps.products.manage.util.formatter.getImageUploadURL;
    assert.deepEqual(fnGetImageUploadURL(null), "", "empty URL for input null");
    assert.deepEqual(fnGetImageUploadURL(""), "", "empty URL for empty string as input");
    assert.deepEqual(fnGetImageUploadURL(123), "", "empty URL for any other non-string");
    assert.deepEqual(fnGetImageUploadURL("xxx"),
            "/sap/opu/odata/sap/EPM_REF_APPS_PROD_MAN_SRV/ProductDrafts('xxx')/Images",
            "image upload URL is generated for the given draft");
});