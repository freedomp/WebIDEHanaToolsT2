(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.WarrantyClaimServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oWarrantyClaimServiceFacade = new jd.ui.eid.service.WarrantyClaimServiceFacade("http://sap.com", "/folder/to/test/data", oModel, true);

    var oDataGetWarrantyClaimsByPrimePartList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getWarrantyClaimsByPrimePartList_Response.json").data;
    var oDataGetWarrantyClaimPrimePart = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getWarrantyClaimPrimePart_Response.json").data;
    var oDataGetWarrantyClaimDetails = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getWarrantyClaimDetails_Response.json").data;

    // Module for WarrantyClaimServiceFacade
    module("jd.ui.eid.service.WarrantyClaimServiceFacade", {
        setup : function() {
            // Start spying request
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };
        },
        teardown : function() {
            this.xhr.restore();
        }
    });

    // *** TEST CASE #1 ***
    test("getWarrantyClaimsByPrimePartList() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        var oBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/WarrantyClaimsByPrimePartList");
        oWarrantyClaimServiceFacade.getWarrantyClaimsByPrimePartList(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError);

        equal(1, this.requests.length);
    });

    // *** TEST CASE #2 ***
    test("getWarrantyClaimsByPrimePartList() should update the path '/WarrantyClaimsByPrimePartList' successfully", function() {
        equal(0, this.requests.length);

        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        var oBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/WarrantyClaimsByPrimePartList");
        oWarrantyClaimServiceFacade.getWarrantyClaimsByPrimePartList(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetWarrantyClaimsByPrimePartList));

        // Assertion
        var aValue = oModel.getProperty("/WarrantyClaimsByPrimePartList");
        // check the first list value
        deepEqual(aValue[0].PrimePartNumber, oDataGetWarrantyClaimsByPrimePartList.Result.WarrantyClaimsByPrimePartList.Records[0].PrimePartNumber);
    });

    // *** TEST CASE #3 ***
    test("getWarrantyClaimPrimePart() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var bJDLinkActive = true;
        var sPrimePartNumber = "AR34432";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        oWarrantyClaimServiceFacade.getWarrantyClaimPrimePart(oCustomFilter, oEvidencePackage, sSearchTerm, bJDLinkActive, sPrimePartNumber,
                fnSuccess, fnError);

        equal(1, this.requests.length);
    });

    // *** TEST CASE #4 ***
    test("getWarrantyClaimPrimePart() should update the paths '/WarrantyClaimPrimePartHeader' and '/WarrantyClaimDetails' successfully", function() {
        equal(0, this.requests.length);

        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var bJDLinkActive = true;
        var sPrimePartNumber = "AR34432";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        oWarrantyClaimServiceFacade.getWarrantyClaimPrimePart(oCustomFilter, oEvidencePackage, sSearchTerm, bJDLinkActive, sPrimePartNumber,
                fnSuccess, fnError);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetWarrantyClaimPrimePart));

        // Assertion 1
        var oValue = oModel.getProperty("/WarrantyClaimPrimePartHeader");
        // check if the prime part header values have been set
        deepEqual(oValue.PrimePartSummary.PrimePartNumber,
                oDataGetWarrantyClaimPrimePart.Result.WarrantyClaimPrimePartHeader.PrimePartSummary.PrimePartNumber);

        // Assertion 2
        var oValue = oModel.getProperty("/WarrantyClaimDetails");
        // check if the prime part header values have been set
        deepEqual(oValue.WarrantyClaimSequenceNumber, oDataGetWarrantyClaimPrimePart.Result.WarrantyClaimDetails.WarrantyClaimSequenceNumber);
    });

    // *** TEST CASE #5 ***
    test("getWarrantyClaimDetails() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        var bJDLinkActive = true;
        var iWarrantyClaimNumber = 1201;
        var aDTCIDList = [];
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        oWarrantyClaimServiceFacade.getWarrantyClaimDetails(iWarrantyClaimNumber, bJDLinkActive, aDTCIDList, fnSuccess, fnError);

        equal(1, this.requests.length);
    });

    // *** TEST CASE #6 ***
    test("getWarrantyClaimDetails() should update the path '/WarrantyClaimDetails' successfully",
            function() {
                equal(0, this.requests.length);

                var bJDLinkActive = true;
                var iWarrantyClaimNumber = 1201;
                var aDTCIDList = [];
                var fnSuccess = sinon.spy();
                var fnError = sinon.spy();
                oWarrantyClaimServiceFacade.getWarrantyClaimDetails(iWarrantyClaimNumber, bJDLinkActive, aDTCIDList, fnSuccess, fnError);

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oDataGetWarrantyClaimDetails));

                // Assertion
                var oValue = oModel.getProperty("/WarrantyClaimDetails");
                // check if the prime part header values have been set
                deepEqual(oValue.WarrantyClaimSequenceNumber,
                        oDataGetWarrantyClaimDetails.Result.WarrantyClaimDetails.Records[0].WarrantyClaimSequenceNumber);
            });

})();
