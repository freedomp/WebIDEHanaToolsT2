(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.BreadcrumbNavigation");

    /**
     * The breadcrumb navigation control handles a list of items.
     * 
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>breadcrumbs : sap.ui.core.Item[] The breadcrumbs to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.BreadcrumbNavigation
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.BreadcrumbNavigation", /** @lends jd.ui.eid.control.BreadcrumbNavigation */
    {
        metadata : {
            aggregations : {
                breadcrumbs : {
                    type : "sap.ui.core.Item",
                    multiple : true,
                    singularName : "breadcrumb"
                }
            },

            events : {
                change : {}
            }
        },

        /**
         * Called when the BreadcrumbNavigation was clicked: It removes all subsequent breadcrumbs which have been selected after this item
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            var selectedBreadcrumbIndex = parseInt($(oEvent.target).data("jdUiEidBreadcrumbid"));
            var aBreadcrumbs = this.getAggregation("breadcrumbs");

            // Remove all breadcrumbs which are display behind the clicked one
            for ( var i = selectedBreadcrumbIndex + 1; i < aBreadcrumbs.length; i++) {
                this.removeBreadcrumb(aBreadcrumbs[i]);
            }

            if (aBreadcrumbs[selectedBreadcrumbIndex]) {
                // Only fire the event if the user clicked on an actual breadcrumb, so not the cloud icon.
                this.fireChange({
                    id : aBreadcrumbs[selectedBreadcrumbIndex].getId(),
                    selectedBreadCrumbIndex : selectedBreadcrumbIndex
                });
            }
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.BreadcrumbNavigationRenderer"
    });

})();