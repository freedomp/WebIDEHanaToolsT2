(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DefaultFilterDateDistanceToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate");

    /**
     * Constructor for a new DefaultFilterDateDistanceToolPopupValueListItemDelegate.
     * 
     * @class The DefaultFilterDateDistanceToolPopupValueListItemDelegate contains all necessary handlers of the filter personalization date distance
     *        toolpopup with a valueListItem as an opener.
     * @extends jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate
     * @name jd.ui.eid.common.delegate.DefaultFilterDateDistanceToolPopupValueListItemDelegate
     */
    jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate.extend(
            "jd.ui.eid.common.delegate.DefaultFilterDateDistanceToolPopupValueListItemDelegate", /** @lends jd.ui.eid.common.delegate.DefaultFilterDateDistanceToolPopupValueListItemDelegate */
            {
                /**
                 * Handles the "submit button pressed" / "enter pressed"-event at the custom distance toolpopup
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event.
                 */
                handleDateDistanceToolPopupSubmit : function(oEvent) {
                    var sFragmentId = this.getFragmentId();
                    var oInputField = sap.ui.core.Fragment.byId(sFragmentId, "value");
                    var oDrpbxDistanceUnit = sap.ui.core.Fragment.byId(sFragmentId, "dropbox");
                    var oDateDistanceToolPopup = this._getOpener().getToolPopup();

                    var iDuration = parseInt(oInputField.getValue());
                    var sUnit = oDrpbxDistanceUnit.getSelectedKey();

                    if (this._validateDateDistanceToolPopupDistance()) {
                        var sItemText = "";
                        switch (sUnit) {
                            case "day" :
                                sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_DAY_MULTIPLE",
                                        "DATE_DISTANCE_CUSTOM_LST_DAY_SINGLE");
                                break;
                            case "week" :
                                sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_WEEK_MULTIPLE",
                                        "DATE_DISTANCE_CUSTOM_LST_WEEK_SINGLE");
                                break;
                            case "month" :
                                sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_MONTH_MULTIPLE",
                                        "DATE_DISTANCE_CUSTOM_LST_MONTH_SINGLE");
                                break;
                        }
                        this._getOpener().setText(sItemText);

                        this._getOpener().changeValue({
                            duration : iDuration,
                            unit : sUnit
                        });
                        oDateDistanceToolPopup.close(0);
                    }
                }
            });
})();