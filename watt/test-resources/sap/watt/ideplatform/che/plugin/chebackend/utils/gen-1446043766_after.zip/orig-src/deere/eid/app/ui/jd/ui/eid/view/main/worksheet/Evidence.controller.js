(function() {
    "use strict";

    /**
     * @class
     * <p>
     * The view displays a navigation bar and either the {@link jd.ui.eid.view.main.worksheet.DTACCaseList DTAC Case List view} or the
     * {@link jd.ui.eid.view.main.worksheet.WarrantyClaimsByPrimePartList Warranty Claim (by Prime Part) List View} below..
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} : Raised while navigating to another view</li>
     * </ul>
     * </p>
     * <p>
     * The view handles the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} : When navigating to the view, the DTC list is refreshed.</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.main.worksheet.Evidence
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.Evidence", {

        oView : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.Evidence
         */
        onInit : function() {
            this.getView().addStyleClass("jdUiEidViewWorksheetEvidence");
            this.oView = this.getView();
            sap.ui.getCore().getEventBus().subscribe('Navigation', 'navigating', this.handleNavigation, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.Evidence
         */
        onExit : function() {
            // Unsubcribe to event bus
            sap.ui.getCore().getEventBus().unsubscribe('Navigation', 'navigating', this.handleNavigation, this);

            // Detroy controls
            $.each(this._mNavigationItemViewCache, function(sProperty, oManagedObject) {
                if (oManagedObject) {
                    oManagedObject.destroy();
                }
                oManagedObject = null;
            });

            // Set properties to null
            this._mNavigationItemViewCache = null;
            this.oView = null;
        },

        /**
         * Event handler for the selected event of the navigation bar control.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        onNavigationItemSelected : function(oEvent) {
            this.displayContentView(oEvent.getParameter("item").getKey());
        },

        /**
         * The default view key to display
         */
        _sDefaultViewKey : "wiDTACCases",

        /**
         * The key of the current view.
         */
        _sCurrentViewKey : null,

        _mNavigationItemViews : {
            wiDTACCases : "jd.ui.eid.view.main.worksheet.evidence.DTACCaseList",
            wiWarrantyClaims : "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList"
        },

        /**
         * Map holding the cached view instances related to the navigation items.
         */
        _mNavigationItemViewCache : {},

        /**
         * Get the content view related to the given key from the navigation item.
         * 
         * @private
         * @param {string}
         *            [sKey] the key of the related navigation item.
         * @returns {sap.ui.core.mvc.View} the related view.
         */
        _getContentView : function(sKey) {
            if (!sKey || !this._mNavigationItemViews[sKey]) {
                // Make sure that sKey is actually a valid navigation item key.
                sKey = this._sCurrentViewKey; // Default value
            }
            var sViewName = this._mNavigationItemViews[sKey];

            if (!this._mNavigationItemViewCache[sViewName]) {
                // If the view hasn't been created and cached yet, we will do that
                // now. Essentially,
                // this is lazy loading.
                this._mNavigationItemViewCache[sViewName] = jd.ui.eid.xmlview(sViewName);
            }

            return this._mNavigationItemViewCache[sViewName];
        },

        /**
         * Display the view related to the given key from the navigation item as the sole content of the shell.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         */
        displayContentView : function(sKey) {
            var sCurrentViewName, sTargetViewName;
            if (sKey !== this._sCurrentViewKey) {
                var oView = this._getContentView(sKey);
                this.byId('layout').removeContent(1);
                this.byId('layout').insertContent(oView, 1);

                // The the origin and target views from the navigation bar
                sCurrentViewName = this._mNavigationItemViews[this._sCurrentViewKey];
                sTargetViewName = this._mNavigationItemViews[sKey];

                this._sCurrentViewKey = sKey;
            } else {
                sTargetViewName = this._mNavigationItemViews[this._sCurrentViewKey];
            }

            // Raise the navigating event to update the content of the navigation item inside the navigation bar
            sap.ui.getCore().getEventBus().publish("Navigation", "navigating", {
                origin : sCurrentViewName,
                target : sTargetViewName
            });
        },

        /**
         * Handles the navigating event.
         * 
         * @param {string}
         *            sChannelId the channel id
         * @param {string}
         *            sEventId the event name
         * @param {object}
         *            oData the data passed along with the event.
         * @see jd.ui.eid.Events#Navigation::navigating
         */
        handleNavigation : function(sChannelId, sEventId, oData) {
            if (oData.target == 'jd.ui.eid.view.main.worksheet.Evidence' && oData.parameters) {
                // Get the parameter of the event to determine the right sub-view inside the navigation item
                var sSubView = oData.parameters;

                // Overwrite the default key by the subView of the event
                if (sSubView == "jd.ui.eid.view.main.worksheet.evidence.DTACCaseList") {
                    this._sDefaultViewKey = "wiDTACCases";
                } else if (sSubView == "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList") {
                    this._sDefaultViewKey = "wiWarrantyClaims";
                }

                // Reset the navigation bar to the default navigation item content
                this.displayContentView(this._sDefaultViewKey);

                // Reset the selected navigation bar item
                this.byId("navigationBar").setSelectedItem(this.byId(this._sDefaultViewKey));
            }
        }
    });
})();