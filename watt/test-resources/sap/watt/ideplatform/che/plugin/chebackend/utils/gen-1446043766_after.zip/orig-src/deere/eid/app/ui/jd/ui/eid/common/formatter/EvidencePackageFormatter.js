(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.EvidencePackageFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    /**
     * @class This formatter class provides methods for formatting Evidence Package data.
     * @static
     * @name jd.ui.eid.common.formatter.EvidencePackageFormatter
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter = {};

    /**
     * Formatter for the Evidence Package 'Status'
     * 
     * @param sEvidencePackageStatusID
     *            The 'Status ID' which needs to be formatted to readable text like 'Open' and 'Closed'.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatPackageStatus = function(iEvidencePackageStatusID) {
        if (iEvidencePackageStatusID == jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Open) {
            return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_TXT_STATUS_OPEN");
        } else if (iEvidencePackageStatusID == jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Close) {
            return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_TXT_STATUS_CLOSED");
        }
    };

    /**
     * returns the sum of the Labor Cost and Part Cost to the given failure date
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatTotalClaimCosts = function(sTimeBin) {
        var aAccWarrantyCosts = sap.ui.getCore().getModel().getProperty('/EvidencePackageDetails/Summary/AccumulatedWarrantyCosts/Records') || [];
        var dTotalCost = 0.0;
        for ( var i = 0; i < aAccWarrantyCosts.length; i++) {
            // if from same failure date and the line type is either labor cost or part cost
            if (aAccWarrantyCosts[i].TimeBin == sTimeBin && aAccWarrantyCosts[i].LineType != "DistinctPINs") {
                dTotalCost += aAccWarrantyCosts[i].AmountOrCount;
            }
        }
        return dTotalCost;
    };

    /**
     * returns the count of distinct PINs to the given failure date
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatTotalNumPINs = function(sTimeBin) {
        var aAccWarrantyCosts = sap.ui.getCore().getModel().getProperty('/EvidencePackageDetails/Summary/AccumulatedWarrantyCosts/Records') || [];
        var iTotalCount = 0.0;
        for ( var i = 0; i < aAccWarrantyCosts.length; i++) {
            // if from same failure date and the line type is Distinct PINs
            if (aAccWarrantyCosts[i].TimeBin == sTimeBin && aAccWarrantyCosts[i].LineType == "DistinctPINs") {
                iTotalCount += aAccWarrantyCosts[i].AmountOrCount;
            }
        }
        return iTotalCount;
    };

    /**
     * return the name of LineType
     * 
     * @param{string} sLineType the line type
     * @return{string} Line Type name
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatLineType = function(sLineType) {
        var sLineTypeName = "";
        switch (sLineType) {
            case "PIN" :
                sLineTypeName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_CHART_TXT_DIMENSION_LINE_TYPE_PIN");
                break;
            case "DTACCase" :
                sLineTypeName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_CHART_TXT_DIMENSION_LINE_TYPE_DTAC_CASE");
                break;
            case "WarrantyClaim" :
                sLineTypeName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_CHART_TXT_DIMENSION_LINE_TYPE_WARRANTY_CLAIM");
                break;
            case "LaborCosts" :
                sLineTypeName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_CHART_TXT_DIMENSION_LINE_TYPE_LABOR_COSTS");
                break;
            case "PartCosts" :
                sLineTypeName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_CHART_TXT_DIMENSION_LINE_TYPE_PART_COSTS");
                break;
        }
        return sLineTypeName;
    };

    /**
     * reset the Count map, this will be called in getEvidencePackageSummary of EvidencePackageFacade
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.resetRunningSumCount = function() {
        this._PINCount = null;
        this._WRNTY = null;
        this._DTAC = null;
    };

    /**
     * returns the count of a line type to a given Time bin
     * 
     * @param {string}
     *            sTimeBin the time bin
     * @param {string}
     *            sLineType
     * @returns{integer} the count value
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.getCountForTimeBinOfLineType = function(sTimeBin, sLineType) {
        // initialize the map
        var count = 0;
        if (!this._PINCount) {
            this._PINCount = [];
            this._WRNTY = [];
            this._DTAC = [];

            var aRunningSum = sap.ui.getCore().getModel().getProperty('/EvidencePackageDetails/Summary/RunningSumbyDate/Records') || [];
            for ( var i = 0; i < aRunningSum.length; i++) {
                switch (aRunningSum[i].LineType) {
                    case "PIN" :
                        this._PINCount[aRunningSum[i].TimeBin] = aRunningSum[i].Count;
                        break;
                    case "DTACCase" :
                        this._DTAC[aRunningSum[i].TimeBin] = aRunningSum[i].Count;
                        break;
                    case "WarrantyClaim" :
                        this._WRNTY[aRunningSum[i].TimeBin] = aRunningSum[i].Count;
                        break;
                }
            };
        }

        switch (sLineType) {
            case "PIN" :
                count = this._PINCount[sTimeBin];
                break;
            case "DTACCase" :
                count = this._DTAC[sTimeBin];
                break;
            case "WarrantyClaim" :
                count = this._WRNTY[sTimeBin];
                break;
        }
        return count;
    };

    /**
     * returns the PIN count to a given time bin
     * 
     * @param{string} sTimeBin time bin
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.getPINCountForTimeBin = function(sTimeBin) {
        if (sTimeBin) {
            return jd.ui.eid.common.formatter.EvidencePackageFormatter.getCountForTimeBinOfLineType(sTimeBin, "PIN");
        }
    };

    /**
     * returns the DTAC Case count to a given time bin
     * 
     * @param{string} sTimeBin time bin
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.getDTACCaseCountForTimeBin = function(sTimeBin) {
        if (sTimeBin) {
            return jd.ui.eid.common.formatter.EvidencePackageFormatter.getCountForTimeBinOfLineType(sTimeBin, "DTACCase");
        }
    };

    /**
     * returns the Waranty Claim count to a given time bin
     * 
     * @param{string} sTimeBin time bin
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.getWarrantyClaimCountForTimeBin = function(sTimeBin) {
        if (sTimeBin) {
            return jd.ui.eid.common.formatter.EvidencePackageFormatter.getCountForTimeBinOfLineType(sTimeBin, "WarrantyClaim");
        }
    };

    /**
     * Formats the chart title of chart <code>AccumulatedWarrantyClaimCostsAndPINsByFailureDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatAccumulatedWarrantyClaimCostsAndPINsByFailureDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_DIS_PINS_BY_FAILURE_MONTH";
                break;
            case "weeks" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_DIS_PINS_BY_FAILURE_WEEK";
                break;
            default :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_DIS_PINS_BY_FAILURE_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats the chart title of chart <code>AccumulatedWarrantyClaimCostsByFailureDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatAccumulatedWarrantyClaimCostsByFailureDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_BY_FAILURE_MONTH";
                break;
            case "weeks" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_BY_FAILURE_WEEK";
                break;
            default :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_ACC_WARRANTY_CLAIM_COST_BY_FAILURE_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats the axis label for an axis which shows failure date, failure week, or failure month.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the axis label for the respective time unit.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatFailureDateAxisLabel = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_TXT_AXIS_FAILURE_MONTH";
                break;
            case "weeks" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_TXT_AXIS_FAILURE_WEEK";
                break;
            default :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_TXT_AXIS_FAILURE_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats the chart title of chart <code>WarrantyClaimCostsByBuildDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatWarrantyClaimCostsByBuildDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COST_BY_BUILD_MONTH";
                break;
            case "weeks" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COST_BY_BUILD_WEEK";
                break;
            default :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COST_BY_BUILD_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats the chart title of chart <code>WarrantyClaimCountByBuildDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatWarrantyClaimCountByBuildDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COUNT_BY_BUILD_MONTH";
                break;
            case "weeks" :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COUNT_BY_BUILD_WEEK";
                break;
            default :
                sTextKey = "EVIDENCE_PACKAGE_DETAILS_CHART_CAP_WARRANTY_CLAIM_COUNT_BY_BUILD_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Returns the concatenation of the Prime Part Number with Prime Part Description
     * 
     * @param {string}
     *            sPrimePartNumber the prime part number
     * @param{sap.ui.model.Context} oContext the context
     * @return{String} the concatenation of Prime Part Number and Prime Part Description
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatPrimePartNumberDescription = function(sPrimePartNumber, oContext) {
        if (oContext) {
            var sPath = oContext.getPath();
            var sPrimePartDescriptionProperty = sPath + "/PrimePartDescription";
            var sPrimePartDescription = this.getModel().getProperty(sPrimePartDescriptionProperty);

            return jd.ui.eid.common.I18NHelper.getText("PRIME_PART_TXT_NUMBER_DESCRIPTION", [sPrimePartNumber, sPrimePartDescription]);
        }
    };

    /**
     * Formatter of the DTAC case Summary-Panel title.
     * 
     * @param {string}
     *            iDTACCaseNumber the DTAC case number.
     * @returns {string} title of the Panel
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatDTACCaseSummaryPanelTitle = function(iDTACCaseNumber) {
        return jd.ui.eid.common.I18NHelper.getText('DTAC_CASE_DETAILS_GRP_PANEL_HEADER', [iDTACCaseNumber]);
    };

    /**
     * Formats the package name and displays a placeholder text if no name is available.
     * 
     * @param {string}
     *            sName the evidence package name.
     * @returns {string} the formatted evidence package name.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatPackageName = function(sName) {
        if (!sName) {
            return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_TXT_NO_NAME");
        } else {
            return sName;
        }
    };

    /**
     * Formats the package description and displays a placeholder text if no description is available.
     * 
     * @param {string}
     *            sDescription the evidence package description.
     * @returns {string} the formatted evidence package description.
     */
    jd.ui.eid.common.formatter.EvidencePackageFormatter.formatPackageDescription = function(sDescription) {
        if (!sDescription) {
            return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_TXT_NO_DESCRIPTION");
        } else {
            return sDescription;
        }
    }

})();