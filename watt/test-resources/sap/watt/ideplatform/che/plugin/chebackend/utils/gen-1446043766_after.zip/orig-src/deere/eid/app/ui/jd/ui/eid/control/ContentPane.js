(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ContentPane");

    /**
     * Constructor of a new ContentPane.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>height : CSSSize (default: undefined) the height of the content pane.</li>
     * <li>tabIndex : integer (default: undefined) the tabindex of the content pane.</li>
     * <li>width: CSSSize (default: undefined) the width of the content pane.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>content (default aggregation) : sap.ui.core.Control[] the controls displayed inside the content pane.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The content pane serves as a simple container for any kind of content.
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.ContentPane
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.ContentPane", {
        metadata : {
            properties : {
                height : {
                    type : "sap.ui.core.CSSSize"
                },
                tabIndex : {
                    type : "int"
                },
                width : {
                    type : "sap.ui.core.CSSSize"
                },
                visible : {
                    type : "boolean",
                    defaultValue : true
                }
            },
            aggregations : {
                content : {
                    type : "sap.ui.core.Control",
                    multiple : true
                }
            },
            defaultAggregation : "content"
        },

        renderer : function(oRm, oControl) {
            var i;

            if (!oControl.getVisible()) {
                return;
            }

            oRm.write("<div");
            if (typeof oControl.getTabIndex() === "number") {
                oRm.writeAttribute("tabindex", oControl.getTabIndex());
            }
            if (oControl.getWidth()) {
                oRm.writeAttributeEscaped("width", oControl.getWidth());
            }
            if (oControl.getHeight()) {
                oRm.writeAttributeEscaped("style", "height:" + oControl.getHeight() + "; width:" + oControl.getWidth());
            }
            oRm.writeControlData(oControl);
            oRm.addClass("jdUiEidContentPane");
            oRm.writeClasses();
            oRm.write(">");
            if (oControl.getContent()) {
                var aItems = oControl.getContent();
                for (i = 0; i < aItems.length; i++) {
                    oRm.renderControl(aItems[i]);
                }
            }
            oRm.write("</div>");
        }
    });
})();