(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("sap.ui.base.ManagedObject");
    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");

    /**
     * Constructor for a new DefaultFilterDateRangeToolPopupValueListItemDelegate.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>fragmentId: The ID of the associated DefaultFilterDateRangeToolPopup fragment instance.</li>
     * <ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>opener: The associated opener of the DefaultFilterDateRangeToolPopup fragment.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The delegate for the 'DefaultFilterDateRangeToolPopup' fragment used in the Filter Personalization screen. An instance of this class is
     *        used while instantiating the fragment.
     * @extends jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate
     * @name jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate
     */
    jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate.extend("jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate",
    /** @lends jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate */
    {
        /**
         * Handles the change event of the type dropdown. The 'To' datepicker is disabled if 'sinceDate' is selected.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleTypeDropdownChanged : function(oEvent) {
            if (sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").getSelectedKey() == "sinceDate") {
                this._getToDatePicker().setEnabled(false);
            } else {
                this._getToDatePicker().setEnabled(true);
            }
            this._validateDateRangeToolPopupRange(this._getFromDatePicker(), this._getToDatePicker());
        },

        /**
         * Validates the date range toolpopup. Overridden because validation logic is different (because of the dropdown to select current date)
         * 
         * @returns {boolean} True if valid, False otherwise.
         */
        _validateDateRangeToolPopupRange : function(oFromDatePicker, oToDatePicker) {
            // If 'Type' is 'since', use current date as 'To' for validation.
            var bValid;

            // If the last 'changed' event from the 'from' and/or 'to' DatePickers indicated an invalid value entered by the user, then no need to
            // validate the date range.
            bValid = this._mDatePickerValidity.from && this._mDatePickerValidity.to;
            if (bValid) {
                var sType = sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").getSelectedKey();
                if (sType === "sinceDate") {
                    var todayYyyymmdd = jd.ui.eid.common.DateHelper.DateToYyyymmdd(FAKE_TODAY());
                    bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange(oFromDatePicker.getYyyymmdd(), todayYyyymmdd);
                } else {
                    bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange(oFromDatePicker.getYyyymmdd(), oToDatePicker.getYyyymmdd());
                }
            }

            if (!bValid) {
                // Create a callout to indicate an error with the
                // from-datepicker
                var oFromDatePickerText = new sap.ui.commons.TextView({
                    text : jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FILTER_ITEM_ERROR_START")
                }).addStyleClass("jdUiTv");
                var oFromCallout = new sap.ui.commons.Callout({
                    content : oFromDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the from-datepicker
                oFromDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oFromDatePicker.setTooltip(oFromCallout);

                // Create a callout to indicate an error with the
                // to-datepicker
                var oToDatePickerText = new sap.ui.commons.TextView({
                    text : jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FILTER_ITEM_ERROR_END")
                }).addStyleClass("jdUiTv");
                var oToCallout = new sap.ui.commons.Callout({
                    content : oToDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the to-datepicker
                oToDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oToDatePicker.setTooltip(oToCallout);
            } else {
                // Set the datepickers as valid
                oFromDatePicker.setValueState(sap.ui.core.ValueState.None);
                oToDatePicker.setValueState(sap.ui.core.ValueState.None);

                // Remove the error callouts
                oFromDatePicker.setTooltip(null);
                oToDatePicker.setTooltip(null);
            }

            return bValid;
        },

        /**
         * Checks if the ToolPopup has an user input. Overridden because the logic required for filter personalization date range is different, and is
         * based on the selection of the 'type' dropdown.
         * 
         * @returns {Boolean} True if there is there is no user input in the ToolPopup
         */
        _isUserInputEmpty : function() {
            // If 'absolute', FROM and TO can be set by user. For 'sinceDate', it's only 'from' (because the 'to' datepicker is disabled)
            if (((sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").getSelectedKey() == "absolute") && (this._getFromDatePicker()
                    .getValue() || this._getToDatePicker().getValue()))
                    || ((sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").getSelectedKey() == "sinceDate") && this
                            ._getFromDatePicker().getValue())) {
                return false;
            }
            return true;
        },

        /**
         * Populates the ToolPopup controls with values. (e.g from the opening ValueListItem's 'value'). Overridden to also set the 'type' dropdown
         * that is not handled in the base class implementation of this method.
         */
        _populateToolPopupValues : function() {
            this._getFromDatePicker().setYyyymmdd(this._getOpener().getValue().from);
            this._getToDatePicker().setYyyymmdd(this._getOpener().getValue().to);
            sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").setSelectedKey(this._getOpener().getValue().type);

            // If type is sinceDate, disable the TO DatePicker
            if (this._getOpener().getValue().type == "sinceDate") {
                this._getToDatePicker().setEnabled(false);
            }
        },

        /**
         * Updates the source with the latest values. This is the source from which the values for the ToolPopup were originally copied from (e.g a
         * ValueListItem). Overridden because the base class implementation doesn't update the 'type' property, which is specific to the
         * FilterSetting's DateRange ToolPopup.
         */
        _updateSource : function() {
            this._getOpener().changeValue({
                from : this._getFromDatePicker().getYyyymmdd(),
                to : this._getToDatePicker().getYyyymmdd(),
                type : sap.ui.core.Fragment.byId(this.getFragmentId(), "typeDropdown").getSelectedKey()
            });
        }
    });
})();