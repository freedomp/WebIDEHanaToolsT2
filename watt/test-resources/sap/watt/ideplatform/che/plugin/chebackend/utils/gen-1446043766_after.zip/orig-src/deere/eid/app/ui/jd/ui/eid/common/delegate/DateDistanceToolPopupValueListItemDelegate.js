(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate");

    /**
     * Constructor for a new DateDistanceToolPopupValueListItemDelegate.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>fragmentId : string (default: "") The ID of the toolpopup fragement </li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>opener : jd.ui.eid.control.ValueListItem The valueListItem that opens the toolPopup.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The DateDistanceToolPopupValueListItemDelegate contains all necessary handlers of the date distance toolpopup with a valueListItem as an
     *        opener.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate", /** @lends jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate */
    {

        metadata : {
            properties : {
                fragmentId : "string"
            },
            associations : {
                opener : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                }
            }
        },

        /**
         * Get the valueListItem that opens the toolPopup
         * 
         * @return {jd.ui.eid.control.ValueListItem} the opener object.
         */
        _getOpener : function() {
            return sap.ui.getCore().byId(this.getAssociation("opener"));
        },

        /**
         * Create the open event handler of the custom distance item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupOpen : function(oEvent) {
            var sFragmentId = this.getFragmentId();
            var oInputField = sap.ui.core.Fragment.byId(sFragmentId, "value");
            var oDrpbxDistanceUnit = sap.ui.core.Fragment.byId(sFragmentId, "dropbox");

            if (this._getOpener().getValue().duration) {
                oInputField.setValue(this._getOpener().getValue().duration);
            }
            if (this._getOpener().getValue().unit) {
                oDrpbxDistanceUnit.setSelectedKey(this._getOpener().getValue().unit);
            }
            this._validateDateDistanceToolPopupDistance();

            // Attach keypress event handler to avoid non numeric values at oInputField
            oInputField.attachBrowserEvent("keypress", $.proxy(this._validateDateDistanceToolPopupDistanceLiveInput, this));

            // Select list item
            this._getOpener().setSelected(true);
        },

        /**
         * Validate the keypress event on the date distance input field: Only numbers should be allowed
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        _validateDateDistanceToolPopupDistanceLiveInput : function(oEvent) {
            // Check whether typed key is not "Enter" and typed key does not refer to a number
            if (oEvent.keyCode != 13 && oEvent.keyCode < 48 || oEvent.keyCode > 57) {
                // Prevent the user input from being show in the input field
                oEvent.stopPropagation();
                oEvent.preventDefault();
                return;
            }
        },

        /**
         * Handles the change event of the custom distance toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the even
         */
        handleDateDistanceToolPopupChanged : function(oEvent) {
            this._validateDateDistanceToolPopupDistance();
        },

        /**
         * Validates the date distance toolpopup
         * 
         * @returns {boolean} True if valid, False otherwise.
         */
        _validateDateDistanceToolPopupDistance : function() {
            var sFragmentId = this.getFragmentId();
            var bValid = false;
            var oInputField = sap.ui.core.Fragment.byId(sFragmentId, "value");
            var sValue = oInputField.getValue();

            /* Check if the input field value is invalid: */
            if (sValue) {
                oInputField.setValueState(sap.ui.core.ValueState.None); // Set input field as valid
                oInputField.setTooltip(null); // Remove error callout
                bValid = true;
            } else {
                // Create a callout to indicate a invalid value
                var oCalloutText = new sap.ui.commons.TextView({
                    text : "{i18n>FILTER_ITEM_ERROR_INVALID_VALUE}"
                }).addStyleClass("jdUiTv");
                var oCallout = new sap.ui.commons.Callout({
                    content : oCalloutText
                }).addStyleClass("jdUiClt");

                oInputField.setValueState(sap.ui.core.ValueState.Error); // Set input field as invalid
                oInputField.setTooltip(oCallout); // Set error callout to field
                bValid = false;
            }

            return bValid;
        },

        /**
         * Handles the "submit button pressed" / "enter pressed"-event at the custom distance toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupSubmit : function(oEvent) {
            var sFragmentId = this.getFragmentId();
            var oInputField = sap.ui.core.Fragment.byId(sFragmentId, "value");
            var oDrpbxDistanceUnit = sap.ui.core.Fragment.byId(sFragmentId, "dropbox");
            var oDateDistanceToolPopup = this._getOpener().getToolPopup();

            if (this._validateDateDistanceToolPopupDistance()) {
                this._getOpener().changeValue({
                    duration : parseInt(oInputField.getValue()),
                    unit : oDrpbxDistanceUnit.getSelectedKey()
                });
                oDateDistanceToolPopup.close(0);
            }
        },

        /**
         * Handles the cancel event of the custom distance toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupCancel : function(oEvent) {
            this._getOpener().getToolPopup().close(0);
        },
    });
})();