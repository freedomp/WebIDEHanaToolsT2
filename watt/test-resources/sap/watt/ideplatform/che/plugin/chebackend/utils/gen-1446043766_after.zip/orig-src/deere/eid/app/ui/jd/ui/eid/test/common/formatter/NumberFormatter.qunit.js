(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("sap.ui.core.format.NumberFormat");

    var fnGetLocale = null;

    module("jd.ui.eid.common.formatter.NumberFormatter", {
        setup : function() {
            var oI18nModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl : "jd/ui/eid/asset/text/i18n.properties"
            });
            sap.ui.getCore().setModel(oI18nModel, 'i18n');

            // Simulate english
            fnGetLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale;
            /**
             * @ignore
             */
            var fnFormatLocale = function() {
                return new sap.ui.core.Locale("en_US");
            };
            sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale = fnFormatLocale;
        },
        teardown : function() {
            sap.ui.getCore().setModel(null, 'i18n');

            // Undo simulation
            sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale = fnGetLocale;
        }
    });
    test("formatFloatToUSDollarCurrency() should format a float to a 2 digit fraction number with $ currency", function() {
        var sResult = jd.ui.eid.common.formatter.NumberFormatter.formatFloatToUSDollarCurrency(12454345.4564456);
        equals('$12,454,345.45', sResult);
    });
    test("formatFloat() should format a float to a digit number to display at UI", function() {
        var sResult = jd.ui.eid.common.formatter.NumberFormatter.formatFloat(12454345.4564456, 3);
        equals('12,454,345.456', sResult);
    });
    test("formatInteger() should format a float to a digit number to display at UI", function() {
        var sResult = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(12454345);
        equals('12,454,345', sResult);
    });
    test("addCurrencySign() should add a currency sign to formatted number", function() {
        var sResult = jd.ui.eid.common.formatter.NumberFormatter.addCurrencySign("12,454,345");
        equals('$12,454,345', sResult);
    });

})();