(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WarrantyClaimFormatter");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");

    /**
     * The controller for the WarrantyClaimPrimePart view
     * 
     * @class
     * <p>
     * The Warranty Claim by Prime Part List view provides the functionality to display details for a Warranty Claim of a set of Warranty Claims with
     * the same prime part. It consists of a navigation area, a header area, and a content area which either displays a chart area or a long text
     * area, depending on the option selected in the content switch. Moreover the view enables the user to add one or multiple Warranty Claims to the
     * Evidence Package. To display the Warranty Claim Details the view WarrantyClaimDetails was embedded.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers
     * and set the required bindings.</li>
     * <li>{@link #.onExit} is called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.setContext} is called while opening the view from the Warranty Claim list. It sets the selected Prime Part Number and search term
     * and triggers a new service call.</li>
     * <li>{@link #._cacheAndRestoreData} is called while switching between the collections (JDLinkActive/Inactive). It caches and restores the
     * collection values, so that no request is triggered again to the server.</li>
     * <li>{@link #.fetchWarrantyClaimPrimePart} is called to trigger a new call to the service GetWarrantyClaimPrimePart.</li>
     * <ul>
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#WarrantyClaimPrimePartView::close} : Notifies the overlay to close the view</li>
     * </ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>_handleCollectionSelected is called while switching between JDLinkActive/Inactive collections This triggers a new service call to get the
     * list of Warranty Claims which are only JDLinkActive/Inactive</li>
     * <li>_handleItemSelectionChanged is called while selecting another Warranty Claim out of the list. This triggers a new service call to get the
     * details for the selected Warranty Claim.</li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart */
    {

        _bJDLinkActive : true,
        _oCachedWarrantyClaimDetails : null,
        _oCachedWarrantyClaimHeader : null,
        _oWarrantyClaimService : null,
        _oWarrantyClaimDetailsView : null,
        _oView : null,
        _sPrimePartNumber : "",
        _sSearchTerm : "",

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        onInit : function() {
            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            oEventBus.subscribe('WarrantyClaimDetailsView', 'close', this.handleCloseWarrantyClaimDetailsView, this);

            // Get a reference to the view
            this._oView = this.getView();

            // Add the Warranty Claim Details view to the CollectionInspectorSummary
            this._oWarrantyClaimDetailsView = jd.ui.eid.xmlview("jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails");
            this.byId("CollectionInspector").addContent(this._oWarrantyClaimDetailsView);

            this._oWarrantyClaimService = this.getServiceFacade("WarrantyClaim");
            this._oWarrantyClaimService.attachRequestFailed($.proxy(this._handleRequestFailed, this));
        },

        /**
         * Called when the service requested failed. It wraps the _onRequestFailed method from the BaseController and add additional logic to disable
         * the action on the WarrantyClaimDetails screen
         */
        _handleRequestFailed : function() {
            // Disable all WarrantyClaimDetails actions except close
            this._oWarrantyClaimDetailsView.getController().disableActions();
            // Call the BaseController failed method
            this._onRequestFailed.apply(this, arguments);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        onExit : function() {
            // Unsubcribe to event bus
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);

            // Detach events
            this._oWarrantyClaimService.detachRequestFailed($.proxy(this._handleRequestFailed, this));

            // Set properties to null
            this._oCachedWarrantyClaimDetails = null;
            this._oCachedWarrantyClaimHeader = null;
            this._oWarrantyClaimService = null;
            this._oView = null;
        },

        /**
         * Set the selected Prime Part
         * 
         * @param {int}
         *            iPrimePartNumber the selected Prime Part Number
         * @param {string}
         *            sSearchTermin the search term which was set to determine the data
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        setContext : function(sPrimePartNumber, sSearchTerm) {
            // Save the SearchTerm from the WarrantyClaimList
            this._sSearchTerm = sSearchTerm;

            // Reset the old values
            var oModel = sap.ui.getCore().getModel();
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/PrimePartNumber", "");
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/PrimePartDescription", "");
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/DistinctPINCount", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/LaborCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/PartCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/TotalClaimCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/WarrantyClaimCount", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/WarrantyClaimList", []);
            oModel.setProperty("/WarrantyClaimDetails", {});

            // Reset cache
            this._oCachedWarrantyClaimHeader = null;
            this._oCachedWarrantyClaimDetails = null;

            // Set the default collection selection
            this._bJDLinkActive = true;
            this.byId("CollectionInspector").setSelectedCollection(this.byId("jdLinkOnline"));

            // Reset the selected collection item
            this.byId("jdLinkOnline").removeAllSelectedItems();
            this.byId("other").removeAllSelectedItems();

            // Fetch the required data
            this._sPrimePartNumber = sPrimePartNumber;
            this.fetchWarrantyClaimPrimePart();
        },

        /**
         * Triggers a service call to get the Warranty Claims for a specific Prime Part and updates the model.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        fetchWarrantyClaimPrimePart : function() {
            // Reset the old values
            var oModel = sap.ui.getCore().getModel();
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/DistinctPINCount", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/LaborCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/PartCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/TotalClaimCost", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/PrimePartSummary/WarrantyClaimCount", 0);
            oModel.setProperty("/WarrantyClaimPrimePartHeader/WarrantyClaimList", []);
            oModel.setProperty("/WarrantyClaimDetails", {});

            // Get the custom Warranty Claim filter selection
            var oCustomFilter = oModel.getProperty("/WarrantyClaimFilters/FilterSelection");

            // Prepare the oEvidencePackage parameter that the
            // service call needs
            var oDTCFilters = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterSelection");
            var aDTCIDs = jd.ui.eid.model.EidModel.TransformationHelper.getDTCIDListFromEvidencePackageDetails();
            var oEvidencePackage = {
                DTCFilters : oDTCFilters,
                DTCIDList : aDTCIDs
            };

            // Set the context at view Warranty Claim Details without refetching the data
            var fnSuccess = function() {
                var iWarrantyClaimSequenceNumber = oModel.getProperty("/WarrantyClaimDetails/WarrantyClaimSequenceNumber");
                this.setWarrantyClaimDetailsContext(iWarrantyClaimSequenceNumber, false);
            };

            // Call the service
            this._oWarrantyClaimService.getWarrantyClaimPrimePart(oCustomFilter, oEvidencePackage, this._sSearchTerm, this._bJDLinkActive,
                    this._sPrimePartNumber, $.proxy(fnSuccess, this), $.proxy(this._handleRequestFailed, this));
        },

        /**
         * Sets a new context to the Warranty Claim Details view
         * 
         * @param {int}
         *            iWarrantyClaimSequenceNumber the number of the WarrantyClaim with should be shown in the Warranty Claim Details view
         * @param {boolean}
         *            bFetchData Indicates if a new data request should be performed after setting the new context
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        setWarrantyClaimDetailsContext : function(iWarrantyClaimSequenceNumber, bFetchData) {
            this._oWarrantyClaimDetailsView.getController().setContext(iWarrantyClaimSequenceNumber, this._bJDLinkActive, bFetchData, true);
        },

        /**
         * Caches the current Item Selection, WarrantyClaimHeader and WarrantyClaimDetails
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        _cacheAndRestoreData : function() {
            // this.oCachedCollectionItemSelection = null;
            // Save the current data in temporary cache
            var oTempCachedWarrantyClaimHeader = $.extend(true, {}, this._oView.getModel().getProperty("/WarrantyClaimPrimePartHeader"));
            var oTempCachedWarrantyClaimDetails = $.extend(true, {}, this._oView.getModel().getProperty("/WarrantyClaimDetails"));

            // Restore the cached data if exists otherwise send a new request
            if (this._oCachedWarrantyClaimHeader && this._oCachedWarrantyClaimDetails) {
                this._oView.getModel().setProperty("/WarrantyClaimPrimePartHeader", this._oCachedWarrantyClaimHeader);
                this._oView.getModel().setProperty("/WarrantyClaimDetails", this._oCachedWarrantyClaimDetails);
                // Set the context at view Warranty Claim Details without refetching the data
                var oModel = sap.ui.getCore().getModel();
                var iWarrantyClaimSequenceNumber = oModel.getProperty("/WarrantyClaimDetails/WarrantyClaimSequenceNumber");
                this.setWarrantyClaimDetailsContext(iWarrantyClaimSequenceNumber, false);
                // Write temporary cache to long-term cache
                this._oCachedWarrantyClaimHeader = $.extend(true, {}, oTempCachedWarrantyClaimHeader);
                this._oCachedWarrantyClaimDetails = $.extend(true, {}, oTempCachedWarrantyClaimDetails);
            } else {
                // Write temporary cache to long-term cache
                this._oCachedWarrantyClaimHeader = $.extend(true, {}, oTempCachedWarrantyClaimHeader);
                this._oCachedWarrantyClaimDetails = $.extend(true, {}, oTempCachedWarrantyClaimDetails);
                this.fetchWarrantyClaimPrimePart();
            }
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the Warranty Claim Details is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/WarrantyClaimPrimePartHeader") {
                // Due to a bug with the CollectionInspector the busy state is set on the content of the view
                this._oView.getContent()[0].setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the Warranty Claim Details has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/WarrantyClaimPrimePartHeader") {
                // Due to a bug with the CollectionInspector the busy state is set on the content of the view
                this._oView.getContent()[0].setBusy(false);
            }
        },

        /**
         * Handles the {@link jd.ui.eid.Events#WarrantyClaimDetailsView::close} event and passes it on as a
         * {@link jd.ui.eid.Events#WarrantyClaimPrimePartView::close} if the view is visible.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        handleCloseWarrantyClaimDetailsView : function(sChannelId, sEvent, oData) {
            if (this.isVisible()) {
                sap.ui.getCore().getEventBus().publish('WarrantyClaimPrimePartView', 'close');
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Handles the event which is fired when a user selects a collection
         * 
         * @param {sap.ui.base.Event}
         *            oControlEvent the control event
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        _handleCollectionSelected : function(oControlEvent) {
            var sCollectionId = oControlEvent.getParameter("collection").getId();

            if (sCollectionId.indexOf("jdLinkOnline") != -1) {
                this._bJDLinkActive = true;
                this._cacheAndRestoreData();
            } else if (sCollectionId.indexOf("other") != -1) {
                this._bJDLinkActive = false;
                this._cacheAndRestoreData();
            }
        },

        /**
         * Handles the event which is fired when a user selects a item in a collection
         * 
         * @param {sap.ui.base.Event}
         *            oControlEvent the control event
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimPrimePart
         */
        _handleItemSelectionChanged : function(oEvent) {
            var sItemId = oEvent.getParameter("selectedItems")[0];
            this.oSelectedCollectionItem = sap.ui.getCore().byId(sItemId);
            var iWarrantyClaimSequenceNumber = this.oSelectedCollectionItem.getBindingContext().getProperty().WarrantyClaimSequenceNumber;
            // Set the context at view Warranty Claim Details without refetching the data
            this.setWarrantyClaimDetailsContext(iWarrantyClaimSequenceNumber, true);
        },

        /**
         * Formats the highlighted property of a collection item and returns true if the warranty claim is already in the evidence package, false
         * otherwise.
         * 
         * @param {boolean}
         *            bCanBeAddedToEvidencePackage true if the warranty claim can be added to the evidence package, false otherwise.
         * @returns {boolean} true if the warranty claim is highlighted (aka in the package), false otherwise.
         */
        formatWarrantyClaimCollectionItemHighlighted : function(bCanBeAddedToEvidencePackage) {
            return bCanBeAddedToEvidencePackage === false;
        }

    }));
})();