(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.EidBasket");
    jQuery.sap.declare("jd.ui.eid.control.EidBasketPINPopulation");

    /**
     * The EidBasketPINPopulation is a basket tile which shows the PIN population. It inherits from
     * jd.ui.eid.control.EidBasket. Only difference is an additional style sheet which defines a
     * rectangle with fixed length and height. Text and number is center aligned.
     * 
     * @class
     * @name jd.ui.eid.control.EidBasketPINPopulation
     * @extends jd.ui.eid.control.EidBasket
     */

    jd.ui.eid.control.EidBasket.extend("jd.ui.eid.control.EidBasketPINPopulation", /** @lends jd.ui.eid.control.EidBasketPINPopulation */
    {
        /**
         * Add own style class for the text view
         */
        init : function() {

            this.addStyleClass("jdUiEidBasketPINPopulationTile");

        },
        /**
         * Renders control
         * 
         * @param {sap.ui.core.RenderManager}
         *            oRenderManager the RenderManager that can be used for writing to the
         *            Render-Output-Buffer
         * @param {sap.ui.core.Control}
         *            oCmb an object representation of the control that should be rendered
         */
        renderer : "jd.ui.eid.control.EidBasketRenderer"

    });
})();