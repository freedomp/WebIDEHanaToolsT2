(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.MachineOptionFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    /**
     * @class
     * <p>
     * The view displays a list of panels for each DTC in the evidence package. In that panel, a table displays machine option codes which have been
     * calculated for the respective DTC. The user can search the list and change the sorting. <strong>Please note</strong> that the data for the
     * individual tables resides entirely on the client (so paging, etc. is done on the client, too). This is because the machine option codes are
     * calculated in the background. If a user enters this screen, it's possible that some calculations haven't returned yet. If the evidence package
     * is saved, only those machine options which are available on the client are saved. If the evidence package is opened later on, non-calculated
     * machine options will be calculated.
     * </p>
     * <p>
     * The view handles the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#MachineOptionService::serviceFailed}</li>
     * <li>{@link jd.ui.eid.Events#MachineOptionService::serviceSuccessfull}</li>
     * <li>{@link jd.ui.eid.Events#MachineOptionService::servicePending}</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
     */
    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.MachineOptionSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.evidencepackage.MachineOptionSummary */
    {

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        onInit : function() {
            var oTable = this.getView().byId("Table");
            var that = this;

            // we have to set the EventDelegate as the panels and tables are rendered by an aggregation. Therefore the
            // controls are not rendered at
            // the controller hook "onAfterRendering"
            var bEventsRegistered = false;
            oTable.addEventDelegate({
                onAfterRendering : function() {
                    // We register only once, so let's maintain a flag in custom data
                    if (!bEventsRegistered) {
                        // we register to the event bus which is implemented for the machine option service only
                        var oEventBus = sap.ui.getCore().getEventBus();
                        oEventBus.subscribe('MachineOptionService', 'serviceFailed', that.handleServiceStatusChanged, that);
                        oEventBus.subscribe('MachineOptionService', 'serviceSuccessfull', that.handleServiceStatusChanged, that);
                        oEventBus.subscribe('MachineOptionService', 'servicePending', that.handleServiceStatusChanged, that);
                        bEventsRegistered = true;
                    }

                    // we have to check also the machine option calculation status once the controls are rendered
                    that.handleServiceStatusChanged();
                }

            }, oTable);

        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        onExit : function() {
            // Unsubscribe from event bus.
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('MachineOptionService', 'serviceFailed', this.handleServiceStatusChanged, this);
            oEventBus.unsubscribe('MachineOptionService', 'serviceSuccessfull', this.handleServiceStatusChanged, this);
            oEventBus.unsubscribe('MachineOptionService', 'servicePending', this.handleServiceStatusChanged, this);
        },

        /**
         * returns the Accordion control
         * 
         * @returns{jd.ui.eid.control.Accordion}
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        _getAccordionControl : function() {
            return this.getView().getContent()[0].getContent()[1];
        },

        /**
         * Changes the table design depending on the machine option calculation status
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        handleServiceStatusChanged : function() {
            var oEvidencePackageServiceFacade = this.getServiceFacade("EvidencePackage");
            var iDTCID = this._getAccordionControl().get_openSectionId();
            var oDTC = oEvidencePackageServiceFacade.MachineOptionCalculation.getStatusForDTC(iDTCID);
            var oTable = this._getAccordionControl().getItemTemplate();

            if (oDTC) {
                // now we know the status of the service request for the specific table
                switch (oDTC.Status) {
                    case jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationSuccessfull :
                        oTable.setBusy(false);
                        // set nodata in case that calculation was successfull but without result
                        this._setNoDataTable(oTable, "MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_DO_NOT_EXIST");
                        break;

                    case jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationFailed :
                        this._setNoDataTable(oTable, "MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_FAILED_CALCULATION");
                        break;

                    case jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationPending :
                        this._setNoDataTable(oTable, "MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_CALCULATION_PENDING");
                        oTable.setBusy(true);
                        break;
                }
            }
        },

        /**
         * Set text of no data control (which is a text view)
         * 
         * @param {sap.ui.commons.Table}
         *            oTable the Tabel control
         * @param {string}
         *            sI18Ntext the text maintained in the language model
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        _setNoDataTable : function(oTable, sI18Ntext) {
            var oTextView = oTable.getNoData();
            oTextView.setText(jd.ui.eid.common.I18NHelper.getText(sI18Ntext));
        },

        /**
         * Event handler for recalculating one machine option code
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        onRecalculate : function(oEvent) {
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageServiceFacade = this.getServiceFacade("EvidencePackage");
            var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
            var oSection = oEvent.getSource().getParent();

            var iDTCID = oSection.getSectionId();
            // var iDTCID = this._getDTCIDFromAggregatedPanel(oPanel);

            oEvidencePackageServiceFacade.calculateMachineOptionCodesForDTC([iDTCID], oEvidencePackageDetailsHeader.DTCFilterSelection);
        },

        /**
         * Enables/Disables Button "Recalculate" of all DTCs
         * 
         * @param {boolean}
         *            bEnable true to enable, otherwise false
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        enableRecalculateButtons : function(bEnable) {

            var aSections = this._getAccordionControl().getSections();
            var aButtons = [];

            for ( var i = 0; i < aSections.length; i++) {
                aButtons = aSections[i].getActions();
                // we can not access the button via id as it is aggregated. So we rely on the xml view
                aButtons[0].setEnabled(bEnable);
            }

        },

        /**
         * Event handler for recalculating all machine option codes
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        onRecalculateAll : function(oEvent) {
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageServiceFacade = this.getServiceFacade("EvidencePackage");
            var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
            var aDTCIDList = oEvidencePackageServiceFacade.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList);

            // we disable the button "Recalculate" while the service for recalculate all DTCs is running to avoid
            // parallel running service requests
            this.enableRecalculateButtons(false);

            var that = this;
            var _enableRecalculateButtons = function() {
                that.enableRecalculateButtons(true);
            };
            oEvidencePackageServiceFacade.calculateMachineOptionCodesForDTC(aDTCIDList, oEvidencePackageDetailsHeader.DTCFilterSelection,
                    _enableRecalculateButtons, _enableRecalculateButtons);
        },

        /**
         * Event handler for show Help for machine option codes
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.MachineOptionSummary
         */
        handleHelpButtonPress : function(oEvent) {
            var sId = "HelpDialog";
            var oHelpDialog = null;
            oHelpDialog = new jd.ui.eid.xmlfragment(this.createId(sId),
                    "jd.ui.eid.fragment.dialog.main.evidencepackage.MachineOptionCodesHelpDialog", {
                        handleClose : function() {
                            if (oHelpDialog.isOpen()) {
                                oHelpDialog.close();
                            }
                        },
                        handleClosed : function(oEvent) {
                            oEvent.getSource().detachClosed(this.handleClosed);
                            oEvent.getSource().destroy();
                        }
                    });

            var sHtmlText = "<div class='jdUiHelpText'>"
                    // description text
                    + jd.ui.eid.common.I18NHelper.getText('MACHINE_OPTION_CODE_HELP_TXT', ["<br>", "<em>", "</em>", "<strong>", "</strong>", "<ul>",
                            "</ul>", "<li>", "</li>", "<embed data-index=\'0\'>"])
                    + "<div class='jdUiHelpImgCenter'> <embed data-index=\'1\'> </div> <br>";

            // Example Machine Option Code table
            sHtmlText += jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_HELP_TXT_CAP_EXAMPLE") + "<embed data-index=\'2\'> <br>";

            // Explanation Text to the example table
            sHtmlText += jd.ui.eid.common.I18NHelper.getText('MACHINE_OPTION_CODE_HELP_TXT_EXAMPLE', ["<br>", "<ul>", "</ul>", "<li>", "</li>"])
                    + "</li></ul> </div> ";

            var oMachineOptionChartImage = new sap.ui.commons.Image({
                src : "jd/ui/eid/asset/img/MachineOptionsChart.png",
                width : "300px"
            });

            var oMachineOptionTableImage = new sap.ui.commons.Image({
                src : "jd/ui/eid/asset/img/MachineOptionTable.png"
            });

            var oLiftChartImage = new sap.ui.commons.Image({
                src : "jd/ui/eid/asset/img/Lift.png"
            });
            var oMessage = this.byId(sId, "Message");
            oMessage.setHtmlText(sHtmlText);
            oMessage.addControl(oMachineOptionChartImage);
            oMessage.addControl(oLiftChartImage);
            oMessage.addControl(oMachineOptionTableImage);

            oHelpDialog.setTitle(jd.ui.eid.common.I18NHelper.getText('MACHINE_OPTION_CODE_TABLE_HED_MACHINE_CODES_HELP_DIALOG_TITLE'));
            oHelpDialog.open();
        },

    }));
})();