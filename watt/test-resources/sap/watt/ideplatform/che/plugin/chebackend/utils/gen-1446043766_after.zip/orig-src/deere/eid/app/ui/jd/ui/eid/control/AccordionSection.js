(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.AccordionSection");
    jd.ui.eid.require("sap.ui.core.Element");

    /**
     * The AccordionSection is an element representing the properties of one section of a <i>jd.ui.eid.control.Accordion</i> control.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li> title : string (default: "") This is the text used for the title of the Accordion section.</li>
     * <li> deletable : boolean (default: false) Specifies whether the delete button on the Accordion section header should be available.</li>
     * <li> collapsed : boolean (default: false) Specifies whether the Accordion section is collapsed or open.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li> actions : sap.ui.core.Control Controls to be rendered next to the section title
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Element
     * @name jd.ui.eid.control.AccordionSection
     */
    sap.ui.core.Element.extend("jd.ui.eid.control.AccordionSection", /** @lends jd.ui.eid.control.AccordionSection */
    {
        metadata : {
            properties : {
                "title" : {
                    type : "string",
                    group : "Appearance",
                    defaultValue : null
                },
                "sectionId" : {
                    type : "string"
                }
            },
            aggregations : {
                "actions" : {
                    type : "sap.ui.core.Control",
                    singularName : "action",
                    multiple : true
                }
            }

        }

    });

})();
