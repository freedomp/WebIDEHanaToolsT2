(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.FilterDomainValueServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    /**
     * @class Service class for filter domain values. Remark: As this class doesn't deal with actual lists, there is no need to register to any events
     *        coming from the list binding.
     * 
     * @name jd.ui.eid.service.FilterDomainValueServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     * 
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.FilterDomainValueServiceFacade", /** @lends jd.ui.eid.service.FilterDomainValueServiceFacade */
    {

        /**
         * Get platform and associated product line filter domain values.
         * 
         * @memberOf jd.ui.eid.service.FilterDomainValueServiceFacade
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         */
        getPlatformAndProductLine : function(fnSuccess, fnError) {

            var sServicePath = "xs/dtc/filters/GetPlatformProdLineCombinations.xsjs";
            var sModelPath = "/DTCFilters/DomainValues";
            var oData = {};
            var fnGetData = function(oData) {
                return oData.Result;
            };
            var sModelFileName = "getPlatformAndProductLine_Response.json";

            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName);
        },

        /**
         * Get filter domain values for DTCs (based on the provided platform and product line).
         * 
         * @memberOf jd.ui.eid.service.FilterDomainValueServiceFacade
         * @param {string}
         *            sPlatformId the selected platform.
         * @param {string}
         *            sProductLineId the selected product line.
         * @param {function}
         *            [fnSuccess] callback that is executed when the service call is successful.
         * @param {function}
         *            [fnError] callback that is executed when the service call results in an error.
         * @param {object}
         *            [mParameters] an optional parameter map
         * @param {string}
         *            [mParameters.sAlternateTargetPath] an alternate target path to write the retrieved data to.
         */
        getDTCFilterDomainValues : function(sPlatformId, sProductLineId, fnSuccess, fnError, mParameters) {
            var sServicePath = "xs/dtc/filters/GetDependentFilters.xsjs";
            var sModelPath = "/DTCFilters/DomainValues";

            // Buffer product line and platform so that we can merge them back into the result afterwards.
            var aBufferedPlatform = this.oModel.getProperty(sModelPath + "/Platforms");

            // Overrule model path if provided. Do this after buffering the platforms cause we only want to keep them on the dashboard, they don't
            // change anyway.
            if (mParameters && mParameters.sAlternateTargetPath) {
                sModelPath = mParameters.sAlternateTargetPath;
            }

            // Compose custom payload
            var oData = {
                PlatformID : sPlatformId,
                ProductLineID : sProductLineId
            };

            var fnGetData = function(oData) {
                oData.Result.Platforms = aBufferedPlatform;
                jd.ui.eid.model.EidModel.TransformationHelper.moveEmptyDTCDomainValuesToEnd(oData.Result);
                return oData.Result;
            };

            var that = this;
            var _fnSuccess = function(oData) {
                // We need to initialize the manual PIN list domain values, otherwise the control won't work properly.
                if (!oData.ManualPINListItems) {
                    that.oModel.setProperty(sModelPath + "/ManualPINListItems", []);
                }

                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };

            var sModelFileName = "getDTCFilterDomainValues_Response.json";

            return this._retrieveRecord(sServicePath, sModelPath, oData, _fnSuccess, fnError, fnGetData, sModelFileName, false);
        }
    });

})();