jQuery.sap.require("nw.epm.refapps.products.manage.util.RemoveService");

var fnGetRemoveService = function(oBundle, fnShowErrorMessage) {
    // get V2 model using gMockServer.getModel(true)
    return new nw.epm.refapps.products.manage.util.RemoveService(gMockServer.getModel(true), /* global gMockServer */
    oBundle, fnShowErrorMessage);
};
// ////////
var fnDeleteProductOrProductDraftTest = function(bDraft) {
    var sDraft = bDraft ? " draft" : "";

    QUnit.module("Delete ONE product" + sDraft, {
        setup : function() {
            this.oI18nModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl : jQuery.sap.getModulePath("nw.epm.refapps.products.manage.i18n.i18n", ".properties")
            });
            // prepare the product draft DraftId-001-4QUnitTest will be deleted in the test
            gMockServer.getModel(true).create("/ProductDrafts", { // EXC_JSHINT_003
                Id : "DraftId-001-4QUnitTest"
            });
            // prepare the product ProductId-001-4QUnitTest will be deleted in the test
            gMockServer.getModel(true).create("/Products", { // EXC_JSHINT_003
                Id : "ProductId-001-4QUnitTest"
            });
        },

        teardown : function() {
            // stop the mock server, reset the test data
            gMockServer.stop(); // EXC_JSHINT_003
        }
    });

    QUnit.asyncTest("user confirms, deletion is successful", function(assert) {
        // prepare callback functions
        var fnShowErrorMessage = function() {
            assert.ok(false, "error message should not be called in this use case.");
        }, fnAfterDeleted = function(bDeleted) {
            if (bDeleted) {
                assert.ok(true, "product" + sDraft + " is deleted, fnAfterDeleted is called.");
                QUnit.start();
            }
        };
        var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
        assert.ok(oRemove, "get a RemoveService instance.");
        if (bDraft) {
            // call delete product draft DraftId-001-4QUnitTest (the draft is created in the setup)
            oRemove.deleteProductDraft("ProductDrafts('DraftId-001-4QUnitTest')", fnAfterDeleted);
        } else {
            // call delete product ProductId-001-4QUnitTest (the product is created in the setup)
            oRemove.deleteProduct("Products('ProductId-001-4QUnitTest')", fnAfterDeleted);
        }
        assert.ok(true, "delete product" + sDraft + " is triggered.");

        var aDialogs = sap.m.InstanceManager.getOpenDialogs();
        assert.ok(aDialogs.length > 0, "confirmation dialog is opened");
        aDialogs[0].getBeginButton().firePress(); // ok button is pressed
        assert.ok(true, "user confirms deletion.");
    });

    QUnit.asyncTest("delete one not-existing product" + sDraft + ", deletion fails", function(assert) {
        // prepare callback functions
        var fnShowErrorMessage = function() {
            assert.ok(true, "product" + sDraft + " cannot be deleted, error message will be shown.");
            QUnit.start();
        }, fnAfterDeleted = function(bDeleted) {
            if (!bDeleted) {
                assert.ok(false, "product" + sDraft + " cannot be deleted, fnAfterDeleted is called.");
            }
        };

        var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
        assert.ok(oRemove, "get a RemoveService instance.");

        if (bDraft) {
            // call delete product draft HT-xxxxx (the product draft should not be available in the mock server)
            oRemove.deleteProductDraft("ProductDrafts('HT-xxxxx')", fnAfterDeleted);
        } else {
            // call delete product HT-xxxxx (the product should not be available in the mock server)
            oRemove.deleteProduct("Products('HT-xxxxx')", fnAfterDeleted);
        }
        assert.ok(true, "delete product" + sDraft + " is triggered.");

        var aDialogs = sap.m.InstanceManager.getOpenDialogs();
        assert.ok(aDialogs.length > 0, "confirmation dialog is opened");
        aDialogs[0].getBeginButton().firePress(); // ok button is pressed
        assert.ok(true, "user confirms deletion.");
    });

    QUnit.asyncTest("user cancels the deletion", function(assert) {
        // prepare callback functions
        var fnShowErrorMessage = function() {
            // user cancels the deletion, no error message should be shown
            assert.ok(false, "error message should not be called in this use case.");
        }, fnAfterDeleted = function() {
            // user cancels the deletion, no fnAfterDeleted should be called
            assert.ok(false, "product" + sDraft + " is deleted, fnAfterDeleted is called.");
        }, fnCancelDelete = function() {
            // user cancels the deletion, fnCancelDelete should be called
            assert.ok(true, "product" + sDraft + " is deleted, fnCancelDelete is called.");
            QUnit.start();
        };

        var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
        assert.ok(oRemove, "get a RemoveService instance.");
        if (bDraft) {
            // call delete product draft DraftId-001-4QUnitTest (the draft is created in the setup)
            oRemove.deleteProductDraft("ProductDrafts('DraftId-001-4QUnitTest')", fnAfterDeleted, fnCancelDelete);
        } else {
            // call delete product ProductId-001-4QUnitTest (the product is created in the setup)
            oRemove.deleteProduct("Products('ProductId-001-4QUnitTest')", fnAfterDeleted);
        }
        assert.ok(true, "delete product" + sDraft + " is triggered.");

        var aDialogs = sap.m.InstanceManager.getOpenDialogs();
        assert.ok(aDialogs.length > 0, "confirmation dialog is opened");
        aDialogs[0].attachAfterClose(function() {
            if (!bDraft) {
                QUnit.start();
            }
        });
        aDialogs[0].getEndButton().firePress(); // cancel button is pressed
        assert.ok(true, "user cancels the deletion.");
    });
};

// ////////
var fnDeleteProductOrProductDraftWithoutConfirmationTest = function(bDraft) {
    var sDraft = bDraft ? " draft" : "";
    QUnit.module("Delete ONE product" + sDraft + " without confirmation dialog", {
        setup : function() {
            this.oI18nModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl : jQuery.sap.getModulePath("nw.epm.refapps.products.manage.i18n.i18n", ".properties")
            });
            // prepare the product draft DraftId-001-4QUnitTest will be deleted in the test
            gMockServer.getModel(true).create("/ProductDrafts", { // EXC_JSHINT_003
                Id : "DraftId-001-4QUnitTest"
            });
            // prepare the product ProductId-001-4QUnitTest will be deleted in the test
            gMockServer.getModel(true).create("/Products", { // EXC_JSHINT_003
                Id : "ProductId-001-4QUnitTest"
            });
        },

        teardown : function() {
            // stop the mock server, reset the test data
            gMockServer.stop(); // EXC_JSHINT_003
        }
    });

    QUnit.asyncTest("deletion without confirmation dialog", function(assert) {
        // prepare callback functions
        var fnShowErrorMessage = function() {
            assert.ok(false, "error message should not be called in this use case.");
        }, fnAfterDeleted = function(bDeleted) {
            if (bDeleted) {
                assert.ok(true, "product" + sDraft + " is deleted, fnAfterDeleted is called.");
                QUnit.start();
            }
        };

        var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
        assert.ok(oRemove, "get a RemoveService instance.");
        if (bDraft) {
            // call delete product draft DraftId-001-4QUnitTest (the draft is created in the setup)
            oRemove.deleteEntityWithoutConfirmationDialog("ProductDrafts('DraftId-001-4QUnitTest')", fnAfterDeleted);
        } else {
            // call delete product ProductId-001-4QUnitTest (the product is created in the setup)
            oRemove.deleteEntityWithoutConfirmationDialog("Products('ProductId-001-4QUnitTest')", fnAfterDeleted);
        }
        assert.ok(true, "delete product" + sDraft + " is triggered.");

        var aDialogs = sap.m.InstanceManager.getOpenDialogs();
        assert.ok(aDialogs.length === 0, "there is no confirmation dialog opened.");
    });
};

// test method deleteProduct
fnDeleteProductOrProductDraftTest(false);
// test method deleteProductDraft
fnDeleteProductOrProductDraftTest(true);
// test method deleteEntityWithoutConfirmationDialog
fnDeleteProductOrProductDraftWithoutConfirmationTest(false);
// test method deleteEntityWithoutConfirmationDialog
fnDeleteProductOrProductDraftWithoutConfirmationTest(true);

QUnit.module("Delete Products", {
    setup : function() {
        this.oI18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl : jQuery.sap.getModulePath("nw.epm.refapps.products.manage.i18n.i18n", ".properties")
        });
        // prepare the product ProductId-001-4QUnitTest will be deleted in the test
        gMockServer.getModel(true).create("/Products", { // EXC_JSHINT_003
            Id : "ProductId-001-4QUnitTest"
        });
        // prepare the product ProductId-002-4QUnitTest will be deleted in the test
        gMockServer.getModel(true).create("/Products", { // EXC_JSHINT_003
            Id : "ProductId-002-4QUnitTest"
        });
    },

    teardown : function() {
        // stop the mock server, reset the test data
        gMockServer.stop(); // EXC_JSHINT_003

        // close the dialog if there is any opened
        var aDialogs = sap.m.InstanceManager.getOpenDialogs();
        if (aDialogs.length > 0) {
            aDialogs[0].getBeginButton().firePress(); // ok button is pressed
        }
    }
});

QUnit.asyncTest("handle empty list", function(assert) {
    // prepare callback functions
    var fnShowErrorMessage = function() {
        // no error message should be shown
        assert.ok(false, "error message should not be called in this use case.");
    }, fnAfterDeleted = function() {
        // no fnAfterDeleted function should be called
        assert.ok(false, "products are deleted, fnAfterDeleted is called.");
    };

    var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
    assert.ok(oRemove, "get a RemoveService instance.");
    oRemove.deleteProducts([], fnAfterDeleted);
    assert.ok(true, "delete products with empty list is triggered.");
    var aDialogs = sap.m.InstanceManager.getOpenDialogs();
    assert.ok(aDialogs.length === 0, "there is no confirmation dialog opened.");
    QUnit.start();
});

QUnit.asyncTest("delete 2 products successfully", function(assert) {
    // prepare callback functions
    var fnShowErrorMessage = function() {
        // no error message should be shown
        assert.ok(false, "error message should not be called in this use case.");
    }, fnAfterDeleted = function(bDelete) {
        if (bDelete) {
            // fnAfterDeleted function should be called and the deletion should be successful
            assert.ok(true, "products are deleted successfully, fnAfterDeleted is called.");
            QUnit.start();
        } else {
            // fnAfterDeleted function should be called, but the deletion should not be failed
            assert.ok(false, "products are deleted NOT successfully, fnAfterDeleted is called.");
        }
    };

    var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
    assert.ok(oRemove, "get a RemoveService instance.");
    // "Products('ProductId-001-4QUnitTest')", "Products('ProductId-002-4QUnitTest')" are created in the setup
    oRemove.deleteProducts([ "Products('ProductId-001-4QUnitTest')", "Products('ProductId-002-4QUnitTest')" ],
            fnAfterDeleted);
    assert.ok(true, "deleting products is triggered.");

    var aDialogs = sap.m.InstanceManager.getOpenDialogs();
    assert.ok(aDialogs.length > 0, "confirmation dialog is opened");
    aDialogs[0].getBeginButton().firePress(); // ok button is pressed
    assert.ok(true, "user confirms deletion.");
});

QUnit.asyncTest("delete 2 products NOT totally successful", function(assert) {
    // prepare callback functions
    var fnShowErrorMessage = function() {
        // no error message should be shown
        assert.ok(false, "error message should not be called in this use case.");
    }, fnAfterDeleted = function(bDelete) {
        if (bDelete) {
            // fnAfterDeleted function should be called, but the deletion is failed
            assert.ok(false, "products are deleted successfully, fnAfterDeleted is called.");
        } else {
            // fnAfterDeleted function should be called, and the deletion is failed
            assert.ok(true, "products are deleted NOT successfully, fnAfterDeleted is called.");
            QUnit.start();
        }
    };

    var oRemove = fnGetRemoveService(this.oI18nModel.getResourceBundle(), fnShowErrorMessage);
    assert.ok(oRemove, "get a RemoveService instance.");
    // "Products('ProductId-001-4QUnitTest')" is created in the setup, "Products('HT-100xxx1')" is not available
    oRemove.deleteProducts([ "Products('ProductId-001-4QUnitTest')", "Products('HT-100xxx1')" ], fnAfterDeleted);
    assert.ok(true, "deleting products is triggered.");

    var aDialogs = sap.m.InstanceManager.getOpenDialogs();
    assert.ok(aDialogs.length > 0, "confirmation dialog is opened");
    aDialogs[0].getBeginButton().firePress(); // ok button is pressed
    assert.ok(true, "user confirms deletion.");
});
