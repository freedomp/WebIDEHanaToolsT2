(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.Dialog");
    jd.ui.eid.require("sap.ui.commons.Dialog");

    /**
     * Constructor of a Custom Dialog which extend the standard Dialog.
     * 
     * Accepts an object literal <code>mSettings</code> that defines initial property values, aggregated and associated objects as well as event
     * handlers.
     * 
     * If the name of a setting is ambiguous (e.g. a property has the same name as an event), then the framework assumes property, aggregation,
     * association, event in that order. To override this automatic resolution, one of the prefixes "aggregation:", "association:" or "event:" can be
     * added to the name of the setting (such a prefixed name must be enclosed in single or double quotes).
     * 
     * The supported settings are:
     * <ul>
     * <li>Properties
     * <ul>
     * <li>{@link #getWidth width} : sap.ui.core.CSSSize</li>
     * <li>{@link #getHeight height} : sap.ui.core.CSSSize</li>
     * <li>{@link #getScrollLeft scrollLeft} : int (default: 0)</li>
     * <li>{@link #getScrollTop scrollTop} : int (default: 0)</li>
     * <li>{@link #getTitle title} : string (default: '')</li>
     * <li>{@link #getApplyContentPadding applyContentPadding} : boolean (default: true)</li>
     * <li>{@link #getShowCloseButton showCloseButton} : boolean (default: true)</li>
     * <li>{@link #getResizable resizable} : boolean (default: true)</li>
     * <li>{@link #getMinWidth minWidth} : sap.ui.core.CSSSize</li>
     * <li>{@link #getMinHeight minHeight} : sap.ui.core.CSSSize</li>
     * <li>{@link #getMaxWidth maxWidth} : sap.ui.core.CSSSize</li>
     * <li>{@link #getMaxHeight maxHeight} : sap.ui.core.CSSSize</li>
     * <li>{@link #getContentBorderDesign contentBorderDesign} : sap.ui.commons.enums.BorderDesign (default: sap.ui.commons.enums.BorderDesign.None)</li>
     * <li>{@link #getModal modal} : boolean (default: false)</li>
     * <li>{@link #getAccessibleRole accessibleRole} : sap.ui.core.AccessibleRole (default: sap.ui.core.AccessibleRole.Dialog)</li>
     * <li>{@link #getKeepInWindow keepInWindow} : boolean (default: false)</li>
     * <li>{@link #getAutoClose autoClose} : boolean (default: false)</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>{@link #getButtons buttons} : sap.ui.core.Control[]</li>
     * <li>{@link #getContent content} : sap.ui.core.Control[]</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>{@link #getDefaultButton defaultButton} : string | sap.ui.commons.Button</li>
     * <li>{@link #getInitialFocus initialFocus} : string | sap.ui.core.Control</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>{@link sap.ui.commons.Dialog#event:closed closed} : fnListenerFunction or [fnListenerFunction, oListenerObject] or [oData,
     * fnListenerFunction, oListenerObject]</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class An interactive window appearing on request displaying information to the user. The API supports features such as popups with fixed
     *        sizes, popups with unlimited width, scrolling bars for large windows, and control nesting (for example, a drop-down list can be included
     *        in the window).
     * @extends sap.ui.commons.Dialog
     * 
     * @constructor
     * @public
     * @name jd.ui.eid.control.Dialog
     */
    sap.ui.commons.Dialog.extend("jd.ui.eid.control.Dialog", /** @lends jd.ui.eid.control.Dialog */
    {
        /**
         * Attaches event handlers to DOM elements and triggers adjustment of the header.
         */
        onAfterRendering : function() {
            // Call the method of the parent
            if (sap.ui.commons.Dialog.prototype.onAfterRendering) {
                sap.ui.commons.Dialog.prototype.onAfterRendering.apply(this, arguments);
            }

            /*
             * Calculate the height of the dialog
             */
            // First calculate the fixed height value
            var iMarginHeight = 62;
            var iHeaderHeight = 19;
            var iFixHeight = iMarginHeight + iHeaderHeight;

            // Than get the variable content height
            var iContentHeight = 0;
            if (this.getContent().length) {
                iContentHeight = this.getContent()[0].$().height();
            }

            // Check whether some buttons have been attached
            var iButtonHeight = 0;
            if (this.getButtons().length) {
                iButtonHeight = this.getButtons()[0].$().height();
            }

            // Sum-up the total height and set it as the total height of dialog
            var iVariableHeight = iContentHeight + iButtonHeight;
            var iTotalHeight = iVariableHeight + iFixHeight;

            if (iTotalHeight != this.$().height()) {
                this.$().height(iTotalHeight);
            }
        },

        renderer : "jd.ui.eid.control.DialogRenderer"
    });
})();
