(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.BaseServiceFacade");

    /**
     * Constructor for a new BaseServiceFacade.
     * 
     * @param {string}
     *            sURL Server URL as string. This URL should refer to the server, not to a specific service.
     * @param {string}
     *            sLocalFolderPath Path to folder where all static JSON files are stored. If parameter "bUseTestData" equals true than the data will
     *            be retrieved from files of this folder.
     * @param {sap.ui.model.Model}
     *            oModel Object of class jd.ui.eid.model.EidModel (if useTestData = false) or sap.ui.model.json.JSONModel (if useTestData = true).
     * @param {boolean}
     *            bUseTestData Object of class Boolean. If false, the service connectivity will be used. Otherwise data will be retrieved from local
     *            files of folder sLocalFolderPath.
     * 
     * @class Facade for the backend service communication. This class serves as a base class for specific service implementations. It supports list
     *        bindings that require a request for actions such as sorting, filtering, or paging.<br>
     *        The following events are are broadcasted via the event bus of the UI5 core:
     *        <ul>
     *        <li>EidModel::fetchingData : fired when fetching data.
     *        <ul>
     *        <li>sPath : string The binding path.</li>
     *        </ul>
     *        </li>
     *        <li>EidModel::dataFetched : fired when data has been fetched.
     *        <ul>
     *        <li>sPath : string The binding path.</li>
     *        </ul>
     *        </li>
     *        </ul>
     * @abstract
     * @extends sap.ui.base.Object
     * @name jd.ui.eid.service.BaseServiceFacade
     */

    sap.ui.base.Object.extend("jd.ui.eid.service.BaseServiceFacade", /** @lends jd.ui.eid.service.BaseServiceFacade */
    {

        constructor : function(sURL, sLocalFolderPath, oModel, bUseTestData, sXSRFToken) {
            // call parent constructor
            sap.ui.base.Object.apply(this, arguments);

            // Initialize the member attributes
            /*
             * This member attribute saves the last oData value which was send to the server (i.e. the custom filter values) Due to the fact that one
             * oData value relates to a specific binding, all oData values are saved grouped by their binding path For example: _oLastData["/DTCList"] =
             * oData
             */
            this._oLastData = {};
            this.oModel = oModel;
            this.bUseTestData = bUseTestData;
            this.sXSRFToken = sXSRFToken;
            this.serverURL = sURL;
            this.sLocalFolderPath = sLocalFolderPath;
            this.bCalledFromBinding = false; // Flag which indicates if the service object was
            // called by the binding class
            this.oEventProvider = new sap.ui.base.EventProvider(); // Will be used to send events
            // from the service object to
            // listeners/handlers (mainly
            // defined in controllers)

            // Register event handlers for events which are fired by the EidModelListBinding objects
            // This allows the service class to act on sorting/filtering/paging of the
            // EidModelListBinding object
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'listBindingChanged', $.proxy(this.handleListBindingChanged, this)); // Called
            // while
            // sorting/filtering was applied
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataRequested', $.proxy(this.handleDataRequested, this)); // Called while paging was
            // applied
        },

        /**
         * Define function to store the last oData value which was send to the server (i.e. the custom filter values).
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sPath Binding path as string.
         * @param {object}
         *            oData Object that was send at last inside the service request (in the "Data" property) to the server (i.e. the custom filter
         *            values).
         * 
         * @public
         */
        setLastData : function(sPath, oData) {
            this._oLastData[sPath] = oData;
        },

        /**
         * Define handler function to reset the model after the event listBindingChanged was fired.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sChannelId Channel of the event as string. This is used to group events.
         * @param {string}
         *            sEventId Id of the event as string.
         * @param {object}
         *            oData Event parameters as object. Contains the listbinding as a property of class jd.ui.eid.model.EidModelListBinding.
         * 
         * @protected
         */
        handleListBindingChanged : function(sChannelId, sEventId, oData) {
            // Set flag to indicate that data was changed (i.e. by sorting/filtering) in the binding
            this.bCalledFromBinding = true;

            // Call hook method (override in subclass)
            this._handleListBindingChanged(oData.oListBinding);
        },

        /**
         * Define handler function to update the model after the event dataRequested was fired.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sChannelId Channel of the event as string. This is used to group events.
         * @param {string}
         *            sEventId Id of the event as string.
         * @param {object}
         *            oData Event parameters as object. Contains the listbinding as a property of class jd.ui.eid.model.EidModelListBinding.
         * 
         * @protected
         */
        handleDataRequested : function(sChannelId, sEventId, oData) {
            // Set flag to indicate that further data was requested (i.e. by paging) in the binding
            this.bCalledFromBinding = true;

            // Call hook method (override in subclass)
            this._handleDataRequested(oData.oListBinding);
        },

        /**
         * Hook function for the handleBindingChanged event handler. Should be overridden in the subclass.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * @param {object}
         *            oListBinding Object of class jd.ui.eid.model.EidModelListBinding.
         * 
         * @protected
         */
        _handleListBindingChanged : function(oListBinding) {
        },

        /**
         * Hook function for the handleDataRequest event handler. Should be overridden in the subclass.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * @param {object}
         *            oListBinding Object of class jd.ui.eid.model.EidModelListBinding.
         * 
         * @protected
         */
        _handleDataRequested : function(oListBinding) {
        },

        /**
         * Attach by a callback function to the event "requestFailed".
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * @param {function}
         *            fnCallback Callback takes no parameter, returns undefined. Will be used as a event handler for the event requestFailed.
         * 
         * @public
         */
        attachRequestFailed : function(fnCallback) {
            this.oEventProvider.attachEvent("requestFailed", fnCallback);
        },

        /**
         * Detach from the event "requestFailed".
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * @param {function}
         *            fnCallback Callback takes no parameter, returns undefined. The event handler will be detached from the event.
         * 
         * @public
         */
        detachRequestFailed : function(fnCallback) {
            this.oEventProvider.detachEvent("requestFailed", fnCallback);
        },

        /**
         * Define function to retrieve list values and reset the model.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sServicePath Path to the service as string. This value will be concatenated with the serverURL that was set in the constructor.
         * @param {function(oData)}
         *            fnSuccess Callback takes the server response when the server request succeeds, returns undefined.
         * @param {function(XMLHttpRequest,
         *            textStatus, errorThrown)} fnError Callback takes the server response when the server request fails, returns undefined.
         * @param {function(oData)}
         *            fnGetData Callback takes the plain server response. Returns the relevant object with the properties Count, Top, Skip, Records.
         * @param {object}
         *            oListBinding Object of class jd.ui.eid.model.EidModelListBinding.
         * @param {object}
         *            [oData] Object that will be send inside the service request (in the "Data" property) to the server (i.e. the custom filter
         *            values). If this parameter won't be set, the last object will be used which is stored inside _oLastData.
         * @param {string}
         *            [sModelDataFileName] Name of file as string that contains the static JSON data.
         * 
         * @protected
         */
        _retrieveList : function(sServicePath, fnSuccess, fnError, fnGetData, oListBinding, oData, sModelDataFileName) {
            $.sap.log.debug("services.BaseServiceFacade->_retrieveList");

            // Set path binding value
            var sPath = oListBinding.sPath;

            // Check if the server will be requested
            if (this.bUseTestData == false) {
                // Check if oData parameter was set, to explicitly retrieve data from the beginning
                // (This reset is also done inside of the EidModelListBinding if filtering/sorting
                // was applied)
                if (!this.bCalledFromBinding && oData) {
                    // => If "true" -> Reset top/skip values
                    oListBinding.reset();

                    // Save the latest oData values that was send to server
                    this.setLastData(sPath, oData);
                }

                // Read last oData value
                oData = this._oLastData[sPath];
                // Note : It is assumed that oData will never be undefined. This is because for lists there is always atleast a search term that is
                // passed to the backend, and in cases where the binding is refreshed, a request for the list would already have been fired (and
                // stored in this._oLastData). oData is later serialized to a JSON string to form the request payload. JSON.stringify will ignore the
                // 'Data' attribute if it is undefined.
                if (oData === undefined) {
                    return;
                }

                // Set Payload, this is the post body of our AJAX request
                var oPayload = {};
                oPayload.Filters = oListBinding.aFilters; // Set the listbinding filtering values
                oPayload.Sorters = oListBinding.aSorters; // Set the listbinding sorting values
                oPayload.Top = oListBinding.iTop; // Set the index, which indicates how many
                // records should be retrieved from server
                oPayload.Skip = oListBinding.iSkip; // Set the index, which indicate how many
                // records should be skipped by server
                oPayload.Data = oData; // Send additional data (i.e. the custom filter values)

                // Define an additional success function
                // This function will be called additionally to the default success function,
                // when the AJAX call succeeds
                var that = this;
                var _fnSuccess = function(oData) {
                    // Get the data of the server response by the fnGetData function
                    // => The details of the specific server response are encapsulated into this
                    // function
                    // This function just needs to assure that the returned object contains the
                    // parameters Count, Top, Skip, Records
                    var oResponse = fnGetData(oData);

                    // Set the actual data count in the listbinding -> This is needed to calculate
                    // the right number of pages for the paging functionality of the listbinding
                    // This is the first thing we do so that if we set the property later, formatters that access the length of the binding have
                    // access to the correct count.
                    oListBinding.setLength(oResponse.Count);

                    // Check if the model already contains the property
                    if (that.oModel.getProperty(sPath) !== undefined) {
                        if (oPayload.Skip != 0) {
                            // Merge old and additional new data
                            var oDataMerge = that.oModel.getProperty(sPath).concat(oResponse.Records);
                            // Update model
                            that.oModel.setProperty(sPath, oDataMerge);
                        } else {
                            // Set the values to the model
                            that.oModel.setProperty(sPath, oResponse.Records);
                        }
                    } else {
                        $.sap.log.fatal("BindingPath: '" + sPath + "' could not be found in the model.");
                    }

                    // Tell everyone out there via the event bus that data has been fetched for the given path.
                    sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                        sPath : oListBinding.getPath()
                    });

                    // Call the nested success function if it was set
                    if (fnSuccess) {
                        fnSuccess(oData);
                    }

                };

                // Define an additional error function
                // This function will be called additionally to the default error function,
                // when the AJAX call fails
                var that = this;
                var _fnError = function(XMLHttpRequest, textStatus, errorThrown) {
                    sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                        sPath : oListBinding.getPath()
                    });

                    // Check if data was changed (i.e. by sorting/filtering) in the binding
                    if (that.bCalledFromBinding) {
                        // Fire "requestFailed" and notify all listeners about the event
                        that.oEventProvider.fireEvent("requestFailed");
                    } else if (fnError) // If data was not changed in the binding => check if an
                    // additional error function was passed
                    {
                        fnError(XMLHttpRequest, textStatus, errorThrown);
                    }

                };

                sap.ui.getCore().getEventBus().publish('EidModel', 'fetchingData', {
                    sPath : oListBinding.getPath()
                });
                // Send request to server
                return this._executeAjax(sServicePath, _fnSuccess, _fnError, oPayload, sModelDataFileName);
            } else { // Use the local files

                // Define an additional success function
                var that = this;
                var _fnSuccess = function(oData) {
                    sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                        sPath : oListBinding.getPath()
                    });

                    // Set response data
                    var oResponse = fnGetData(oData);

                    // Update the length
                    oListBinding.setLength(oResponse.Records.length);

                    // Set the data to the model
                    that.oModel.setProperty(sPath, oResponse.Records);

                    // Tell everyone out there via the event bus that data has been fetched for the given path.
                    sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                        sPath : oListBinding.getPath()
                    });

                    // Call the nested success function if it was set
                    if (fnSuccess) {
                        fnSuccess(oData);
                    }
                };

                sap.ui.getCore().getEventBus().publish('EidModel', 'fetchingData', {
                    sPath : oListBinding.getPath()
                });
                // Send request to server
                return this._executeAjax(sServicePath, _fnSuccess, fnError, null, sModelDataFileName);
            }
        },

        /**
         * Method to retrieve a single record from XSE and assign it to the given path in the model.
         * 
         * @param {string}
         *            sServicePath Path to the service as string. This value will be concatenated with the serverURL that was set in the constructor.
         * @param {string}
         *            sModelPath The model path to assign the return value of fnGetData to.
         * @param {object}
         *            [oData] Object that will be send inside the service request (in the "Data" property) to the server.
         * @param {function(oData)}
         *            fnSuccess Callback takes the server response when the server request succeeds, returns undefined.
         * @param {function(XMLHttpRequest,
         *            textStatus, errorThrown)} fnError Callback takes the server response when the server request fails, returns undefined.
         * @param {function(oData)}
         *            fnGetData Callback takes the plain server response. Returns the relevant object to be assigned to the given model path.
         * @param {string}
         *            [sModelDataFileName] Name of file as string that contains the static JSON data.
         * @param {boolean}
         *            [bMerge] True if data should be merged, then only new properties of the object associated with the given model path will be
         *            saved and old properties remain. False otherwise.
         * 
         * @protected
         */
        _retrieveRecord : function(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName, bMerge) {
            // merge when calling setobject
            var oModel = this.oModel;
            var _fnSuccess = function(oData) {
                sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                    sPath : sModelPath
                });

                var oMergedData;
                if (bMerge === true) {
                    // If data is merged, previous properties of sModelPath remain unchanged. This
                    // is not a deep merge functionality.
                    var oCurrentData = oModel.getProperty(sModelPath);
                    if (!oCurrentData) {
                        oCurrentData = {};
                    }
                    oMergedData = jQuery.extend(true, fnGetData(oData), oCurrentData);
                } else {
                    oMergedData = fnGetData(oData);
                }
                oModel.setProperty(sModelPath, oMergedData);

                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };

            var _fnError = function(XMLHttpRequest, textStatus, errorThrown) {
                sap.ui.getCore().getEventBus().publish('EidModel', 'dataFetched', {
                    sPath : sModelPath
                });

                if (fnError) {
                    fnError(XMLHttpRequest, textStatus, errorThrown);
                }
            };

            var oPayload = {
                Data : oData
            };

            sap.ui.getCore().getEventBus().publish('EidModel', 'fetchingData', {
                sPath : sModelPath
            });

            // Call _executeAjax and return the $.ajax promise.
            return this._executeAjax(sServicePath, _fnSuccess, _fnError, oPayload, sModelFileName);
        },

        /**
         * Define function for pushing data to a backend service. This function should be used if no data will be retrieved back from server, except
         * messages.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sServicePath Path to the service as string. This value will be concatenated with the serverURL that was set in the constructor.
         * @param {function(oData)}
         *            [fnSuccess] Callback takes the server response when the server request succeeds, returns undefined.
         * @param {function(XMLHttpRequest,
         *            textStatus, errorThrown)} [fnError] Callback takes the server response when the server request fails, returns undefined.
         * @param {object}
         *            [oData] Object that will be send inside the data property of the request to the server.
         * @param {string}
         *            [sModelDataFileName] Name of file as string that contains the static JSON data. This value will be concatenated with the
         *            sLocalFolderPath that was set in the constructor.
         * 
         * @protected
         */
        _send : function(sServicePath, fnSuccess, fnError, oData, sModelDataFileName) {
            $.sap.log.debug("services.BaseServiceFacade->_send");
            var oPayload = {};
            oPayload.Data = oData;
            this._executeAjax(sServicePath, fnSuccess, fnError, oPayload, sModelDataFileName);
        },

        /*
         * Map that holds the ajax request objects by service path
         */
        _mRequestsByServicePathCache : {},

        /**
         * Cancels pending requests for the given path
         * 
         * @param {string}
         *            sServicePath the path to which the service would write the data upon return.
         */
        cancelPendingRequestForServicePath : function(sServicePath) {
            if (this._mRequestsByServicePathCache[sServicePath]) {
                var oXhr = this._mRequestsByServicePathCache[sServicePath];
                oXhr.abort();
            }
        },

        /**
         * Define function for calling a backend service.
         * 
         * @memberOf jd.ui.eid.service.BaseServiceFacade
         * 
         * @param {string}
         *            sServicePath Path to the service as string. This value will be concatenated with the serverURL that was set in the constructor.
         * @param {function(oData)}
         *            [fnSuccess] Callback takes the server response when the server request succeeds, returns undefined.
         * @param {function(XMLHttpRequest,
         *            textStatus, errorThrown)} [fnError] Callback takes the server response when the server request fails, returns undefined.
         * @param {object}
         *            [oPayload] Object that will be send inside the service request to the server.
         * @param {string}
         *            [sModelDataFileName] Name of file as string that contains the static JSON data. This value will be concatenated with the
         *            sLocalFolderPath that was set in the constructor.
         * @param {boolean}
         *            bNoAbort if true, the service request will not be abort if requested a second time with the same service path
         * @returns {jqXHR} the jQuery ajax request.
         * @protected
         */
        _executeAjax : function(sServicePath, fnSuccess, fnError, oPayload, sModelDataFileName, bNoAbort) {
            // If there is a request for the same service path pending, we abort it.
            if (!bNoAbort) {
                this.cancelPendingRequestForServicePath(sServicePath);
            }
            // Check if payload was set and change it to a string values
            var sPayload = "";
            if (oPayload !== undefined) {
                sPayload = encodeURIComponent(JSON.stringify(oPayload));
            }

            $.sap.log.debug("Requesting service path '" + sServicePath + "'");
            // $.sap.log.debug(sPayload);

            var sAjaxUrl = null;
            var oAjax;

            // If backend connectivity should be used
            if (this.bUseTestData == false) {
                sAjaxUrl = this.serverURL + sServicePath;

                // Send AJAX post request to server
                var that = this;
                var sMyServicePath = sServicePath;
                this._mRequestsByServicePathCache[sServicePath] = oAjax = $.ajax({ // store ajax request in request cache.
                    type : "POST",
                    url : sAjaxUrl,
                    data : sPayload,
                    beforeSend : function(xhr) {
                        xhr.setRequestHeader("X-CSRF-Token", that.sXSRFToken);
                    },
                    success : function(oData, textStatus, jqXHR) {
                        $.sap.log.debug("Success: The server send the following response: " + JSON.stringify(oData));

                        // Call nested function
                        if (fnSuccess) {
                            fnSuccess(oData);
                        }
                        that.bCalledFromBinding = false;

                        // Reset request cache
                        that._mRequestsByServicePathCache[sMyServicePath] = null;
                    },
                    error : function(XMLHttpRequest, textStatus, errorThrown) {
                        if (textStatus == 'abort') {
                            // The request has been aborted, probably by the facade because a new request to the same URL has been triggered, so we
                            // don't need to do anything.
                            $.sap.log.debug("Request to service path '" + sMyServicePath + "' aborted");
                        } else {
                            $.sap.log.fatal("Error: The following problem occurred: " + textStatus, XMLHttpRequest.responseText + ","
                                    + XMLHttpRequest.status + "," + XMLHttpRequest.statusText);

                            // Call nested function
                            if (fnError) {
                                fnError(XMLHttpRequest, textStatus, errorThrown);
                            }
                            that.bCalledFromBinding = false;
                        }

                        // Reset request cache
                        that._mRequestsByServicePathCache[sMyServicePath] = null;
                    },
                    dataType : "json"
                }, this);

            } else // Else read data from local file
            {
                if (sModelDataFileName === undefined) {
                    sModelDataFileName = 'template.json';
                }
                sAjaxUrl = this.sLocalFolderPath + sModelDataFileName;

                // Send AJAX get request to retrieved data from file
                oAjax = $.ajax({
                    type : "GET",
                    url : sAjaxUrl,
                    success : function(oData, textStatus, jqXHR) {
                        $.sap.log.debug("Success: The server send the following response: " + JSON.stringify(oData));
                        if (fnSuccess) {
                            fnSuccess(oData);
                        }
                    },
                    error : function(XMLHttpRequest, textStatus, errorThrown) {
                        $.sap.log.fatal("Error: The following problem occurred: " + textStatus, XMLHttpRequest.responseText + ","
                                + XMLHttpRequest.status + "," + XMLHttpRequest.statusText);
                        if (fnError) {
                            fnError(XMLHttpRequest, textStatus, errorThrown);
                        }
                    },
                    dataType : "json"
                }, this);
            }

            if (sAjaxUrl !== undefined) {
                $.sap.log.debug("Request send to URL: " + sAjaxUrl);
            }

            return oAjax;
        }
    });

})();