(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.URLHandler");

    module("jd.ui.eid.common.URLHandler", {
        setup : function() {

        },
        teardown : function() {

        }
    });
    
    test("generateURL appends param to a short URL", function() {
        var sExpectedResult = encodeURIComponent("HTTP://sap.com/test?evidencePackage=4711");      
        var sResult = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL("4711", "HTTP://sap.com/test");       
        equal(sResult, sExpectedResult);
    });
    
    test("generateURL appends param to a long URL", function() {
        var sExpectedResult = encodeURIComponent("HTTP://sap.com/test?foo=23&evidencePackage=4711");      
        var sResult = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL("4711", "HTTP://sap.com/test?foo=23");       
        equal(sResult, sExpectedResult);
    });
    
    test("generateURL replaces param in a short URL", function() {
        var sExpectedResult = encodeURIComponent("HTTP://sap.com/test?evidencePackage=4712");      
        var sResult = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL("4712", "HTTP://sap.com/test?evidencePackage=4711");       
        equal(sResult, sExpectedResult);
    });
    
    test("generateURL replaces param at the end of a long URL", function() {
        var sExpectedResult = encodeURIComponent("HTTP://sap.com/test?foo=bar&evidencePackage=4712");      
        var sResult = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL("4712", "HTTP://sap.com/test?foo=bar&evidencePackage=4711");       
        equal(sResult, sExpectedResult);
    });
    
    test("generateURL replaces param in the middle of along URL", function() {
        var sExpectedResult = encodeURIComponent("HTTP://sap.com/test?evidencePackage=4712&foo=bar");      
        var sResult = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL("4712", "HTTP://sap.com/test?evidencePackage=4711&foo=bar");       
        equal(sResult, sExpectedResult);
    });

})();