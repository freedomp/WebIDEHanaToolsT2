SAP internal development: SAP Fiori Reference Application to demonstrate a shop scenario on the EPM model (full screen application)

For documentation on Fiori Reference Apps, see
https://wiki.wdf.sap.corp/wiki/display/refapps/Fiori+Reference+Applications+Home