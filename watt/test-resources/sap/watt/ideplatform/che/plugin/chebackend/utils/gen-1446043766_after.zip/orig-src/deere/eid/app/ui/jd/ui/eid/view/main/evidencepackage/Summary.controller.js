(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.chart.ChartHelper");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EPSummaryChartController");

    /**
     * @class
     * <p>
     * The Evidence Package Summary View is used to display the charts of Evidence Summary charts.
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @augments jd.ui.eid.view.main.shared.EPSummaryChartController
     * @name jd.ui.eid.view.main.evidencepackage.Summary
     */
    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.Summary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.EPSummaryChartController, /** @lends jd.ui.eid.view.main.evidencepackage.Summary */
            {

                _bRefreshRequired : true,

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 */
                onInit : function() {
                    this.getView().addStyleClass("jdUiEidViewEvidencePackageSummary");

                    // Init merge controllers
                    this.initEPSummaryChartsInFragment();

                    // Subcribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.subscribe('EvidencePackage', 'DTCRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.subscribe('EvidencePackage', 'DTACCaseRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.subscribe('EvidencePackage', 'warrantyClaimRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.subscribe('EvidencePackageView', 'contextChanged', this.fetchEvidencePackageSummary, this);
                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 */
                onAfterRendering : function() {
                    this.onEPSummaryChartControllerAfterRendering();

                    if (this._bRefreshRequired) {
                        this._bRefreshRequired = false;
                        this.fetchEvidencePackageSummary();
                    }
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 */
                onExit : function() {
                    // Unsubcribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.unsubscribe('EvidencePackage', 'DTCRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.unsubscribe('EvidencePackage', 'DTACCaseRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.unsubscribe('EvidencePackage', 'warrantyClaimRemoved', this.fetchEvidencePackageSummary, this);
                    oEventBus.unsubscribe('EvidencePackageView', 'contextChanged', this.fetchEvidencePackageSummary, this);

                    // Destroy merge controllers
                    this.exitEPSummaryChartController();
                },

                /**
                 * Fetches the summary data.
                 */
                fetchEvidencePackageSummary : function() {
                    if (this.isVisible()) {
                        var that = this;
                        var oModel = sap.ui.getCore().getModel();
                        var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");

                        this.getView().getContent()[0].setBusy(true);
                        this.getServiceFacade("EvidencePackage").getEvidencePackageSummary(oEvidencePackageDetailsHeader, function() {
                            // Success callback
                            that.getView().getContent()[0].setBusy(false);
                        }, function() {
                            // Error callback
                            that.getView().getContent()[0].setBusy(false);
                            oModel.setProperty("/EvidencePackageDetails/Summary", {});
                            that._onRequestFailed.apply(that, arguments);
                        });
                    } else {
                        this._bRefreshRequired = true;
                    }
                }

            }));

})();