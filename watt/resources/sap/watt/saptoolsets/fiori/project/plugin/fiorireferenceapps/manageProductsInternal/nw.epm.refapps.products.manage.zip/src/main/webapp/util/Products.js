jQuery.sap.declare("nw.epm.refapps.products.manage.util.Products");
jQuery.sap.require("nw.epm.refapps.products.manage.util.RemoveService");

// Helper class for centrally handling oData CRUD and function import services. The interface provides the business
// meanings for the application and can be reused in different places where the UI-specific actions after the call
// could still be different and will be handled in the corresponding controller of the view.
// Note that this class also handles busy dialogs.
// Every (main) view of this app has an instance of this class as an attribute so that it can forward all explicit
// backend calls to it.
// Note that this class forwards all delete operations to helper class
// nw.epm.refapps.products.manage.util.RemoveService,
// which is instantiated on demand. Thereby, nw.epm.refapps.lib.reuse.util.messages.showErrorMessage is used to
// display error messages.

sap.ui.base.Object.extend("nw.epm.refapps.products.manage.util.Products", {
	_oResourceBundle: null,
	_oDataModel: null,
	constructor: function(oResourceBundle, oModel) {
		this._oResourceBundle = oResourceBundle;
		this._oDataModel = oModel;
	},

	// Delete methods are forwarded to RemoveService. The specification of these methods can be found there.

	deleteProducts: function(aPaths, fnAfterDeleted) {
		var oDeleteHelper = this._getDeleteHelper();
		oDeleteHelper.deleteProducts(aPaths, fnAfterDeleted);
	},

	deleteProduct: function(sPath, fnAfterDeleted, bWithoutConfirmationDialog) {
		var oDeleteHelper = this._getDeleteHelper();
		if (bWithoutConfirmationDialog) {
			oDeleteHelper.deleteEntityWithoutConfirmationDialog(sPath, fnAfterDeleted);
		} else {
			oDeleteHelper.deleteProduct(sPath, fnAfterDeleted);
		}
	},

	deleteProductDraft: function(sPath, bIsDraftDirty, fnAfterDeleted, fnDeleteCanceled) {
		var oDeleteHelper = this._getDeleteHelper();
		if (bIsDraftDirty) {
			// User needs to confirm the deletion
			oDeleteHelper.deleteProductDraft(sPath, fnAfterDeleted, fnDeleteCanceled);
		} else {
			oDeleteHelper.deleteEntityWithoutConfirmationDialog(sPath, fnAfterDeleted);
		}
	},

	deleteImageDraft: function(sPath, fnAfterDeleted) {
		var oDeleteHelper = this._getDeleteHelper();
		oDeleteHelper.deleteEntityWithoutConfirmationDialog(sPath, fnAfterDeleted);
	},

	// Additional methods for working with products

	// Creates a product draft. Note that there is only one product draft for the user, the ID of which is defined
	// in the backend when the draft is created.
	// new: Returns a promise object which can be chained with .done function to execute the actions when the creation
	// is successful
	createProductDraft: function() {
		var oDeferred = new jQuery.Deferred();
		// At least one attribute must be filled in the object passed to the create call (requirement of the oData
		// service)
		var oNewProduct = {
			ProductId: ""
		};
		this._oDataModel.create("/ProductDrafts", oNewProduct, {
			success: oDeferred.resolve,
			error: this._onError
		});
		return oDeferred.promise();
	},

	// This method is called when the App is started. It checks whether the user currently possesses a draft (note that
	// by contract there is at most one).
	// If this is the case, the user is urged to either proceed with editing this draft or revert the draft.
	// fnNavToProductDraft - a function that possesses one parameter (the data of the draft object) navigating to the
	// screen showing this draft.
	// fnOkAction - a function that possesses one parameter (the data of the draft object) that is called when the user
	// has actually decided to proceed with editing the draft. Note that navigation to the edit screen has already been
	// performed, however this function might want to do some additional adjustment.
	// fnCancelNavigation (optional) - a function that is called when the user has decided to revert the draft. More
	// precisely, it is called after successful deletion of the draft.
	// oController - the controller that called this from which we get the information which view to attach dialogs to

	handleProductDraft: function(oController, fnNavToProductDraft, fnOkAction, fnCancelNavigation) {
		// Creates a callback that is executed when the draft information has been retrieved
		var fnOnSuccess = function(oResponseContent) {
			// By contract there cannot be more than one (per user). As we use the oData protocol, the result is
			// nevertheless an array.
			var oProductDraft = oResponseContent && oResponseContent.results && oResponseContent.results[0];
			if (oProductDraft) {
				// Navigates to Draft before showing user the confirmation dialog
				fnNavToProductDraft(oProductDraft);
				this._requestUserNavigateToDraft(oProductDraft, oController, fnOkAction, fnCancelNavigation);
			}
		};

		// Retrieves draft information from the backend
		this._oDataModel.read("/ProductDrafts", {
			success: jQuery.proxy(fnOnSuccess, this),
			error: this._onError
		});
	},

	// Helper method for handleProductDraft that is called when a draft exists and navigation to this draft has already
	// been performed. For more information, see handleProductDraft.
	// oProductDraft - the data of the draft as read from the backend.

	_requestUserNavigateToDraft: function(oProductDraft, oController, fnOkAction, fnCancelNavigation) {
		// Callback function in the event that the user wants to revert the draft. It deletes the draft (without further
		// dialog) and calls fnCancelNavigation (presume that the function navigate away from the draft screen).

		var fnCancelled = jQuery.proxy(function() {
			var oDeleteHelper = this._getDeleteHelper();
			var sProductDraftPath = this._oDataModel.createKey("ProductDrafts", {
				Id: oProductDraft.Id
			});
			oDeleteHelper.deleteEntityWithoutConfirmationDialog(sProductDraftPath, fnCancelNavigation);
		}, this);
		// Creates a formatter for date and time instances
		var oDateFormatter = sap.ui.core.format.DateFormat.getDateTimeInstance({
			style: "short"
		});
		// The message presented to the user depends on whether the draft is for a new product or an already existing
		// product
		var sQuestion = oProductDraft.IsNewProduct ? this._oResourceBundle.getText("ymsg.editNewDraft", [oDateFormatter.format(oProductDraft.CreatedAt)]) :
			this._oResourceBundle.getText("ymsg.editDraft", [
                oProductDraft.Name, oDateFormatter.format(oProductDraft.CreatedAt)]);

		// This dialog is specifically built for this app because a new standard message box is
		// not yet available
		var oDialog = new sap.m.Dialog({
			title: this._oResourceBundle.getText("xtit.unsavedDraft"),
			content: [new sap.m.Text({
				text: sQuestion
			}).addStyleClass("sapUiSmallMargin")],
			contentWidth: "400px",
			buttons: [new sap.m.Button({
				text: this._oResourceBundle.getText("xbut.resume"),
				press: function() {
					oDialog.close();
					fnOkAction(oProductDraft);
				}
			}), new sap.m.Button({
				text: this._oResourceBundle.getText("xbut.discard"),
				press: function() {
					oDialog.close();
					fnCancelled();
				}
			})]
		});
		oController.getView().addDependent(oDialog);
		jQuery.sap.syncStyleClass("sapUiSizeCompact", oController.getView(), oDialog);
		oDialog.open();
	},

	// Creates product draft from a specified product ID for CopyProduct
	copyProductToDraft: function(sProductId, fnNavToDraft) {
		// Calls function import CopyProduct
		this._callFunctionAndNavToProductDraft("/CopyProduct", sProductId, fnNavToDraft);
	},

	// Gets product draft from a specified product ID for EditProduct
	getProductDraftFromProductId: function(sProductId, fnNavToDraft) {
		// Calls function import EditProduct
		this._callFunctionAndNavToProductDraft("/EditProduct", sProductId, fnNavToDraft);
	},

	_callFunctionAndNavToProductDraft: function(sFunctionName, sProductId, fnNavToDraft) {
		// Calls function import EditProduct or CopyProduct
		this._callFunctionImport(sFunctionName, {
			ProductId: sProductId
		}, function(oResponseContent) {
			if (oResponseContent && oResponseContent.Id) {
				fnNavToDraft(oResponseContent.Id);
			}
		});
	},

	// Convenience method for calling function imports. Provides error handling and the busy indicator.
	_callFunctionImport: function(sFunctionName, oURLParameters, fnAfterFunctionExecuted) {
		this._oDataModel.callFunction(sFunctionName, {
			method: "POST",
			urlParameters: oURLParameters,
			success: fnAfterFunctionExecuted,
			error: this._onError
		});
	},

	// Turns ProductDraft into Product and deletes ProductDraft
	activateProduct: function(sDraftId, fnDraftSaved, fnAfterActivation) {
		this.oDraftToActivate = {
			sDraftId: sDraftId,
			fnAfterActivation: fnAfterActivation
		};
		this._submitChanges(null, fnDraftSaved);
	},

	// Saves ProductDraft each time a user edits a field
	saveProductDraft: function(fnSaveFailed, fnAfterSaved) {
		this._submitChanges(fnSaveFailed, fnAfterSaved);
	},

	_submitChanges: function(fnSaveFailed, fnAfterSaved) {
		if (this.bIsChanging) {
			return;
		}
		this.sMessage = "";
		var fnSuccess = function(oResponseData) {
			this.bIsChanging = false;
			if (!this._oDataModel.hasPendingChanges() || !this.sMessage) {
				var i;
				for (i = 0; i < oResponseData.__batchResponses.length; i++) {
					var oEntry = oResponseData.__batchResponses[i];
					if (oEntry.response) {
						if (jQuery.sap.startsWith(oEntry.response.body, "{\"error\":")) {
							var oErrModel = new sap.ui.model.json.JSONModel();
							oErrModel.setJSON(oEntry.response.body);
							this.sMessage = oErrModel.getProperty("/error/message/value") || "Error";
							fnAfterSaved(this.sMessage);
							break;
						}
					}
				}
			}
			if (this.sMessage === "") {
				this._submitChanges(fnSaveFailed, fnAfterSaved);
			}
		};
		if (this._oDataModel.hasPendingChanges() && !this.sMessage) {
			this.bIsChanging = true;
			var mParameters = {};
			mParameters.success = jQuery.proxy(fnSuccess, this);
			mParameters.error = fnSaveFailed;
			mParameters.batchGroupId = "editproduct";

			this._oDataModel.submitChanges(mParameters);
		} else {
			if (this.oDraftToActivate && !this.sMessage) {
				this._callFunctionImport("/ActivateProduct", {
					ProductDraftId: this.oDraftToActivate.sDraftId
				}, this.oDraftToActivate.fnAfterActivation);

			}
			this.oDraftToActivate = null;
		}
	},

	saveSelectProductDraft: function() {
		this._oDataModel.submitChanges(null, this.onSubmitDraftErrorSelect);
	},

	onSubmitDraftErrorSelect: function(oError) {
		// Currently no valueStateText for Select Control, but will be delivered by UI5 in v 26
		nw.epm.refapps.lib.reuse.util.messages.showErrorMessage(oError);
	},

	// Error handler (that uses showErrorMessage from the reusable library)
	_onError: function(oError) {
		nw.epm.refapps.lib.reuse.util.messages.showErrorMessage(oError);
	},

	// Convenience method for retrieving an instance of the RemoveService
	_getDeleteHelper: function() {
		return new nw.epm.refapps.products.manage.util.RemoveService(this._oDataModel, this._oResourceBundle,
			nw.epm.refapps.lib.reuse.util.messages.showErrorMessage);
	}

});