(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ValueListItemRenderer");

    /**
     * Default renderer of control jd.ui.eid.control.ValueListItem
     * 
     * @class
     * @static
     * @name jd.ui.eid.control.ValueListItemRenderer
     */
    jd.ui.eid.control.ValueListItemRenderer = {};

    jd.ui.eid.control.ValueListItemRenderer.render = function(oRm, oControl) {
        oRm.write("<li ");
        oRm.writeControlData(oControl);
        oRm.addClass("sapUiLbxI");
        oRm.addClass("jdUiEidValueListItem");
        if (!oControl.getEnabled()) {
            oRm.addClass("sapUiLbxIDis");
        } else if (oControl.getSelected()) {
            oRm.addClass("sapUiLbxISel");
        }

        // Only add the jdUiEidValueListItemClickable style only if the listitem
        // is not disabled and a toolpopup has been added
        if (oControl.getEnabled() && oControl.getToolPopup()) {
            oRm.addClass("jdUiEidValueListItemClickable");
        }

        oRm.writeClasses();
        oRm.write(">");

        oRm.write("<span ");

        if (!oControl.getEnabled()) {
            oRm.addClass("jdUiEidValueListItemDisabled sapUiLbxITxt");
        } else {
            oRm.addClass("sapUiLbxITxt");
        }

        oRm.writeClasses();
        oRm.write(">");
        oRm.writeEscaped(oControl.getText());
        oRm.write("</span>");

        oRm.write("</li>");
    };

})();