/**
 * @fileoverview Detect some warning for usages of (window.)document APIs
 * @author Achref Kilani Jrad
 * @ESLint          Version 0.14.0 / February 2015
 */

// ------------------------------------------------------------------------------
// Rule Disablement
// ------------------------------------------------------------------------------
/*eslint-disable complexity, max-depth */
/*eslint-disable global-strict*/
/*eslint-disable strict*/
// ------------------------------------------------------------------------------
// Invoking global form of strict mode syntax for whole script
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
// Rule Definition
// ------------------------------------------------------------------------------
module.exports = function(context) {

    "use strict";
    var FORBIDDEN_DOM_ACCESS = [
            "getElementById", "getElementsByClassName", "getElementsByName",
            "getElementsByTagName"
    ], FORBIDDEN_WINDOW_USAGES = [
            "innerWidth", "innerHeight", "setTimeout", "getSelection"
    ], FORBIDDEN_LOCATION_USAGES = [
            "href", "hash", "assign"
    ];
    var FULL_BLACKLIST = FORBIDDEN_DOM_ACCESS.concat(FORBIDDEN_WINDOW_USAGES,
            FORBIDDEN_LOCATION_USAGES);

    var FORBIDDEN_DOCUMENT_OBJECT = [], FORBIDDEN_SCREEN_OBJECT = [], FORBIDDEN_BODY_OBJECT = [], FORBIDDEN_HISTORY_OBJECT = [], FORBIDDEN_LOCATION_OBJECT = [];

    var MESSAGE_DOM_ACCESS = "Direct DOM access, use jQuery selector instead"; // 17
    var MESSAGE_WINDOW_USAGES = "Proprietary Browser API access, use jQuery selector instead"; // 23
    var MESSAGE_TIMEOUT = "Timeout with value > 0"; // 33
    var MESSAGE_HISTROY_USAGES = "Direct history manipulation, does not work with deep links, use router and navigation events instead"; // 34
    var MESSAGE_GLOBAL_SELECTION = "Global selection modification, only modify local selections"; // 35
    var MESSAGE_LOCATION_ASSIGN = "Usage of location.assign()"; // 30-3
    var MESSAGE_LOCATION_HASH = "Direct Hash manipulation, use router instead"; // 30-2
    //    var MESSAGE_LOCATION_HREF = "Usage of location.href"; // 30-1
    var MESSAGE_LOCATION_OVERR = "Override of location"; // 30-1

    var MEMBER = "MemberExpression", CALL = "CallExpression", IDENTIFIER = "Identifier", IF_CONDITION = "IfStatement", CONDITION_EXP = "ConditionalExpression", UNARY = "UnaryExpression", LITERAL = "Literal";
    // --------------------------------------------------------------------------
    // Helpers
    // --------------------------------------------------------------------------
    function isType(node, type) {
        return node && node.type === type;
    }
    function isIdentifier(node) {
        return isType(node, IDENTIFIER);
    }
    function isMember(node) {
        return isType(node, MEMBER);
    }
    function isCall(node) {
        return isType(node, CALL);
    }
    function isCondition(node) {
        return isType(node, IF_CONDITION) || isType(node, CONDITION_EXP);
    }
    function isUnary(node) {
        return isType(node, UNARY);
    }
    function isLiteral(node) {
        return isType(node, LITERAL);
    }

    function contains(a, obj) {
        for (var i = 0; i < a.length; i++) {
            if (obj === a[i]) {
                return true;
            }
        }
        return false;
    }

    function isDomAccess(methodName) {
        return contains(FORBIDDEN_DOM_ACCESS, methodName);
    }

    function isWindowUsage(methodName) {
        return contains(FORBIDDEN_WINDOW_USAGES, methodName);
    }

    function isLocationUsage(methodName) {
        return contains(FORBIDDEN_LOCATION_USAGES, methodName);
    }

    function isWindow(node) {
        return isIdentifier(node) && node.name === "window";
    }

    function isHistory(node, justHistory) {
        if (isIdentifier(node)) {
            return node.name === "history"
                    || (!justHistory && contains(FORBIDDEN_HISTORY_OBJECT,
                            node.name));
        } else if (isMember(node)) {
            return isWindow(node.object) && isIdentifier(node.property)
                    && isHistory(node.property, true);
        }
        return false;
    }

    function getRightestMethodName(node) {
        if (isMember(node.callee)) {
            return node.callee.property.name;
        } else {
            return node.callee.name;
        }
    }

    function processVariableDeclarator(node) {
        if (node.init) {
            if (isMember(node.init)) {
                var firstElement = node.init.object.name, secondElement = node.init.property.name;

                if (firstElement + "." + secondElement === "window.document") {
                    FORBIDDEN_DOCUMENT_OBJECT.push(node.id.name);
                } else if (firstElement + "." + secondElement === "window.history") {
                    FORBIDDEN_HISTORY_OBJECT.push(node.id.name);
                } else if (firstElement + "." + secondElement === "window.location") {
                    FORBIDDEN_LOCATION_OBJECT.push(node.id.name);
                } else if (firstElement + "." + secondElement === "window.screen") {
                    FORBIDDEN_SCREEN_OBJECT.push(node.id.name);
                } else if ((secondElement === "body")
                        && (node.init.object.property)) {
                    firstElement = node.init.object.property.name;
                    if (firstElement + "." + secondElement === "document.body") {
                        context.report(node, MESSAGE_WINDOW_USAGES);
                        FORBIDDEN_BODY_OBJECT.push(node.id.name);
                    }
                }
            } else if (isIdentifier(node.init)
                    && (node.init.name === "document")) {
                FORBIDDEN_DOCUMENT_OBJECT.push(node.id.name);
            } else if (isIdentifier(node.init) && (node.init.name === "screen")) {
                FORBIDDEN_SCREEN_OBJECT.push(node.id.name);
            } else if (isIdentifier(node.init)
                    && (node.init.name === "location")) {
                FORBIDDEN_LOCATION_OBJECT.push(node.id.name);
            } else if (isIdentifier(node.init)
                    && (node.init.name === "history")) {
                FORBIDDEN_HISTORY_OBJECT.push(node.id.name);
            }
        }
    }
    function processSetTimeOut(node) {
        if (node.callee.type === "Identifier"
                && node.callee.name === "setTimeout" && node.arguments
                && node.arguments.length > 1 && node.arguments[1].value > 0) {
            context.report(node, MESSAGE_TIMEOUT);
        }
    }

    function buildCalleePath(memberExpressionNode) {
        var obj = memberExpressionNode.object;
        if (isIdentifier(obj)) {
            return obj.name;
        } else if (isMember(obj)) {
            return buildCalleePath(obj) + "." + obj.property.name;
        } else {
            return "";
        }
    }

    function isForbiddenObviousApi(calleePath) {
        var elementArray = calleePath.split(".");
        var lastElement = elementArray[elementArray.length - 1];
        return lastElement;
    }

    function processLocationMessage(node, methodName) {
        if (methodName === "assign") {
            context.report(node, MESSAGE_LOCATION_ASSIGN);
        } else if (methodName === "hash") {
            context.report(node, MESSAGE_LOCATION_HASH);
        }
    }

    function isLocation(node, justLocation) {
        if (isIdentifier(node)) {
            return node.name === "location"
                    || (!justLocation && contains(FORBIDDEN_LOCATION_OBJECT,
                            node.name));
        } else {
            return false;
        }
    }

    function isInCondition(node, maxDepth) {
        // we check the depth here because the call might be nested in a block statement and in an expression statement (http://jointjs.com/demos/javascript-ast)
        // (true?history.back():''); || if(true) history.back(); || if(true){history.back();} || if(true){}else{history.back();}
        if (maxDepth > 0) {
            var parent = node.parent;
            return isCondition(parent) || isInCondition(parent, maxDepth - 1);
        }
        return false;
    }

    function isMinusOne(node) {
        return isUnary(node) && node.operator === "-"
                && isLiteral(node.argument) && node.argument.value === 1;
    }

    function processHistory(node) {
        var callee = node.callee;
        if (isMember(callee)) {
            // process window.history.back() | history.forward() | var h = history; h.go()
            if (isHistory(callee.object) && isIdentifier(callee.property)) {
                switch (callee.property.name) {
                    case "forward":
                        context.report(node, MESSAGE_HISTROY_USAGES);
                        break;
                    case "back":
                        if (!isInCondition(node, 3)) {
                            context.report(node, MESSAGE_HISTROY_USAGES);
                        }
                        break;
                    case "go":
                        var args = node.arguments;
                        if (args.length === 1 && isMinusOne(args[0])) {
                            if (!isInCondition(node, 3)) {
                                context.report(node, MESSAGE_HISTROY_USAGES);
                            }
                        } else {
                            context.report(node, MESSAGE_HISTROY_USAGES);
                        }
                        break;
                    default:
                }
            }
            // ELSE:
            // TODO: check if node.callee is identifier and identifier is a reference to history.back / .go / .forward
            // processing var go = history.go; go();
        }
    }

    function checkAssignmentAgainstOverride(node) {
        var identifier = node.left;
        if (isLocation(identifier)) { // location
            context.report(node, MESSAGE_LOCATION_OVERR);
        } else if (isMember(identifier)) {
            if (isIdentifier(identifier.property)
                    && identifier.property.name === "href") {
                if (isLocation(identifier.object)) { // location.href
                    context.report(node, MESSAGE_LOCATION_OVERR);
                } else if (isMember(identifier.object)
                        && isWindow(identifier.object.object)
                        && isLocation(identifier.object.property, true)) { // window.location.href
                    context.report(node, MESSAGE_LOCATION_OVERR);
                }
            } else if (isWindow(identifier.object)
                    && isLocation(identifier.property, true)) { // window.location
                context.report(node, MESSAGE_LOCATION_OVERR);
            }
        }
    }

    // --------------------------------------------------------------------------
    // Public
    // --------------------------------------------------------------------------

    return {
        "VariableDeclarator": function(node) {
            processVariableDeclarator(node);
        },
        "CallExpression": function(node) {
            processSetTimeOut(node);
            processHistory(node);
        },
        "AssignmentExpression": function(node) {
            checkAssignmentAgainstOverride(node);
        },
        "MemberExpression": function(node) {
            if (isCall(node.parent) && (!node.computed)) {

                var methodName = getRightestMethodName(node.parent), memberExpressionNode = node, calleePath;
                if ((typeof methodName === "string")
                        && (contains(FULL_BLACKLIST, methodName))) {
                    calleePath = buildCalleePath(memberExpressionNode);
                    var speciousObject = isForbiddenObviousApi(calleePath);

                    if (speciousObject === "document"
                            && isDomAccess(methodName)) {
                        context.report(node, MESSAGE_DOM_ACCESS);
                    } else if (speciousObject !== "document"
                            && contains(FORBIDDEN_DOCUMENT_OBJECT,
                                    speciousObject)) {
                        context.report(node, MESSAGE_DOM_ACCESS);
                    }

                    if ((speciousObject === "window")
                            && isWindowUsage(methodName)
                            && (methodName === "setTimeout")) {
                        context.report(node, MESSAGE_TIMEOUT);
                    }

                    if ((speciousObject === "window")
                            && isWindowUsage(methodName)
                            && (methodName === "getSelection")) {
                        context.report(node, MESSAGE_GLOBAL_SELECTION);
                    }

                    if (((speciousObject === "location") && isLocationUsage(methodName))
                            || ((speciousObject !== "location") && (contains(
                                    FORBIDDEN_LOCATION_OBJECT, speciousObject)))) {
                        processLocationMessage(node, methodName);
                    }
                } else if ((typeof methodName === "string")) {
                    calleePath = buildCalleePath(memberExpressionNode);
                    speciousObject = isForbiddenObviousApi(calleePath);

                    if (((speciousObject === "body") && (calleePath
                            .indexOf("document.") !== -1))

                            || ((speciousObject === "body") && (contains(
                                    FORBIDDEN_DOCUMENT_OBJECT, calleePath
                                            .slice(0, calleePath
                                                    .lastIndexOf(".body")))))

                            || (contains(FORBIDDEN_BODY_OBJECT, speciousObject))) {
                        context.report(node, MESSAGE_WINDOW_USAGES);
                    }

                }

            } else {
                var calleePathNonCmpt = buildCalleePath(node);
                var speciousObjectNonCmpt = isForbiddenObviousApi(calleePathNonCmpt);

                // console.log("methodName " + methodName);
                // console.log("calleePath " + calleePathNonCmpt);
                // console.log("speciousObject " + speciousObjectNonCmpt);
                // console.log("-----------------------");

                if ((calleePathNonCmpt === "window") && (node.property)
                        && isWindowUsage(node.property.name)) {
                    /*
                     * window.innerHeight = 16; for exp
                     */
                    context.report(node, MESSAGE_WINDOW_USAGES);
                } else if ((calleePathNonCmpt === "window.screen")
                        || (calleePathNonCmpt === "screen")
                        || (contains(FORBIDDEN_SCREEN_OBJECT, calleePathNonCmpt))) {
                    context.report(node, MESSAGE_WINDOW_USAGES);
                }

                if (((calleePathNonCmpt === "document.body") || (calleePathNonCmpt === "window.document.body"))
                        && (speciousObjectNonCmpt === "body")) {
                    context.report(node, MESSAGE_WINDOW_USAGES);
                } else if (((speciousObjectNonCmpt === "body") && (contains(
                        FORBIDDEN_DOCUMENT_OBJECT, calleePathNonCmpt.slice(0,
                                calleePathNonCmpt.lastIndexOf(".body")))))
                        || (contains(FORBIDDEN_BODY_OBJECT, calleePathNonCmpt))) {
                    context.report(node, MESSAGE_WINDOW_USAGES);
                }

                if ((((calleePathNonCmpt === "window.location") || (calleePathNonCmpt === "location"))
                        && (node.property) && isLocationUsage(node.property.name))
                        || (contains(FORBIDDEN_LOCATION_OBJECT,
                                calleePathNonCmpt))) {
                    processLocationMessage(node, node.property.name);

                }

            }

        }

    };

};
