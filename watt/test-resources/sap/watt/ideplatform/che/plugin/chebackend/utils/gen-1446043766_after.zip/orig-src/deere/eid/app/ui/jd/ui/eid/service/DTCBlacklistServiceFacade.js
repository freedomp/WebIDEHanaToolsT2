(function() {
    "use strict";

    // Requires BaseServiceFacade
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");
    jQuery.sap.declare("jd.ui.eid.service.DTCBlacklistServiceFacade");

    /**
     * @class
     * <p>
     * The DTC blacklist service facade provides functionality to add or remove a DTC to/from the blacklist and to retrieve the list of blacklisted
     * DTC for the current user. When a DTC is added or removed, the list of blacklisted DTC is not automatically refetched from this facade.<br />
     * Note : As 'User ID' is available in the session, it does not need to be passed explicitly by any of this class's methods.
     * </p>
     * @name jd.ui.eid.service.DTCBlacklistServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.DTCBlacklistServiceFacade", /** @lends jd.ui.eid.service.DTCBlacklistServiceFacade */
    {
        /**
         * see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleListBindingChanged : function(oListBinding) {
            // This is invoked if the filtering/sorting on the UI table changes.
            // If the list binding is relevant, then get the updated blacklist based on new
            // filtering/sorting etc. This information is available inside oListBinding.
            if (oListBinding.sPath == '/DTCBlacklist') {
                this.getDTCBlacklist(oListBinding);
            }
        },

        /**
         * see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleDataRequested : function(oListBinding) {
            // This is invoked when there is paging on the UI table
            // If the list binding is relevant, then get the updated blacklist based on the new
            // binding information (oListBinding)
            if (oListBinding.sPath == '/DTCBlacklist') {
                this.getDTCBlacklist(oListBinding);
            }
        },

        /**
         * Add the supplied DTC ID to the user's blacklist.
         * 
         * @param {string}
         *            sDTCId the ID of the DTC to be added to the user's blacklist
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful
         * @param {function}
         *            fnError callback that is executed when the service call results in an error
         * 
         */
        addDTCToBlacklist : function(sDTCId, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/personal/dtc_blacklist/AddDTCToBlacklist.xsjs";

            // Prepare the custom payload
            var oArgs = {
                DTCID : parseInt(sDTCId, 10)
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs);
        },

        /**
         * Remove the supplied DTC ID from the user's blacklist.
         * 
         * @param {string}
         *            sDTCId the ID of the DTC to be removed from the user's blacklist
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        removeDTCFromBlacklist : function(sDTCId, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/personal/dtc_blacklist/RemoveDTCFromBlacklist.xsjs";

            // Prepare the custom payload
            var oArgs = {
                DTCID : parseInt(sDTCId, 10)
            };

            // Call this service
            // sServicePath, fnSuccess, fnError, oPayload, sModelDataFileName
            this._send(sServicePath, fnSuccess, fnError, oArgs);
        },

        /**
         * Get the list of DTCs for the current user. Method for retrieving the current user's DTC blacklist. It prepares the custom payload object
         * with search term as an attribute, and invokes the _retrieveList() method of the BaseServiceFacade (base class of
         * DTCBlacklistServiceFacade).
         * 
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control
         * @param {string}
         *            sSearchTerm the search string. If there is no search term, this can be an empty string or null
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        getDTCBlacklist : function(oBinding, sSearchTerm, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/personal/dtc_blacklist/GetBlacklist.xsjs";

            // Set test data file name
            var sModelDataFileName = "getBlacklist.json";

            // Prepare the custom payload for this service call
            // If no search term was provided, this is an empty object. Otherwise, the search term
            // is an attribute of oArgs.
            var oArgs = {};
            if (sSearchTerm) {
                oArgs.SearchTerm = sSearchTerm;
            } else {
                oArgs.SearchTerm = "";
            }

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of DTCs within this object.
            var fnGetListData = function(oData) {
                return oData.Result.DTCBlacklist;
            };

            // Invoke _retrieveList
            this._retrieveList(sServicePath, fnSuccess, fnError, fnGetListData, oBinding, oArgs, sModelDataFileName);
        }
    });

})();