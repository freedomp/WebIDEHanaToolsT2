(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.DTACCaseServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    oModel.init();
    sap.ui.getCore().setModel(oModel);
    var oBindingDTACCaseList = new jd.ui.eid.model.EidModelListBinding(oModel, "/DTACCaseList");
    oModel.setProperty("/DTACCaseFilters", {
        DomainValues : {
            TagCloud : {}
        }
    });
    var oDTACCaseServiceFacade = new jd.ui.eid.service.DTACCaseServiceFacade("http://sap.com", "/folder/to/test/data", oModel, true);

    var oDataGetDTACCaseList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTACCaseList_Response.json").data;
    var oDataGetDTACCaseDetails = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTACCaseDetails_Response.json").data;

    // Module for DTACCaseServiceFacade
    module("jd.ui.eid.service.DTACCaseServiceFacade", {
        setup : function() {
            // Start spying request
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };
        },
        teardown : function() {
            this.xhr.restore();
        }
    });

    // *** TEST CASE #1 ***
    test("getDTACCaseList() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();

        oDTACCaseServiceFacade.getDTACCaseList(oBindingDTACCaseList, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError);

        equal(1, this.requests.length);
    });

    // *** TEST CASE #2 ***
    test("getDTACCaseList() should update the paths '/DTACCaseList' and '/DTACCaseFilters/DomainValues/TagCloud' successfully", function() {
        var oCustomFilter = {};
        var oEvidencePackage = {};
        var sSearchTerm = "dfd";
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();

        oDTACCaseServiceFacade.getDTACCaseList(oBindingDTACCaseList, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTACCaseList));

        // Assertion
        var oValue = oModel.getProperty("/DTACCaseList");
        // test one value from the table path of the response
        deepEqual(oValue[0].DTACCaseNumber, oDataGetDTACCaseList.Result.DTACCaseList.Records[0].DTACCaseNumber);

        var oValue2 = oModel.getProperty("/DTACCaseFilters/DomainValues/TagCloud");
        // test one value from the tagcloud
        deepEqual(oValue2[0].Tag, oDataGetDTACCaseList.Result.TagCloud[0].Tag);
    });

    // *** TEST CASE #3 ***
    test("getDTACCaseDetails() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        oDTACCaseServiceFacade.getDTACCaseDetails();

        equal(1, this.requests.length);
    });

    // *** TEST CASE #4 ***
    test("getDTACCaseDetails() should update the path '/DTACCaseDetails'", function() {
        var fnSuccess = sinon.spy();
        var fnError = sinon.spy();
        var iDTACCaseNumber = oDataGetDTACCaseDetails.Result.DTACCaseDetails.Records[0].DTACCaseNumber;

        // Trigger the ajax request
        oDTACCaseServiceFacade.getDTACCaseDetails(iDTACCaseNumber, fnSuccess, fnError);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTACCaseDetails));

        // Assertion
        var oValue = oModel.getProperty("/DTACCaseDetails");
        // test one value from the response
        deepEqual(oValue.DTACCaseNumber, iDTACCaseNumber);
    });

})();
