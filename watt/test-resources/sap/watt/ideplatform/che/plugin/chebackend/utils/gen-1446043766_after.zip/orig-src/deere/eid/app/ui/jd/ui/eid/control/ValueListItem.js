(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ValueListItem");

    /**
     * The ValueListItem control implements a list item which contains a specific value
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>text : string (default: "") This property defines the label of the item.</li>
     * <li>value : object This property defines the value of the item.</li>
     * <li>enabled : boolean (default: true) This property defines whether the list item should be enabled or not</li>
     * <li>selected : boolean (default: false) This property indicates if the interval item is mark/unmarked</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>toolPopup : sap.ui.ux3.ToolPopup The Popup of the interval item.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>select : Raised when the item was selected.</li>
     * <li>valueChanged : Raised when the value of the item changed.</li>
     * <li>toolPopupCanceled : Raised when the ValueListItem's ToolPopup is canceled by the user. </li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.ValueListItem
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.ValueListItem", /** @lends jd.ui.eid.control.ValueListItem */
    {
        metadata : {
            properties : {
                text : {
                    type : "string"
                },
                value : {
                    type : "object"
                },
                enabled : {
                    type : "boolean",
                    defaultValue : true
                },
                selected : {
                    type : "boolean",
                    defaultValue : false
                }
            },

            aggregations : {
                toolPopup : {
                    type : "sap.ui.ux3.ToolPopup",
                    multiple : false
                }
            },

            events : {
                select : {},
                valueChanged : {},
                toolPopupCanceled : {}
            }
        },

        /**
         * On item selection: Open the pop-up if defined and raise select event
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            if (this.getEnabled()) {
                var oToolPopup = this.getToolPopup();
                if (oToolPopup !== null) {
                    // Set tool popup position
                    oToolPopup.setPosition(sap.ui.core.Popup.Dock.BeginTop, sap.ui.core.Popup.Dock.EndTop, this, "0 -5");
                    if (!oToolPopup.isOpen()) {
                        oToolPopup.open();
                    }
                }

                // Notify select-event listeners
                this.fireSelect({
                    id : this.getId(),
                    text : this.getText()
                });
            }

        },

        /**
         * Set the value of the list item
         * 
         * @param {object}
         *            oValue value of the list item as an object
         * @returns {jd.ui.eid.control.ValueListItem} This for method chaining.
         */
        setValue : function(oValue) {
            this.setProperty("value", oValue);
            return this;
        },

        setText : function(sText) {
            this.setProperty("text", sText);
            return this;
        },

        /**
         * Change the value of the list item and fire the event valueChanged
         * 
         * @param {object}
         *            oValue value of the list item as an object
         */
        changeValue : function(oValue) {
            if (oValue) {
                this.setValue(oValue);
                this.fireValueChanged();
            }
        },

        /**
         * Called when the associated ToolPopup's delegate raises the 'canceled' event
         */
        onToolPopupCanceled : function() {
            // Let the FilterItem know
            this.fireToolPopupCanceled();
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.ValueListItemRenderer"
    });

})();