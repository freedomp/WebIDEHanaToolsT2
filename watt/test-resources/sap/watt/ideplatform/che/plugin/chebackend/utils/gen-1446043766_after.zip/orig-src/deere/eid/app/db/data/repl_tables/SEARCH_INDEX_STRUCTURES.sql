
----------------------------------------------------------------------------------------------------------
-- Search Indices on Master Data Tables
----------------------------------------------------------------------------------------------------------

DROP FULLTEXT INDEX "EID"."NATIVE_PIN_INDEX_REPL";
CREATE FULLTEXT INDEX native_pin_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::MK_MACHINE_EIA" (native_pin)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."DTC_INDEX_REPL";
CREATE FULLTEXT INDEX dtc_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::DTC_MASTER" (dtc)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."WARNING_LIGHT_INDEX_REPL";        
CREATE FULLTEXT INDEX warning_light_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::DTC_MASTER" (warning_light)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."L1_INDEX_REPL";
CREATE FULLTEXT INDEX l1_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::DTC_MASTER" (l1_text)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."L2_INDEX_REPL";
CREATE FULLTEXT INDEX l2_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::DTC_MASTER" (l2_text)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PRIME_PART_NUM_INDEX_REPL";
CREATE FULLTEXT INDEX prime_part_num_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::WRNTY_CLAIM_EIA" (prime_part_num)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PART_NAME_DSC_INDEX_REPL";        
CREATE FULLTEXT INDEX part_name_dsc_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::WRNTY_CLAIM_EIA" (part_name_dsc)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PRIME_PART_DTL_TXT_INDEX_REPL";
CREATE FULLTEXT INDEX prime_part_dtl_txt_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::WRNTY_CLAIM_TEXT_EIA" (prime_part_dtl_txt)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL'
        TEXT MINING ON;

DROP FULLTEXT INDEX "EID"."QW_PROBLEM_INDEX_REPL";
CREATE FULLTEXT INDEX qw_problem_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::QW_NOTES" (qw_problem)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS ON 
        CONFIGURATION 'EXTRACTION_CORE_VOICEOFCUSTOMER'
        TEXT MINING ON;

DROP FULLTEXT INDEX "EID"."QW_NOTES_INDEX_REPL";
CREATE FULLTEXT INDEX qw_notes_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::QW_NOTES" (qw_notes)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS ON 
        CONFIGURATION 'EXTRACTION_CORE_VOICEOFCUSTOMER'
        TEXT MINING ON;

DROP FULLTEXT INDEX "EID"."UNIT_INDEX_REPL";
CREATE FULLTEXT INDEX unit_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::MANAGED_USERS" (unit)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."DEPT_INDEX_REPL";
CREATE FULLTEXT INDEX dept_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::MANAGED_USERS" (dept)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."FULLNAME_INDEX_REPL";
CREATE FULLTEXT INDEX fullname_index_repl ON "EID"."deere.eid.app.db.data.repl_tables::MANAGED_USERS" (fullname)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';


----------------------------------------------------------------------------------------------------------
-- Search Indices on Application-Specific Tables
----------------------------------------------------------------------------------------------------------

DROP FULLTEXT INDEX "EID"."PACKAGE_NAME_INDEX";
CREATE FULLTEXT INDEX package_name_index 
ON "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H" (PACKAGE_NAME) 
ASYNC
FUZZY SEARCH INDEX ON
LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
FAST PREPROCESS OFF
SEARCH ONLY OFF
TEXT ANALYSIS OFF 
CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PACKAGE_DESC_INDEX";
CREATE FULLTEXT INDEX package_desc_index  
ON "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H" (PACKAGE_DESC) 
ASYNC
FUZZY SEARCH INDEX ON
LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
FAST PREPROCESS OFF
SEARCH ONLY OFF
TEXT ANALYSIS OFF 
CONFIGURATION 'LINGANALYSIS_FULL';
