module("formatterTest", {
    setup : function() {
        jQuery.sap.require("nw.epm.refapps.lib.reuse.util.formatter");
        jQuery.sap.require("nw.epm.refapps.testhelpers.ResourceBundleMock");
        sinon.stub(nw.epm.refapps.lib.reuse.util.formatter, "_getResourceBundle", function() {
            var oResourceBundle = sap.ui.getCore().getLibraryResourceBundle("nw.epm.refapps.lib.reuse");
            return new nw.epm.refapps.testhelpers.ResourceBundleMock(oResourceBundle);
        });

        jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
        sinon.stub(sap.ca.ui.model.format.QuantityFormat, "FormatQuantityStandard", function(fMeasure, sUnit) {
            return "{" + fMeasure + "," + sUnit + "}";
        });
    },
    teardown : function() {
        nw.epm.refapps.lib.reuse.util.formatter._getResourceBundle.restore();
        sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard.restore();
    }
});

test("formatAvailabilityText", function() {
    function check(iTestValue, sExpectedValue) {
        equal(nw.epm.refapps.lib.reuse.util.formatter.formatAvailabilityText(iTestValue), sExpectedValue);
    }
    check(-45, "xfld.outOfStock");
    check(0, "xfld.outOfStock");
    check(0.35, "xfld.outOfStock");
    check(null, "xfld.outOfStock");
    check(void 0, "xfld.outOfStock");
    check("", "xfld.outOfStock");
    check("dd", "xfld.outOfStock");
    check(1, "xfld.inStockLeft/1");
    check(9, "xfld.inStockLeft/9");
    check(10, "xfld.inStock");
});

test("formatAvailabilityStatus", function() {
    function check(iTestValue, sExpectedValue) {
        equal(nw.epm.refapps.lib.reuse.util.formatter.formatAvailabilityStatus(iTestValue), sExpectedValue);
    }
    check(-45, sap.ui.core.ValueState.Error);
    check(0, sap.ui.core.ValueState.Error);
    check(0.35, sap.ui.core.ValueState.Error);
    check(null, sap.ui.core.ValueState.Error);
    check(void 0, sap.ui.core.ValueState.Error);
    check("", sap.ui.core.ValueState.Error);
    check("dd", sap.ui.core.ValueState.Error);
    check(1, sap.ui.core.ValueState.Success);
});

test("formatMeasure", function() {
    function check(iTestValue1, sTestValue2, sExpectedValue) {
        equal(nw.epm.refapps.lib.reuse.util.formatter.formatMeasure(iTestValue1, sTestValue2), sExpectedValue);
    }
    check(45.2345, "KGM", "{45.2345,KGM} KGM");
    check(45.12, "MTR", "{45.12,MTR} MTR");
    check(void 0, "MTR", "");
    check(null, "MTR", "");
    check("", "MTR", "");
    check("dd", "MTR", "");
});