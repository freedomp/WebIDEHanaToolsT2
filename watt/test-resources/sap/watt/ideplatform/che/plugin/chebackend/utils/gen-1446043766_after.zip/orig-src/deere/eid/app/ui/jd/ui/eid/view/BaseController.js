(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.application.Application");

    /**
     * The BaseController can be merged into other sap.ui.mvc.Controller objects and provides utility functions.
     * 
     * Example for merging:
     * 
     * <pre>
     * jd.ui.eid.require(&quot;jd.ui.eid.view.BaseController&quot;);
     * sap.ui.controller(&quot;view.ViewName&quot;, jQuery.extend(true, {}, jd.ui.eid.view.BaseController, {
     * // here goes the usual view methods like createContent(), etc.
     * }));
     * </pre>
     * 
     * @class
     * @static
     */
    jd.ui.eid.view.BaseController = {

        /**
         * Get a reference to the singleton application
         * 
         * @returns {jd.ui.eid.application.Application}
         */
        getApplication : function() {
            return jd.ui.eid.application.Application.getInstance();
        },

        /**
         * @see {@link jd.ui.eid.application.Application#getServiceFacade}
         */
        getServiceFacade : function(sKey) {
            return this.getApplication().getServiceFacade(sKey);
        },

        /**
         * @see {@link jd.ui.eid.application.Application#getNotificationCenter}
         */
        getNotificationCenter : function() {
            return this.getApplication().getNotificationCenter();
        },

        /**
         * This function can be used as a generic event handler for the 'requestFailed' event raised by the BaseServiceFacade. It shows an alert with
         * a generic error message
         * 
         * @see jd.ui.eid.application.Application#handleAjaxError
         */
        _onRequestFailed : function(oXMLHttpRequest, sTextStatus, oErrorThrown) {
            var sErrorText;
            var fnCallback = undefined;
            if (sTextStatus == 'parsererror' && oXMLHttpRequest.responseText.indexOf('login') > 0) {
                // Session has timeout
                // But this has already been handled by the Application (see
            } else {
                // Other error
                sErrorText = jd.ui.eid.common.I18NHelper.getText("MSG_MSE_REQUEST_FAILED");
                jd.ui.eid.application.Application.getInstance().getNotificationCenter().alert(sErrorText, fnCallback);
            }
        },

        /**
         * Returns an Element of the connected view with the given local Id. If two Ids are provided, the first one refers to the id of a fragment
         * assigned to the view and the second one to an element within that fragment.
         * 
         * @see sap.ui.core.mvc.Controller#byId
         * @param {string}
         *            sId The view-local id or the id of the fragment.
         * @param {string}
         *            [sSubId] The fragment-local id.
         * @returns {sap.ui.core.Element} Element by its id.
         */
        byId : function(sId, sSubId) {
            if (!sSubId) {
                return sap.ui.core.mvc.Controller.prototype.byId.apply(this, arguments);
            } else {
                var sLocalFragmentId = this.createId(sId);
                return sap.ui.core.Fragment.byId(sLocalFragmentId, sSubId);
            }
        },

        /**
         * Returns true if the view is visible otherwise false
         * 
         * @returns {sap.ui.core.Element} Element by its id.
         */
        isVisible : function() {
            var oView = this.getView();

            // Pre-check the prerequisites from the hook method
            if (!oView.$().is(":visible") || !this._isVisible()) {
                return false;
            }

            // Search for a visible parent view
            while (oView != null) {
                // Check whether the current view is the root view
                if (oView instanceof sap.ui.core.mvc.View && oView.getId() == "__xmlview0") {
                    return true;
                }

                var oParentView = oView.getParent();
                if (oParentView) {
                    if (oParentView instanceof sap.ui.core.mvc.View) {
                        return true;
                    } else if (oParentView instanceof sap.ui.ux3.OverlayContainer && oParentView.isOpen()) {
                        return true;
                    } else {
                        oView = oParentView;
                    }
                } else {
                    return false;
                }
            }
        },

        /**
         * Hook function for additional checks regarding the visibility in the subclasses. Should be overridden in the subclass.
         */
        _isVisible : function() {
            return true;
        }

    };
})();