(function() {
    "use strict";

    // This file contains core functionality required for the custom preload mechanism and documentation on the namespaces.

    jQuery.sap.declare("jd.ui.eid.jd-ui-eid-core");
    jQuery.sap.require("sap.ui.core.Fragment");

    // Registr maps
    var _aModuleRegistry = {}, _mViewRegistry = {}, _mFragmentRegistry = {};

    /**
     * Helper method to resolve a module into a string (either returns the the input parameter if if's a string or concatenates modName and type if
     * it's an object.
     * 
     * @param {string|object}
     *            sModuleName the name of the module. Either a string or an object with properties modName and type.
     * @returns {string} the module name as string.
     */
    var _getModuleName = function(sModuleName) {
        if (sModuleName instanceof Object) {
            sModuleName = sModuleName.modName + "." + sModuleName.type;
        }
        return sModuleName;
    };

    /**
     * @namespace
     * <p>
     * The Emerging Issue Detection (EID) application is an SAP UI5-based web application connecting to HANA via XS Engine (XSE).
     * </p>
     * <h1>High Level Design</h1>
     * <p>
     * The application is mainly build around business objects such as DTCs (Diagnostic Trouble Codes), DTAC cases and warranty claims, which are
     * composed into an evidence package.
     * </p>
     * <h2>Entry Points and Applications</h2>
     * <p>
     * There are three different entry points (also referred to as applications):
     * <ul>
     * <li>Main - the main application covers the evidence package creation process - {@link jd.ui.eid.view.main View Hierarchy}.</li>
     * <li>Customizing - the customizing application covers maintaining the main application's customizing
     * {@link jd.ui.eid.view.customizing View Hierarchy}.</li>
     * <li>Print - the print application covers the print view of the evidence package.</li>
     * </ul>
     * These entry points each have their own html files in the respective sub-folder (e.g. <code>eid/ui/main</code>) and their own configuration
     * object (see {@link jd.ui.eid.application}).
     * </p>
     * <p>
     * Each html file first loads the UI5 library from the server and then the <code>bootstrap.js</code> file. The <code>script</code> tag which
     * includes the bootstrap file can have the following parameters:
     * <ul>
     * <li><code>jd-ui-eid-app</code> : string the application which should be started (main, customizing, print, test).</li>
     * <li><code>jd-ui-eid-env</code> : string the environment in which the application should run (dev, prod).</li>
     * <li><code>jd-ui-eid-opt</code> : boolean (default: false) true if optimized sources should be used (from the target folder), false
     * otherwise.</li>
     * </ul>
     * </p>
     * <p>
     * The different html files for each application do the following:
     * <ul>
     * <li><code>index_local.html</code> : file for local testing, retrieves the UI5 sources from the eclipse installation and uses the current dev
     * sources for the application.</li>
     * <li><code>index_local_opt.html</code> : file for local testing, retrieves the UI5 sources from the eclipse installation and uses the
     * optimized sources for the application.</li>
     * <li><code>index_dev.html</code> : file for testing on the server, retrieves the UI5 sources from HANA and uses the current dev sources for
     * the application.</li>
     * <li><code>index.html</code> : file to be called for productive usage, retrieves the UI5 sources from HANA and uses the optmized sources for
     * the application.</li>
     * </ul>
     * </p>
     * <h2>Integration with XSE</h2>
     * <p>
     * The application integrates with XSE via XSJS services and uses an application-specific JSON-based protocol as payload. On the client side,
     * there is a {@link jd.ui.eid.service service layer} and a {@link jd.ui.eid.model custom model layer} which are responsible for data handling. If
     * the application requires data from XSE, it calls a method on a service class (usually called from a controller method). The service class then
     * calls the respective XSJS service via jQuery's AJAX API. Once the response has been retrieved, the service class takes the data and pushes it
     * into the custom model. This in turn will update related bindings, etc. and thus, leverage all the available UI5 features around models and data
     * bindings.
     * </p>
     * <p>
     * The custom model implementation supports paging, sorting, and filtering on the server-side. That means, when handling lists, the application
     * usually only has a subset of data available on the client. If more data is required (e.g. when the user goes through several pages), the next
     * chunk of data is retrieved.
     * </p>
     * <h2>Folder Structure</h2>
     * <p>
     * The folder structure is as follows:
     * <ul>
     * <li>{@link jd.ui.eid.application application} - contains a central application object and application-specific parameters.</li>
     * <li>asset - contains all non-JavaScript resources:
     * <ul>
     * <li>css - contains all CSS resources (only after the build process).</li>
     * <li>data - contains test data files for local testing.</li>
     * <li>img - contains all image resources.</li>
     * <li>less - contains all LESS resources (which will be compiled into CSS by the build process).</li>
     * <li>text - contains the text resources.</li>
     * </ul>
     * </li>
     * <li>{@link jd.ui.eid.common common} - contains helper classes and utility functions.</li>
     * <li>{@link jd.ui.eid.control control} - contains all custom controls.</li>
     * <li>fragment - contains all xml fragments.</li>
     * <li>{@link jd.ui.eid.model model} - contains files relevant for the application-specific model implementation.</li>
     * <li>{@link jd.ui.eid.service service} - contains all service classes.</li>
     * <li>test - contains all automated unit test files per class.</li>
     * <li>{@link jd.ui.eid.view view} - contains all views and their controllers.</li>
     * </ul>
     * </p>
     * <h2>Design Patterns</h2>
     * <p>
     * The application uses several design patterns:
     * <ul>
     * <li>Fragment Delegates</li>
     * <li>Merge Controllers</li>
     * </ul>
     * </p>
     * <h3>Fragment Delegates</h3>
     * <p>
     * Fragment delegates are essentially controllers of fragments. They are all located in {@link jd.ui.eid.common.delegate}. They are assigned to a
     * fragment when it is programmatically instantiated and serves as the event handler for all events from that fragment. For some delegates, there
     * is an inheritance tree if there are multiple delegates with similar functionality.
     * </p>
     * <h3>Merge Controllers</h3>
     * <p>
     * Merge Controllers are static classes whose properties (i.e. methods) are merged into a UI5 controller declaration. Most merge controllers are
     * located in {@link jd.ui.eid.main.view.shared}. They are merged using jQuery's <code>extend</code> mechanism. Most merge controllers have an
     * <code>init</code> and <code>exit</code> method (see documentation of the respective merge controller) which needs to be called from the
     * consuming controller in the respective lifecycle hooks in order to work properly. Some merge controllers have config objects which have to be
     * set before they are initialized (e.g. to provide the id of specific controls handled by the merge controller.)
     * </p>
     * <h2>Build Process (Optimized Sources)</h2>
     * <p>
     * The optimized application sources are generated using <a href="http://maven.apache.org/">Maven</a>. Whenever the application is changed, the
     * Maven build process needs to be triggered in order to generate optimized sources. The Maven environment has to be set up as per the official
     * Maven documentation. Afterwards, the optimized sources can be generated using via calling <code>mvn clean compile</code> from the console in
     * the folder of the <code>pom.xml</code> file. The generated sources are stored in the <code>target</code> folder.
     * </p>
     * <p>
     * In order for the build process to work properly, the following prerequisites have to be met by the coding:
     * <ul>
     * <li>It is assumed that the Javascript coding of each file is wrapped in an anonymous function, e.g.:
     * 
     * <pre>
     * (function() {
     *     // Coding goes here
     * })();
     * </pre>
     * 
     * </li>
     * <li>It is assumed that there is only one declare statement per file.</li>
     * <li>It is assumed that all views and fragments are of type XML.</li>
     * <li>It is assumed that a view and its controller have the same name.</li>
     * <li>It is assumed that all XML fragment tags have a <code>fragmentName</code> attribute which contains qualified name for the fragment that
     * you would also pass to sap.ui.xmlfragment.</li>
     * </ul>
     * </p>
     * <p>
     * The build process will compile a <code>all.js</code> file which contains the entire application coding including the xml fragments and xml
     * views.
     * </p>
     * <h2>Automated Unit Tests</h2>
     * <p>
     * The automated unit test suite is based on jQuery's QUnit. The test suite can be executed from the html files in the <code>eid/ui/test</code>
     * folder.
     * </p>
     * 
     * @name jd.ui.eid
     */
    jd.ui.eid = {};

    /**
     * Ensures that the given module is loaded and executed before execution of the current script continues. Wraps the default implementation so that
     * if require fails (e.g. due to session timeout), the application can respond.
     * 
     * @see jd.ui.eid.require
     */
    jd.ui.eid.require = function(sModuleName, fnCallback) {
        try {
            $.sap.require.apply(this, arguments);
        } catch (oError) {
            $.sap.log.error(oError.message);
        }
    };

    /**
     * Custom method for instantiating an XML fragment. If the fragment is available in our fragment registry, we call the standard implementation
     * with the markup, otherwise, we let standard implementation load the view as usual.
     * 
     * @see sap.ui.xmlfragment
     * @param {string}
     *            [sId] id of the newly created Fragment
     * @param {string|object}
     *            vFragment name of the Fragment (or Fragment configuration as described above, in this case no sId may be given. Instead give the id
     *            inside the config object, if desired)
     * @param {sap.ui.core.mvc.Controller}
     *            [oController] a Controller to be used for event handlers in the Fragment
     * @returns {sap.ui.core.Control|sap.ui.core.Control[]} the root Control(s) of the created Fragment instance
     */
    jd.ui.eid.xmlfragment = function(sId, vFragment, oController) {
        try {
            var _sId, _sFragmentName, _oController, _oContainingView;
            if (typeof (sId) === "string") { // basic call
                if (typeof (vFragment) === "string") { // with ID
                    _sId = sId;
                    _sFragmentName = vFragment;
                    _oController = oController;

                } else { // no ID, sId is actually the name and vFragment the optional Controller
                    _sFragmentName = sId;
                    _oController = vFragment;
                }
            } else { // advanced call
                _sId = sId.id;
                _sFragmentName = sId.fragmentName;
                _oContainingView = sId.containingView;
                _oController = vFragment; // second parameter "vFragment" is the optional Controller
            }

            if (_mFragmentRegistry[_sFragmentName]) {
                var sXml = _mFragmentRegistry[_sFragmentName];
                var oFragmentConfig = {
                    fragmentContent : sXml,
                    type : 'XML'
                };
                if (_sId) {
                    oFragmentConfig.id = _sId;
                }
                if (_oContainingView) {
                    oFragmentConfig.containingView = _oContainingView;
                }
                return sap.ui.fragment(oFragmentConfig, _oController);
            } else {
                return sap.ui.xmlfragment.apply(this, arguments);
            }
        } catch (oError) {
            $.sap.log.error(oError.message);
        }
    };

    /**
     * Custom method for instantiating a view. If the view is available in our view registry, we call the standard implementation with the markup,
     * otherwise, we let the standard implementation load the view as usual.
     * 
     * @see jd.ui.eid.xmlview
     * @param {string}
     *            [sId] id of the newly created view
     * @param {string|object}
     *            vView name of the view or view configuration as described above.
     * @returns {sap.ui.core.mvc.XMLView} the created XMLView instance.
     */
    jd.ui.eid.xmlview = function(sId, vView) {
        try {
            var _vView = arguments.length == 1 ? sId : vView;
            var sModuleName = _getModuleName(_vView);
            if (_mViewRegistry[sModuleName]) {
                return sap.ui.xmlview({
                    viewContent : _mViewRegistry[sModuleName]
                });
            } else {
                return sap.ui.xmlview(_vView);
            }
        } catch (oError) {
            $.sap.log.error(oError.message);
        }
    };

    /* SECTION - Preload Mechanism - START */

    // Keep a reference to the original $.sap.require implementation.
    var _fnStandardImplementation = $.sap.require;

    /**
     * We extend (i.e. overwrite and call the original implementation after doing some custom stuff) the require mechanism of UI5. DISCLAIMER: DO NOT
     * use this unless you are aware of the consequences and implications of such a change.<br />
     * What we do is essentially check whether a passed module is available in our custom module registry. If so, we evaluate the module and
     * afterwards remove it from our registry (we don't need it there anymore). In all other cases (also for debug resources), we let the original UI5
     * implementation take over.
     * 
     * @param {string|object}
     *            sModuleName the name of the module. Either a string or an object with properties modName and type.
     */
    $.sap.require = function(sModuleName) {
        var _sModuleName = _getModuleName(sModuleName);
        if (!sap.ui.getCore().getConfiguration().getDebug() && _aModuleRegistry[_sModuleName]) {
            var fnModule = _aModuleRegistry[_sModuleName];
            delete _aModuleRegistry[_sModuleName];
            fnModule();
        } else {
            _fnStandardImplementation.apply($.sap, arguments);
        }
    };

    /**
     * Registers an XML view as preloaded.
     * 
     * @param {string|object}
     *            sView the name of the module. Either a string or an object with properties modName and type.
     * @param {string}
     *            sXml the xml string containing the view declaration.
     */
    jd.ui.eid.registerXMLView = function(sView, sXml) {
        _mViewRegistry[sView] = sXml;
    };

    /**
     * Registers an XML fragment as preloaded.
     * 
     * @param {string}
     *            sFragment the name of the fragment.
     * @param {string}
     *            sXml the xml string containing the fragment declaration.
     */
    jd.ui.eid.registerXMLFragment = function(sFragment, sXml) {
        _mFragmentRegistry[sFragment] = sXml;
    };

    /**
     * Registers a module as preloaded.
     * 
     * @param {string|object}
     *            sModuleName the name of the module. Either a string or an object with properties modName and type.
     * @param {function}
     *            fn a function containing the module.
     */
    jd.ui.eid.registerModule = function(sModuleName, fn) {
        sModuleName = _getModuleName(sModuleName);
        _aModuleRegistry[sModuleName] = fn;
    };

    /* SECTION - Preload Mechanism - END */

    /* SECTION - Extensions & Workarounds - START */

    (function() {
        // sap.ui.commons.Label
        // Labels should have tooltip
        $.sap.require("sap.ui.commons.Label");

        var fnStandardOnAfterRendering = sap.ui.commons.Label.prototype.onAfterRendering;

        sap.ui.commons.Label.prototype.onAfterRendering = function() {
            if (typeof fnStandardOnAfterRendering == "function") {
                fnStandardOnAfterRendering.apply(this, arguments);
            }

            if (!this.$().attr("title") && !this.getTooltip()) {
                // If it doesn't have a tooltip yet, we add the label as a tooltip
                var sLabelText = this.$().text();
                var sTooltip = sLabelText.replace(":", ""); // remove colon
                this.$().attr("title", sTooltip);
            }
        };
    })();

    (function() {
        // This is a workaround for a bug in the toolbar regarding the overflow popup which is displayed when there is not sufficient space for all
        // the items to be displayed.
        // To reproduce the error:
        // 1) Go to the dashboard and resize the screen the screen so that you see an overflow popup in the toolbar above the table/chart.
        // 2) Click on the arrow which will display the overflow toolpopup.
        // 3) While the arrow is open, click on personalization in the shell.
        // 4) Navigate back to the dashboard
        // Then, you'll see an Uncaught Exception on the console which will crash the application.
        // NB: This workaround can probably be removed in a higher UI5 version (> UI5 1.20).
        $.sap.require("sap.ui.commons.ToolbarRenderer");
        sap.ui.commons.ToolbarRenderer.emptyOverflowPopup = function(oToolbar) {
            var oPopupHolder = jQuery.sap.domById(oToolbar.getId() + "-pu");
            if (oPopupHolder /* WORKAROUND BEGIN */&& oToolbar.getDomRef() /* WORKAROUND END */) {
                var oOverflowButton = jQuery.sap.domById(oToolbar.getId() + "-mn");
                var oToolbarCont = oToolbar.getDomRef().firstChild.firstChild;
                while (oPopupHolder.hasChildNodes()) {
                    oToolbarCont.insertBefore(oPopupHolder.firstChild, oOverflowButton);
                }
            }
        };

    })();

    /* SECTION - Extensions & Workarounds - END */

    /* Namespace Comments */

    /**
     * @namespace The application namespace provides scenario-specific application objects.
     * @name jd.ui.eid.application
     */

    /**
     * @namespace The common namespace provides commonly used functions.
     * @name jd.ui.eid.common
     */

    /**
     * @namespace The control namespace contains all custom controls.
     * @name jd.ui.eid.control
     */

    /**
     * @namespace The fragment namespace contains all XML fragments used in the application.
     * @name jd.ui.eid.fragment
     */

    /**
     * @namespace The model namespace provides the custom model implementation. The custom model implementation is loosely coupled to the
     *            {@link jd.ui.eid.service service namespace}.
     * @name jd.ui.eid.model
     */

    /**
     * @namespace
     * <p>
     * The service namespace provides functionality to interact with the HANA backend services.
     * </p>
     * <h2>Client Request for Lists</h2>
     * <p>
     * For enabling the server to filter/sort list data by filtering/sorting criteria that were set on client-side, the client has to send them inside
     * the data request. Therefore the client will execute a HTTP post-request, sending the required filtering/sorting criteria within the HTTP-body.
     * Due to the paging requirements the client also needs to specify the data chunk, which he requires to display the right page.
     * </p>
     * <p>
     * The following JSON format specifies the general structure, which will be supported by the service framework to serve to requirements mentioned
     * above.
     * </p>
     * <p>
     * POST-Body:
     * 
     * <pre>
     * {
     *     &quot;Filters&quot; : [],
     *     &quot;Sorters&quot; : [],
     *     &quot;Top&quot; : 10,
     *     &quot;Skip&quot; : 10,
     *     &quot;Data&quot; : {}
     * }
     * </pre>
     * 
     * </p>
     * <p>
     * <ul>
     * <li>The property Filters contains all filtering criteria, which were set by the table control.</li>
     * <li>The property Sorters contains all sorting criteria, which were set by the table control.</li>
     * <li>The property Top contains the amount of data, which will be retrieved from the backend service.</li>
     * <li>The property Skip contains the amount of data the client already received and should be skipped within the data request.</li>
     * <li>The property Data contains additional parameters which should be passed within the request.</li>
     * <li>i.e. this could the filtering values of the custom control.</li>
     * </ul>
     * </p>
     * <h2>Server Response for Lists</h2>
     * <p>
     * After the backend service received the client request mentioned at chapter 2.1.1, the server will respond with the following JSON string.
     * </p>
     * <p>
     * Response:
     * 
     * <pre>
     * {
     *     &quot;Result&quot;: {
     *         &quot;DTCList&quot;: {
     *             &quot;Count&quot;: 28,
     *             &quot;Records&quot;: [...]
     *      }
     *     }
     *     }
     * </pre>
     * 
     * </p>
     * <p>
     * Within the response the client will return a Result which could contain multiple list objects. Each list objects will be defined by four
     * properties:
     * <ul>
     * <li>Count: Total amount of data records.</li>
     * <li>Records: List of data.</li>
     * </ul>
     * </p>
     * <h2>Class Hierarchy</h2>
     * <p>
     * Inside the service package all classes are stored which implement a specific backend service connection. Therefore all service classes should
     * extend the generic class {@link jd.ui.eid.service.BaseServiceFacade BaseServiceFacade}. This class is defined as abstract and offers all basic
     * functions which every service class should use to establish a backend service communication.
     * </p>
     * 
     * @name jd.ui.eid.service
     */

    /**
     * @namespace The view namespace contains all views and their respective controller. As a general rule: if a view contains other views, those are
     *            usually available in a sub-folder with the same name as the view (e.g. {@link jd.ui.eid.view.main.Worksheet Worksheet view} and the
     *            views which are displayed in that view can be found in the {@link jd.ui.eid.view.main.worksheet worksheet sub-folder}.
     * @name jd.ui.eid.view
     */

    /**
     * @namespace
     * <p>
     * The customizing views belong to the customizing application. It consists of a {@link jd.ui.eid.view.customizing.Shell shell view} and four
     * views:
     * <ul>
     * <li>{@link jd.ui.eid.view.customizing.shell.KeyValueParameters Parameters view} for maintaining general parameters.</li>
     * <li>{@link jd.ui.eid.view.customizing.shell.KPIs KPIs view} for maintaining KPIs (i.e. name, description).</li>
     * <li>{@link jd.ui.eid.view.customizing.shell.Severity Severity & Warning Light view} for assigning a severity rating to warning lights (e.g.
     * for KPI calculation).</li>
     * <li>{@link jd.ui.eid.view.customizing.shell.EngineHours Engine Hour Ranges view} for maintaining engine hour ranges per platform & product
     * line combination.</li>
     * </ul>
     * </p>
     * @name jd.ui.eid.view.customizing
     */

    /**
     * @namespace
     * <p>
     * The main views belong to the main application. It consists of a {@link jd.ui.eid.view.main.Shell shell view} as the frame, an overlay for the
     * {@link jd.ui.eid.view.main.Worksheet worksheet} (used for creating evidence packages) and another overlay for the
     * {@link jd.ui.eid.view.main.EvidencePackage evidence package} itself.
     * </p>
     * <p>
     * The view hierarchy can be described as follows:
     * <ul>
     * <li>{@link jd.ui.eid.view.main.Shell Shell}
     * <ul>
     * <li>{@link jd.ui.eid.view.main.shell.Dashboard DTC Dashboard}</li>
     * <li>{@link jd.ui.eid.view.main.shell.EvidencePackageList Evidence Package List}</li>
     * <li>{@link jd.ui.eid.view.main.shell.personalization.FilterSettings DTC Filter Personalization}</li>
     * <li>{@link jd.ui.eid.view.main.shell.personalization.DTCBlacklist DTC Blacklist}</li>
     * </ul>
     * </li>
     * <li>{@link jd.ui.eid.view.main.Worksheet Worksheet}
     * <ul>
     * <li>Discovery (no view)
     * <ul>
     * <li>{@link jd.ui.eid.view.main.worksheet.discovery.DTCList DTC List}</li>
     * </ul>
     * </li>
     * <li>{@link jd.ui.eid.view.main.worksheet.Evidence Evidence}
     * <ul>
     * <li>{@link jd.ui.eid.view.main.worksheet.evidence.DTACCaseList DTAC Case List}</li>
     * <li>{@link jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList Warranty Claims By Prime Part List}</li>
     * </ul>
     * </li>
     * </ul>
     * </li>
     * <li>{@link jd.ui.eid.view.main.EvidencePackage}
     * <ul>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.Summary Summary}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.DTCSummary DTC Summary}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.DTACCaseSummary DTAC Case Summary}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary Warranty Claim Summary}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.MachineOptionSummary Machine Option Code Summary}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.PINPopulationSummary PIN Population Summary}</li>
     * </ul>
     * </li>
     * </ul>
     * </p>
     * @name jd.ui.eid.view.main
     */

    /**
     * @namespace Listing of the events fired via the UI5 event bus and their parameters.
     */
    jd.ui.eid.Events = null;

    /**
     * Fired when input parameters are sent to the print application when printing the evidence package.
     * 
     * @name jd.ui.eid.Events#PrintEvidencePackage::inputShared
     * @event
     * @param {object}
     *            EvidencePackageHeader map of evidence package header data.
     * @param {object}
     *            PrintFilterOptions map of print options chosen by the user.
     */

    /**
     * Fired by the print application once the print queue has been processed and the evidence package is ready for printing.
     * 
     * @name jd.ui.eid.Events#PrintEvidencePackage::ready
     * @event
     */

    /**
     * Fired by the print application to request input data for the print view of the evidence package.
     * 
     * @name jd.ui.eid.Events#PrintEvidencePackage::requestInput
     * @event
     */

    /**
     * Fired by the Evidence Package view after the context changed
     * 
     * @name jd.ui.eid.Events#EvidencePackageView::contextChanged
     * @event
     */

    /**
     * Fired by Evidence Package Service Facade when a machine option service request is pending
     * 
     * @name jd.ui.eid.Events#MachineOptionService::servicePending
     * @event
     * 
     */

    /**
     * Fired by Evidence Package Service Facade when a machine option service request failed
     * 
     * @name jd.ui.eid.Events#MachineOptionService::serviceFailed
     * @event
     * 
     */

    /**
     * Fired by Evidence Package Service Facade when a machine option service request was successfull
     * 
     * @name jd.ui.eid.Events#MachineOptionService::serviceSuccessfull
     * @event
     * 
     */

    /**
     * Fired by the Shell to notify about KPI retrieval
     * 
     * @name jd.ui.eid.Events#Model::kpisRetrieved
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.shared.DTCDetails} view if it should be closed
     * 
     * @name jd.ui.eid.Events#DTCDetailsView::close
     * @event
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the {@link jd.ui.eid.view.main.shared.DTCDetails DTC Details View} if the overlay
     * was closed.
     * 
     * @name jd.ui.eid.Events#DTCDetailsOverlay::closed
     * @event
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the {@link jd.ui.eid.view.main.shared.DTCDetails DTC Details View} on the
     * dashboard if the overlay was closed.
     * 
     * @name jd.ui.eid.Events#DTCDetailsOverlayDashboard::closed
     * @event
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.shared.DTCDetails DTC Details View} on the dashboard if it should be closed.
     * 
     * @name jd.ui.eid.Events#DTCDetailsViewDashboard::close
     * @event
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.evidence.DTACCaseDetails DTAC Case Details View} if it should be closed.
     * 
     * @name jd.ui.eid.Events#DTACCaseDetailsView::close
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the {@link jd.ui.eid.view.main.evidence.DTACCaseDetails DTAC Case Details View}
     * if the overlay was closed.
     * 
     * @name jd.ui.eid.Events#DTACCaseDetailsOverlay::closed
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.evidence.WarrantyClaimDetails Warranty Claim Details View} if it should be closed.
     * 
     * @name jd.ui.eid.Events#WarrantyClaimDetailsView::close
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the
     * {@link jd.ui.eid.view.main.evidence.WarrantyClaimDetails Warranty Claim Details View} if the overlay was closed.
     * 
     * @name jd.ui.eid.Events#WarrantyClaimDetailsOverlay::closed
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.evidence.WarrantyClaimPrimePart Warranty Claim Prime Part View} if it should be closed.
     * 
     * @name jd.ui.eid.Events#WarrantyClaimPrimePartView::close
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the
     * {@link jd.ui.eid.view.main.evidence.WarrantyClaimPrimePart Warranty Claim Prime Part View} if the overlay was closed.
     * 
     * @name jd.ui.eid.Events#WarrantyClaimPrimePartOverlay::closed
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.Worksheet Worksheet View} if it should be closed.
     * 
     * @name jd.ui.eid.Events#WorksheetView::close
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the {@link jd.ui.eid.view.main.Worksheet Worksheet View} if the overlay was
     * closed.
     * 
     * @name jd.ui.eid.Events#WorksheetOverlay::closed
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.view.main.EvidencePackage Evidence Package View} if it should be closed.
     * 
     * @name jd.ui.eid.Events#EvidencePackageView::close
     * @event
     * 
     */

    /**
     * Fired by the {@link jd.ui.eid.common.OverlayViewContainer} of the {@link jd.ui.eid.view.main.EvidencePackage Evidence Package View} if the
     * overlay was closed.
     * 
     * @name jd.ui.eid.Events#EvidencePackageOverlay::closed
     * @event
     * 
     */

    /**
     * Fired by while navigating to another view
     * 
     * @name jd.ui.eid.Events#Navigation::navigating
     * @event
     * @param {string}
     *            origin the origin view name
     * @param {string}
     *            target the target view name
     */

    /**
     * Fired to trigger a navigation within the shell to the workset item passed as parameter.
     * 
     * @name jd.ui.eid.Events#Shell::navigate
     * @event
     * @param {string}
     *            target the workset item id to navigate to.
     */

    /**
     * Fired when a DTC was removed from the Evidence Package DTC basket
     * 
     * @name jd.ui.eid.Events#EvidencePackage::DTCRemoved
     * @event
     */

    /**
     * Fired when a DTC filter was changed in the Evidence Package
     * 
     * @name jd.ui.eid.Events#EvidencePackage::editDTCFilter
     * @event
     */

    /**
     * Fired to notify all views to update their data after the DTC filter changed
     * 
     * @name jd.ui.eid.Events#EvidencePackage::newDTCFiltersApplied
     * @event
     * 
     */
})();