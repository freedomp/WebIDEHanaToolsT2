(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.DateRangeFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");

    /**
     * This custom control inherits from the jd.ui.eid.controls.FilterItem control. It lets the user choose two dates: a start date and an end date
     * and writes these to the inherited selection property of the FilterItem (more specifically, to selection.Start and selection.End in a YYYYMMDD
     * format).
     * 
     * Technically, it consists of three hidden aggregations:
     * <ul>
     * <li>a sap.ui.commons.Datepicker for the start date</li>
     * <li>a sap.ui.commons.Label in between</li>
     * <li>a sap.ui.commons.Datepicker for the end date</li>
     * There is minimal validation logic: the CalendarWeekFilterItem makes sure that either no dates are selected at all, or two dates (where the end
     * date is bigger or equal to the start date).
     * 
     * <ul>
     * <li>Events
     * <ul>
     * <li>invalid : thrown if the end date is earlier than the start date</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.DateRangeFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.DateRangeFilterItem",
    /** @lends jd.ui.eid.control.DateRangeFilterItem */
    {
        metadata : {
            properties : {},

            aggregations : {
                _startDatePicker : {
                    type : "sap.ui.commons.DatePicker",
                    multiple : false,
                    visibility : "hidden"
                },
                _fromLabel : {
                    type : "sap.ui.commons.Label",
                    multiple : false,
                    visibility : " hidden"
                },
                _endDatePicker : {
                    type : "sap.ui.commons.DatePicker",
                    multiple : false,
                    visibility : "hidden"
                },
                _toLabel : {
                    type : "sap.ui.commons.Label",
                    multiple : false,
                    visibility : " hidden"
                }
            },
            events : {
                invalid : {}
            }
        },

        /**
         * Instantiate the aggregations
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);
            this.addStyleClass("jdUiEidDateRangeFilterItem");

            this.oStartDatePicker = new sap.ui.commons.DatePicker({
                locale : jd.ui.eid.common.DateHelper.getLocale(),
                change : [this._handleDatepickerChange, this]
            }).addStyleClass("jdUiEidDateRangeFilterItemStart jdUiDatepicker");
            this.setAggregation("_startDatePicker", this.oStartDatePicker);

            this.oFromLabel = new sap.ui.commons.Label({
                text : "{i18n>DATE_RANGE_FLD_FROM}"
            }).addStyleClass('jdUiEidDateRangeFilterItemLabel jdUiLbl');
            this.oFromLabel.setTextAlign(sap.ui.core.TextAlign.Right);
            this.setAggregation("_fromLabel", this.oFromLabel);

            this.oEndDatePicker = new sap.ui.commons.DatePicker({
                locale : jd.ui.eid.common.DateHelper.getLocale(),
                change : [this._handleDatepickerChange, this]
            }).addStyleClass("jdUiEidDateRangeFilterItemEnd jdUiDatepicker");
            this.setAggregation("_endDatePicker", this.oEndDatePicker);

            this.oToLabel = new sap.ui.commons.Label({
                text : "{i18n>DATE_RANGE_FLD_TO}"
            }).addStyleClass('jdUiEidDateRangeFilterItemLabel jdUiLbl');
            this.oToLabel.setTextAlign(sap.ui.core.TextAlign.Right);
            this.setAggregation("_toLabel", this.oToLabel);
        },

        /**
         * Sets the date pickers to the initial dates from the model
         * 
         * @param {object}
         *            oSelection
         * @param {string}
         *            oSelection.Start a start date in the following format: yyyyMMdd
         * @param {string}
         *            oSelection.End an end date in the following format: yyyyMMdd
         * @returns {jd.ui.eid.control.DateRangeFilterItem} this
         */
        setSelection : function(oSelection) {
            if (oSelection) {
                this.setProperty("selection", oSelection);
                var bAct = false;
                if (oSelection.Start) {
                    var sYyyymmdd = jd.ui.eid.common.DateHelper.hyphenizedDateToYyyymmdd(oSelection.Start);
                    this.oStartDatePicker.setYyyymmdd(sYyyymmdd);
                    bAct = true;
                } else {
                    this.oStartDatePicker.setYyyymmdd('');
                }

                if (oSelection.End) {
                    var sYyyymmdd = jd.ui.eid.common.DateHelper.hyphenizedDateToYyyymmdd(oSelection.End);
                    this.oEndDatePicker.setYyyymmdd(sYyyymmdd);
                } else {
                    this.oEndDatePicker.setYyyymmdd('');
                    bAct = false;
                }
                this.oStartDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oEndDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oStartDatePicker.setTooltip(null);
                this.oEndDatePicker.setTooltip(null);
                this.setActive(bAct);
            }
            return this;
        },

        /**
         * An event handler for DatePicker change events. It verifies input and handles errors
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the original event from the DatePicker
         */
        _handleDatepickerChange : function(oEvent) {

            var sStart = this.oStartDatePicker.getYyyymmdd();
            var sEnd = this.oEndDatePicker.getYyyymmdd();

            var sStartTextDate = this.oStartDatePicker.getValue();
            var oStartTextDate = sStartTextDate ? jd.ui.eid.common.DateHelper.parseLocalShortDate(sStartTextDate) : null;
            var sEndTextDate = this.oEndDatePicker.getValue();
            var oEndTextDate = sEndTextDate ? jd.ui.eid.common.DateHelper.parseLocalShortDate(sEndTextDate) : null;

            // The user has entered an invalid text in the TextField of the start DatePicker
            var bStartInvalid = sStartTextDate
                    && !jd.ui.eid.common.DateHelper.isSameDay(oStartTextDate, jd.ui.eid.common.DateHelper.YyyymmddToDate(sStart));
            if (bStartInvalid) {
                this._callOutHelper("{i18n>DATE_RANGE_FILTER_ITEM_ERROR_INVALID}", this.oStartDatePicker);
            } else {
                this.oStartDatePicker.setTooltip(null);
                this.oStartDatePicker.setValueState(sap.ui.core.ValueState.None);
            }

            // The user has entered an invalid text in the TextField of the end DatePicker
            var bEndInvalid = sEndTextDate && !jd.ui.eid.common.DateHelper.isSameDay(oEndTextDate, jd.ui.eid.common.DateHelper.YyyymmddToDate(sEnd));
            if (bEndInvalid) {
                this._callOutHelper("{i18n>DATE_RANGE_FILTER_ITEM_ERROR_INVALID}", this.oEndDatePicker);
            } else {
                this.oEndDatePicker.setTooltip(null);
                this.oEndDatePicker.setValueState(sap.ui.core.ValueState.None);
            }

            if (bStartInvalid || bEndInvalid) {
                return;

                // both Datepickers are empty, this's ok
            } else if (!sStart && !sEnd) {
                this.setProperty('selection', {
                    Start : '',
                    End : ''
                });
                this.oStartDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oEndDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oStartDatePicker.setTooltip(null);
                this.oEndDatePicker.setTooltip(null);
                this.setActive(false);
                this.fireValueChanged();

                // only one Datepicker has a value, display a nag for the empty one
            } else if (!sStart || !sEnd) {
                this._callOutHelper("{i18n>DATE_RANGE_FILTER_ITEM_ERROR_SET}", (!sStart) ? this.oStartDatePicker : this.oEndDatePicker);
                this.fireInvalid();

                // the start date is later than the end date, set both Datepickers to
                // invalid
            } else if (parseInt(sStart, 10) > parseInt(sEnd, 10)) {
                this._callOutHelper("{i18n>DATE_RANGE_FILTER_ITEM_ERROR_START}", this.oStartDatePicker);
                this._callOutHelper("{i18n>DATE_RANGE_FILTER_ITEM_ERROR_END}", this.oEndDatePicker);
                this.fireInvalid();

                // there are valid entries in both Datepickers
            } else {
                sStart = jd.ui.eid.common.DateHelper.yyyymmddToHyphenizedDate(sStart);
                sEnd = jd.ui.eid.common.DateHelper.yyyymmddToHyphenizedDate(sEnd);
                this.setProperty('selection', {
                    Start : sStart,
                    End : sEnd
                });
                this.oStartDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oEndDatePicker.setValueState(sap.ui.core.ValueState.None);
                this.oStartDatePicker.setTooltip(null);
                this.oEndDatePicker.setTooltip(null);
                this.setActive(true);
                this.fireValueChanged();
            }
        },

        /**
         * Helper method that sets the error state of a Datepicker and adds a callout with an error message
         * 
         * @param {string}
         *            sErrorMessage
         * @param {sap.ui.commons.DatePicker}
         *            oDatePicker
         */
        _callOutHelper : function(sErrorMessage, oDatePicker) {
            oDatePicker.setTooltip(null);
            oDatePicker.setValueState(sap.ui.core.ValueState.Error);
            var oCallout = new sap.ui.commons.Callout({
                content : new sap.ui.commons.TextView({
                    text : sErrorMessage
                }).addStyleClass("jdUiTv")
            }).addStyleClass("jdUiClt");
            oDatePicker.setTooltip(oCallout);
        },

        /**
         * Resets the DatePickers to display no date and have them display today's date when they open
         */
        _clear : function() {
            // reset both datepickers, this doesn't trigger events, so we don't need to double check for previous values
            this.oStartDatePicker.setTooltip(null);
            this.oStartDatePicker.setValueState(sap.ui.core.ValueState.None);
            this.oStartDatePicker.setYyyymmdd("");

            this.oEndDatePicker.setTooltip(null);
            this.oEndDatePicker.setValueState(sap.ui.core.ValueState.None);
            this.oEndDatePicker.setYyyymmdd("");

            var oCurrentSelection = this.getSelection();
            var oEmptySelection = {
                Start : "",
                End : ""
            };
            this.setActive(false);

            if (!$.sap.equal(oCurrentSelection, oEmptySelection)) {
                this.setSelection(oEmptySelection);
                return true;
            }
            return false;
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.DateRangeFilterItemRenderer"

    });
})();