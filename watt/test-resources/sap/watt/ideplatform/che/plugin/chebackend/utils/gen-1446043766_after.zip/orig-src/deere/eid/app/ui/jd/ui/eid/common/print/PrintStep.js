(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new PrintStep.
     * <ul>
     * <li>Events
     * <ul>
     * <li>processed : fired once the print step is completed.</li>
     * </ul>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The PrintStep is a base class from which specific print steps can be derived. It provides basic functionality such as state management
     *        and logging.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.print.PrintStep
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.print.PrintStep", /** @lends jd.ui.eid.common.print.PrintStep */
    {
        metadata : {
            events : {
                processed : {}
            }
        },

        _sLogComponent : null,
        _iState : null,
        _fnProcessCondition : null,

        /**
         * Initialize the print step.
         */
        init : function() {
            this._iState = jd.ui.eid.common.print.PrintStep.State.Inactive;
            this._sLogComponent = this.getMetadata().getName();
        },

        /**
         * Fires the <code>processed</code> event.
         * 
         * @param {object}
         *            mParameters a map of parameters to be passed with the event.
         */
        fireProcessed : function(mParameters) {
            $.sap.log.debug("Step processed " + this.getId(), null, this._sLogComponent);
            this._iState = jd.ui.eid.common.print.PrintStep.State.Completed;
            this.fireEvent("processed", mParameters);
        },

        /**
         * Processes the step.
         */
        process : function() {
            $.sap.log.debug("Processing step " + this.getId(), null, this._sLogComponent);
            this._iState = jd.ui.eid.common.print.PrintStep.State.Processing;

            // If a process condition was provided for this PrintStep, it should be executed only if the process condition function returns true.
            if (this.getProcessCondition() && !this.getProcessCondition()()) {
                $.sap.log.debug("Skipping step " + this.getId(), null, this._sLogComponent);
                this.fireProcessed();
                return;
            }

            this._process();
        },

        /**
         * Internal hook method with the processing logic. This method must be overrided by subclasses.
         * 
         * @abstract
         */
        _process : function() {
            // hook
        },

        /**
         * Sets the 'process condition' for this PrintStep. The step is processed only if this function returns true just before the step is executed.
         * 
         * @param {function}
         *            fnProcessCondition The function to be used as the process condition for this PrintStep
         * @returns {object} this PrintStep to facilitate chaining.
         */
        setProcessCondition : function(fnProcessCondition) {
            this._fnProcessCondition = fnProcessCondition;
            return this;
        },

        /**
         * Returns the process condition function for this PrintStep
         * 
         * @returns {function} the process condition for this PrintStep
         */
        getProcessCondition : function() {
            return this._fnProcessCondition;
        },

        /**
         * Gets the current state of the step.
         * 
         * @returns {jd.ui.eid.common.print.PrintStep.State} the state of the print step.
         */
        getState : function() {
            return this._iState;
        }
    });

    /**
     * @namespace Enumeration for process step states.
     */
    jd.ui.eid.common.print.PrintStep.State = {
        NotStarted : 0,
        Processing : 1,
        Completed : 2
    };
})();