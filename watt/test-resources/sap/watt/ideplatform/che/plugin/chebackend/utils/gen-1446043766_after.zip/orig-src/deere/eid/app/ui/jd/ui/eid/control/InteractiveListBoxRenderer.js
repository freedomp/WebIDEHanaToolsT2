(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.InteractiveListBoxRenderer");
    jd.ui.eid.require("sap.ui.commons.ListBoxRenderer");

    /**
     * Default renderer for control {@link jd.ui.eid.control.InteractiveListBox}.
     * 
     * @class Default renderer for control {@link jd.ui.eid.control.InteractiveListBox}.
     * @extends sap.ui.commons.ListBoxRenderer
     * @static
     * @name jd.ui.eid.control.InteractiveListBoxRenderer
     */
    jd.ui.eid.control.InteractiveListBoxRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.InteractiveListBoxRenderer, sap.ui.commons.ListBoxRenderer);

    /**
     * @see {sap.ui.commons.ListBoxRenderer#renderItemList}
     */
    jd.ui.eid.control.InteractiveListBoxRenderer.renderItemList = function(oListBox, rm) {

        // Write the start tag
        rm.write("<ul id='" + oListBox.getId() + "-list'");

        rm.writeAttribute("tabindex", this.getTabIndex(oListBox));

        // add ARIA stuff
        rm.writeAccessibilityState(oListBox, {
            role : "listbox",
            multiselectable : oListBox.getAllowMultiSelect()
        });
        rm.write(">");

        var items = oListBox.getItems(), iRealItemIndex = 0, // to not count separators
        iRealItemCount = 0;

        for ( var i = 0; i < items.length; i++) {
            if (!(items[i] instanceof sap.ui.core.SeparatorItem)) {
                iRealItemCount++;
            }
        }

        var bMarkLastChild = (jQuery.browser.msie && (jQuery.browser.version == 8 || jQuery.browser.version == 7)); // IE8 workaround for "last-cild"

        // Write the rows with the items
        for ( var i = 0; i < items.length; i++) {
            var item = items[i];

            if (item instanceof sap.ui.core.SeparatorItem) {
                // draw a separator
                // not supported
            } else {
                // regular ListItem or just a plain Item
                rm.write("<li");
                rm.writeElementData(item);
                rm.writeAttribute("data-sap-ui-lbx-index", i);

                rm.addClass("sapUiLbxI");
                if (!item.getEnabled()) {
                    rm.addClass("sapUiLbxIDis");
                }
                rm.writeAttribute("tabindex", "-1"); // make all LIs to focusable elements, tabindex will be changed by ItemNavigation
                if (oListBox.isIndexSelected(i)) {
                    rm.addClass("sapUiLbxISel");
                }
                rm.writeClasses();

                // get the text values
                var sText = item.getText();

                // tooltip
                if (item.getTooltip_AsString()) {
                    rm.writeAttributeEscaped("title", item.getTooltip_AsString());
                } else {
                    rm.writeAttributeEscaped("title", sText);
                }

                // ARIA
                rm.writeAccessibilityState(item, {
                    role : "option",
                    selected : (i === oListBox.getSelectedIndex()),
                    setsize : iRealItemCount,
                    posinset : iRealItemIndex + 1
                });

                rm.write(">");

                // write icon column if required
                // EDIT: not supported

                // write the main text
                rm.write("<span class='sapUiLbxITxt");
                if (bMarkLastChild && !bDisplaySecondaryValues) {
                    rm.write(" sapUiLbxILastChild");
                }
                rm.write("'");
                rm.writeAttribute("id", item.getId() + "-txt");
                var oTextAlign = oListBox.getValueTextAlign();
                if (oTextAlign) {
                    rm.write("style='text-align:" + sap.ui.commons.ListBoxRenderer.getTextAlign(oTextAlign, null) + "'");
                }
                rm.write(">");

                // <EDIT>
                rm.write("<input");
                rm.writeAttribute("type", "text");
                rm.addClass("jdUiEidInteractiveListBoxItemInput");
                rm.writeClasses();
                rm.writeAttribute("value", sText);
                rm.write(" />");
                // </EDIT>

                rm.write("<span");
                rm.addClass("jdUiEidInteractiveListBoxItemText");
                rm.writeClasses();
                rm.write(">");

                if (sText === "" || sText === null) {
                    rm.write("&nbsp;");
                } else {
                    rm.writeEscaped(sText);
                }
                rm.write("</span>");

                // Potentially display second column
                // not supported

                rm.write("<span");
                rm.addClass("jdUiEidInteractiveListBoxActionGroup");
                rm.writeClasses();
                rm.write(">");

                rm.write("<span");
                rm.addClass("jdUiEidInteractiveListBoxActionEdit");
                rm.writeClasses();
                rm.write("></span>");

                rm.write("<span");
                rm.addClass("jdUiEidInteractiveListBoxActionRemove");
                rm.writeClasses();
                rm.write("></span>");

                rm.write("</span>");

                rm.write("</span></li>");
                iRealItemIndex++;
            }
        }

        // Close the surrounding element
        rm.write("</ul>");
    };

})();