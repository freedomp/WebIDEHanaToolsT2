(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ToolPopup");
    jd.ui.eid.require("sap.ui.ux3.ToolPopup");

    /**
     * @class This ToolPopup is a themed and extended version of the UI5 standard ToolPopup.
     * 
     * It also disables animations for opening and closing.
     * 
     * <ul>
     * <li>Associations
     * <ul>
     * <li>autoCloseAreas : sap.ui.core.Control[] These controls are used to determine
     * autoCloseAreas of the sap.ui.core.Popup used internally.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * 
     * @extends sap.ui.ux3.ToolPopup
     * @name jd.ui.eid.control.ToolPopup
     */
    sap.ui.ux3.ToolPopup.extend("jd.ui.eid.control.ToolPopup",
    /** @lends jd.ui.eid.control.ToolPopup */
    {
        metadata : {
            associations : {
                autoCloseAreas : {
                    type : "sap.ui.core.Control",
                    singularName : "autoCloseArea",
                    multiple : true
                }
            }
        },

        /**
         * Adds branding CSS class, sets up autoCloseArea Control<->DomRef tracking.
         */
        init : function() {
            sap.ui.ux3.ToolPopup.prototype.init.apply(this, arguments);
            
            this.addStyleClass("jdUiEidToolPopup");

            // create this.oPopup
            this._ensurePopup();
            this._disablePopupAnimations();
            this.oPopup.setFollowOf(true);
            
            // mirrors the this.oPopup autoCloseAreas, see _onAfterRenderingDelegate
            this.aAutoCloseAreasDomRefs = [];
            // saves which control had which domref, see _onAfterRenderingDelegate
            this.oDomRefMap = {};
            // onAfterRendering delegate
            this.fnDelegate = {
                onAfterRendering : jQuery.proxy(this._onAfterRenderingDelegate, this)
            };
        },

        /**
         * Delegate to get informed when autocloseareas are re-rendered and their domRefs have to be
         * updated in this.oPopup
         * 
         * This function is called on different occasions:
         * <ul>
         * <li> after rendering (oEvent set), </li>
         * <li> at {@link sap.ui.ux3.ToolPopup#addAutoCloseArea} (oControl set) and </li>
         * <li> at {@link sap.ui.ux3.ToolPopup#removeAutoCloseArea} (oControl set, bRemove = true)
         * </li>
         * </ul>
         * 
         * @param {sap.ui.core.Event}
         *            oEvent event when used as a delegate event handler
         * @param {sap.ui.core.Control|DomRef}
         *            [oControl] control when used at {@link sap.ui.ux3.ToolPopup#addAutoCloseArea}
         *            or {@link sap.ui.ux3.ToolPopup#removeAutoCloseArea}
         * @param {boolean}
         *            [bRemove] should only be set when called from
         *            {@link sap.ui.ux3.ToolPopup#removeAutoCloseArea}
         * 
         */
        _onAfterRenderingDelegate : function(oEvent, oControl, bRemove) {
            if (oEvent != undefined) {
                oControl = oEvent.srcControl;
            }

            
            // remove old domRef
            this.aAutoCloseAreasDomRefs.slice(this.aAutoCloseAreasDomRefs
                    .indexOf(this.oDomRefMap[oControl]), 1);

            var oDomRef = oControl instanceof sap.ui.core.Element ? oControl.getDomRef() : oControl;
            if (!bRemove && oDomRef) {
                // add new domRef
                this.aAutoCloseAreasDomRefs.push(oDomRef);
                this.oDomRefMap[oControl] = oDomRef;
            }
            this.oPopup.setAutoCloseAreas(this.aAutoCloseAreasDomRefs);
        },

        /**
         * Set opener. This internally also adds the Opener to the autoCloseAreas.
         * 
         * @param [sap.ui.core.Control]
         *            oOpener
         */
        setOpener : function(oOpener) {
            // remove old opener from autocloseareas
            if (this.oOpener != null) {
                this.removeAutoCloseArea(this.oOpener);
            }
            sap.ui.ux3.ToolPopup.prototype.setOpener.apply(this, arguments);
            this.oOpener = oOpener;
            this.addAutoCloseArea(oOpener);
        },

        /**
         * do nothing here, superclass implementation causes infinite calls on this method
         */
        onfocusin : function() {
        },

        /**
         * Add an autoclosearea
         * 
         * @param [sap.ui.core.Control]
         *            oAutoClose the Control to add as AutoCloseArea
         */
        addAutoCloseArea : function(oAutoClose) {
            this.addAssociation("autoCloseAreas", oAutoClose);
            
            this._onAfterRenderingDelegate(undefined, oAutoClose);

            oAutoClose.addEventDelegate(this.fnDelegate);
        },

        /**
         * Remove an autoCloseArea
         * 
         * @param [sap.ui.core.Control]
         *            oAutoClose the Control to add as AutoCloseArea
         */
        removeAutoCloseArea : function(oAutoClose) {
            this._onAfterRenderingDelegate(undefined, oAutoClose, true);
            if(oAutoClose instanceof sap.ui.core.Element) {
            	oAutoClose.removeEventDelegate(this.fnDelegate);
            }
        },

        /**
         * Disable all open/close animations for the control by wrapping this.oPopup.close()/open()
         * with variants accepting durations set during this.open()/close()
         */
        _disablePopupAnimations : function() {
            this.oPopup.setDurations(0, 0);

            // disable close animation
            if (this.fnPopupClose === undefined) {
                var fnStdClose = this.oPopup.close;
                this.fnPopupClose = function() {
                    fnStdClose.apply(this, [0]);
                };
                this.oPopup.close = this.fnPopupClose;
            }

            // disable open animation
            if (this.fnPopupOpen === undefined) {
                var fnStdOpen = this.oPopup.open;
                this.fnPopupOpen = function() {
                    fnStdOpen.apply(this, [0]);
                };
                this.oPopup.open = this.fnPopupOpen;
            }
        },

        /**
         * Toggle visibility of the popup.
         */
        toggle : function() {
            if (this.isOpen()) {
                this.close();
            } else {
                this.open();
            }
        },

        /**
         * This overwrite does not accept parameters. Use setPosition() instead.
         * 
         * @see sap.ui.ux3.ToolPopup#open
         */
        open : function() {
            return sap.ui.ux3.ToolPopup.prototype.open.apply(this, []);
        },

        /**
         * This overwrite does not accept parameters.
         * 
         * @see sap.ui.ux3.ToolPopup#close
         */
        close : function() {
            return sap.ui.ux3.ToolPopup.prototype.close.apply(this, []);
        },

        renderer : "sap.ui.ux3.ToolPopupRenderer"
    });
})();