(function() {
    "use strict";
    $.sap.declare("jd.ui.eid.control.Fragment");
    $.sap.require("sap.ui.core.Fragment");

    /**
     * Constructor of a new Fragment.
     * 
     * @class Custom fragment implementation to leverage inlined XML fragments (created during build process). The object dispatches the creation of a
     *        fragment to {@link jd.ui.eid.xmlfragment}. It can be called like any other fragment from e.g. XML views. <strong>NB:</strong> This is
     *        technically not a control. It's in the control namespace for the sake of simplicity when referring to custom controls (i.e. custom
     *        managed objects).
     * @name jd.ui.eid.control.Fragment
     * @extends sap.ui.base.ManagedObject
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.control.Fragment", {
        metadata : {
            properties : {
                type : "string"
            }
        },
        constructor : function(sId, mSettings) {
            // sap.ui.base.ManagedObject.apply(this, arguments);
            // Dispatch to the custom fragment init method
            // var oControl = jd.ui.eid.xmlfragment.apply(null, arguments);
            var oControl = jd.ui.eid.xmlfragment(sId, mSettings, this);
            return oControl;
        }
    });

})();