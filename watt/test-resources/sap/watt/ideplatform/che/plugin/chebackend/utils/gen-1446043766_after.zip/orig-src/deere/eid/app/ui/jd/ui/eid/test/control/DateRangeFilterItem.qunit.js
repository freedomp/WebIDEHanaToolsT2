(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.DateRangeFilterItem");

    var oFilterItem = null;
    var oModel = null;
    var oData = {
        selection : {
            Start : "2013-11-30",
            End : "2013-12-01"
        }
    };

    module("jd.ui.eid.control.DateRangeFilterItem", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(oData);
            oFilterItem = new jd.ui.eid.control.DateRangeFilterItem();
            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    test("_clear() should set the selection.start to an empty string", function() {
        oFilterItem.bindProperty('selection', '/selection');
        var sExpResult = "";
        notEqual(oFilterItem.getSelection().Start, sExpResult);
        oFilterItem._clear();
        deepEqual(oFilterItem.getSelection().Start, sExpResult);
    });

    test("_clear() should return true if the model was changed", function() {
        oFilterItem.setSelection({
            Start : "2014-01-01",
            End : "2014-01-02"
        });
        var bExpResult = true;
        var bResult = oFilterItem._clear();
        equal(bResult, bExpResult);
    });

    test("_clear() should return false if the model was not changed", function() {
        oFilterItem.setSelection({
            Start : "",
            End : ""
        });
        var bExpResult = false;
        var bResult = oFilterItem._clear();
        equal(bResult, bExpResult);
    });

    test("getSelection() should return the correct model values", function() {
        oFilterItem.bindProperty('selection', '/selection');
        var oExpResult = oData.selection.Start;
        deepEqual(oFilterItem.getSelection().Start, oExpResult);
        oExpResult = oData.selection.End;
        deepEqual(oFilterItem.getSelection().End, oExpResult);
    });

    test("_handleDatepickerChange should set both fields to error state if the datepickers pass invalid values", function() {
        // there is no programmatic way to set DatePicker text fields with invalid values
        /**
         * @ignore
         */
        var fnGetValue1 = function() {
            return "foo";
        };
        oFilterItem.getAggregation("_startDatePicker").getValue = fnGetValue1;
        /**
         * @ignore
         */
        var fnGetValue2 = function() {
            return "bar";
        };
        oFilterItem.getAggregation("_endDatePicker").getValue = fnGetValue2;
        // simulate handling of change event
        oFilterItem._handleDatepickerChange();

        var sExpResult = sap.ui.core.ValueState.Error;
        var sStartState = oFilterItem.getAggregation("_startDatePicker").getValueState();
        equal(sStartState, sExpResult);
        var sEndState = oFilterItem.getAggregation("_endDatePicker").getValueState();
        equal(sEndState, sExpResult);
    });

})();