(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.PersonalizationFiltersServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oServiceFacade = new jd.ui.eid.service.PersonalizationFiltersServiceFacade("http://sap.com", "/jd/ui/eid/asset/data/", oModel, true);

    // Module for getDTCBlacklist()
    module("jd.ui.eid.service.PersonalizationFiltersServiceFacade", {
        setup : function() {
            // Start spying on methods
            sinon.spy(oServiceFacade, "_retrieveRecord");
            sinon.spy(oServiceFacade, "_send");
        },
        teardown : function() {
            // Stop spying on methods
            oServiceFacade._retrieveRecord.restore();
            oServiceFacade._send.restore();
        }
    });

    // *** TEST CASE #1 ***
    test(
            "getPersonalizationFilters() invokes the _retrieveRecord method of BaseServiceFacade with an empty object for the request's custom payload.",
            function() {
                // Invoke getPersonalizationFilters()
                oServiceFacade.getPersonalizationFilters();

                // Check if _retrieveRecord was invoked with an empty custom payload object
                if (oServiceFacade._retrieveRecord.getCall(0) != null) {
                    ok("_retrieveRecord was invoked");
                }

                equals(JSON.stringify(oServiceFacade._retrieveRecord.getCall(0).args[2]), JSON.stringify({}),
                        "_retrieveRecord was passed an empty object for custom payload");
            });

    // *** TEST CASE #2 ***
    test(
            "savePersonalizationFilters() invokes the _send method of the BaseServiceFacade and passes the input data in an attribute called PersonalizationFilters in the custom payload.",
            function() {
                // Create a dummy payload object
                var oData = {
                    Dummy : "Dummy object"
                };

                // Invoke savePersonalizationFilters()
                oServiceFacade.savePersonalizationFilters(oData);

                // Was _send invoked?
                if (oServiceFacade._send.getCall(0) != null) {
                    ok("_send was invoked");
                }

                // Was the custom payload passed with the correct attribute?
                equals(oServiceFacade._send.getCall(0).args[3].PersonalizationFilters, oData,
                        "Custom payload was passed with the PersonalizationFilters attribute");
            });
})();
