(function() {
    "use strict";

    var oView = null;

    // Module for DTC Blacklist
    module("jd.ui.eid.view.main.worksheet.Evidence.view", {
        setup : function() {
            oView = jd.ui.eid.xmlview("jd.ui.eid.view.main.worksheet.Evidence");
            oView.placeAt("content", "only");
        },
        teardown : function() {
            // oView.destroy();
            oView = null;
            setTimeout(function() {
                $("#content").html("");
            }, 1000);

        }
    });
    /*
     * test("_getContentView() should return a view instance if no key parameter is provided.",
     * function() { var oContentView = oView._getContentView(); ok(oContentView instanceof
     * sap.ui.core.mvc.View); });
     * 
     * test("_getContentView() should return the same view instance when provided with the same
     * key.", function() { var sKey = "wiDTACCases"; var oFirstContentView =
     * oView._getContentView(sKey); var oSecondContentView = oView._getContentView(sKey);
     * equal(oFirstContentView, oSecondContentView); });
     * 
     * test("_getContentView() should return different view instances for different keys.",
     * function() { var oFirstContentView = oView._getContentView("wiDTACCases"); var
     * oSecondContentView = oView._getContentView("wiWarrantyClaims"); notEqual(oFirstContentView,
     * oSecondContentView); });
     * 
     * test( "displayContentView() should call _getContentView() and pass the provided key as
     * parameter.", function() { var sKey = "wiWarrantyClaims"; var oSpy = sinon.spy(oView,
     * "_getContentView");
     * 
     * oView.displayContentView(sKey);
     * 
     * ok(oSpy.called); ok(oSpy.calledWith(sKey)); });
     */
})();