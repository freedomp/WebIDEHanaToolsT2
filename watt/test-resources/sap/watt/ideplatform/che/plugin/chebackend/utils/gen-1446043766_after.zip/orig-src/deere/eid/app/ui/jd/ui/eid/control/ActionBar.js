(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ActionBar");

    /**
     * Constructor for a new ActionBar.
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>toolbar : sap.ui.commons.Toolbar the toolbar to be displayed instead of business actions.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The custom ActionBar ignores the common aggregations such as <code>businessActions</code> and <code>socialActions</code> and only
     *        displays the toolbar aggregation. That way, as a developer, one has full control over all button properties.
     * @name jd.ui.eid.control.ActionBar
     * @extends sap.ui.ux3.ActionBar
     */
    sap.ui.ux3.ActionBar.extend("jd.ui.eid.control.ActionBar", {
        metadata : {
            aggregations : {
                toolbar : {
                    type : "sap.ui.commons.Toolbar",
                    multiple : false
                }
            }
        },

        /**
         * @ignore
         */
        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.write(">");
            oRm.renderControl(oControl.getAggregation("toolbar"));
            oRm.write("</div>");
        }
    });
})();