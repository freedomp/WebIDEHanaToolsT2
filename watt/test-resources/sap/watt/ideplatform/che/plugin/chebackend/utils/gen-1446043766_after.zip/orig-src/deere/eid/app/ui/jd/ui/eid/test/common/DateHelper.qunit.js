(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DateHelper");

    module("jd.ui.eid.common.DateHelper", {
        setup : function() {

        },
        teardown : function() {

        }
    });

    /* ----- subtractDays() ----- */
    test("subtractDays() should return the same date as input, if 0 days are subtracted.", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/11/15"));
        var iSubtractDays = 0;
        var sExpectedResult = sInputDate;
        var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);

        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "Today's date {minus} 0 days = today's date");
    });

    test("subtractDays() should return the previous date, if 1 day is subtracted.", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/11/15")); // 15th Nov.
        var iSubtractDays = 1;
        var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/11/14")); // 14th Nov.
        var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "15/Nov/2014 {minus} 1 day = 14/Nov/2014");
    });

    test("subtractDays() should return the expected result, if 20 (i.e > 1) days are subtracted such that the result is within the same month.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/05/30")); // 30th May
                var iSubtractDays = 20;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/05/10")); // 10th May
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "30/May/2014 {minus} 20 days = 10/May/2014");
            });

    test(
            "subtractDays() should return the expected result, if 20 (i.e > 1) days are subtracted such that the result lies in the previous month, but in the same year. The previous month has 30 days.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/05/12")); // 12th May
                var iSubtractDays = 20;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/04/22")); // 22nd April
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "12/May/2014 {minus} 20 days = 22/Apr/2014");
            });

    test(
            "subtractDays() should return the expected result, if 23 (i.e > 1) days are subtracted such that the result lies in the previous month, but in the same year. The previous month has 31 days.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/04/10"));// .toJSON(); // 10th April
                var iSubtractDays = 23;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2014/03/18"));// .toJSON(); // 18th March
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Apr/2014 {minus} 23 days = 18/Mar/2014");
            });

    test(
            "subtractDays() should return the expected result, if 23 (i.e > 1) days are subtracted such that the result lies in the previous month, but in the same year. The previous month has 29 days.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2000/03/10")); // 10th March
                var iSubtractDays = 23;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2000/02/16")); // 16th Feb
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Mar/2000 {minus} 23 days = 16/Feb/2000");
            });

    test(
            "subtractDays() should return the expected result, if 23 (i.e > 1) days are subtracted such that the result lies in the previous month, but in the same year. The previous month has 28 days.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/03/10")); // 10th March
                var iSubtractDays = 23;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/02/15")); // 15th Feb
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Mar/2001 {minus} 23 days = 15/Feb/2001");
            });

    test(
            "subtractDays() should return the expected result, if 33 (i.e > 1) days are subtracted such that the result lies in the previous month, in the previous year.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/01/10")); // 10th Jan
                var iSubtractDays = 33;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2000/12/08")); // 8th Dec
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Jan/2001 {minus} 33 days = 08/Dec/2000");
            });

    test("subtractDays() should return the expected result, if 435 (i.e > 365) days are subtracted such that the result lies in the previous year.",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/01/10")); // 10th Jan
                var iSubtractDays = 435;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("1999/11/02")); // 2nd Nov
                var sActualResult = jd.ui.eid.common.DateHelper.subtractDays(sInputDate, iSubtractDays);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Jan/2001 {minus} 435 days = 02/Nov/1999");
            });

    /* ----- subtractMonths() ----- */
    test("subtractMonths() should return the same date as input, if 0 months are subtracted", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/01/10")); // 10th Jan
        var iSubtractMonths = 0;
        var sExpectedResult = sInputDate;
        var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "10/Jan/2001 {minus} 0 months = 10/Jan/2001");
    });

    test("subtractMonths() should return the previous month (same year), if 1 month is subtracted.", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/05/20")); // 20th May
        var iSubtractMonths = 1;
        var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/04/20")); // 20th April
        var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "20/May/2004 {minus} 1 months = 20/Apr/2004");
    });

    test("subtractMonths() should return the previous month (previous year), if 1 month is subtracted.", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/01/02")); // 2nd Jan
        var iSubtractMonths = 1;
        var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2003/12/02")); // 2nd Dec
        var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "02/Jan/2004 {minus} 1 month = 02/Dec/2003");
    });

    test("subtractMonths() should return July 31st, if 1 month is subtracted from August 31st (edge case, consecutive months with 31 days)",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/08/31")); // 31st Aug
                var iSubtractMonths = 1;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/07/31")); // 31st Jul
                var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "31/Aug/2004 {minus} 1 month = 31/Jul/2004");
            });

    test("subtractMonths() should return April 30th, if 1 month is subtracted from May 31st (edge case, previous month has 30 days. Current has 31)",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/05/31")); // 31st May
                var iSubtractMonths = 1;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/04/30")); // 30th Apr
                var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "31/May/2004 {minus} 1 month = 30/Apr/2004");
            });

    test(
            "subtractMonths() should return March 30th, if 1 month is subtracted from April 30th (edge case, previous month has 31 days. Current has 30)",
            function() {
                var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/04/30")); // 30th April
                var iSubtractMonths = 1;
                var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2004/03/30")); // 30th March
                var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
                ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "31/Apr/2004 {minus} 1 month = 30/Mar/2004");
            });

    test("subtractMonths() should return expected result when 1 month subtracted from March 31 (on a non-leap year)", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/03/31")); // 31st March
        var iSubtractMonths = 1;
        var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2001/02/28")); // 28th Feb
        var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "31/Mar/2001 {minus} 1 month = 28/Feb/2001");
    });

    test("subtractMonths() should return expected result when 1 month subtracted from March 31 (on a leap year)", function() {
        var sInputDate = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2000/03/31")); // 31st March
        var iSubtractMonths = 1;
        var sExpectedResult = jd.ui.eid.common.DateHelper.DateToJSONDate(new Date("2000/02/29")); // 28th Feb
        var sActualResult = jd.ui.eid.common.DateHelper.subtractMonths(sInputDate, iSubtractMonths);
        ok(_areJSONDatesEqual(sActualResult, sExpectedResult), "31/Mar/2000 {minus} 1 month = 29/Feb/2000");
    });

    test("parseLocalShortDate() returns a date representing the string", function() {
        var oOriginalDate = jd.ui.eid.common.DateHelper.YyyymmddToDate("20140205");
        var oLocale = new sap.ui.core.Locale(jd.ui.eid.common.DateHelper.getLocale().toString());
        var oDateString = sap.ui.core.format.DateFormat.getDateInstance({
            style : "short"
        }, oLocale).format(oOriginalDate);

        var oDate = jd.ui.eid.common.DateHelper.parseLocalShortDate(oDateString);
        ok(jd.ui.eid.common.DateHelper.isSameDay(oOriginalDate, oDate));
    });

    test("JSONDateToLocalDateTime() return a date converted from UTC to local datetime", function() {
        var oDate = new Date();
        var oJSONObject = JSON.stringify({
            date : oDate
        });
        var oConvertedDate = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(JSON.parse(oJSONObject).date);
        deepEqual(oDate, oConvertedDate);
    });

    // Private helper method. Returns true if both dates are equal (compares only day, month and year). Returns false if different.
    function _areJSONDatesEqual(sDate1, sDate2) {
        var iYear1 = sDate1.slice(0, 4);
        var iYear2 = sDate2.slice(0, 4);
        var iMonth1 = sDate1.slice(5, 7);
        var iMonth2 = sDate2.slice(5, 7);
        var iDay1 = sDate1.slice(8, 10);
        var iDay2 = sDate2.slice(8, 10);

        if ((iYear1 == iYear2) && (iMonth1 == iMonth2) && (iDay1 == iDay2)) {
            return true;
        }
        return false;
    }

})();