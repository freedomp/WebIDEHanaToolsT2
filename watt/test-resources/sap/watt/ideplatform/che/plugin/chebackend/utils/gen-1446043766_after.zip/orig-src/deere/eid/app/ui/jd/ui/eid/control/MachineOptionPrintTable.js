(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.MachineOptionPrintTable");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    /**
     * Constructor for a new MachineOptionPrintTable.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>machineOption : array of objects --> this array is the property "MachineOption" of object described in AM-10-04_MachineOptions.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The MachineOptionPrintContainer prints a table for machine option codes. Reason: Using the standard UI5 control while printing would
     *        cause usability and performance problems
     * @name jd.ui.eid.control.MachineOptionPrintTable
     * @extends sap.ui.core.Control
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.MachineOptionPrintTable", /** @lends jd.ui.eid.control.MachineOptionPrintTable */
    {
        metadata : {
            properties : {
                machineOption : {
                    type : "object[]", // we need the [] for defining arrays as stated in the UI5 documentation.
                    defaultValue : []
                }
            },

        },

        renderer : function(oRm, oControl) {
            var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");

            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.write(">");
            oRm.write("<div>");

            if (oControl.getMachineOption().length == 0) {
                // if we have no machine option codes calculated we render a information text
                oRm.write(jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_DO_NOT_EXIST"));
            } else if (oControl.getMachineOption().length == 1
                    && oEvidencePackageServiceFacade.MachineOptionCalculation.hasCalculationNotYetStarted(oControl.getMachineOption()[0])) {
                // If the flag "machine option not yet calculated" is set, we render also an appropriate information text
                oRm.write(jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_NOT_YET_CALCULATED"));
            } else {
                // this is the normal case: DTC has multiple machine code options, so we render a table
                oRm.write("<table");
                oRm.addClass("jdUiEidPrintTable");
                oRm.writeClasses();
                oRm.write(">");

                // Table headers
                oRm.write("<thead>");
                oRm.write("<tr>");
                oRm.write("<th>" + jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_CODE") + "</th>");
                oRm.write("<th>" + jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_DESCRIPTION") + "</th>");
                oRm.write("<th>" + jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_LIFT") + "</th>");
                oRm.write("<th>" + jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_TAKE_RATE") + "</th>");
                oRm.write("</thead>");
                oRm.write("</tr>");

                // Table body
                oRm.write("<tbody>");

                $.each(oControl.getMachineOption(), function(i, oCode) {
                    oRm.write("<tr>");
                    // cell machineOptionCode
                    oRm.write("<td>" + oCode.MachineOptionCode + "</td>");
                    // cell description
                    oRm.write("<td>" + oCode.Description + "</td>");
                    // cell Lift
                    oRm.write("<td");
                    oRm.addClass("jdUiEidPrintTableQtyCell");
                    oRm.writeClasses();
                    oRm.write(">");
                    oRm.write(jd.ui.eid.common.formatter.NumberFormatter.formatFloatTo2DigitFractionNumber(oCode.Lift) + "</td>");
                    // cell Option Take rate
                    oRm.write("<td");
                    oRm.addClass("jdUiEidPrintTableQtyCell");
                    oRm.writeClasses();
                    oRm.write(">");
                    oRm.write(jd.ui.eid.common.formatter.NumberFormatter.formatFloatTo2DigitFractionNumber(oCode.OptionTakeRate) + "</td>");
                    oRm.write("</tr>");
                });

                oRm.write("</tbody>");
                oRm.write("</table>");
                oRm.write("</div>");
            }

            oRm.write("</div>");

        }
    });
})();