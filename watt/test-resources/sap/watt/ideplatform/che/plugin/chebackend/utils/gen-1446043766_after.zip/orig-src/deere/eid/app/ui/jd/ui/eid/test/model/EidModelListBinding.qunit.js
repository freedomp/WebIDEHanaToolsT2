(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");

    var oModel = null;
    var oBinding = null;
    var oData = null;
    var oTemplateData = {
        StringProperty : 'String',
        IntegerProperty : 1,
        FloatProperty : 1.1,
        ArrayProperty : [1, 2, 3],
        ObjectProperty : {
            FirstProperty : 'first',
            SecondProperty : 'second'
        },
        SmallArray : [],
        MediumArray : [],
        LargeArray : [],
    };
    var iSmallArraySize = 50;
    var iMediumArraySize = 100;
    var iLargeArraySize = 500;

    module("jd.ui.eid.model.EidModelListBinding", {
        setup : function() {
            oModel = new jd.ui.eid.model.EidModel();
            oModel.setSizeLimit(10000);
            // Make a copy of the template data
            oData = jQuery.extend(true, {}, oTemplateData);
            oData.SmallArray = _createArrayWithNEntries(iSmallArraySize);
            oData.MediumArray = _createArrayWithNEntries(iMediumArraySize);
            oData.LargeArray = _createArrayWithNEntries(iLargeArraySize);
            oModel.setData(oData);
            oBinding = _createMediumListBinding();
        },
        teardown : function() {
            oModel = null;
            oBinding = null;
        }
    });

    test("_jdUiEidGetListFromModel() should return the array from the model.", function() {
        oBinding = _createMediumListBinding();
        var aItems = oBinding._jdUiEidGetListFromModel();
        equal(aItems.length, iMediumArraySize);
        equal(aItems, oData.MediumArray);
    });

    test("getLength() should return the number of entries associated with the list binding.", function() {
        oBinding = _createMediumListBinding();
        equal(oBinding.getLength(), iMediumArraySize);
    });

    test(
            "getContexts() should return an array of the size of the number of entries associated with the list binding and the data is available on the client.",
            function() {
                oBinding = _createMediumListBinding();
                ok(oBinding.getLength() == iMediumArraySize, "getLength must be euqal what is requested.");
                equal(oBinding.getContexts().length, iMediumArraySize);
            });

    test("getContexts() should return the second 10 records if start index is 10 and length 10 and the data is available on the client.", function() {
        oBinding = _createMediumListBinding();
        var iLength = 10;
        ok(oBinding.getLength() > iLength, "getLength must be greated than what is requested.");
        var aContexts = oBinding.getContexts(0, iLength);
        equals(aContexts.length, iLength);
        equals(aContexts[0].getProperty(), oModel.getData().MediumArray[0]);
        equals(aContexts[iLength - 1].getProperty(), oModel.getData().MediumArray[iLength - 1]);
    });

    test("getContexts() should return the first 10 records if start index is 0 and length 10 and the data is available on the client.", function() {
        oBinding = _createMediumListBinding();
        var iLength = 10;
        var iOffset = 10;
        ok(oBinding.getLength() > (iLength + iOffset), "getLength must be greated than what is requested.");
        var aContexts = oBinding.getContexts(iOffset, iLength);
        equals(aContexts.length, iLength);
        equals(aContexts[0].getProperty(), oModel.getData().MediumArray[iOffset + 0]);
        equals(aContexts[iLength - 1].getProperty(), oModel.getData().MediumArray[iOffset + iLength - 1]);
    });

    test(
            "getContexts() should return ab array of the size of the number of entries associated with the list binding even if the data is not available on the client.",
            function() {
                oBinding = _createMediumListBinding();
                oBinding.setLength(1000);
                var aContexts = oBinding.getContexts(0, 1000);
                equals(aContexts.length, 1000);
            });

    test("getContexts() should fire the dataRequested event via the event bus if the requested chunk of data is not available in the model. ",
            function() {
                oBinding = _createMediumListBinding();
                var iRequestedSize = 1000;
                oBinding.setLength(iRequestedSize);
                var spy = _createSpyForDataRequestedEvent();

                var aContexts = oBinding.getContexts(0, iRequestedSize);
                ok(spy.calledOnce);

                var mData = spy.args[0][2];
                equal(mData.oListBinding, oBinding);
                equal(mData.iSkip, iMediumArraySize, "Skip the data which is already there.");
                equal(mData.iTop, iRequestedSize - iMediumArraySize, "Top the missing data.");
            });

    test("getContexts() should note fire the dataRequested event via the event bus if the requested chunk of data is available in the model. ",
            function() {
                oBinding = _createMediumListBinding();
                oBinding.setLength(1000);
                var spy = _createSpyForDataRequestedEvent();

                var aContexts = oBinding.getContexts(0, iMediumArraySize);
                ok(!spy.called);
            });

    test("getContexts should return all the data on the client if called with no properties even if it exceeds the chunk size.", function() {
        oBinding = _createLargeListBinding();
        oBinding.setLength(iLargeArraySize + 1);

        var aContexts = oBinding.getContexts();
        equals(aContexts.length, iLargeArraySize);
    });

    test(
            "getContexts should return all the data on the client if called with no properties even if its below the chunk size and the length was previously set to zero.",
            function() {
                oBinding = _createSmallListBinding();
                oBinding.setLength(0);
                equals(oBinding.getLength(), 0);
                equals(oModel.getProperty("/SmallArray").length, iSmallArraySize);

                var aContexts = oBinding.getContexts();
                equals(aContexts.length, iSmallArraySize);
            });

    test(
            "getContexts should return all the data on the client if called with no properties even if its below the chunk size and it is explicitely asked for more data.",
            function() {
                oBinding = _createSmallListBinding();
                equals(oModel.getProperty("/SmallArray").length, iSmallArraySize);

                var aContexts = oBinding.getContexts(0, iSmallArraySize + 10);
                equals(aContexts.length, iSmallArraySize);
            });

    test(
            "getContexts should return the data on the client if called with properties 10, 50 even if its below the chunk size and it is explicitely asked for more data.",
            function() {
                oBinding = _createSmallListBinding();
                equals(oModel.getProperty("/SmallArray").length, iSmallArraySize);

                var aContexts = oBinding.getContexts(10, iSmallArraySize);
                equals(aContexts.length, iSmallArraySize - 10);
            });

    var _createArrayWithNEntries = function(iN) {
        var aArray = [];
        for ( var i = 0; i < iN; i++) {
            aArray.push(i);
        }
        return aArray;
    };

    var _createSmallListBinding = function() {
        return new jd.ui.eid.model.EidModelListBinding(oModel, "/SmallArray");
    };

    var _createMediumListBinding = function() {
        return new jd.ui.eid.model.EidModelListBinding(oModel, "/MediumArray");
    };

    var _createLargeListBinding = function() {
        return new jd.ui.eid.model.EidModelListBinding(oModel, "/LargeArray");
    };

    var _createSpyForDataRequestedEvent = function() {
        var spy = sinon.spy();
        sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataRequested', spy);
        return spy
    };

})();