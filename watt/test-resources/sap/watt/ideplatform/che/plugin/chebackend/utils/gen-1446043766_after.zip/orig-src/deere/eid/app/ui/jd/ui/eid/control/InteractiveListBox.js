(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.InteractiveListBox");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");

    /**
     * Constructor for a new InteractiveListBox.
     * <ul>
     * <li>Events
     * <ul>
     * <li>itemRemoved : fired when an item has been removed.</li>
     * <li>itemUpdated : fired when an item has been updated.</li>
     * <li>itemsChanged : fired when the item aggregation changed.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The InteractiveListBox control provides functionality for in-place editing items and deleting an item. Each line item consists of an
     *        input field, a span tag with the text of the item and two icons for edit and delete. The icons are only visible when the line item is
     *        hovered. The input field becomes visible when the edit button is pressed. Then, the focus is set on the input field and the underlying
     *        text field is hidden. When the user presses enter or unfocuses the input field, the value is saved. When the user hits escape while
     *        editing the item, the current changes are discarded. When the delete icon is clicked, the respective list item is removed from the item
     *        aggregation. The ItemNavigation delegate is deactivated so that keyboard events while editing the item text don't interfere with
     *        navigating inside the list box. Thus, navigating with the keyboard is not supported. As opposed to the default implementation where the
     *        li tags are displayed as table rows, they are displayed as block elements so that they can have a bottom border which serves as a
     *        separator between two items.
     * @extends jd.ui.eid.control.ListBox
     * @name jd.ui.eid.control.InteractiveListBox
     */
    jd.ui.eid.control.ListBox.extend("jd.ui.eid.control.InteractiveListBox",
    /** @lends jd.ui.eid.control.InteractiveListBox */
    {
        metadata : {
            events : {
                itemRemoved : {},
                itemUpdated : {},
                itemsChanged : {}
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.ListBox.prototype.init.apply(this, arguments);

            // Add the style class here so that we don't have to do any unnecessary
            // overwrites in the renderer
            this.addStyleClass("jdUiEidInteractiveListBox");
        },

        /* Internal Event Handler */

        /**
         * Event handler called when the edit icon is clicked. Toggles the disabled property of the input element related to the respective list item.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleEdit : function(oEvent) {
            var oListItem = this._getListItemDOMRef(oEvent.target);
            var attr = jQuery(oListItem).attr("data-sap-ui-lbx-index");
            if (typeof attr == "string" && attr.length > 0) {
                var iIndex = parseInt(attr, 10); // Get the selected index from the HTML
                $.sap.log.debug("_handleEdit for index " + iIndex, null, "jd.ui.eid.control.InteractiveListBox");
                this.enableEditModeForItem(iIndex);
            }
        },

        /**
         * Event handler called when the remove icon is clicked. Removes the corresponding item from the aggregation.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleRemove : function(oEvent) {
            var oListItem = this._getListItemDOMRef(oEvent.target);
            var attr = jQuery(oListItem).attr("data-sap-ui-lbx-index");
            if (typeof attr == "string" && attr.length > 0) {
                var iIndex = parseInt(attr, 10); // Get the selected index from the HTML
                $.sap.log.debug("_handleRemove for index " + iIndex, null, "jd.ui.eid.control.InteractiveListBox");

                // Get the item object
                var aItems = this.getItems();
                var oItem = aItems[iIndex];

                // ... and remove it from the aggregation.
                this.removeItem(oItem);
                this.fireItemRemoved({
                    item : oItem,
                    index : iIndex
                });

                this.fireItemsChanged();

                this._bEditingNewItem = false;
            }
        },

        /**
         * Event handler called when an item has been changed. Updates the value of the corresponding item object.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleChange : function(oEvent) {
            var sNewValue = jQuery.trim(jQuery(oEvent.target).attr("value"));
            var oListItem = this._getListItemDOMRef(oEvent.target);
            var attr = jQuery(oListItem).attr("data-sap-ui-lbx-index");
            if (typeof attr == "string" && attr.length > 0) {
                var iIndex = parseInt(attr, 10); // Get the selected index from the HTML
                $.sap.log.debug("_handleChange for index " + iIndex, null, "jd.ui.eid.control.InteractiveListBox");

                // Get item
                var aItems = this.getItems();
                var oItem = aItems[iIndex];

                if (sNewValue.length == 0) {
                    $.sap.log.debug("item changed to empty text, removing...", null, "jd.ui.eid.control.InteractiveListBox");
                    this.removeItem(oItem);
                    this.fireItemRemoved({
                        item : oItem,
                        index : iIndex
                    });
                    this.fireItemsChanged();
                } else {
                    $.sap.log.debug("item changed, updating...", null, "jd.ui.eid.control.InteractiveListBox");
                    // Update value
                    var sOldValue = oItem.getText();
                    this.$().find("li[data-sap-ui-lbx-index='" + iIndex + "'] .jdUiEidInteractiveListBoxItemText").html(sNewValue);
                    oItem.setKey(sNewValue);
                    oItem.setText(sNewValue);
                    this.fireItemUpdated({
                        item : oItem,
                        index : iIndex,
                        oldKey : sOldValue,
                        oldText : sOldValue
                    });
                }

                this._bEditingNewItem = false;

                this.disableEditModeForItem(iIndex);
            }
        },

        /**
         * Event handler for the escape key on the input field. Discards the current changes to a list item.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleEscapeKey : function(oEvent) {
            var attr = jQuery(oEvent.target.parentNode.parentNode).attr("data-sap-ui-lbx-index");
            if (typeof attr == "string" && attr.length > 0) {
                var iIndex = parseInt(attr, 10); // Get the selected index from the HTML

                // Get item
                var aItems = this.getItems();
                var oItem = aItems[iIndex];

                // Reset value in DOM tree
                jQuery(oEvent.target).attr("value", oItem.getText());

                this.disableEditModeForItem(iIndex);
            }
        },

        /**
         * Event handler called when an item is clicked. This also includes space where sub elements of the item are placed.
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            if (!this.getEnabled() || !this.getEditable()) {
                return;
            }

            // What we need to to is to figure out what exactly was clicked. We're gonna do
            // this based on the css class of the event's target and delegate the event
            // accordingly.
            var oSource = oEvent.target;
            var sClassName = oSource.getAttribute("class");
            if (sClassName == 'jdUiEidInteractiveListBoxActionEdit') {
                this._handleEdit(oEvent);
            } else if (sClassName == 'jdUiEidInteractiveListBoxActionRemove') {
                this._handleRemove(oEvent);
            } else if (sClassName == 'jdUiEidInteractiveListBoxItemInput' && oSource.readonly === false) {
                // Don't do anything.
            } else {
                // The input was clicked but it was disabled, so in that case, it should be
                // selected. We'll modify the event's target so that it looks like the span
                // element inside the li element was clicked. This can then be handled by
                // the default implementation.
                oEvent.target = this._getListItemDOMRef(oSource);
                // Pass the event on to the default implementation.
                jd.ui.eid.control.ListBox.prototype.onclick.apply(this, arguments);
            }
        },

        /**
         * @see jd.ui.eid.control.ListBox#setSelectedKeys
         */
        setSelectedKeys : function(aSelectedKeys) {
            if (aSelectedKeys.length && aSelectedKeys.length === 0) {
                // If there are no selected keys, make sure that the control has a valid internal state
                this._bEditingNewItem = false;
            }
            return jd.ui.eid.control.ListBox.prototype.setSelectedKeys.apply(this, arguments);
        },

        /* Internal Helper Methods */

        /**
         * Gets the reference to the list item element from any child element.
         * 
         * @param {object}
         *            oSource The child element of a list item element.
         * @returns {jQuery|null} The jQuery object of the list item if found or null.
         */
        _getListItemDOMRef : function(oSource) {
            var sCSSClass = ".sapUiLbxI";
            var $source = jQuery(oSource);

            if ($source.is(sCSSClass)) {
                return $source;
            } else {
                var $parents = $source.parents(sCSSClass);
                if ($parents.get(0)) {
                    return $parents.get(0);
                } else {
                    return null;
                }
            }
        },

        /* Control Logic */

        /*
         * True if a new item was added and is currently being edited, false otherwise. Used to avoid that when a new item was just added, that
         * another item can be added right afterwards while the previous one is still empty.
         */
        _bEditingNewItem : false,

        /**
         * Adds a new empty item to the item aggregation and sets the focus on it.
         */
        addAndEditItem : function() {
            var oItem;
            if (!this._bEditingNewItem) {
                oItem = new sap.ui.core.Item();
                this.insertItem(oItem, 0);
            } else {
                oItem = this.getItems()[0];
            }

            var that = this;
            // Do this in a timeout to give the UI thread time to add the item to the DOM
            // tree so that we can access it via jQuery.
            setTimeout(function() {
                that.enableEditModeForItem(0);
            }, 0);
            this._bEditingNewItem = true;
        },

        /**
         * 
         */
        isEditingNewItem : function() {
            return this._bEditingNewItem;
        },

        /**
         * Disables the edit mode for the item associated with the given index. The method will hide the input field of the given item and make the
         * item's text visible.
         * 
         * @param {integer}
         *            iIndex item index for which the edit mode should be disabled.
         */
        disableEditModeForItem : function(iIndex) {
            this.$().find("li[data-sap-ui-lbx-index='" + iIndex + "'] .jdUiEidInteractiveListBoxItemInput").hide();
            this.$().find("li[data-sap-ui-lbx-index='" + iIndex + "'] .jdUiEidInteractiveListBoxItemText").show();
        },

        /**
         * Enables the edit mode for the item associated with the given index. If the edit mode is not already enabled for the given item, the method
         * will hide the text of the list item. It will then make the input field visible and set the focus to the end.
         * 
         * @param {integer}
         *            iIndex item index for which the edit mode should be enabled.
         */
        enableEditModeForItem : function(iIndex) {
            var $listBoxItemText = this.$().find("li[data-sap-ui-lbx-index='" + iIndex + "'] .jdUiEidInteractiveListBoxItemText");

            if ($listBoxItemText.is(":visible")) {
                var oItem = this.getItems()[iIndex];
                var iTextLength = oItem.getText().length;
                var $listBoxItemInput = this.$().find("li[data-sap-ui-lbx-index='" + iIndex + "'] .jdUiEidInteractiveListBoxItemInput");

                $listBoxItemText.hide();
                $listBoxItemInput.show();
                $listBoxItemInput.each(function(i, el) {
                    el.setSelectionRange(iTextLength, iTextLength);
                });
            }

        },

        /**
         * Event handler for the pseudo event 'enter'. If the event was triggered from the input field, the changes will be saved.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onsapenter : function(oEvent) {
            $.sap.log.debug("onsapenter", null, "jd.ui.eid.control.InteractiveListBox");
            var oSource = oEvent.target;
            if (jQuery(oSource).is(".jdUiEidInteractiveListBoxItemInput")) {
                this._handleChange(oEvent);
            }
        },

        /**
         * Event handler for the pseudo event 'escape'. If the event was triggered from the input field, the changes will be discarded.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onsapescape : function(oEvent) {
            var oSource = oEvent.target;
            if (jQuery(oSource).is(".jdUiEidInteractiveListBoxItemInput")) {
                this._handleEscapeKey(oEvent);
            }
        },

        /**
         * Event handler for the pseudo event 'select'. The method doesn't do anything but overriding the default behavior of the list box.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onselect : function(oEvent) {

        },

        /**
         * Event handler for the pseudo event 'select start'. The method doesn't do anything but overriding the default behavior of the list box.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onselectstart : function(oEvent) {

        },

        /**
         * Event handler for the pseudo event 'space'. The method doesn't do anything but overriding the default behavior of the list box.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onsapspace : function(oEvent) {

        },

        /**
         * Event handler for the pseudo event 'space with modifiers'. The method doesn't do anything but overriding the default behavior of the list
         * box.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        onsapspacemodifiers : function(oEvent) {

        },

        /**
         * @see {@link sap.ui.commons.ListBox#_calcTotalHeight} This method can be used to adjust the total height of the list box when scrolling.
         */
        _calcTotalHeight : function() {
            var sHeight = jd.ui.eid.control.ListBox.prototype._calcTotalHeight.apply(this, arguments);

            var iHeight = parseInt(sHeight.substr(0, sHeight.length - 2));
            this._sTotalHeight = (iHeight + 10) + "px";

            return this._sTotalHeight;
        },

        /* Control Rendering */

        /**
         * Attaches event handlers to DOM elements and disables item navigation.
         */
        onAfterRendering : function() {
            jd.ui.eid.control.ListBox.prototype.onAfterRendering.apply(this, arguments);

            // Attach event handler
            this.$().find('.jdUiEidInteractiveListBoxItemInput').bind("blur", $.proxy(this._handleChange, this));

            // Remove delegate which would usually handle most of the events to enable
            // keyboard navigation among the different list items.
            this.removeDelegate(this.oItemNavigation);
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onBeforeRendering : function() {
            jd.ui.eid.control.ListBox.prototype.onBeforeRendering.apply(this, arguments);

            // Detach event handlers
            this.$().find('.jdUiEidInteractiveListBoxItemInput').unbind("blur", this._handleChange);
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onExit : function() {
            jd.ui.eid.control.ListBox.prototype.onExit.apply(this, arguments);

            // Detach event handlers
            this.$().find('.jdUiEidInteractiveListBoxItemInput').unbind("blur", this._handleChange);
        },

        renderer : "jd.ui.eid.control.InteractiveListBoxRenderer"

    });
})();