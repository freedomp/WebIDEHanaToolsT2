(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCChartController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCSummaryController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.chart.ChartHelper");
    jQuery.sap.require("jd.ui.eid.common.BusinessProcessHelper");

    /**
     * @class
     * <p>
     * The DTCDetailChart View is used to display the charts of DTC details
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.evidencepackage.DTCSummary
     */
    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.DTCSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.DTCChartController, jd.ui.eid.view.main.shared.DTCSummaryController,
            /** @lends jd.ui.eid.view.main.evidencepackage.DTCSummary */
            {

                _oView : null,

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                onInit : function() {
                    // Get a reference to the view
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewEvidencePackageDTCSummary");

                    // Subscribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
                    oEventBus.subscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

                    // Config
                    this.mDTCChartControllerConfig._bIsSetOfCharts = true;
                    this.mDTCChartControllerConfig._fnKPISelectedCallback = function(oEvent, oDTCChartController) {
                        // This callback is invoked when the KPI for a KPI chart is selected. It updates the selected KPI in the list of DTCs in the
                        // evidence package header.
                        var oAssociatedChart = oDTCChartController._oKPIMenuAssociatedChart;
                        var oContext = oAssociatedChart.getBindingContext();
                        var iDTCID = oContext.getProperty("DTCMasterData/DTCID");
                        var mDTC = jd.ui.eid.model.EidModel.TransformationHelper.getDTCHeaderForDTCIDFromEvidencePackageDetails(iDTCID);
                        // Figure out whether the associated chart is the first or the second one. We do this by checking the position of the parent
                        // (MatrixLayoutCell) in its parent (MatrixLayoutRow).
                        var oContentPane = oAssociatedChart.getParent();
                        var iIndex = oContentPane.getParent().indexOfContent(oContentPane);
                        var sSelectedKPIID = oEvent.getSource().getBindingContext().getProperty("KPIID");
                        if (iIndex == 0) {
                            // First KPI
                            mDTC.SelectedKPIID1 = sSelectedKPIID;
                        } else {
                            mDTC.SelectedKPIID2 = sSelectedKPIID;
                        }
                    };
                    // The DTCSummaryController contains the factory that will generate the panels (containing tables, charts etc.) for each
                    // DTC. Since the same factory is also used in the print view, we are specifying which fragment needs to be instantiated
                    // by the factory. Print and DTC Summary use (and thus pass) different fragments
                    this.mDTCSummaryControllerConfig.sFactoryFragmentName = "jd.ui.eid.fragment.evidencepackage.DTCSummaryTemplate";

                    // Init merged controllers
                    // this.initDTCChartController();

                    // Set refresh flag to get the data from the backend for the current evidence package
                    this.bRefresh = true;

                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered. This is used to refresh the chats
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                onAfterRendering : function() {
                    if (this.bRefresh) {
                        this.onDTCChartControllerAfterRendering();
                        this.loadDTCDetails();
                        this.bRefresh = false;
                    }
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                onExit : function() {
                    // Unsubcribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
                    oEventBus.unsubscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

                    // Set properties to null
                    this._oView = null;
                    this.mDTCChartControllerConfig = null;
                },

                /**
                 * Handles the evidence package context change by resetting the refresh flag
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                handleEvidencePackageContextChanged : function() {
                    this.bRefresh = true;
                },

                /* SECTION - Event Bus Handling - START */

                /**
                 * Handles the event fired when data for Evidence Package Details is fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                handleModelFetchingData : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/DTCFilters/FilterSelection") {
                        this._oView.setBusy(true);
                    }
                },

                /**
                 * Handles the event fired when data for Evidence Package Case Details has been fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                handleModelDataFetched : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/DTCFilters/FilterSelection") {
                        this._oView.setBusy(false);
                    }
                },

                /* SECTION - Event Bus Handling - END */

                /**
                 * This function loads the DTC details
                 * 
                 * @param{string} sDTCID the DTC Id
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                loadDTCDetails : function(sDTCID) {
                    var oModel = sap.ui.getCore().getModel();
                    var that = this;
                    var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
                    this._oView.getContent()[0].setBusy(true);

                    // Trigger backend services
                    var $getDTCDetailsPromise = this.getServiceFacade("EvidencePackage").getDTCDetailsList(oEvidencePackageDetailsHeader, null,
                            function() {
                                that._oView.getContent()[0].setBusy(false);
                                that._onRequestFailed.apply(that, arguments);
                            });
                    var $getDTCKPIsPromise = this.getServiceFacade("EvidencePackage").getKPIsForDTCList(oEvidencePackageDetailsHeader, null,
                            function() {
                                that._oView.getContent()[0].setBusy(false);
                                that._onRequestFailed.apply(that, arguments);
                            });

                    // Once both requests have completed successfully, remove the busy indicator from the view
                    $.when($getDTCDetailsPromise, $getDTCKPIsPromise).done(function() {
                        that._oView.getContent()[0].setBusy(false);
                    });
                },

                /**
                 * this function returns the complete Id of the Chart which belongs to the clicked KPIS selector
                 * 
                 * @private
                 * @param{objejct} oEvent event triggered by the selection of KPI selector
                 * @return{string} the id of Chart
                 * 
                 * @memberOf jd.ui.eid.view.main.evidencepackage.DTCSummary
                 */
                _getChartIdUnderKPISelector : function(oEvent) {
                    return this.getChartBelowKPISelector(oEvent);
                },

                handleDeleteDTCFromEP : function(oEvent) {
                    var sSelectedDTCCode = oEvent.getSource().getBindingContext().getProperty('DTCMasterData/DTCCode');
                    var sSelectedDTCID = oEvent.getSource().getBindingContext().getProperty('DTCMasterData/DTCID');

                    // Callback function for confirmation to delete dialog
                    var fnOnDeleteConfirmation = function(bConfirmed) {
                        if (bConfirmed) {
                            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTC(sSelectedDTCID);
                        }
                    };

                    // Get confirmation from user before proceeding
                    var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CONFIRM_DELETE_DTC", [sSelectedDTCCode]);
                    this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);

                }

            }));

})();