(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.WorkSheetFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");

    /**
     * @class This formatter class provides methods for formatting Worksheet Data including the Worksheet Quick Views
     * @static
     * @name jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter = {};

    /**
     * Returns count of DTC Codes of current evidence package
     * 
     * @param {array}
     *            aDTCCodeList array of DTC Codes
     * @returns {integer} count number of DTC Codes
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getDTCBasketCount = function(aDTCCodeList) {
        if (aDTCCodeList) {
            return aDTCCodeList.length;
        } else {
            return 0;
        };
    };

    /**
     * Returns count of DTAC Cases of current evidence package
     * 
     * @param {array}
     *            aDATCCaseList array of DTAC Cases
     * @returns {integer} count number of DTAC Cases
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getDTACCaseBasketCount = function(aDTACCaseList) {
        if (aDTACCaseList) {
            return aDTACCaseList.length;
        } else {
            return 0;
        }
    };

    /**
     * Returns count of Warranty Claims of current evidence package
     * 
     * @param {array}
     *            aWarrantyClaimList array of Warranty Claims
     * @returns {integer} count number of Warranty Claims
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getWarrantyClaimBasketCount = function(aWarrantyClaimList) {
        if (aWarrantyClaimList) {
            return aWarrantyClaimList.length;
        } else {
            return 0;
        }
    };

    /**
     * Returns basket title for DTCs
     * 
     * @param {array}
     *            aDTCCodeList arry of DTCs
     * @return {string} DTC text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getDTCBasketText = function(aDTCCodeList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTCBasketCount(aDTCCodeList),
                "DTC_BASKET_FLD_COUNT_MULTIPLE", "DTC_BASKET_FLD_COUNT_SINGLE");
    };

    /**
     * Returns basket title for DTAC Cases
     * 
     * @param {array}
     *            aDTACCaseList array of DTAC Cases
     * @return {string} DTAC Case text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getDTACCaseBasketText = function(aDTACCaseList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTACCaseBasketCount(aDTACCaseList),
                "DTAC_CASE_BASKET_FLD_COUNT_MULTIPLE", "DTAC_CASE_BASKET_FLD_COUNT_SINGLE");
    };

    /**
     * Returns basket title for Warranty Claims
     * 
     * @param {array}
     *            aWarrantyClaimList array of Warranty Claims
     * @return {string} Warranty Claim text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.getWarrantyClaimBasketText = function(aWarrantyClaimList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter
                .getWarrantyClaimBasketCount(aWarrantyClaimList), "WARRANTY_CLAIM_BASKET_FLD_COUNT_MULTIPLE",
                "WARRANTY_CLAIM_BASKET_FLD_COUNT_SINGLE");
    };

    /**
     * Formats table title for DTCs
     * 
     * @param {array}
     *            aDTCCodeList array of DTCs
     * @return {string} DTC count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTCQuickviewTitle = function(aDTCCodeList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTCBasketCount(aDTCCodeList),
                "DTC_TABLE_CAP_COUNT_MULTIPLE", "DTC_TABLE_CAP_COUNT_SINGLE");
    };

    /**
     * Formats table title for DTAC Cases
     * 
     * @param {array}
     *            aDTACCaseList array of DTAC Cases
     * @return {string} DTAC Case count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTACCaseQuickviewTitle = function(aDTACCaseList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTACCaseBasketCount(aDTACCaseList),
                "DTAC_CASE_TABLE_CAP_COUNT_MULTIPLE", "DTAC_CASE_TABLE_CAP_COUNT_SINGLE");
    };

    /**
     * Formats table title for Warranty Claims
     * 
     * @param {array}
     *            aWarrantyClaimList array of Warranty Claims
     * @return {string} Warranty Claim count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatWarrantyClaimQuickviewTitle = function(aWarrantyClaimList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter
                .getWarrantyClaimBasketCount(aWarrantyClaimList), "WARRANTY_CLAIM_TABLE_COUNT_MULTIPLE", "WARRANTY_CLAIM_TABLE_COUNT_SINLGE");
    };

    /**
     * Formats table title for removed DTCs
     * 
     * @param {array}
     *            aDTCCodeList array of DTCs
     * @return {string} DTC count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTCRemovedTitle = function(aDTCCodeList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTCBasketCount(aDTCCodeList),
                "DTC_TABLE_CAP_COUNT_MULTIPLE", "DTC_TABLE_CAP_COUNT_SINGLE");
    };

    /**
     * Formats table title for removed DTAC Cases
     * 
     * @param {array}
     *            aDTACCaseList array of DTAC Cases
     * @return {string} DTAC Case count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTACCaseRemovedTitle = function(aDTACCaseList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter.getDTACCaseBasketCount(aDTACCaseList),
                "DTAC_CASE_TABLE_CAP_COUNT_MULTIPLE", "DTAC_CASE_TABLE_CAP_COUNT_SINGLE");
    };

    /**
     * Formats table title for removed Warranty Claims
     * 
     * @param {array}
     *            aWarrantyClaimList array of Warranty Claims
     * @return {string} Warranty Claim count and text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatWarrantyClaimRemovedTitle = function(aWarrantyClaimList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(jd.ui.eid.common.formatter.WorkSheetFormatter
                .getWarrantyClaimBasketCount(aWarrantyClaimList), "WARRANTY_CLAIM_TABLE_COUNT_MULTIPLE", "WARRANTY_CLAIM_TABLE_COUNT_SINLGE");
    };

    /**
     * Formats visible rows for a Basket table Maximum row count is 5
     * 
     * @param {array}
     *            aArray the Array with table items
     * @return {integer} Visible Rows count
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatVisibleRows = function(aArray) {

        if (aArray) {

            if (aArray.length > 5) {
                return 5;
            }

            else if (aArray.length == 0) {
                // we return 1 as 0 will produce a bug when setting it to property "visibleRowCount" of table control
                return 1;
            } else {
                return aArray.length;
            }
        } else {
            return 1;
        }
    };

    /**
     * Decides if table should be shown or not
     * 
     * @param {array}
     *            aArray the Array with table items
     * @return {boolean} boolean value
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatTableVisibility = function(aArray) {

        if (aArray) {

            if (aArray.length == 0) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    };

    /**
     * Returns text for Dialog "SimulateNewDTCFilter" based on changed PINPopulation
     * 
     * 
     * @param {array}
     *            aArray the Array with table items
     * @return {string} the text
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.setTextforDialogSimulateNewDTCFilter = function(oSimulatedEvidencePackage) {

        var oModel = sap.ui.getCore().getModel();
        var iCurrentPINPopulation = oModel.getProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation") || 0;
        var iSimulatedPINPopulation = oModel.getProperty("/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation") || 0;

        var sText = "";

        // set start text
        if (iSimulatedPINPopulation < iCurrentPINPopulation) {

            sText = jd.ui.eid.common.I18NHelper.getText("SIMULATED_EVIDENCE_PACKAGE_DIALOG_INF_FILTER_PIN_CHANGE_DECREASE", [
                    jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iCurrentPINPopulation),
                    jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iSimulatedPINPopulation)]);

        } else if (iSimulatedPINPopulation > iCurrentPINPopulation) {
            sText = jd.ui.eid.common.I18NHelper.getText("SIMULATED_EVIDENCE_PACKAGE_DIALOG_INF_FILTER_PIN_CHANGE_INCREASE", [
                    jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iCurrentPINPopulation),
                    jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iSimulatedPINPopulation)]);

        }

        else {
            sText = jd.ui.eid.common.I18NHelper.getText("SIMULATED_EVIDENCE_PACKAGE_DIALOG_INF_FILTER_PIN_CHANGE_NONE");
        }

        // Add constant text
        sText += "\n\r" + jd.ui.eid.common.I18NHelper.getText("SIMULATED_EVIDENCE_PACKAGE_DIALOG_INF_FILTER_PIN_CHANGE_STATIC");

        // Add text only if some itens will be removed
        if (oSimulatedEvidencePackage.RemovedDTCCodeList.length > 0 || oSimulatedEvidencePackage.RemovedDTACCaseList.length > 0
                || oSimulatedEvidencePackage.RemovedWarrantyClaimList.length > 0) {
            sText += "\n\r" + jd.ui.eid.common.I18NHelper.getText("SIMULATED_EVIDENCE_PACKAGE_DIALOG_INF_FILTER_PIN_CHANGE_TABLES");
        };

        return sText;
    };
    /**
     * Returns a '*' if the basket item is added new since the last save of the evidence package
     * 
     * @param {string}
     *            sAddedOn Time stamp of added basket item
     * @return {string} returns '*' if basket item is new
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatNewAddedBasketItem = function(sAddedOn) {
        // get time stamp of last save
        var oModel = sap.ui.getCore().getModel();
        var oAddedOn = {};
        var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");

        // Format JSON string to date object of last save date
        var oLastSave = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(oEvidencePackageDetails.LastChangedDate);
        if (oLastSave == undefined) {
            // may happen if evidence package is not yet saved the first time
            oLastSave = new Date();
            oLastSave.setFullYear(1800);
        };

        if (jQuery.type(sAddedOn) === "date") {
            oAddedOn = sAddedOn;
        } else {
            oAddedOn = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(sAddedOn);
        }
        if (oAddedOn > oLastSave) {
            return '*';
        }
        return ""; // fallback
    };

    /**
     * Returns a default description if the given description is empty otherwise the description remains unchanged
     * 
     * @param {string}
     *            sDescription the given description
     * @return {string} returns the description
     * @memberOf jd.ui.eid.common.formatter.WorkSheetFormatter
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDescription = function(sDescription) {
        if (!sDescription) {
            return jd.ui.eid.common.I18NHelper.getText("NO_DESCRIPTION_AVAILABLE_TXT_DEFAULT");
        } else {
            return sDescription;
        }

    };

    /**
     * Checks whether a Dealer name was set. If set than the Dealer name will be returned otherwise the Dealer id.
     * 
     * @param {String}
     *            sDealerName The Dealer name
     * @param {string}
     *            sDealerID The Dealer id
     * 
     * @returns {String}
     */
    jd.ui.eid.common.formatter.WorkSheetFormatter.formatDealerName = function(sDealerName, sDealerID) {
        if (sDealerName) {
            return sDealerName;
        } else if (sDealerID) {
            return sDealerID;
        }
    };

})();