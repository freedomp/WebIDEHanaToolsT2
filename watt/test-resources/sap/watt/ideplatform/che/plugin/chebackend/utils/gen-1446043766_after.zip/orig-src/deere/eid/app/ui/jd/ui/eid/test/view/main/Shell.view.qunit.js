(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require({
        modName : "jd.ui.eid.view.main.shell.Dashboard",
        type : "controller"
    });

    var oShell = null;

    // Module for DTC Blacklist
    module("jd.ui.eid.view.main.Shell.view", {
        setup : function() {
            oShell = jd.ui.eid.xmlview("jd.ui.eid.view.main.Shell");
        },
        teardown : function() {
            // oShell.destroy();
            oShell = null;
            // setTimeout(function() {
            // $("#content").html("");
            // }, 1000);

        }
    });
    /*
     * test("_getContentView() should return a view instance if no key parameter is provided.",
     * function() { var oView = oShell._getContentView(); ok(oView instanceof sap.ui.core.mvc.View);
     * });
     * 
     * test("_getContentView() should return the same view instance when provided with the same
     * key.", function() { var sKey = "wiPersonalization"; var oFirstView =
     * oShell._getContentView(sKey); var oSecondView = oShell._getContentView(sKey);
     * equal(oFirstView, oSecondView); });
     * 
     * test("_getContentView() should return different view instances for different keys.",
     * function() { var oFirstView = oShell._getContentView("wiPersonalization"); var oSecondView =
     * oShell._getContentView("wiDashboard"); notEqual(oFirstView, oSecondView); });
     * 
     * test( "displayContentView() should call _getContentView() and pass the provided key as
     * parameter.", function() { var sKey = "wiPersonalization"; var oSpy = sinon.spy(oShell,
     * "_getContentView");
     * 
     * oShell.displayContentView(sKey);
     * 
     * ok(oSpy.called); ok(oSpy.calledWith(sKey)); });
     */
})();