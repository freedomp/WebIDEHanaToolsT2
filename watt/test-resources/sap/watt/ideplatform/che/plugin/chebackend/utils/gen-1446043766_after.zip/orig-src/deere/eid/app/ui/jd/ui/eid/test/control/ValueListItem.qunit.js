(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");

    var oValueListItem = null;

    module("jd.ui.eid.control.ValueListItem", {
        setup : function() {
            oValueListItem = new jd.ui.eid.control.ValueListItem({
                text : "text",
                value : {
                    duration : 2,
                    unit : "month"
                },
                toolPopup : new sap.ui.ux3.ToolPopup()
            });
            oValueListItem.placeAt("content");
        },
        teardown : function() {
            oValueListItem.destroy();
            oValueListItem = null;
        }
    });

    // *** TEST CASE #1 ***
    test("setValue() should update the value property", function() {
        var oValue = oValueListItem.getProperty("value");
        oValueListItem.setValue({});
        notEqual(oValue, oValueListItem.getProperty("value"));
    });

    // *** TEST CASE #2 ***
    test("changeValue() should update the value property", function() {
        var oValue = oValueListItem.getProperty("value");
        oValueListItem.changeValue({});
        notEqual(oValue, oValueListItem.getProperty("value"));
    });

    // *** TEST CASE #3 ***
    test("changeValue() should fire the valueChanged event", function() {
        // Register spy
        var spy = sinon.spy(oValueListItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        oValueListItem.changeValue({});

        // Initial assertion
        ok(spy.called);
    });

    // *** TEST CASE #3 ***
    test("onclick() should fire the select event", function() {
        // First, remove tool popup for this test
        var oToolPopup = oValueListItem.getToolPopup();
        oToolPopup.destroy();

        // Register spy
        var spy = sinon.spy(oValueListItem, 'fireSelect');

        // Initial assertion
        ok(!spy.called);

        oValueListItem.onclick();

        // Initial assertion
        ok(spy.called);
    });

    // *** TEST CASE #4 ***
    test("onclick() should open the toolPopup", function() {
        var oToolPopup = oValueListItem.getToolPopup();
        var spy = sinon.spy();
        oToolPopup.open = spy;
        oToolPopup.close();
        oValueListItem.onclick();
        equal(true, spy.calledOnce);
    });

})();