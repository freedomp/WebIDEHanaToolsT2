(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WarrantyClaimFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WorkSheetFormatter");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.chart.ChartHelper");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");

    /**
     * The controller for the WarrantyClaimDetails view
     * 
     * @class
     * <p>
     * The Warranty Claim Details view provides the functionality to display details for one specific Warranty Claim.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers
     * and set the required bindings.</li>
     * <li>{@link #.onExit} is called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.setContext} is called while opening the view. It sets the selected Warranty Claim Sequence Number and the JDLinkActive flag.
     * </li>
     * <li>{@link #.fetchWarrantyClaimDetails} is called to trigger a new call to the service GetWarrantyClaimDetails.</li>
     * <li>{@link #._displayFacetContent} is called when another facet is required in the content area. It removes the old content and adds the new
     * facet to the current content.</li>
     * <li>{@link #._getFacetContent} is called from _displayFacetContent. It defines the content for all facets.</li>
     * <li>{@link #.isAlreadyInEvidencePackage} is called after receiving the data from the backend service. It enables/disables the add to evidence
     * package button by checking if the WarrantyClaimSequenceNumber is already in the package. </li>
     * <li>{@link #.checkActionState} is called to activate/deactivate the actions by calling isAlreadyInEvidencePackage
     * <li>{@link #.onActionSelected} is called while adding one Warranty Claim to the Evidence Package, adding multiple Warranty Claims to the
     * Evidence Package or closing the view.</li>
     * <ul>
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#WarrantyClaimDetailsView::close} : Notifies the overlay to close the view</li>
     * </ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>_handleFacetSelected is called when a new facet is selected. Switch the facet of the content area by calling _displayFacetContent </li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails */
    {
        _bAddActionsActive : true, // Initialize the _bAddActionsActive flag. It indicates whether the add buttons
        // are visible or not.
        _bJDLinkActive : false, // Initialize the JDLinkActive flag
        _oAddAllToPackageButton : null,
        _oAddToPackageButton : null,
        _oClaimText : null,
        _oView : null,
        _oVulcanoChart : null,
        _oWarrantyClaimService : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiEidViewWorksheetEvidenceWarrantyClaimDetails");
            this._oAddAllToPackageButton = this.byId("addToPackage");
            this._oAddToPackageButton = this.byId("addToPackage");

            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

            // bind context of the complete view to WarrantyClaimDetails
            this._oView.bindElement("/WarrantyClaimDetails");

            this._oWarrantyClaimService = this.getServiceFacade("WarrantyClaim");
            this._oWarrantyClaimService.attachRequestFailed(this._handleRequestFailed, this);

            // Set the dealer quickview binding
            var sDealerQuickViewId = this._oView.createId("DealerQuickView");
            var oDealerQuickView = sap.ui.core.Fragment.byId(sDealerQuickViewId, "DealerQuickView");
            oDealerQuickView.bindElement("/WarrantyClaimDetails");

            // Set the pin/machine quickview binding
            var sMachineQuickViewId = this._oView.createId("MachineQuickView");
            var oMachineQuickView = sap.ui.core.Fragment.byId(sMachineQuickViewId, "MachineQuickView");
            oMachineQuickView.bindElement("/WarrantyClaimDetails");
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         */
        onAfterRendering : function() {
            var sVulcanoChartFragmentId = this._oView.createId("VulcanoChartFragment");
            var oVulcanoChart = sap.ui.core.Fragment.byId(sVulcanoChartFragmentId, "VulcanoChart");
            if (oVulcanoChart) {
                jd.ui.eid.common.chart.ChartHelper.rerenderCharts([oVulcanoChart]);
            }
        },

        /**
         * Called when the service requested failed. It wraps the _onRequestFailed method from the BaseController and add additional logic to disable
         * the action on the WarrantyClaimDetails screen
         */
        _handleRequestFailed : function() {
            // Disable all WarrantyClaimDetails actions except close
            this.disableActions();
            // Call the BaseController failed method
            this._onRequestFailed.apply(this, arguments);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        onExit : function() {
            // Unsubcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);

            // Detach from events
            this._oWarrantyClaimService.detachRequestFailed(this._handleRequestFailed, this);

            // Destroy controls
            if (this._oClaimText) {
                this._oClaimText.destroy();
            }
            if (this._oVulcanoChartFragment) {
                this._oVulcanoChartFragment.destroy();
            }

            // Set properties to null
            this._oAddAllToPackageButton = null;
            this._oAddToPackageButton = null;
            this._oClaimText = null;
            this._oView = null;
            this._oVulcanoChartFragment = null;
            this._oWarrantyClaimService = null;
        },

        /**
         * Set the selected WarrantyClaimSequenceNumber
         * 
         * @param {int}
         *            iWarrantyClaimSequenceNumber the selected WarrantyClaimSequenceNumber.
         * @param {boolean}
         *            bJDLinkActive the JDLinkActive flag of the selected WarrantyClaim.
         * @param {boolean}
         *            [bFetchData=true] if true than a new request will be triggered to receive the new data otherwise not.
         * @param {boolean}
         *            [bAddActionsActive=false] if true actions are visible, if false actions are hidden, if not defined actions are visible.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        setContext : function(iWarrantyClaimSequenceNumber, bJDLinkActive, bFetchData, bAddActionsActive) {
            // Default values
            if (bFetchData === undefined) {
                bFetchData = true;
            }
            if (bAddActionsActive === undefined) {
                bAddActionsActive = false;
            }

            // Set the right facet regarding the JDLinkActive flag
            this._bJDLinkActive = bJDLinkActive;
            if (bJDLinkActive) {
                this.byId("chart").setVisible(true);
                this._displayFacetContent("chart");
                this.byId("ThingViewer").setSelectedFacet(this.byId("chart"));
            } else {
                this.byId("chart").setVisible(false);
                this._displayFacetContent("claimText");
                this.byId("ThingViewer").setSelectedFacet(this.byId("claimText"));
            }

            // Set the flag which indicates whether the "Add" actions are shown or not
            if (bAddActionsActive == true) {
                this._bAddActionsActive = bAddActionsActive;
            } else if (bAddActionsActive == false) {
                this._bAddActionsActive = bAddActionsActive;
                this._oAddAllToPackageButton.setEnabled(false);
                this._oAddToPackageButton.setEnabled(false);
            }
            if (bFetchData) {
                // Reset the old values
                var oModel = sap.ui.getCore().getModel();
                oModel.setProperty("/WarrantyClaimDetails", {});

                // Trigger a new service call
                this.fetchWarrantyClaimDetails(iWarrantyClaimSequenceNumber);
            } else {
                // Just check the current action state
                this.checkActionState();
            }

        },

        /**
         * Triggers a service call to get the Warranty Claim Details and updates the model.
         * 
         * @param {int}
         *            iWarrantyClaimSequenceNumber the selected WarrantyClaimSequenceNumber
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        fetchWarrantyClaimDetails : function(iWarrantyClaimSequenceNumber) {
            // Reset the old values
            var oModel = sap.ui.getCore().getModel();
            oModel.setProperty("/WarrantyClaimDetails", {});
            var aDTCIDs = jd.ui.eid.model.EidModel.TransformationHelper.getDTCIDListFromEvidencePackageDetails();
            this._oWarrantyClaimService.getWarrantyClaimDetails(iWarrantyClaimSequenceNumber, this._bJDLinkActive, aDTCIDs, $.proxy(
                    this.checkActionState, this), $.proxy(this._handleRequestFailed, this));
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the Warranty Claim Details is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/WarrantyClaimDetails") {
                this._oView.getContent()[0].setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the Warranty Claim Details has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/WarrantyClaimDetails") {
                this._oView.getContent()[0].setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * This event handler is called when the facet was changed
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        _handleFacetSelected : function(oEvent) {
            this._displayFacetContent(oEvent.getParameter("id"));
        },

        /**
         * Display the facet content related to the given key from the navigation item.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        _displayFacetContent : function(sKey) {
            var oThingGroup = this.byId("facetContent");
            oThingGroup.removeAllContent();

            // Get the right content regarding the key value and add it to the ThingGroup
            var oFacetContent = this._getFacetContent(sKey);
            oThingGroup.addContent(oFacetContent);
        },

        /**
         * Get the content related to the given key from the navigation item.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         * @returns {sap.ui.core.Control} oContent the facet content
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        _getFacetContent : function(sKey) {
            var oContent = null;

            /*
             * Check whether the facet content is a chart or claimText
             */
            if (sKey.indexOf("chart") != -1) {
                // Check for existing VulcanoChart
                if (!this._oVulcanoChartFragment) {
                    var sVulcanoChartFragmentId = this._oView.createId("VulcanoChartFragment");
                    this._oVulcanoChartFragment = jd.ui.eid.xmlfragment(sVulcanoChartFragmentId,
                            "jd.ui.eid.fragment.warrantyclaim.details.VulcanoChart", this);
                    var oVulcanoChart = sap.ui.core.Fragment.byId(sVulcanoChartFragmentId, "VulcanoChart");
                    jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oVulcanoChart, "Line");
                }
                oContent = this._oVulcanoChartFragment;
            } else if (sKey.indexOf("claimText") != -1) {
                // Check for existing ClaimText
                if (!this._oClaimText) {
                    this._oClaimText = new sap.ui.commons.FormattedTextView({
                        htmlText : "{/WarrantyClaimDetails/ClaimText}",
                        width : "100%"
                    }).addStyleClass("jdUiFTV");
                }
                oContent = this._oClaimText;
            }

            return oContent;
        },

        /**
         * Check whether the Warranty Claim is part of the Evidence Package
         * 
         * @param {integer}
         *            the number of the Warranty Claim that should be checked
         * 
         * @returns {boolean} true if the Warranty Claim was found else false
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetailst
         */
        isAlreadyInEvidencePackage : function(iWarrantyClaimSequenceNumber) {
            var oData = sap.ui.getCore().getModel().getData();
            for ( var i = 0; i < oData.EvidencePackageDetails.Header.WarrantyClaimList.length; i++) {
                var iTempWarrantyClaimSequenceNumber = oData.EvidencePackageDetails.Header.WarrantyClaimList[i].WarrantyClaimSequenceNumber;
                if (iWarrantyClaimSequenceNumber == iTempWarrantyClaimSequenceNumber) {
                    return true;
                }
            };
            return false;
        },

        /**
         * Disable all actions except close
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        disableActions : function() {
            this._oAddAllToPackageButton.setEnabled(false);
            this._oAddToPackageButton.setEnabled(false);
        },

        /**
         * Check if the addAllToPackage and addToPackage action should be enabled/disabled
         * 
         * @memeberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimDetails
         */
        checkActionState : function() {
            // Only change the action status if the add actions are not deactivated in general
            if (this._bAddActionsActive) {
                var oModel = sap.ui.getCore().getModel();
                var bFound = false;

                // Get the Warranty Claims which belong to the selected Prime Part
                var aWarrantyClaimList = oModel.getProperty("/WarrantyClaimPrimePartHeader/WarrantyClaimList");

                // By default disable the button "Add all to Package"
                this._oAddAllToPackageButton.setEnabled(false);

                // Check whether one Warranty Claim has not been added to the Evidence Package
                var that = this;
                $.each(aWarrantyClaimList, function(iIndex, mValues) {
                    if (!that.isAlreadyInEvidencePackage(mValues.WarrantyClaimSequenceNumber)) {
                        // Enable the button if one Warranty Claim exists which is not yet in the package
                        that._oAddAllToPackageButton.setEnabled(true);
                        return false;
                    }
                });

                // Check whether the Warranty Claim from the Warranty Claim Details has already been assigned to the Evidence Package
                var iWarrantyClaimSequenceNumber = oModel.getProperty("/WarrantyClaimDetails").WarrantyClaimSequenceNumber;
                bFound = this.isAlreadyInEvidencePackage(iWarrantyClaimSequenceNumber);
                // Disable the addToPackage button if the Warranty Claim is already in the package
                this._oAddToPackageButton.setEnabled(!bFound);
            }
        },

        /**
         * Handles the 'Add All' button.
         */
        handleAddAllToEvidencePackage : function() {
            // Check whether the Warranty Claims of the Evidence Package collide with the Warranty Claims of the Prime Part
            var iCollisionCount = jd.ui.eid.model.EidModel.TransformationHelper.getCollisionsOfEvidencePackageWarrantyClaims();

            if (iCollisionCount > 0) {
                var that = this;
                // Create a dialog message if not existing
                var oDialog = sap.ui.core.Fragment.byId("AddAllToPackageDialog", "Dialog");
                if (!oDialog) {
                    oDialog = jd.ui.eid.xmlfragment("AddAllToPackageDialog",
                            "jd.ui.eid.fragment.dialog.main.evidencepackage.WarrantyClaimAddAllToPackageDialog", {
                                handleButtonPress : function(oEvent) {
                                    var iResult = oDialog.indexOfButton(oEvent.getSource());
                                    if (iResult == 0) {
                                        that._addAllWarrantyClaimsToPackage();
                                    } else if (iResult == 1) {
                                        that._addAllWarrantyClaimsToPackage(iCollisionCount);
                                    }
                                    // Close the dialog
                                    oDialog.close();
                                },
                                handleClosed : function(oEvent) {
                                    oDialog.close();
                                }
                            });
                }
                oDialog.open();
                // Set text of dialog message
                var sDialogMessageId = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iCollisionCount,
                        'WARRANTY_CLAIM_ADD_ALL_TO_PACKAGE_DIALOG_MSW__MULTIPLE_DEFAULT_MESSAGE',
                        'WARRANTY_CLAIM_ADD_ALL_TO_PACKAGE_DIALOG_MSW_SINGLE_DEFAULT_MESSAGE');
                sap.ui.core.Fragment.byId("AddAllToPackageDialog", "Message").setText(sDialogMessageId);
            } else {
                this._addAllWarrantyClaimsToPackage();
            }
        },

        /**
         * Adds all warranty claims that are currently displayed to the evidence package. If collision if greater than zero, already existing warranty
         * claims will not be overwritten.
         * 
         * @param {integer}
         *            [iCollisionCount=0] number of warranty claims which are already in the evidence package of the ones that you are about to be
         *            added.
         */
        _addAllWarrantyClaimsToPackage : function(iCollisionCount) {
            if (!iCollisionCount) {
                iCollisionCount = 0;
            }
            var bOverwrite = iCollisionCount === 0;
            var oData = this._oView.getModel().getData();

            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addAllWarrantyClaimsToPackage(bOverwrite, this._bJDLinkActive);

            // Disable the addAllToPackage button
            this._oAddAllToPackageButton.setEnabled(false);

            // Close view by event call
            sap.ui.getCore().getEventBus().publish('WarrantyClaimDetailsView', 'close');

            // Show message on screen
            var sSuccessMsg = jd.ui.eid.common.I18NHelper.getNumberChoiceText(oData.WarrantyClaimPrimePartHeader.WarrantyClaimList.length
                    - iCollisionCount, 'WARRANTY_CLAIM_DETAILS_MSG_ALL_ADDED_SUCCESSFULLY_TO_PACKAGE_MULTIPLE',
                    'WARRANTY_CLAIM_DETAILS_MSG_ALL_ADDED_SUCCESSFULLY_TO_PACKAGE_SINGLE');
            this.getNotificationCenter().success(sSuccessMsg);
        },

        /**
         * Handles the 'Add to Package' button and adds the warranty claim to the package.
         */
        handleAddToEvidencePackage : function() {
            // The models data
            var oData = this._oView.getModel().getData();

            var mPrimePartSummary = oData.WarrantyClaimPrimePartHeader.PrimePartSummary;
            var mWarrantyClaimFilterSelection = oData.WarrantyClaimFilters.FilterSelection;
            var mWarrantyClaimFilterState = oData.WarrantyClaimFilters.FilterState;
            var mWarrantyClaim = oData.WarrantyClaimDetails;

            // Disable the button
            this._oView.byId("addToPackage").setEnabled(false);

            // Add Warranty Claim to the evidence package
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addWarrantyClaim(mPrimePartSummary, mWarrantyClaim, mWarrantyClaimFilterSelection,
                    mWarrantyClaimFilterState, this._bJDLinkActive);

            // Show message on screen
            this.getNotificationCenter().success(
                    jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_DETAILS_MSG_ADDED_SUCCESSFULLY_TO_PACKAGE',
                            [mWarrantyClaim.WarrantyClaimNumber]));
        },

        /**
         * Handles the close button and closes the view.
         */
        handleClose : function() {
            // Close view by event call
            sap.ui.getCore().getEventBus().publish('WarrantyClaimDetailsView', 'close');
        }

    }));
})();