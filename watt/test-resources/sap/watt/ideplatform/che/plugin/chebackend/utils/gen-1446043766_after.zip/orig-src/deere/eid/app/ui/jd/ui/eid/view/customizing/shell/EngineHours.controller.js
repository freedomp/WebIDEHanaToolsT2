(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.customizing.shell.BaseController");

    /**
     * @class The controller handles a table of engine hour segments by 'platform & product line' combination retrieved from the backend that can be
     *        updated, duplicated, or deleted by the user and the user can add new combinations. Changing or adding a combination is done via a dialog
     *        (see <code>jd.ui.eid.fragment.dialog.customizing.AddEditEngineHourDialog.xml</code>), where all values can be changed. Platform and
     *        product line are pre-populated from the {@link jd.ui.eid.service.FilterDomainValueServiceFacade} and retrieved in
     *        {@link #.fetchDataHookAfter}. If a new combination is created (includes duplicate), that combination may not be existent yet.
     *        Additionally, the engine hour ranges have to be in sequence to be valid. Validation is done in {@link #.handleDialogOk}. The deletion
     *        of a row has to be confirmed by the user (see {@link #.handleDeleteRow}).
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.customizing.shell.EngineHours
     * @augments jd.ui.eid.view.customizing.shell.BaseController
     */
    sap.ui.controller("jd.ui.eid.view.customizing.shell.EngineHours", jQuery.extend(true, {}, jd.ui.eid.view.customizing.shell.BaseController, /** @lends jd.ui.eid.view.customizing.shell.EngineHours */
    {
        /* Configuration */

        _mConfig : {
            mFetchData : {
                sMethodName : "getEngineHoursSegments"
            },
            mSendData : {
                sPath : "/EngineHourSegments",
                sMethodName : "updateEngineHourSegments",
                sSuccessTextKey : "ENGINE_HOURS_TABLE_MSG_SAVE_SUCCESSFUL"
            },
            mDialog : {
                sId : "AddEditEngineHourDialog",
                sFragment : "jd.ui.eid.fragment.dialog.customizing.AddEditEngineHourDialog",
                sContextPath : "/EngineHourDialog"
            },
            mHelpDialog : {
                sLongTextKey : "ENGINE_HOURS_TABLE_EXP_HELP_TEXT",
                sTitleTextKey : "ENGINE_HOURS_TABLE_HED_HELP_DIALOG"
            },
            sTableId : "table"
        },

        /* View Life Cycle */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#onInitHookAfter
         */
        onInitHookAfter : function() {
            this._oServiceFilter = this.getServiceFacade("FilterDomainValue");
            this._oServiceFilter.attachRequestFailed(this._onRequestFailed);
        },

        /* Service Interaction */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#fetchDataHookAfter
         */
        fetchDataHookAfter : function(fnError) {
            this._oServiceFilter.getPlatformAndProductLine(null, fnError);
        },

        /* View Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleEditRowHookBefore
         */
        handleEditRowHookBefore : function(oEvent) {
            // Flag to check if dialog has been called to create or update severity.
            this._bNewDialogFlag = false;

            // Set title for dialog box
            var oDialogBox = this.getDialogBox();
            oDialogBox.bindProperty("title", "i18n>ENGINE_HOURS_DETAILS_HED_UPDATE_DIALOG");

            // Before we open the dialog, let's reset the selected index on the table
            var oTableDialogField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            oTableDialogField.setSelectedIndex(-1);
        },

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleEditRowHookAfter
         */
        handleEditRowHookAfter : function(oEvent) {
            // Simulate a change in the platform selection so that the binding of the product line dropdown field is updated.
            this.updateDialogProductLineFieldBinding(true);
        },

        /**
         * Handles the click on the insert button and opens the dialog for creating a new item.
         */
        handleInsertRow : function() {
            var oDialogBox = this.getDialogBox();
            var oModel = sap.ui.getCore().getModel();

            // Flag to check if dialog has been called to create or update severity.
            this._bNewDialogFlag = true;

            // Let's create a new record for the first available platform and its first product line so that there are values selected when the dialog
            // opens and pre-populate the bounds table with one entry.
            var mNewRow = {
                PlatformName : oModel.getProperty("/DTCFilters/DomainValues/Platforms/0/Name"),
                ProductLine : oModel.getProperty("/DTCFilters/DomainValues/Platforms/0/ProductLines/0/Name"),
                BoundLimits : [{
                    LowerBound : 0,
                    UpperBound : null
                }]
            };
            oModel.setProperty(this._mConfig.mDialog.sContextPath, mNewRow);

            // Simulate a change in the platform selection so that the binding of the product line dropdown field is updated.
            this.updateDialogProductLineFieldBinding(true);

            oDialogBox.bindProperty("title", "i18n>ENGINE_HOURS_DETAILS_HED_NEW_DIALOG");

            oDialogBox.open();
        },

        /**
         * Handles the click on the duplicate button and opens the dialog with a copy of the selected row.
         */
        handleDuplicateRow : function() {
            var oDialogBox = this.getDialogBox();
            var oModel = sap.ui.getCore().getModel();

            // Flag to check if dialog has been called to create or update severity.
            this._bNewDialogFlag = true;

            // Let's create a new record by copying the record of the selected row.
            var oTable = this.byId("table");
            var mCurrentRow = oTable.getContextByIndex(oTable.getSelectedIndex()).getProperty();
            var mNewRow = jQuery.extend(true, {}, mCurrentRow);
            oModel.setProperty(this._mConfig.mDialog.sContextPath, mNewRow);

            // Simulate a change in the platform selection so that the binding of the product line dropdown field is updated.
            this.updateDialogProductLineFieldBinding(true);

            oDialogBox.bindProperty("title", "i18n>ENGINE_HOURS_DETAILS_HED_DUPLICATE_DIALOG");

            oDialogBox.open();
        },

        /**
         * Handles press event of the 'delete' button of the table by displaying a confirmation dialog to the user and only removing the row if the
         * user confirms.
         */
        handleDeleteRow : function() {
            // Get the selected row index
            var oTable = this._oView.byId("table");
            var iRowIndex = oTable.getSelectedIndex();

            // Don't to anything if no row is selected
            if (iRowIndex == -1) {
                return;
            }
            var oContext = oTable.getContextByIndex(iRowIndex);

            // Define callback for the confirmation dialog.
            var that = this;
            var fnOnDeleteConfirmation = function(bConfirmed) {
                if (bConfirmed) {
                    // To get model data to delete row from model
                    // directly.
                    var oModel = oTable.getModel();
                    var oArrayData = oModel.getProperty(that._mConfig.mSendData.sPath);
                    var iArrayIndex = $.inArray(oContext.getProperty(), oArrayData);
                    if (iArrayIndex == -1) {
                        $.sap.log.error("The context of the row which was selected for deletion wasn't found in the model.", null,
                                'jd.ui.eid.view.customizing.shell.EngineHours');
                        return;
                    }
                    oArrayData.splice(iArrayIndex, 1);
                    // Setting back data to the model.
                    oModel.setProperty(that._mConfig.mSendData.sPath, oArrayData);

                    // Eventually update the table to show the proper row count (this would also happen automatically but with a short delay and we
                    // don't want that), as well as resetting the row selection.
                    oTable.setVisibleRowCount(oArrayData.length);
                    oTable.setSelectedIndex(-1);

                    // Also update the data loss manager
                    that._oDLM.setDirty(true);
                }
            };

            // Get confirmation from user before proceeding
            var oContext = oTable.getContextByIndex(oTable.getSelectedIndex());
            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_TABLE_MSW_CONFIRM_DELETE", [
                    oContext.getProperty("PlatformName"), oContext.getProperty("ProductLine")]);
            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);
        },

        /**
         * Handles the row selection of the table and disables/enables the buttons in the toolbar.
         */
        handleRowSelection : function() {
            var oTable = this.byId("table");
            var oButton = this.byId("dulpicateButton");
            var deleteButton = this.byId("deleteButton");

            if (oTable.getSelectedIndex() >= 0) {
                oButton.setEnabled(true);
                deleteButton.setEnabled(true);
            } else {
                oButton.setEnabled(false);
                deleteButton.setEnabled(false);
            }
        },

        /* Dialog Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleDialogBeforeOpenHook
         */
        handleDialogBeforeOpenHook : function() {
            // Before we open the dialog, let's reset the selected index on the table
            var oTableDialogField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            oTableDialogField.setSelectedIndex(-1);

            // Detach all error tooltips from controls
            var oPlatformField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "Platform");
            var oProductLineField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "ProductLine");
            this.detachErrorTooltipFromControl(oPlatformField);
            this.detachErrorTooltipFromControl(oProductLineField);

            // Clear the extension area of the table
            var oTableDialog = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            oTableDialog.destroyExtension();
        },

        /**
         * This function get the selected row and delete it from the table model in the dialog.
         */
        handleDialogDeleteRow : function() {
            // Get the selected row index
            // var oTable = this._oView.byId("table");
            var oTableDialogField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            var iRowIndex = oTableDialogField.getSelectedIndex();
            // This shouldn't happen, but don't proceed if no row is
            // selected
            if (iRowIndex == -1) {
                return;
            }
            // To get model data to delete row from model
            // directly.
            var oModel = oTableDialogField.getModel();
            var oArrayData = oModel.getProperty("/EngineHourDialog/BoundLimits");
            oArrayData.splice(iRowIndex, 1);
            // Setting back data to the model.
            oModel.setProperty("/EngineHourDialog/BoundLimits", oArrayData);
            this.sanitizeDialogRanges();

            // Eventually update the table to show the proper row count (this would also happen automatically but with a short delay and we
            // don't want that), as well as resetting the row selection.
            oTableDialogField.setSelectedIndex(-1);
        },

        /**
         * This function inserts a new row on click of insert button in the dialog box.
         */
        handleDialogInsertRow : function(oEvent) {
            var oTableDialogField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            var oModel = sap.ui.getCore().getModel();
            // Copying object to new path for dialog binding
            var oData = oModel.getProperty("/EngineHourDialog/BoundLimits");
            var iIndex = 0;
            if (oTableDialogField.getSelectedIndex() != -1) {
                iIndex = oTableDialogField.getSelectedIndex() + 1; // Insert after the selected element
            } else {
                iIndex = oData.length;
            }

            oData.splice(iIndex, 0, {
                LowerBound : 0,
                UpperBound : null
            });
            // Set the new row as selected
            oTableDialogField.setSelectedIndex(iIndex);

            oModel.setProperty("/EngineHourDialog/BoundLimits", oData);
            this.sanitizeDialogRanges();
        },

        /**
         * This method sets back values to the given row
         */
        handleDialogOk : function() {
            this.sanitizeDialogRanges();
            if (this.validateBounds() & this.validatePlatformAndProductLineCombination()) {
                var oModel = sap.ui.getCore().getModel();
                if (this._bNewDialogFlag) {
                    // Get the selected row index
                    var oTable = this._oView.byId("table");
                    // To get model data to add row to the model directly.
                    var aArrayData = oModel.getProperty("/EngineHourSegments");
                    // To set index for last row to be added
                    var lastRowIndex = aArrayData.length;
                    // To get data from the model
                    var oData = oModel.getData();
                    // To create new row data
                    var oDialogValue = oModel.getProperty(this._mConfig.mDialog.sContextPath);

                    // Dirty workaround because if the user enters zero when
                    // creating a new entry, this will not be
                    // reflected in the model
                    if (!oDialogValue.BoundLimits[0].LowerBound || oDialogValue.BoundLimits[0].LowerBound == "0") {
                        oDialogValue.BoundLimits[0].LowerBound = 0;
                    }

                    oData.EngineHourSegments.push(jQuery.extend(true, {}, oDialogValue));

                    oModel.setData(oData);
                    oTable.setVisibleRowCount(lastRowIndex + 1);

                    // If a new item has been added, we need to update the data loss manager
                    this._oDLM.setDirty(true);
                } else {
                    // Compare the values of the dialog with the values of the table. Only if the values are not the same, we need to change the state
                    // of the data loss manager
                    if (!oModel.pathsEqual(this._sDialogPath, this._mConfig.mDialog.sContextPath)) {
                        this._oDLM.setDirty(true);
                    }
                    oModel.setProperty(this._sDialogPath, oModel.getProperty(this._mConfig.mDialog.sContextPath));
                }
                this._bNewDialogFlag = false;
                this._oDialog.close();
            }
        },

        /**
         * Handles the row selection of the dialog's table and disables/enables the buttons in the toolbar.
         */
        handleDialogRowSelection : function() {
            var oTable = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            var oDeleteButton = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "dialogDeleteButton");
            var oInsertButton = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "dialogInsertButton");

            if (oTable.getSelectedIndex() >= 0) {
                oDeleteButton.setEnabled(true);
            } else {
                oDeleteButton.setEnabled(false);
            }

            var aBounds = sap.ui.getCore().getModel().getProperty("/EngineHourDialog/BoundLimits");
            oInsertButton.setEnabled(!(aBounds.length == 10));
        },

        /**
         * Handler of the platform dropdown field's change event to update the binding of the product line dropdown field.
         */
        handleDialogPlatformChange : function() {
            this.updateDialogProductLineFieldBinding(false);
        },

        /**
         * Updates the product line field's binding based on the platform value in the model.
         * 
         * @param {boolean}
         *            bFromDialogContext If true, the product line from the dialog context/model will be pre-selected, if false, the first product
         *            line will be pre-selected.
         */
        updateDialogProductLineFieldBinding : function(bFromDialogContext) {
            var oModel = sap.ui.getCore().getModel();

            // First, we need to find out the index of the selected platform so that we can construct the path to the related product lines.
            var sSelectedKey = oModel.getProperty("/EngineHourDialog/PlatformName");
            var iSelectedKey = 0;

            var aPlatformList = oModel.getProperty("/DTCFilters/DomainValues/Platforms");
            jQuery.each(aPlatformList, function(idx, value) {
                if (sSelectedKey == value.ID) {
                    iSelectedKey = idx;
                    return false; // break
                }
            });

            if (!bFromDialogContext) {
                // Let's construct the path, update the model for the dialog...
                var sPath = "/DTCFilters/DomainValues/Platforms/" + iSelectedKey + "/ProductLines/0/Name";
                oModel.setProperty(this._mConfig.mDialog.sContextPath + "/ProductLine", oModel.getProperty(sPath));
            }
            // ... and also the binding for the product line dropdown field.
            var oProductLineDropdownBox = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "ProductLine");
            oProductLineDropdownBox.bindContext('/DTCFilters/DomainValues/Platforms/' + iSelectedKey);
            oProductLineDropdownBox.bindProperty("value", "/EngineHourDialog/ProductLine");
        },

        /**
         * Handler for the live change event of the lower bound text fields. Updates the upper bound of the previous row.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired.
         */
        handleDialogLowerBoundLiveChange : function(oEvent) {
            var iValue = oEvent.getParameter("liveValue");
            var iIndex = oEvent.getSource().getParent().getIndex();

            // Update the upper bound of the previous row (of course only if the current row is not the first one).
            if (iIndex != 0) {
                var oTable = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
                // sap.ui.getCore().getModel().setProperty("UpperBound", iValue, oTable.getContextByIndex(iIndex - 1));
            }
        },

        /**
         * Handler for the change event of the lower bound text fields. Updates the upper bound of the previous row.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired.
         */
        handleDialogLowerBoundChange : function(oEvent) {
            var iIndex = oEvent.getSource().getParent().getIndex();

            // Update the upper bound of the previous row (of course only if the current row is not the first one).
            if (iIndex != 0) {
                var oTable = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
                // We read the value from the model, so that we get the raw value, not the formatted one.
                var iValue = oTable.getContextByIndex(iIndex).getProperty("LowerBound");
                sap.ui.getCore().getModel().setProperty("UpperBound", iValue, oTable.getContextByIndex(iIndex - 1));
            }
        },

        /* Validation */

        /**
         * Validates the combination of platform and product line for uniqueness. The combination is valid if its unique.
         * 
         * @return {boolean} True if the combination is valid, false otherwise.
         */
        validatePlatformAndProductLineCombination : function() {
            var oPlatformField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "Platform");
            var oProductLineField = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "ProductLine");
            var sPlatformValue = oPlatformField.getValue();
            var sProductLineValue = oProductLineField.getValue();

            // Loop through all available engine hours segments and count the occurences when platform and product occur on the model.
            var oModel = sap.ui.getCore().getModel();
            var aEngineHourSegments = oModel.getProperty("/EngineHourSegments");
            var iOccurenceCount = 0;
            for ( var i = 0; i < aEngineHourSegments.length; i++) {
                var mEngineHourSegment = aEngineHourSegments[i];
                if (sPlatformValue == mEngineHourSegment.PlatformName && sProductLineValue == mEngineHourSegment.ProductLine) {
                    iOccurenceCount++;
                }
            }

            // If the occurence is one and we didn't create a record (than the user didn't change the combination) or if the occurence is zero, we're
            // good. Everything else is invalid.
            if (iOccurenceCount == 0 || (iOccurenceCount == 1 && !this._bNewDialogFlag)) {
                this.detachErrorTooltipFromControl(oPlatformField);
                this.detachErrorTooltipFromControl(oProductLineField);
                return true;
            } else {
                var sMessage = jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_DETAILS_MSE_DUPLICATE_COMBINATION", [sPlatformValue,
                        sProductLineValue]);
                this.attachErrorTooltipToControl(oPlatformField, sMessage);
                this.attachErrorTooltipToControl(oProductLineField, sMessage);
                return false;
            }
        },

        /**
         * Method validate bounds value if they are sorted and if any row is empty or not name.
         * 
         * @param {Boolean}
         */
        validateBounds : function() {
            var oTableDialog = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "table");
            var aEngineHourRanges = oTableDialog.getModel().getProperty("/EngineHourDialog/BoundLimits");
            var iRowCount = oTableDialog.getModel().getProperty("/EngineHourDialog/BoundLimits").length;
            var sTextKey = null;

            for ( var i = 0; i < iRowCount; i++) {
                var oBoundField = oTableDialog.getRows()[i].getCells()[0];
                var iBoundValue = jQuery.trim(aEngineHourRanges[i].LowerBound);
                oBoundField.setValueState(sap.ui.core.ValueState.None);

                if (iBoundValue == "") {
                    oBoundField.setValueState(sap.ui.core.ValueState.Error);
                    sTextKey = "ENGINE_HOURS_DETAILS_MSE_LOWER_BOUND_REQUIRED";
                } else if (isNaN(iBoundValue)) {
                    oBoundField.setValueState(sap.ui.core.ValueState.Error);
                    sTextKey = "ENGINE_HOURS_DETAILS_MSE_LOWER_BOUND_NOT_NUMERIC";
                } else if (i < iRowCount - 1) {
                    var oSubsequentBoundField = oTableDialog.getRows()[i + 1].getCells()[0];
                    var iSubsequentBoundValue = jQuery.trim(aEngineHourRanges[i + 1].LowerBound);

                    if (iSubsequentBoundValue == "") {
                        sTextKey = "ENGINE_HOURS_DETAILS_MSE_LOWER_BOUND_REQUIRED";
                        oSubsequentBoundField.setValueState(sap.ui.core.ValueState.Error);
                    } else if (isNaN(iSubsequentBoundValue)) {
                        sTextKey = "ENGINE_HOURS_DETAILS_MSE_LOWER_BOUND_NOT_NUMERIC";
                        oSubsequentBoundField.setValueState(sap.ui.core.ValueState.Error);
                    } else if (parseFloat(iBoundValue) >= parseFloat(iSubsequentBoundValue)) {
                        oSubsequentBoundField.setValueState(sap.ui.core.ValueState.Error);
                        sTextKey = "ENGINE_HOURS_DETAILS_MSE_INVALID_SEQUENCE";
                    }

                }
            }

            if (sTextKey) {
                // There has been an error, so either reuse the text view in the table's extension or create a new one.
                var aTableExtension = oTableDialog.getExtension();
                if (!aTableExtension[0]) {
                    oTableDialog.addExtension(new sap.ui.commons.TextView({
                        semanticColor : sap.ui.commons.TextViewColor.Negative
                    }));
                    // Reread the table extension so that we have the current content in the array.
                    aTableExtension = oTableDialog.getExtension();
                }
                aTableExtension[0].setText(jd.ui.eid.common.I18NHelper.getText(sTextKey));
                return false;
            } else {
                // There's no error so let's get rid of the extension area.
                oTableDialog.destroyExtension();
                return true;
            }
        },

        /* Formatters */

        /**
         * Formats bound values to comma separated string.
         * 
         * @param {array}
         *            aBounds an array of objects with properties <code>LowerBound</code> and <code>UpperBound</code>.
         * @return {string} concatenated string of the bounds
         */
        formatBoundsToString : function(aBounds) {
            var sBounds = "";
            var mFractionDigits = {
                min : 0,
                max : 5
            };
            if (aBounds) {
                for ( var i = 0; i < aBounds.length; i++) {
                    var mBound = aBounds[i];
                    if (i == (aBounds.length - 1)) {
                        // if this is the last segment, we just display the lower bound with 'greater than'
                        sBounds += jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_RANGE_OPEN",
                                [jd.ui.eid.common.formatter.NumberFormatter.formatFloat(mBound.LowerBound, mFractionDigits)]);
                    } else {
                        sBounds += jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_RANGE", [
                                jd.ui.eid.common.formatter.NumberFormatter.formatFloat(mBound.LowerBound, mFractionDigits),
                                jd.ui.eid.common.formatter.NumberFormatter.formatFloat(mBound.UpperBound, mFractionDigits)])
                                + jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_TABLE_TXT_RANGE_SEPARATOR");
                    }
                }
                return sBounds;
            }
        },

        /**
         * Formats the upper bound of an engine hour segment by either prefix it with a 'less than' symbol or by transforming it into the infinity
         * symbol.
         * 
         * @param {string}
         *            sValue value of upper bound
         * @return {string} formatted string
         */
        formatUpperBound : function(sValue) {
            if (sValue == null || sValue == "") {
                return jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_INFINITE_UPPER_BOUND");
            } else {
                return jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_UPPER_BOUND_LESS_THAN", [sValue]);
            }
        },

        /**
         * Formats a platform and product line combination into a concatenated string.
         * 
         * @param {string}
         *            sPlatform the platform.
         * @param {string}
         *            sProductLine the product line.
         * @returns {string} concatenated string.
         */
        formatPlatformAndProductLineCell : function(sPlatform, sProductLine) {
            return jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_TABLE_CEL_PLATFORM_PRODUCT_LINE", [sPlatform, sProductLine]);
        },

        /**
         * Sanitizes all engine hour ranges in the dialog's model to that the upper bound of the last range is <code>null</code> and all other
         * bounds are set to the lower bound of the subsequent range.
         */
        sanitizeDialogRanges : function() {
            var oModel = sap.ui.getCore().getModel();
            var aBoundLimits = oModel.getProperty("/EngineHourDialog/BoundLimits");
            for ( var i = 0; i < aBoundLimits.length; i++) {
                if (i == (aBoundLimits.length - 1)) {
                    aBoundLimits[i].UpperBound = null;
                } else {
                    aBoundLimits[i].UpperBound = parseFloat(aBoundLimits[i + 1].LowerBound);
                }
                aBoundLimits[i].LowerBound = parseFloat(aBoundLimits[i].LowerBound);
            }
            oModel.setProperty("/EngineHourDialog/BoundLimits", aBoundLimits);
        }

    }));
})();