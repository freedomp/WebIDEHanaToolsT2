(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ExactBrowser");

    /**
     * @class This class is a branded and extended version of the SAP UI5 standard ExactBrowser.
     * 
     * It allows to disable animations for one (re)rendering, as these may cause flickering if at
     * the same time, one sublist is displayed while another is hidden.
     * 
     * @name jd.ui.eid.control.ExactBrowser
     * @extends sap.ui.ux3.ExactBrowser
     */
    sap.ui.ux3.ExactBrowser.extend("jd.ui.eid.control.ExactBrowser",
    /** @lends jd.ui.eid.control.ExactBrowser */
    {
        /**
         * Add style class for branding.
         * 
         * @see sap.ui.ux3.ExactBrowser#init
         */
        init : function() {
            sap.ui.ux3.ExactBrowser.prototype.init.apply(this, arguments);

            // for branding CSS
            this.addStyleClass("jdUiEidUx3ExactBrowser");
        },

        /**
         * Disable all animations for the next (re)rendering
         * 
         * Attention: This might have side effects during rendering, as the global variable
         * jQuery.fx.off will be set to true during rendering of this control. It will be reset afterwards.
         */
        disableAnimationsForNextRendering : function() {
            this.bDisableAnimationForNextRendering = true;
        },

        /**
         * Disable animations if requested by {@link jd.ui.eid.control.ExactBrowser#disableAnimationsForNextRendering}
         * 
         * @see jd.ui.eid.control.ExactBrowser#disableAnimationsForNextRendering
         * @see jd.ui.eid.control.ExactBrowser#onAfterRendering
         */
        onBeforeRendering : function() {
            if (this.bDisableAnimationForNextRendering) {
                // save previous setting for later reset in onAfterRendering()
                this.bDefaultAnimationSetting = jQuery.fx.off;
                jQuery.fx.off = true;
            };

            if (sap.ui.ux3.ExactBrowser.prototype.onBeforeRendering) {
                sap.ui.ux3.ExactBrowser.prototype.onBeforeRendering.apply(this, arguments);
            }
        },

        /**
         * Reenable animations if they were disabled by {@link jd.ui.eid.control.ExactBrowser#onBeforeRendering}
         * 
         * @see jd.ui.eid.control.ExactBrowser#disableAnimationsForNextRendering
         * @see jd.ui.eid.control.ExactBrowser#onBeforeRendering
         */
        onAfterRendering : function() {
            if (this.bDisableAnimationForNextRendering) {
                // reset to previous setting
                jQuery.fx.off = this.bDefaultAnimationSetting;
            };
            // rendering done -> reset for next rendering
            this.bDisableAnimationForNextRendering = false;

            if (sap.ui.ux3.ExactBrowser.prototype.onAfterRendering) {
                sap.ui.ux3.ExactBrowser.prototype.onAfterRendering.apply(this, arguments);
            }
        },

        renderer : "sap.ui.ux3.ExactBrowserRenderer"
    });

})();