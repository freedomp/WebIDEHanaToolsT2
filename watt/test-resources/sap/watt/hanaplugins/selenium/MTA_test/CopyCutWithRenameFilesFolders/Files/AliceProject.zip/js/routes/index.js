module.exports.testdata = require('./testdata');
module.exports.userinfo = require('./userinfo');
module.exports.adressbook = require('./adressbook');
