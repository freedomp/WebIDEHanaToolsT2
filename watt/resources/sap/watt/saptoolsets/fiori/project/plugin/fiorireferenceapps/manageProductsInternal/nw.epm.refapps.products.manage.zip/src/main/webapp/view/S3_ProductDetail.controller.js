jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("nw.epm.refapps.products.manage.view.S3_ProductDetail", {
    // Stores the currently requested context path
    _sContextPath : "",
    // Stores the current product that is bound to the view, it could be null if the requested product cannot be found
    // any more (such as deeplink use case)
    _oProduct : null,
    // Helper instance used to handle backend operations
    _oHelper : null,
    _oComponent : null,
    _oResourceBundle : null,
    _oView : null,
    _oEventBus : null,
    _sIdentity : "nw.epm.refapps.product.manage",
    _sListMode : null,

    onInit : function() {
        this._oView = this.getView();
        this._oResourceBundle = this.oApplicationFacade.getResourceBundle();
        // Gets the application component and the data operation helper instance
        var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
        this._oComponent = sap.ui.component(sComponentId);
        this._oEventBus = this._oComponent.getEventBus();
        this._oHelper = this._oComponent.getODataHelper(this._oResourceBundle, this.getView().getModel());
        // Attaches these to the RoutePatternMatched event
        this.oRouter.attachRoutePatternMatched(this.onRoutePatternMatched, this);
        this._oEventBus.subscribe(this._sIdentity, "enableEditingButton", this.setEditingButtonEnabled, this);
        this._oEventBus.subscribe(this._sIdentity, "setListMode", this.setListMode, this);
        this._sListMode = this.getView().getModel("device").getData().listMode;
        this.setHeaderFooterOptions(this._buildHFOptions());
    },

    onRoutePatternMatched : function(oEvent) {
        if (!oEvent.getParameter("arguments").productID) {
            return;
        }
        this._sContextPath = "/Products('" + oEvent.getParameter("arguments").productID + "')";
        this._oView.bindElement(this._sContextPath, {
            expand : "Supplier"
        });
        // Updates the footer AFTER the view is bound to the requested data, there are two possibilities to identify
        // that the binding is set:

        // 1. If the requested data is already available locally in the model, the binding is set directly.
        if (!this._extractProduct()) {
            // 2. If the binding is not set yet, the binding is retrieved remotely.
            this.getView().getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
                if (!this._extractProduct()) {
                    // Handles the case that the product cannot be retrieved remotely (such as it was already deleted).
                    // Calls the showEmptyView function on the master page, which is provided by scaffolding.
                    this._oEventBus.publish(this._sIdentity, "showEmptyView", {
                        sProduct : "xtit.product",
                        sMessage : "ymsg.productNotAvailable"
                    });
                }
            }, this));
        }
    },

    _extractProduct : function() {
        var oBindingContext = this._oView.getBindingContext();
        this._oProduct = null;
        if (oBindingContext) {
            if (oBindingContext.getPath() === this._sContextPath) {
                this._oProduct = oBindingContext.getObject();
                this.setHeaderFooterOptions(this._updateHFOptions());
            }
            return true;
        } else {
            return false; // The requested product is not available in backend
        }
    },
    // Updates email and Buttons options; is only called after the view is bound to a product.
    _updateHFOptions : function() {
        var bButtonDisabled = false;
        // Checks if the master page is in multiSelect mode. If so, the Edit, Delete, and Copy buttons need to be
        // deactivated.
        if (this._sListMode === sap.m.ListMode.MultiSelect) {
            bButtonDisabled = true;
        }

        return {

            sI18NDetailTitle : "xtit.product",
            buttonList : [ {
                // Sets Edit button
                sId : "editButton",
                sI18nBtnTxt : "xbut.edit",
                onBtnPressed : jQuery.proxy(this.onEditPressed, this),
                bDisabled : bButtonDisabled
            }, {
                // Sets Delete button
                sId : "deleteButton",
                sI18nBtnTxt : "xbut.delete",
                onBtnPressed : jQuery.proxy(this.onDeletePressed, this),
                bDisabled : bButtonDisabled
            }, {
                // Sets Copy button
                sId : "copyButton",
                sI18nBtnTxt : "xbut.copy",
                onBtnPressed : jQuery.proxy(this.onCopyPressed, this),
                bDisabled : bButtonDisabled
            } ],
            oEmailSettings : {
                sSubject : this._getEmailSubject(),
                sRecepient : "",
                fGetMailBody : jQuery.proxy(this._getEmailContent, this)
            }
        };

    },
    // Sets statically header and footer; is called onInit so that footer is visible whilst awaiting data
    _buildHFOptions : function() {
     
        return {
            sI18NDetailTitle : "xtit.product",
            buttonList : [ {
                // Sets Edit button
                sId : "editButton",
                sI18nBtnTxt : "xbut.edit",
                onBtnPressed : jQuery.proxy(this.onEditPressed, this)
            }, {
                // Sets Delete button
                sId : "deleteButton",
                sI18nBtnTxt : "xbut.delete",
                onBtnPressed : jQuery.proxy(this.onDeletePressed, this)
            }, {
                // Sets Copy button
                sId : "copyButton",
                sI18nBtnTxt : "xbut.copy",
                onBtnPressed : jQuery.proxy(this.onCopyPressed, this)
            } ]
        };
    },

    // User wants to open the business card of the product supplier
    onSupplierPressed : function(oEvent) {
        // Read supplier data
        var oModel = this.getView().getModel();
        var sSupplierPath = this._sContextPath + "/Supplier";
        var oSupplierData = oModel.getObject(sSupplierPath);
        // Callback for the cross-navigation in the business card
        var fnCallbackNavPara = function() {
            var oNavConfig = {};
            oNavConfig.target = {};
            oNavConfig.target.semanticObject = "EPMSupplier";
            oNavConfig.target.action = "displayFactSheet";
            oNavConfig.params = {
                EPMSupplierExternalId : oSupplierData.Id
            };
            return oNavConfig;
        };

        // Set data for the business card
        var oSupplierConfig = {
            title : this._oResourceBundle.getText("xtit.supplier"),
            companyname : oSupplierData.Name,
            companyphone : oSupplierData.Phone,
            companyaddress : oSupplierData.FormattedAddress,
            maincontactname : oSupplierData.FormattedContactName,
            maincontactphone : oSupplierData.ContactPhone1,
            maincontactmobile : oSupplierData.ContactPhone2,
            maincontactemail : oSupplierData.ContactEmail,
            maincontactemailsubj : this._getEmailSubject(),
            beforeExtNav : fnCallbackNavPara
        };
        jQuery.sap.require("sap.ca.ui.quickoverview.CompanyLaunch");
        new sap.ca.ui.quickoverview.CompanyLaunch(oSupplierConfig).openBy(oEvent.getSource());
    },

    // Called by ProductMaster controller via Event Bus
    setEditingButtonEnabled : function(sChannel, sEvent, oParm) {
        var bEnabled = oParm.bEnabled;
        this.setBtnEnabled("editButton", bEnabled);
        this.setBtnEnabled("deleteButton", bEnabled);
        this.setBtnEnabled("copyButton", bEnabled);
    },

    // User wants to copy the current product
    onCopyPressed : function() {
        // Defines callback function to be executed after the product is copied to a new product draft in the backend
        var fnAfterCopy = function(sDraftId) {
            // Reuses the navToDraftForNewProduct function on the master page that is also used for AddProduct;
            // Navigates to the draft and then removes the selection in the master list.

            this._oEventBus.publish(this._sIdentity, "onCopyPressed", {
                sDraftId : sDraftId
            });
        };
        this._oHelper.copyProductToDraft(this._oProduct.Id, jQuery.proxy(fnAfterCopy, this));
    },

    // User wants to edit the current product
    onEditPressed : function() {
        // Define callback function to be executed after a product draft is generated based on the current product in
        // the backend.
        var fnNavToProductDraft = function(sDraftId) {
            if (sDraftId && typeof sDraftId === "string") {
                // Navigates to the Edit Product page
                this._oComponent.navToProductEditPage(sDraftId);
            }
        };
        this._oHelper.getProductDraftFromProductId(this._oProduct.Id, jQuery.proxy(fnNavToProductDraft, this));
    },

    // User wants to delete the current product
    onDeletePressed : function() {
        // Defines callback function to be executed after the product is deleted successfully in the backend
        var fnRemoveItemInMaster = function() {
            // Extra first step in phone mode:
            // Navigates away from current (deleted) product page and back to the master page
            this._oComponent.navBackToMasterPageInPhone();
            // Reuses the removeItemsFromMasterList function on the master page that is also used there for the
            // DeleteProduct function;
            // Refreshes the master list and after that brings the deletion success message toast.
            var sConfirmation = this._oResourceBundle.getText("ymsg.deleteConfirmation", this.byId("ProductHeader")
                    .getTitle());
            this._oEventBus.publish(this._sIdentity, "removeItemsFromMasterList", {
                sConfirmation : sConfirmation
            });
        };
        this._oHelper.deleteProduct(this._sContextPath, jQuery.proxy(fnRemoveItemInMaster, this));
    },

    _getEmailSubject : function() {
        return this._oResourceBundle.getText("xtit.emailSubject", [ this._oProduct.Name ]);
    },

    _getEmailContent : function() {
        return this._oResourceBundle.getText("xtit.emailContent", [ this._oProduct.Id, this._oProduct.Description,
                this._oProduct.SupplierName ]);
    },

    setListMode : function(sChannel, sEvent, oParm) {

        this._sListMode = oParm.sListMode;

    }

});