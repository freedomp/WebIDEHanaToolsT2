sap.ui.jsview("jds.tree", {

	getControllerName : function() {
		return "jds.tree";
	},

	createContent : function(oController) {
        var backendURL = "/rest/addressbook/tree"
	    var oModel = new sap.ui.model.json.JSONModel(backendURL, false);

        oModel.attachParseError(function(oControlEvent) {
            alert("Something has gone wrong while accessing the REST service at " + backendURL + ". Please check whether the node.js application is up and running.")
        })

        oModel.attachRequestFailed(function(oControlEvent) {
            alert("Something has gone wrong while accessing the REST service at " + backendURL + ". Please check whether the node.js application is up and running.")
        })

        var oTable = new sap.ui.table.TreeTable({
            id : "AddressBookOverview",
            columns: [
                new sap.ui.table.Column({label: "Name", template: "name"}),
                new sap.ui.table.Column({label: "City", template: "city"}),
                new sap.ui.table.Column({label: "Phone", template: "phone"})
            ],
            visibleRowCount : 20,
            width : "100%",
            selectionMode : sap.ui.table.SelectionMode.Single,
            selectionBehavior : sap.ui.table.SelectionBehavior.Row
        });

        oTable.setModel(oModel);
        var oSorter = new sap.ui.model.Sorter("name");
        oTable.bindRows("/books", oSorter);

        // button to generate more data
        var oBtn = new sap.ui.commons.Button({text: "Create Data",
            press: function() {
                var aData = jQuery.ajax({
                    type : "GET",
                    contentType : "application/json",
                    url : "/rest/addressbook/testdata",
                    dataType : "json",
                    async: false, 
                    success : function(data, textStatus, jqXHR) {
                        oModel.loadData("/rest/addressbook/tree");
                    },
                    statusCode: {
                        401 : function() {
                            location.reload();
                        }
                    }
                });
            }
        });
        oTable.setToolbar(new sap.ui.commons.Toolbar({items: [oBtn]}));

        var oPanel = new sap.ui.commons.Panel().setText("Address Books").addContent(oTable);
        return oPanel;
	}
});
