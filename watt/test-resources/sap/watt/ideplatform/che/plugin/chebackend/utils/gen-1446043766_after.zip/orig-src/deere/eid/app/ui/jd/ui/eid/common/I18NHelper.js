(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.I18NHelper");

    /**
     * @class This helper class provides methods for reading I18N texts
     * @static
     * @name jd.ui.eid.common.I18NHelper
     */
    jd.ui.eid.common.I18NHelper = {};

    /**
     * Fetches i18n text based on the provided key.
     * 
     * @memberOf jd.ui.eid.common.I18NHelper
     * @param {string}
     *            sTextKey The key for which text needs to be retrieved.
     * @param {array}
     *            [aParams] An array with values for placeholders in the retrieved text
     */
    jd.ui.eid.common.I18NHelper.getText = function(sTextKey, aParams) {
        return sap.ui.getCore().getModel("i18n").getResourceBundle().getText(sTextKey, aParams);
    };

    /**
     * Fetches the i18n text based on the numeric value.
     * 
     * @param {integer}
     *            iValue the value to be passed as a placeholder.
     * @param {string}
     *            sTextKeyMany the text key used if the value is greater than 1.
     * @param {string}
     *            [sTextKeyOne] the text key used if the value equals 1. If not provided, <code>sTextKeyMany</code> is used.
     * @param {string}
     *            [sTextKeyZero] the text key used if the value equals 0. If not provided, <code>sTextKeyMany</code> is used.
     * @returns {string} formatted string.
     */
    jd.ui.eid.common.I18NHelper.getNumberChoiceText = function(iValue, sTextKeyMany, sTextKeyOne, sTextKeyZero) {
        // Initialize defaults
        if (!sTextKeyZero) {
            sTextKeyZero = sTextKeyMany;
        }
        if (!sTextKeyOne) {
            sTextKeyOne = sTextKeyMany;
        }

        if (iValue == 0) {
            return this.getText(sTextKeyZero, [iValue]);
        } else if (Math.abs(iValue) == 1) {
            return this.getText(sTextKeyOne, [iValue]);
        } else {
            return this.getText(sTextKeyMany, [iValue]);
        }
    };
})();