
----------------------------------------------------------------------------------------------------------
-- Search Indices on Master Data Tables
----------------------------------------------------------------------------------------------------------

DROP FULLTEXT INDEX "EID"."NATIVE_PIN_INDEX";
CREATE FULLTEXT INDEX native_pin_index ON "EID"."deere.etl.eid.catalog.tables::MK_MACHINE_EIA" (native_pin)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "DATA_DS_TELEMATICS"."DTC_INDEX";
CREATE FULLTEXT INDEX dtc_index ON "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::DTC_MASTER" (dtc)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "DATA_DS_TELEMATICS"."WARNING_LIGHT_INDEX";        
CREATE FULLTEXT INDEX warning_light_index ON "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::DTC_MASTER" (warning_light)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "DATA_DS_TELEMATICS"."L1_INDEX";
CREATE FULLTEXT INDEX l1_index ON "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::DTC_MASTER" (l1_text)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "DATA_DS_TELEMATICS"."L2_INDEX";
CREATE FULLTEXT INDEX l2_index ON "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::DTC_MASTER" (l2_text)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PRIME_PART_NUM_INDEX";
CREATE FULLTEXT INDEX prime_part_num_index ON "EID"."deere.etl.eid.catalog.tables::WRNTY_CLAIM_EIA" (prime_part_num)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PART_NAME_DSC_INDEX";        
CREATE FULLTEXT INDEX part_name_dsc_index ON "EID"."deere.etl.eid.catalog.tables::WRNTY_CLAIM_EIA" (part_name_dsc)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PRIME_PART_DTL_TXT_INDEX";
CREATE FULLTEXT INDEX prime_part_dtl_txt_index ON "EID"."deere.etl.eid.catalog.tables::WRNTY_CLAIM_TEXT_EIA" (prime_part_dtl_txt)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL'
        TEXT MINING ON;

DROP FULLTEXT INDEX "DATA_DS_DTAC"."QW_PROBLEM_INDEX";
CREATE FULLTEXT INDEX qw_problem_index ON "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_NOTES" (qw_problem)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS ON 
        CONFIGURATION 'EXTRACTION_CORE_VOICEOFCUSTOMER'
        TEXT MINING ON;

DROP FULLTEXT INDEX "DATA_DS_DTAC"."QW_NOTES_INDEX";
CREATE FULLTEXT INDEX qw_notes_index ON "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_NOTES" (qw_notes)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS ON 
        CONFIGURATION 'EXTRACTION_CORE_VOICEOFCUSTOMER'
        TEXT MINING ON;

DROP FULLTEXT INDEX "ZSECURITY"."UNIT_INDEX";
CREATE FULLTEXT INDEX unit_index ON "ZSECURITY"."deere.security.core.catalog.tables::MANAGED_USERS" (unit)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "ZSECURITY"."DEPT_INDEX";
CREATE FULLTEXT INDEX dept_index ON "ZSECURITY"."deere.security.core.catalog.tables::MANAGED_USERS" (dept)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "ZSECURITY"."FULLNAME_INDEX";
CREATE FULLTEXT INDEX fullname_index ON "ZSECURITY"."deere.security.core.catalog.tables::MANAGED_USERS" (fullname)
        ASYNC 
        FUZZY SEARCH INDEX ON
        LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
        FAST PREPROCESS OFF 
        SEARCH ONLY OFF 
        TEXT ANALYSIS OFF 
        CONFIGURATION 'LINGANALYSIS_FULL';


----------------------------------------------------------------------------------------------------------
-- Search Indices on Application-Specific Tables
----------------------------------------------------------------------------------------------------------

DROP FULLTEXT INDEX "EID"."PACKAGE_NAME_INDEX";
CREATE FULLTEXT INDEX package_name_index 
ON "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H" (PACKAGE_NAME) 
ASYNC
FUZZY SEARCH INDEX ON
LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
FAST PREPROCESS OFF
SEARCH ONLY OFF
TEXT ANALYSIS OFF 
CONFIGURATION 'LINGANALYSIS_FULL';

DROP FULLTEXT INDEX "EID"."PACKAGE_DESC_INDEX";
CREATE FULLTEXT INDEX package_desc_index  
ON "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H" (PACKAGE_DESC) 
ASYNC
FUZZY SEARCH INDEX ON
LANGUAGE DETECTION ('EN', 'DE', 'ES', 'FR')
FAST PREPROCESS OFF
SEARCH ONLY OFF
TEXT ANALYSIS OFF 
CONFIGURATION 'LINGANALYSIS_FULL';
