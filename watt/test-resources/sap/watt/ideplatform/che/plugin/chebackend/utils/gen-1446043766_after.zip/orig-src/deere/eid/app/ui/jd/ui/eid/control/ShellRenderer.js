(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ShellRenderer");

    /**
     * Renderer for the custom Shell. Method definitions are copied from the standard Shell's renderer (sap.ui.ux3.ShellRenderer from UI5 v 1.16.5),
     * with modifications in some methods.
     * 
     * @class Renderer for the custom control {@link jd.ui.eid.control.Shell}.
     * @extends sap.ui.ux3.ShellRenderer
     * @name jd.ui.eid.control.ShellRenderer
     * @static
     */
    jd.ui.eid.control.ShellRenderer = {};

    /**
     * Renders the control. Custom logic in this method, is the invocation of the _renderCustomHeader method. The rest of the code is the same as the
     * standard method.
     */
    jd.ui.eid.control.ShellRenderer.render = function(oRenderManager, oControl) {
        // convenience variable
        var rm = oRenderManager;
        var bPaneOpen = false;
        var iPaneWidthPlus = sap.ui.ux3.Shell._PANE_OUTER_DISTANCE; // width
        // of
        // pane
        // plus
        // how
        // far
        // it
        // is
        // from
        // the
        // edge
        var bRtl = sap.ui.getCore().getConfiguration().getRTL();
        var sId = oControl.getId();

        if (sap.ui.ux3.Shell.FIRST_RENDERING) {
            document.body.style.margin = "0"; // does not seem to work in initial
            // onBeforeRendering
        }

        // write the root HTML element TODO: this should use the existing <body>! But where is the
        // staticarea, then?
        rm.write("<div");
        rm.writeControlData(oControl);
        rm.addClass("jdUiEidShell");
        // rm.addClass("jdUiEidShellHead" + jd.ui.eid.control.Shell.ShellHeaderType.Standard);
        // rm.addClass("jdUiEidShellDesign" + oControl.getDesignType());

        rm.addClass("jdUiEidShellDesignLight");
        rm.addClass("jdUiEidShellNoTools");

        if (oControl._topSyncRefId && !oControl.getAllowOverlayHeaderAccess()) {
            rm.addClass("jdUiEidShellBlockHeaderAccess");
        }
        rm.writeClasses();
        rm.write(">");

        // write header
        rm.write("<img id='" + sId + "-hdrImg' class='jdUiEidShellHeaderImg' src='");
        rm.write(sap.ui.resource('sap.ui.core', 'themes/base/img/1x1.gif'));
        rm.write("' />");

        // <EDIT>
        // Render JD-specific header
        this._renderCustomHeader(oRenderManager, oControl);
        // </EDIT>

        // Proceed with standard Shell header
        rm.write("<header id='" + sId + "-hdr' class='jdUiEidShellHeader' role='banner'>");
        var tabIndex = oControl._topSyncRefId ? " tabindex='0'" : "";
        rm.write("<span class='jdUiEidShellFocusDummy' id='" + sId + "-focusDummyHdrStart'" + tabIndex + "></span>");
        jd.ui.eid.control.ShellRenderer.renderHeader(rm, oControl);
        rm.write("<span class='jdUiEidShellFocusDummy' id='" + sId + "-focusDummyHdrEnd'" + tabIndex + "></span>");
        rm.write("</header>   <!-- end of jdUiEidShellHeader -->");

        // write page background
        rm.write("<div id='", sId, "-bg' class='jdUiEidShellBg'></div>");
        rm.write("<img id='", sId, "-bgImg' class='jdUiEidShellBgImg' src='");
        rm.write(sap.ui.resource('sap.ui.core', 'themes/base/img/1x1.gif'));

        rm.write("'/>");

        // write workset items
        var wsMargin = bPaneOpen ? " style='margin-" + (bRtl ? "left" : "right") + ":" + (iPaneWidthPlus + 22) + "px'" : "";
        rm.write("<div id='", sId, "-wBar'" + wsMargin + " class='jdUiEidShellWorksetBar'>");
        jd.ui.eid.control.ShellRenderer.renderWorksetItems(rm, oControl);
        rm.write("</div>   <!--  end of worksetBar -->");

        // write tool palette area
        rm.write("<section id='" + sId + "-tp' class='jdUiEidShellToolPaletteArea' role='complementary'>");
        jd.ui.eid.control.ShellRenderer.renderToolPalette(rm, oControl);
        rm.write("</section> <!-- end of toolPaletteArea -->");

        // write page canvas and content

        var paneExtraStyle = bPaneOpen ? " style='" + (bRtl ? "left" : "right") + ":" + iPaneWidthPlus + "px'" : "";
        rm.write("<div class='jdUiEidShellCanvas'" + paneExtraStyle + " id='" + sId + "-canvas'>");

        jd.ui.eid.control.ShellRenderer.renderFacetBar(rm, oControl);

        rm.write("<article class='jdUiEidShellContent jdUiEidShellContentNoFacetBar' id='" + sId + "-content' role='main'>"); // Add additional CSS
        // class to adjust
        // scrolling
        var aContent = oControl.getContent();
        for ( var i = 0; i < aContent.length; i++) {
            rm.renderControl(aContent[i]);
        }
        rm.write("</article><div class='jdUiEidShellNotifySpace'></div></div>");

        // write pane bar
        var tabIndex = oControl._topSyncRefId ? " tabindex='0'" : "";
        rm.write("<span class='jdUiEidShellFocusDummy' id='" + sId + "-focusDummyPane'" + tabIndex + "></span>");
        rm.write("<aside id='" + sId + "-paneBar' class='jdUiEidShellPaneBar" + (bPaneOpen ? " jdUiEidShellPaneBarOpen" : "")
                + "' role='complementary' style='width:" + iPaneWidthPlus + "px;'>");
        rm.write("<section id='" + sId + "-paneContent' style='width:" + "px;' class='jdUiEidShellPaneBarContent' role='tabpanel'>");
        rm.write("</section>");

        rm.write("<div id='" + sId + "-paneBarRight' class='jdUiEidShellPaneBarRight'>");
        rm.write("<ul id='" + sId + "-paneBarEntries' class='jdUiEidShellPaneEntries' role='tablist'>");
        rm.write("</ul>");

        rm.write("</div>");

        // Render overflow button
        rm.write("<div id='" + sId + "-paneBarOverflowButton' class='jdUiEidShellPaneOverflowButton'");
        rm.addStyle("display", "none;"); // So it does not depend on theme being loaded
        rm.writeStyles();
        rm.write(">");
        rm.writeIcon(sap.ui.core.IconPool.getIconURI("slim-arrow-down"), [], {
            "id" : sId + "-paneBarOverflowButtonIcon",
            "tabindex" : "0"
        });
        rm.write("</div>");

        rm.write("</aside>   <!-- end of paneBar -->");

        // write the purely visual background
        rm.write("<div class='jdUiEidShellCanvasBackground "
                + (bPaneOpen ? "jdUiEidShellCanvasBackgroundOpen" : "jdUiEidShellCanvasBackgroundClosed") + "' id='" + sId + "-canvasBackground'"
                + paneExtraStyle + ">");
        rm.write("<div class='jdUiEidShellCanvasBackgroundRight'></div>");
        rm.write("</div>");

        rm.write("<div id='" + sId + "-notify' class='jdUiEidShellNotify'>");
        jd.ui.eid.control.ShellRenderer.renderNotificationArea(rm, oControl);
        rm.write("</div>");

        // render closing tag for root element
        rm.write("</div>");
    };

    /**
     * This method has been overridden to draw the green and yellow header strips (instead of the standard yellow + black strips)
     * 
     * @see sap.ui.ux3.ShellRenderer
     */
    jd.ui.eid.control.ShellRenderer.renderHeader = function(rm, oControl) {
        rm.write("<hr id='" + oControl.getId() + "-hdrGreenLine' class='jdUiEidShellYellowLine'/><hr id='" + oControl.getId()
                + "-hdrYellowLine' class='jdUiEidShellGreenLine'/>");
    };

    /**
     * This method is the same as the standard implementation, and hasn't been modified.
     * 
     * @see sap.ui.ux3.ShellRenderer
     */
    jd.ui.eid.control.ShellRenderer.renderToolPalette = function(rm, oControl) {
        var rb = sap.ui.getCore().getLibraryResourceBundle("sap.ui.ux3");
        var sId = oControl.getId();

        var tabIndex = oControl._topSyncRefId ? " tabindex='0'" : "";
        rm.write("<span class='jdUiEidShellFocusDummy' id='" + oControl.getId() + "-focusDummyTPStart'" + tabIndex + "></span>");

        // write standard tools
        var sAccDescr = rb.getText("SHELL_TOOLPANE_GENERIC"), bStandardToolPresent = false, bFirstTool = true, sStandardToolsHtml = "";

        if (bStandardToolPresent) {
            rm.write("<div role='toolbar'aria-describedby='" + sId + "-genericToolsDescr'>");
            rm.write("<span id='" + sId + "-genericToolsDescr' style='display:none;'>" + sAccDescr + "</span>");
            rm.write(sStandardToolsHtml + "</div>");
        }

        rm.write("<span class='jdUiEidShellFocusDummy' id='" + oControl.getId() + "-focusDummyTPEnd'" + tabIndex + "></span>");
    };

    /**
     * This method is the same as the standard implementation, and hasn't been modified.
     * 
     * @see sap.ui.ux3.ShellRenderer
     */
    jd.ui.eid.control.ShellRenderer.renderNotificationArea = function(rm, oControl) {
        rm.write("<div class='jdUiEidShellNotifyBG'></div>");
        if (oControl.getNotificationBar()) {
            rm.renderControl(oControl.getNotificationBar());
        }
    };

    /**
     * This method is the same as the standard implementation, and hasn't been modified.
     * 
     * @see sap.ui.ux3.ShellRenderer
     */
    jd.ui.eid.control.ShellRenderer.renderWorksetItems = function(rm, oControl) {
        var aItems = oControl.getWorksetItems();
        oControl._oWorksetBar.setAssociatedItems(aItems);
        if (!oControl._oWorksetBar.isSelectedItemValid() && (aItems.length > 0)) {
            oControl.setAssociation("selectedWorksetItem", aItems[0], true); // set the first
            // item as being
            // selected if there
            // is no item
            // selected
            oControl._oWorksetBar.setSelectedItem(aItems[0]); // set the first item as being
            // selected if there is no item
            // selected
        }
        if (rm) {
            rm.renderControl(oControl._oWorksetBar);
        }
    };

    /**
     * This method is the same as the standard implementation, and hasn't been modified.
     * 
     * @see sap.ui.ux3.ShellRenderer
     */
    jd.ui.eid.control.ShellRenderer.renderFacetBar = function(rm, oControl) {
        var aSubItems;
        var oSelectedWsi = sap.ui.getCore().byId(oControl.getSelectedWorksetItem()); // by now it
        // is
        // guaranteed
        // that the
        // association
        // is
        // properly
        // initialized
        if (oSelectedWsi) {
            // if parent is also a NavigationItem, the selected one is a second-level item and we
            // need to go up one level
            var parent = oSelectedWsi.getParent();
            if (parent && parent instanceof sap.ui.ux3.NavigationItem) {
                oSelectedWsi = parent;
            }

            aSubItems = oSelectedWsi.getSubItems();
            oControl._oFacetBar.setAssociatedItems(aSubItems);
            if (!oControl._oFacetBar.isSelectedItemValid() && (aSubItems.length > 0)) {
                oControl._oFacetBar.setSelectedItem(aSubItems[0]); // set the first item as being
                // selected if there is no item
                // selected
            }
        }

        if (rm) {
            rm.renderControl(oControl._oFacetBar);
        }
    };

    /**
     * Renders the custom header
     * 
     * @param {sap.ui.core.RenderManager}
     *            rm The render manager
     * @param {jd.ui.eid.control.Shell}
     *            oControl The current instance of the custom shell
     */
    jd.ui.eid.control.ShellRenderer._renderCustomHeader = function(rm, oControl) {
        // Adding '-hdrLine' DIV required for OverlayContainer
        rm.write("<div id='" + oControl.getId() + "-hdrLine' style='jdUiEidDummyHeaderLine'></div>");

        // Container for header
        rm.write("<div class='jdUiEidShellHeaderArea'>");

        // Container for header logo
        rm.write("<div class='jdUiEidShellHeaderLogo'>");
        rm.write("<img src='" + oControl.getAppIcon() + "'/>");
        rm.write("</div>"); // jdUiEidShellHeaderLogo

        // Container for header content (app name and header items)
        rm.write("<div class='jdUiEidShellHeaderContent'>");

        // Application name
        rm.write("<span class='jdUiEidShellHeaderContentAppName'>");
        rm.writeEscaped(oControl.getAppTitle());
        rm.write("</span>");

        // Header items
        var aHeaderItems = oControl.getHeaderItems();
        rm.write("<div class='jdUiEidShellHeaderItems'>");
        $.each(aHeaderItems, function(i, oItem) {
            rm.renderControl(oItem);
        });

        // Logoff button
        if (oControl.getShowLogoutButton()) {
            rm.write("<a id='" + oControl.getId() + "-logout' title='");
            rm.write(jQuery.sap.escapeHTML(oControl.getLogoutButtonTooltip()));
            rm.write("' tabindex='0' role='button' class='jdUiEidShellHeaderButton jdUiEidShellHeader-logout'></a>");
        }

        rm.write("</div>"); // jdUiEidShellHeaderItems
        rm.write("</div>"); // jdUiEidShellHeaderContent
        rm.write("</div>"); // jdUiEidShellHeaderWelcomeMessage
        rm.write("</div>"); // jdUiEidShellHeaderArea

    };

})();