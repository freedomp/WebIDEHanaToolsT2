(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CheckBoxFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");

    /**
     * The CheckBoxFilterItem provides a simple checkbox instead of the collapse icon and cannot be collapsed.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>checked : boolean (default: false) True if the checkbox is checked, false otherwise.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.CheckBoxFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.CheckBoxFilterItem",
    /** @lends jd.ui.eid.control.CheckBoxFilterItem */
    {
        metadata : {
            properties : {
                checked : {
                    type : "boolean",
                    defaultValue : false
                }
            },
            aggregations : {
                rightItem : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            }
        },

        /**
         * Initialize control and sets a custom style class.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);
            this.addStyleClass("jdUiEidCheckBoxFilterItem");
        },

        /* Internal Event Handler */

        /**
         * Toggles the checked property.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleChange : function(oEvent) {
            this.setChecked(!this.getChecked());
            this.fireValueChanged();
        },

        /* Custom Getter & Setter */

        /**
         * Set checked property and toggles the respective CSS class
         * 
         * @param {boolean}
         *            bChecked True if the check box should be checked, false otherwise.
         * @return {jd.ui.eid.control.CheckBoxFilterItem} this.
         */
        setChecked : function(bChecked) {
            this.setProperty('checked', bChecked);

            // Toggle css class
            if (bChecked) {
                this.addStyleClass("jdUiEidCheckBoxFilterItemChecked");
            } else {
                this.removeStyleClass("jdUiEidCheckBoxFilterItemChecked");
            }

            return this;
        },

        /* Internal Control Logic */

        /**
         * Sets the checked property to false.
         */
        _clear : function() {
            var bWasCheckedBefore = this.getChecked();
            this.setChecked(false);
            return bWasCheckedBefore !== false;
        },

        /* Rendering */

        /**
         * Attaches event handlers to DOM elements.
         */
        onAfterRendering : function() {
            // Attach event handler
            this.$().find('.jdUiEidCheckBoxFilterItemCheckBox').bind("click", $.proxy(this._handleChange, this));
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onBeforeRendering : function() {
            // Detach event handlers
            this.$().find('.jdUiEidCheckBoxFilterItemCheckBox').unbind("click", this._handleChange);
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onExit : function() {
            // Detach event handlers
            this.$().find('.jdUiEidCheckBoxFilterItemCheckBox').unbind("click", this._handleChange);
        },

        renderer : "jd.ui.eid.control.CheckBoxFilterItemRenderer"

    });

})();