(function() {
    "use strict";

    // Requires Base ServiceFacade
    jQuery.sap.declare("jd.ui.eid.service.EvidencePackageServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");
    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.common.formatter.EvidencePackageFormatter");

    /**
     * @class Service class for operations related to the Evidence Package list. Note : As 'User ID' is available in the session, it does not need to
     *        be passed explicitly by any of this class's methods.
     * 
     * @name jd.ui.eid.service.EvidencePackageServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     * 
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.EvidencePackageServiceFacade",
    /** @lends jd.ui.eid.service.EvidencePackageServiceFacade */
    {
        // Define array which stores the current pending requests which are triggered by the method getEvidencePackageDetails()
        _aPendingGetEvidencePackageDetailsRequests : [],

        /**
         * see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleListBindingChanged : function(oListBinding) {
            // This is invoked if the filtering/sorting on the UI table changes.
            // If the list binding is relevant, then get the updated evidence
            // package list
            // based on the new
            // filtering/sorting etc. This information is available inside
            // oListBinding.
            if (oListBinding.sPath == '/EvidencePackageList') {
                this.getEvidencePackageList(oListBinding);
            } else if (oListBinding.sPath == "/EvidencePackageDetails/PINPopulationList") {
                this.getEvidencePackagePINPopulationList(oListBinding);
            }
        },

        /**
         * see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleDataRequested : function(oListBinding) {
            // This is invoked when there is paging on the UI table
            // If the list binding is relevant, then get the updated evidence
            // package list
            // based on the
            // new
            // binding information (oListBinding)
            if (oListBinding.sPath == '/EvidencePackageList') {
                this.getEvidencePackageList(oListBinding);
            } else if (oListBinding.sPath == "/EvidencePackageDetails/PINPopulationList") {
                this.getEvidencePackagePINPopulationList(oListBinding);
            }
        },

        /**
         * Delete an evidence package
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {string}
         *            sEvidencePackageId the ID of the evidence package to be deleted
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful
         * @param {function}
         *            fnError callback that is executed when the service call results in an error
         * @public
         * 
         */
        deleteEvidencePackage : function(sEvidencePackageId, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/evidence/DeleteEvidencePackage.xsjs";

            // Prepare the custom payload
            var oArgs = {
                EvidencePackageID : sEvidencePackageId
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs);
        },

        /**
         * Set an evidence package's status to 'Closed'
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {string}
         *            sEvidencePackageId The ID of the evidence package for which the status is to be set to 'Closed'
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * @public
         */
        closeEvidencePackage : function(sEvidencePackageId, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/evidence/CloseEvidencePackage.xsjs";

            // Prepare the custom payload
            var oArgs = {
                EvidencePackageID : sEvidencePackageId
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs);
        },

        /**
         * Get the list of evidence packages
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control
         * @param {string}
         *            sSearchTerm the search string. If there is no search term, this can be an empty string or null
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getEvidencePackageList : function(oBinding, sSearchTerm, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/evidence/GetEvidencePackageList.xsjs";

            // Set test data file name
            var sModelDataFileName = "getEvidencePackageList.json";

            // Prepare the custom payload for this service call
            // If no search term was provided, this is an empty object. Otherwise,
            // the
            // search term
            // is an attribute of oArgs.
            var oArgs = {};
            if (sSearchTerm) {
                oArgs.SearchTerm = sSearchTerm;
            } else {
                oArgs.SearchTerm = "";
            }

            // Prepare the fnGetListData callback. It accepts an object (custom part
            // of
            // server's
            // response)
            // and returns the array of evidence packages within this object.
            var fnGetListData = function(oData) {
                return oData.Result.EvidencePackageList;
            };

            // Invoke _retrieveList
            this._retrieveList(sServicePath, fnSuccess, fnError, fnGetListData, oBinding, oArgs, sModelDataFileName);
        },

        /**
         * Stores a single evidence package to the database
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {string}
         *            sLastView the last view which is processed by the user
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        saveEvidencePackage : function(oEvidencePackageDetailsHeader, sLastView, fnSuccess, fnError) {
            // As we do not receive any response, a model file name is not required
            var sServicePath = "xs/evidence/SaveEvidencePackage.xsjs";
            var oData = {
                // map application model data to service request
                PackageName : oEvidencePackageDetailsHeader.PackageName,
                PackageID : oEvidencePackageDetailsHeader.PackageID,
                PackageDescription : oEvidencePackageDetailsHeader.PackageDescription,
                DTCCodeList : oEvidencePackageDetailsHeader.DTCCodeList,
                DTCFilterSelection : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCFilterState : oEvidencePackageDetailsHeader.DTCFilterState,
                DTACCaseList : oEvidencePackageDetailsHeader.DTACCaseList,
                WarrantyClaimList : oEvidencePackageDetailsHeader.WarrantyClaimList,
                MachineOptionCodes : oEvidencePackageDetailsHeader.MachineOptionCodes,
                // Store the current last view
                LastView : (sLastView == null) ? "" : sLastView
            };

            var that = this;
            var _fnSuccess = function(oData) {
                if (oData.Result.PackageId) {
                    that.oModel.setProperty("/EvidencePackageDetails/Header/PackageID", oData.Result.PackageId);
                } else {
                    $.sap.log.error("Evidence package saved successfully but service didn't return a generated evidence package id.");
                }

                // set values in the model which are retrieved by the backend only
                that.oModel.setProperty("/EvidencePackageDetails/Header/AnalystName", oData.Result.AnalystName);
                that.oModel.setProperty("/EvidencePackageDetails/Header/FactoryCode", oData.Result.FactoryCode);
                that.oModel.setProperty("/EvidencePackageDetails/Header/DepartmentNumber", oData.Result.DepartmentNumber);
                that.oModel.setProperty("/EvidencePackageDetails/Header/LastChangedDate", oData.Result.LastChangedDate);

                // Get Root DLM and reset it, so that the save warning message does not appear
                jd.ui.eid.common.DataLossManager.getRootInstance().reset();

                if (fnSuccess) {
                    fnSuccess(oData);
                }

            };
            // call _send of base service facade
            this._send(sServicePath, _fnSuccess, fnError, oData);
        },

        /**
         * <p>
         * Get Evidence Package Details. This service is needed to load a saved evidence package. The service returns JSON structure
         * AM-01-10_EvidencePackageDetailsHeader.
         * </p>
         * <p>
         * Once the evidence package details have been retrieved, the DTC filter domain values for the stored filter selection are retrieved, before
         * invoking the success callback. The correct filter domain values are required so that the read-only filters in the worksheet can be
         * displayed and for the DTAC case and warranty claim filters as domain values (e.g. engine hour ranges).
         * </p>
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {integer}
         *            iPackageID the ID of the Evidence Package
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getEvidencePackageDetails : function(iPackageID, fnSuccess, fnError) {
            var that = this;
            var sServicePath = "xs/evidence/GetEvidencePackageDetails.xsjs";
            var sModelPath = "/EvidencePackageDetails/Header";
            var oData = {
                PackageID : parseInt(iPackageID)
            };

            var fnGetData = function(oData) {
                return oData.Result;
            };

            // Prepare the fnSuccess callback. The callback first retrieves the DTC domain values for the stored DTC filters, then initializes the
            // filter selections and filter states
            var _fnSuccess = function(oData) {
                var oParentData = oData;
                var mEvidencePackageHeader = oData.Result;
                var sPlatform = mEvidencePackageHeader.DTCFilterSelection.PlatformAndProductLine[0].PlatformID;
                var sProductLine = mEvidencePackageHeader.DTCFilterSelection.PlatformAndProductLine[0].ProductLine[0];
                var aBufferedPlatforms = that.oModel.getProperty("/DTCFilters/DomainValues/Platforms");

                // Clear the array which stores the parallel backend requests (GetDependentFilters & GetEvidencePackagePINPopulation)
                that._aPendingGetEvidencePackageDetailsRequests = [];

                // Trigger service call to the domain value service
                var $getDependentFilters = that._retrieveRecord("xs/dtc/filters/GetDependentFilters.xsjs",
                        "/EvidencePackageDetails/_DTCFilters/DomainValues", {
                            PlatformID : sPlatform,
                            ProductLineID : sProductLine
                        }, function(oData) {
                            // Success callback
                            // If the entire thing was successful, we can continue and apply all the things to the model...

                            // Set the DTAC case filters, either to the ones form the last DTAC case or to default if no DTAC case is contained.
                            var aDTACCaseList = mEvidencePackageHeader.DTACCaseList;
                            var iLength = aDTACCaseList.length;
                            var iIndexOfLastDTACCase = 0;
                            if (iLength > 0) {
                                // Get the last DTAC Case that has been added to the Evidence Package
                                // Convert the JSON UTC date to the local timezone date
                                var dLastAddedOn = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(aDTACCaseList[iIndexOfLastDTACCase].AddedOn);
                                for ( var i = 1; i < iLength; i++) {
                                    var dCurrentAddedOn = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(aDTACCaseList[i].AddedOn);
                                    if (dLastAddedOn < dCurrentAddedOn) {
                                        iIndexOfLastDTACCase = i;
                                        dLastAddedOn = dCurrentAddedOn;
                                    }
                                }
                            }
                            that.oModel.setProperty("/DTACCaseFilters/FilterSelection", jQuery.extend(true, {}, (iLength > 0
                                    ? aDTACCaseList[iIndexOfLastDTACCase].DTACCaseFilterSelection
                                    : jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter.FilterSelection)));
                            that.oModel.setProperty("/DTACCaseFilters/FilterState", jQuery.extend(true, {}, (iLength > 0
                                    ? aDTACCaseList[iIndexOfLastDTACCase].DTACCaseFilterState
                                    : jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter.FilterState)));

                            // Set the Warranty claim filters
                            var aWarrantyClaimList = mEvidencePackageHeader.WarrantyClaimList;
                            var iLength = aWarrantyClaimList.length;
                            var iIndexOfLastWarrantyClaim = 0;
                            if (iLength > 0) {
                                // Get the last DTAC Case that has been added to the Evidence Package
                                // Convert the JSON UTC date to the local timezone date
                                var dLastAddedOn = jd.ui.eid.common.DateHelper
                                        .JSONDateToLocalDateTime(aWarrantyClaimList[iIndexOfLastWarrantyClaim].AddedOn);
                                for ( var i = 1; i < iLength; i++) {
                                    var dCurrentAddedOn = jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime(aWarrantyClaimList[i].AddedOn);
                                    if (dLastAddedOn < dCurrentAddedOn) {
                                        iIndexOfLastWarrantyClaim = i;
                                        dLastAddedOn = dCurrentAddedOn;
                                    }
                                }
                            }
                            that.oModel.setProperty("/WarrantyClaimFilters/FilterSelection", jQuery.extend(true, {}, (iLength > 0
                                    ? aWarrantyClaimList[iIndexOfLastWarrantyClaim].WarrantyClaimFilterSelection
                                    : jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter.FilterSelection)));
                            that.oModel.setProperty("/WarrantyClaimFilters/FilterState", jQuery.extend(true, {}, (iLength > 0
                                    ? aWarrantyClaimList[iIndexOfLastWarrantyClaim].WarrantyClaimFilterState
                                    : jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter.FilterState)));
                        }, fnError, function(oData) {
                            // GetData callback
                            oData.Result.Platforms = aBufferedPlatforms;
                            jd.ui.eid.model.EidModel.TransformationHelper.moveEmptyDTCDomainValuesToEnd(oData.Result);
                            // First, we do something special about the manual pin list. As both the domain values and the selection come from the
                            // user, let's add the selection also as domain values.
                            oData.Result.ManualPINListItems = mEvidencePackageHeader.DTCFilterSelection.ManualPinList;
                            return oData.Result;
                        }, "getDependentFilters_Response.json");

                // Store this request for later usage
                that._aPendingGetEvidencePackageDetailsRequests.push($getDependentFilters);

                // Trigger service call to get the new PINPopulation
                // Therefore we are calling getEvidencePackageAnalysisData
                var oEvidencePackageHeader = that.oModel.getProperty("/EvidencePackageDetails/Header");
                var $getEvidencePackagePINPopulation = that.getEvidencePackagePINPopulation(oEvidencePackageHeader,
                        "/EvidencePackageDetails/_DTCFilters/PINPopulation", null, that._onRequestFailed);

                // Store this request for later usage
                that._aPendingGetEvidencePackageDetailsRequests.push($getEvidencePackagePINPopulation);

                // Once both requests have completed successfully call the passed success function
                $.when($getEvidencePackagePINPopulation, $getDependentFilters).done(function() {
                    // Clear the array which stores the parallel backend requests (GetDependentFilters & GetEvidencePackagePINPopulation)
                    that._aPendingGetEvidencePackageDetailsRequests = [];

                    // call nested function
                    if (fnSuccess) {
                        fnSuccess(oParentData);
                    }
                });
            };

            var sModelFileName = "GetEvidencePackageDetails_Response.json";

            this._retrieveRecord(sServicePath, sModelPath, oData, _fnSuccess, fnError, fnGetData, sModelFileName, false);
        },

        /**
         * Abort pending requests of getEvidencePackageDetails
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @public
         */
        abortPendingGetEvidencePackageDetailsRequests : function() {
            $.each(this._aPendingGetEvidencePackageDetailsRequests, function(iIndex, oRequest) {
                oRequest.abort();
            });
        },

        /**
         * Get Evidence Package Analysis Data. This service is required whenever the user deletes a basket item in the review evidence package screen
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getEvidencePackageAnalysisData : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            var that = this;
            var sServicePath = "xs/evidence/GetEvidencePackageAnalysisData.xsjs";
            var sModelPath = "/EvidencePackageDetails/AnalysisData";
            var oData = {
                PackageID : oEvidencePackageDetailsHeader.PackageID,
                DTCFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCIDList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
                DTACCaseList : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
                WarrantyClaimList : this.convertWarrantyClaimListToNumberList(oEvidencePackageDetailsHeader.WarrantyClaimList)
            };

            if (oData.PackageID == "") {
                oData.PackageID = -1; // back end can not deal with empty property, so we take a -1 as integer is expexted
            }

            var fnGetData = function(oData) {
                that.oModel.setProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation", oData.Result.AnalysisData.PINPopulation);
                return oData.Result.AnalysisData;
            };

            var sModelFileName = "getEvidencePackageAnalysisData_Response.json";

            return this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName, false);
        },

        /**
         * Get Evidence Package PINPopulation returns the amount of pin for a specific evidence package
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getEvidencePackagePINPopulation : function(oEvidencePackageDetailsHeader, sPINPopulationModelPath, fnSuccess, fnError) {
            var that = this;
            var sServicePath = "xs/evidence/GetEvidencePackagePINPopulation.xsjs";
            var oData = {
                DTCFilter : oEvidencePackageDetailsHeader.DTCFilterSelection
            };

            var fnGetData = function(oData) {
                that.oModel.setProperty(sPINPopulationModelPath, oData.Result.PINPopulation);
                return "";
            };

            var sModelFileName = "getEvidencePackageAnalysisData_Response.json";

            return this._retrieveRecord(sServicePath, "", oData, fnSuccess, fnError, fnGetData, sModelFileName, false);
        },

        /**
         * Get Evidence Package Summary
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getEvidencePackageSummary : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {

            // initialize the formatter count map
            jd.ui.eid.common.formatter.EvidencePackageFormatter.resetRunningSumCount();

            var sServicePath = "xs/evidence/GetEvidencePackageSummary.xsjs";
            var sModelPath = "/EvidencePackageDetails/Summary";
            var oData = {
                PackageID : oEvidencePackageDetailsHeader.PackageID,
                DTCFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCIDList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
                DTACCaseList : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
                WarrantyClaimList : this.convertWarrantyClaimListToNumberList(oEvidencePackageDetailsHeader.WarrantyClaimList)
            };

            if (oData.PackageID == "") {
                oData.PackageID = -1; // back end can not deal with empty property, so we take a -1 as integer is expexted
            }

            var fnGetData = function(oData) {
                return oData.Result.Summary;
            };

            var that = this;
            // we define an own success function to update the path /EvidencePackageDetails/AnalysisData
            var _fnSuccess = function(oData) {
                var oAnalysisData = oData.Result.AnalysisData;
                that.oModel.setProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation", oData.Result.AnalysisData.PINPopulation);
                that.oModel.setProperty("/EvidencePackageDetails/AnalysisData", oAnalysisData);

                if (fnSuccess) {
                    fnSuccess(oData);
                };
            };

            var sModelFileName = "getEvidencePackageSummary_Response.json";

            this._retrieveRecord(sServicePath, sModelPath, oData, _fnSuccess, fnError, fnGetData, sModelFileName, false);
        },

        /**
         * Get chart data and DTC master data for an array of DTCs Ids
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getDTCDetailsList : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {

            var sServicePath = "xs/dtc/DTC_Details.xsjs";
            var sModelPath = "/EvidencePackageDetails/DTCDetailsList";
            var oModel = sap.ui.getCore().getModel();
            var oData = {
                CustomFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCCodeList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
            };
            var fnGetData = function(oData) {
                if (oModel.getProperty("/EvidencePackageDetails/DTCDetailsList")) {
                    return $.extend(true, [], oModel.getProperty("/EvidencePackageDetails/DTCDetailsList"), oData.Result.DTCDetails);
                } else {
                    return oData.Result.DTCDetails;
                }
            };

            var sModelFileName = "getDTCDetailsList_Response.json";

            return this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName, false);

        },

        /**
         * Get details about an array of DTAC Cases
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getDTACCaseDetailsList : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {

            var sServicePath = "/xs/dtac/GetDTACCaseDetails.xsjs";
            var sModelPath = "/EvidencePackageDetails/DTACCaseDetailsList";
            var oData = {
                DTACCaseNumbers : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
            };
            var fnGetData = function(oData) {
                return oData.Result.DTACCaseDetails.Records;
            };

            var sModelFileName = "getDTACCaseDetailsList_Response.json";

            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName, false);
        },

        /**
         * Retrieve further details about an array of warranty claims
         * 
         * @memberOf jd.ui.eid.service.WarrantyClaimServiceFacade
         * 
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getWarrantyClaimDetailsList : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            var sServicePath = "/xs/warranty/GetWarrantyClaimDetails.xsjs";
            var sModelPath = "/EvidencePackageDetails/WarrantyClaimDetailsList";
            var oData = {
                WarrantyClaimList : this.convertWarrantyClaimListToMapList(oEvidencePackageDetailsHeader.WarrantyClaimList),
                DTCIDList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList)
            };

            var fnGetData = function(oData) {
                return oData.Result.WarrantyClaimDetails.Records;
            };

            var sModelFileName = "getWarrantyClaimDetailsList_Response.json";

            // Invoke record retrieval
            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName);
        },

        /**
         * Get PIN Population list for Evidence Package
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control
         * @param {string}
         *            sSearchTerm the search string. If there is no search term, this can be an empty string or null
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getEvidencePackagePINPopulationList : function(oBinding, sSearchTerm, oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/evidence/GetEvidencePackagePopulation.xsjs";

            // Set test data file name
            var sModelDataFileName = "getEvidencePackagePINPopulationList.json";

            // Prepare the custom payload for this service call. If there's no header available, this method was called from
            // _handleDataRequested or _handleListBindingChanged.
            var oArgs = null;
            if (oEvidencePackageDetailsHeader) {
                oArgs = {
                    PackageID : oEvidencePackageDetailsHeader.PackageID,
                    DTCFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                    DTCIDList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
                    DTACCaseList : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
                    WarrantyClaimList : this.convertWarrantyClaimListToNumberList(oEvidencePackageDetailsHeader.WarrantyClaimList)
                };

                if (sSearchTerm) {
                    oArgs.SearchTerm = sSearchTerm;
                } else {
                    oArgs.SearchTerm = "";
                }
            }

            // Prepare the fnGetListData callback. It accepts an object (custom part
            // of server's response) and returns the array of PIN Population Records within this object.
            // The path '/EvidencePackageDetails/PINPopulationList' will be updated via the binding object
            var fnGetListData = function(oData) {
                return oData.Result.PINPopulation;
            };

            // Invoke _retrieveList
            this._retrieveList(sServicePath, fnSuccess, fnError, fnGetListData, oBinding, oArgs, sModelDataFileName);
        },

        /**
         * Gets the PIN Population list for an evidence package and updates the /EvidencePackageDetails/PINPopulationList path. It is different from
         * "getEvidencePackagePINPopulationList", as it does not require a reference to a binding. Used for getting the ManualPINList from the Print
         * application, where there is no UI5 table (and thus, no binding) available.
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {object}
         *            oEvidencePackageDetailsHeader for required JSON structure see AM-01-10_EvidencePackageDetailsHeader
         * @param {function}
         *            fnSuccess success callback
         * @param {function}
         *            fnError error callback
         */
        getEvidencePackagePINPopulationListAsRecord : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/evidence/GetEvidencePackagePopulation.xsjs";

            // Set test data file name
            var sModelFileName = "getEvidencePackagePINPopulationList.json";

            // Set the model path
            var sModelPath = "/EvidencePackageDetails/PINPopulationList";

            // Prepare the custom payload for this service call
            var oArgs = {
                SearchTerm : "",
                PackageID : oEvidencePackageDetailsHeader.PackageID,
                DTCFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCIDList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
                DTACCaseList : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
                WarrantyClaimList : this.convertWarrantyClaimListToNumberList(oEvidencePackageDetailsHeader.WarrantyClaimList)
            };

            // Callback (required by _retrieveRecord) that returns the part of the response that represents the PIN Population
            var fnAjaxSuccess = function(oData) {
                sap.ui.getCore().getModel().setProperty(sModelPath, oData.Result.PINPopulation.Records);
                if (fnSuccess) {
                    fnSuccess();
                }
            };

            // Trigger the request. The backend service expects filters, sorters etc. So we use _executeAjax and pass the entire
            // response object here (instead of the typical behaviour, where filters, sorters etc. are calculated from the binding)
            var oPayload = {
                Filters : [],
                Sorters : [],
                Data : oArgs
            };
            this._executeAjax(sServicePath, fnAjaxSuccess, fnError, oPayload, sModelFileName);
        },

        /**
         * Triggers a batch operation in the backend for fetching the KPI trends for all DTCs included in the evidence package whose header is passed
         * as a parameter
         * 
         * @param {Object}
         *            oEvidencePackageDetailsHeader Object representing the evidence package header
         * @param {Function}
         *            fnSuccess The success callback function.
         * @param {Function}
         *            fnError The error callback function.
         */
        getKPIsForDTCList : function(oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            var sServicePath = "xs/dtc/GetDTCKPIs.xsjs";
            var sModelFileName = "getDTCKPIs_Response_Single.json";
            var aDTCIDList = this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList);
            var oModel = sap.ui.getCore().getModel();
            var oArgs = {
                CustomFilter : oEvidencePackageDetailsHeader.DTCFilterSelection,
                DTCIDList : aDTCIDList
            };

            // Map the server response to the correct nodes, based on whichever DTCs we have received KPI details.
            var fnAjaxSuccess = function(oData) {
                // Check if /EvidencePackageDetails/DTCDetailsList exists. If not, this means that DTC Details has not yet been
                // fetched from the backend.
                if (!oModel.getProperty("/EvidencePackageDetails/DTCDetailsList")) {
                    oModel.setProperty("/EvidencePackageDetails/DTCDetailsList", []);
                }

                // Get KPI info for each DTC and put it in the right place in the model. Should be mapped to a 'KPIs' subnode within
                // the matching /EvidencePackageDetails/DTCDetailsList/[x]
                var mDTCMap = oData.Result.DTCMap;
                var aDTCCodeList = oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList");
                $.each(aDTCCodeList, function(i, oDTC) {
                    var sDTCID = oDTC.DTCID;
                    if (mDTCMap[sDTCID]) {
                        if (!oModel.getProperty("/EvidencePackageDetails/DTCDetailsList/" + i)) {
                            oModel.setProperty("/EvidencePackageDetails/DTCDetailsList/" + i, {
                                DTCMasterData : {
                                    KPIs : []
                                }
                            });
                        }

                        // Map over KPIs and AffectedPINs to DTCDetailsList/{1..n}/DTCMasterData
                        oModel.setProperty("/EvidencePackageDetails/DTCDetailsList/" + i + "/DTCMasterData/KPIs", mDTCMap[sDTCID].KPIs);
                        oModel.setProperty("/EvidencePackageDetails/DTCDetailsList/" + i + "/DTCMasterData/AffectedPINs",
                                mDTCMap[sDTCID].AffectedPINs);
                    }
                });

                if (fnSuccess) {
                    fnSuccess();
                }
            };

            // Trigger the backend request.
            var oPayload = {
                Filters : [],
                Sorters : [],
                Data : oArgs
            };
            return this._executeAjax(sServicePath, fnAjaxSuccess, fnError, oPayload, sModelFileName);
        },

        /**
         * Converts DTC Code List into a smaller array for back end service call
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {array}
         *            aDTCCodeList for required JSON structure see AM-01-10-01_DTCCodeList
         * @returns {array} aDTCIDList array of DTCID integer values
         * 
         * @public
         */
        convertDTCCodeList : function(aDTCCodeList) {
            var aArray = [];
            if (aDTCCodeList) {
                for ( var i = 0; i < aDTCCodeList.length; i++) {
                    aArray.push(aDTCCodeList[i].DTCID);
                }
            }
            return aArray;
        },

        /**
         * Converts DTAC Case List into a smaller array for back end service call
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {array}
         *            aDTACCaseList for required JSON structure see AM-01-10-02_DTACCaseList
         * @returns {array} array of plain DTAC Case numbers
         * 
         * @public
         */
        convertDTACCaseList : function(aDTACCaseList) {
            var aArray = [];
            if (aDTACCaseList) {
                for ( var i = 0; i < aDTACCaseList.length; i++) {
                    aArray.push(aDTACCaseList[i].DTACCaseNumber);
                }
            }
            return aArray;
        },

        /**
         * Converts an Warranty Claim object array into an array of map objects.
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {array}
         *            aWarrantyClaimListBig for required JSON structure see AM-01-10-03_WarrantyClaimList
         * @returns {array} array of key/value pairs containing WarrantyClaimSequenceNumber and JDLinkActive
         * @public
         */
        convertWarrantyClaimListToMapList : function(aWarrantyClaimList) {
            var aArray = [];
            if (aWarrantyClaimList) {
                for ( var i = 0; i < aWarrantyClaimList.length; i++) {
                    // For the mass interface we don't need the Vulcano chart, therefore JDLinkActive is set to false for all Warranty
                    // Claims.
                    aArray.push({
                        WarrantyClaimSequenceNumber : aWarrantyClaimList[i].WarrantyClaimSequenceNumber,
                        JDLinkActive : false
                    });
                }

            }
            return aArray;
        },

        /**
         * Converts an Warranty Claim object array into an array of Warranty Claim Sequence Numbers
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {array}
         *            aWarrantyClaimList for required JSON structure see AM-01-10-03_WarrantyClaimList
         * @returns {array} array of plain warranty claim sequence numbers
         * @public
         */
        convertWarrantyClaimListToNumberList : function(aWarrantyClaimList) {
            var aArray = [];
            if (aWarrantyClaimList) {
                for ( var i = 0; i < aWarrantyClaimList.length; i++) {
                    aArray.push(aWarrantyClaimList[i].WarrantyClaimSequenceNumber);
                }

            }
            return aArray;
        },

        /**
         * Simulates changed DTC Filters for a single Evidence Package and updates it in '/SimulatedEvidencePackageDetails' (AM-01-16) of the
         * application model including new PIN Population
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {object}
         *            oNewDTCFilterSelection for required JSON structure see AM-01-15-02_FilterSelection
         * @param {object}
         *            oNewDTCFilterState for required JSON structure see AM-01-15-03_FilterState
         * @param {object}
         *            oEvidencePackageDetailsHeader current selected Evidence Package. For required JSON structure see AM-01-10_EvidencePackageDetails
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * @public
         */
        simulateNewDTCFilters : function(oNewDTCFilterSelection, oNewDTCFilterState, oEvidencePackageDetailsHeader, fnSuccess, fnError) {
            var sServicePath = "xs/evidence/EvidencePackageApplyFilter.xsjs";

            var sModelFileName = "ApplyDTCFilter_Response.json";
            // Build Payload for Backend request
            var oPayload = {
                Data : {
                    CustomFilter : oNewDTCFilterSelection,
                    DTCCodeList : this.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList),
                    DTACCaseList : this.convertDTACCaseList(oEvidencePackageDetailsHeader.DTACCaseList),
                    WarrantyClaimList : this.convertWarrantyClaimListToNumberList(oEvidencePackageDetailsHeader.WarrantyClaimList)
                }
            };

            // own success method to update different application model paths by the
            // given result
            var that = this;
            var _fnSuccess = function(oData) {
                // get current evidence package for simulation update
                var oModel = that.oModel;
                var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
                // we clone the current evidence package to the simulated version to get the header
                // afterwards we overwrite everything which is new
                var oSimulatedEvidencePackageDetailsHeader = $.extend(true, {}, oEvidencePackageDetailsHeader);

                // set new filter settings and filter state into simulated evidence
                // package
                oSimulatedEvidencePackageDetailsHeader.DTCFilterSelection = oNewDTCFilterSelection;
                oSimulatedEvidencePackageDetailsHeader.DTCFilterState = oNewDTCFilterState;

                // We prepare the root object for the path
                // '/SimulatedEvidencePackageDetails'
                var oRootForSimulatedEvidencePackageDetails = {
                    Header : oSimulatedEvidencePackageDetailsHeader,
                    RemovedDTCCodeList : [],
                    RemovedDTACCaseList : [],
                    RemovedWarrantyClaimList : [],
                    _DTCFilters : {
                        DomainValues : oModel.getProperty("/SimulatedEvidencePackageDetails/_DTCFilters/DomainValues"),
                        PINPopulation : oData.Result.PINPopulation.valueOf()
                    }
                };

                // check if DTCs, DTAC Cases and Warranty Claims have to be removed from evidence package after filter values have changed
                // Therefore we pass the current evidence package details (containing DTCs, DTAC Cases and Warranty Claims)
                // and the response from the server containing the DTCs, DTAC Cases and Warranty Claim of the
                // Evidence Package after the new filters have been applied to the _processItemRemovalOfSimulatedEvidencePackageDetailsfunction.
                that._processItemRemovalOfSimulatedEvidencePackageDetails(oRootForSimulatedEvidencePackageDetails.Header.DTCCodeList,
                        oData.Result.DTCCodeList, "DTCID", oRootForSimulatedEvidencePackageDetails.RemovedDTCCodeList);
                that._removeMachineOptionCodes(oRootForSimulatedEvidencePackageDetails.Header.MachineOptionCodes,
                        oRootForSimulatedEvidencePackageDetails.RemovedDTCCodeList); // remove machine option codes of removed DTCs

                that._processItemRemovalOfSimulatedEvidencePackageDetails(oRootForSimulatedEvidencePackageDetails.Header.DTACCaseList,
                        oData.Result.DTACCaseList, "DTACCaseNumber", oRootForSimulatedEvidencePackageDetails.RemovedDTACCaseList);

                that._processItemRemovalOfSimulatedEvidencePackageDetails(oRootForSimulatedEvidencePackageDetails.Header.WarrantyClaimList,
                        oData.Result.WarrantyClaimList, "WarrantyClaimSequenceNumber",
                        oRootForSimulatedEvidencePackageDetails.RemovedWarrantyClaimList);

                // Finally update the simulated evidence package in the path
                oModel.setProperty("/SimulatedEvidencePackageDetails", oRootForSimulatedEvidencePackageDetails);

                // call fnSuccess function from caller
                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };
            this._executeAjax(sServicePath, _fnSuccess, fnError, oPayload, sModelFileName);
        },

        /**
         * Calculate machine option codes for a given DTC
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {array}
         *            aSelectedDTCList Array of DTCIDs for which the machine options should be calculated
         * @param {object}
         *            oCustomFilter for required JSON structure see AM-01-15-02_FilterSelection
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * @public
         */
        calculateMachineOptionCodesForDTC : function(aSelectedDTCList, oCustomFilter, fnSuccess, fnError) {

            var sServicePath = "xs/dtc/CalculateMachOptionCodesDTC.xsjs";
            var sModelFileName = "CalculateMachineOptionCodesForDTC_Response.json";
            var oPayload = {
                Data : {
                    DTCList : aSelectedDTCList,
                    CustomFilter : oCustomFilter
                }
            };

            var that = this;
            // define own success function to update the path for the given DTC
            var _fnSuccess = function(oData) {
                // get current evidence package for simulation update
                var oModel = that.oModel;
                var oEvidencePackageDetail = oModel.getProperty("/EvidencePackageDetails/Header");

                for ( var j = 0; j < oData.Result.MachineOptionCodes.length; j++) {

                    for ( var i = 0; i < oEvidencePackageDetail.MachineOptionCodes.length; i++) {

                        // We pick the right DTC to update the machine codes
                        if (oEvidencePackageDetail.MachineOptionCodes[i].DTCID == oData.Result.MachineOptionCodes[j].DTCID) {
                            oEvidencePackageDetail.MachineOptionCodes[i].MachineOption = oData.Result.MachineOptionCodes[j].MachineOption;

                            oModel
                                    .setProperty("/EvidencePackageDetails/Header/MachineOptionCodes/" + i,
                                            oEvidencePackageDetail.MachineOptionCodes[i]);
                        }
                    }

                }
                // notify service request administration
                that.MachineOptionCalculation.endServiceWithSuccessfull(oPayload.Data.DTCList);

                // call fnSuccess function from caller
                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };

            // Build own failed method
            var _fnError = function(XMLHttpRequest, textStatus, errorThrown) {
                that.MachineOptionCalculation.endServiceWithFailed(oPayload.Data.DTCList);
            };

            var oAjax = this._executeAjax(sServicePath, _fnSuccess, _fnError, oPayload, sModelFileName, true);
            // notice status administration
            this.MachineOptionCalculation.startService(aSelectedDTCList, oAjax);
        },

        /**
         * Initialize Evidence Package Details path
         * 
         * @returns {object} oEvidencePackageDetails the JSON object of model path '/EvidencePackageDetails/Header'
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @public
         */
        initializeEvidencePackageDetails : function() {

            var oEvidencePackageDetails = this.oModel.getProperty("/EvidencePackageDetails/Header");

            oEvidencePackageDetails.PackageName = "";
            oEvidencePackageDetails.PackageID = 0;
            oEvidencePackageDetails.PackageDescription = "";
            oEvidencePackageDetails.AnalystName = "";
            oEvidencePackageDetails.FactoryCode = "";
            oEvidencePackageDetails.DepartmentNumber = null;
            oEvidencePackageDetails.LastChangedDate = "";
            oEvidencePackageDetails.PackageStatusID = jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Open;
            oEvidencePackageDetails.PackageOwnedByCurrentUser = 1; // New Package is always owned by current user
            oEvidencePackageDetails.DTCCodeList = [];
            oEvidencePackageDetails.DTCFilterSelection = jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterSelection);
            oEvidencePackageDetails.DTCFilterState = jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterState);
            oEvidencePackageDetails.DTACCaseList = [];
            oEvidencePackageDetails.WarrantyClaimList = [];
            oEvidencePackageDetails.LastView = "";
            oEvidencePackageDetails.MachineOptionCodes = [];

            this.oModel.setProperty("/EvidencePackageDetails/Header", oEvidencePackageDetails);
            return oEvidencePackageDetails;
        },

        /**
         * Remove machine option codes from evidence package for a given DTC list
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @param {object}
         *            aMachinesOptionCodes array of machine option codes. For required JSON structure see
         *            AM-01-10_EvidencePackageDetails-MachineOptionCodes.
         * @param {array}
         *            aRemovedDTCList the removed DTC list for which the machine options should be removed
         * @public
         */
        _removeMachineOptionCodes : function(aMachinesOptionCodes, aRemovedDTCList) {
            $.each(aRemovedDTCList, function(iDTCIDIndex, iDTCID) {
                $.each(aMachinesOptionCodes, function(iMachineOptionIndex, oMachineOptionCode) {
                    if (oMachineOptionCode.DTCID == iDTCID) {
                        // remove machine option codes of removed DTC
                        aMachinesOptionCodes.splice(iMachineOptionIndex, 1);
                        return false;
                    };
                });
            });
        },

        /**
         * Remove Evidence Package items (i.e. DTC, DTAC Cases, Warranty Claims) from Simulated Evidence Package Details which are obsolete. This
         * function checks the current Evidence Package items agains those items that are part of the Evidence Package after the simulation. All items
         * will be removed from the current list which are still in the current list but not any more in the new list. The removed items will be added
         * to the removed items list which will be handed over while calling the function.
         * 
         * @param {array}
         *            aCurrentList the current list of Evidence Package items, which are available in the Evidence Package. This list contains of
         *            objects with a key property which identifies the objects.
         * @param {array}
         *            aNewList the new list of Evidence Package items which are available in the Evidence Package after the simulation. This array
         *            just contains the key properties of the Evidence Package items.
         * @param {string}
         *            sKeyName the name of the key property in the aCurrentList array, which will be used to check the item's identity.
         * @param {array}
         *            aRemovedItemsList is a reference to the array which should contain the list of removed items. This list contains of objects from
         *            aCurrentList.
         * 
         * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade
         * @private
         */
        _processItemRemovalOfSimulatedEvidencePackageDetails : function(aCurrentList, aNewList, sKeyName, aRemovedItemsList) {
            for ( var i = 0; i < aCurrentList.length; i++) {
                var bRemoveItem = true;
                for ( var j = 0; j < aNewList.length; j++) {
                    if (aCurrentList[i][sKeyName] == aNewList[j]) {
                        // Item is still valid after filter changes have been applied
                        bRemoveItem = false;
                        break;
                    };
                }
                if (bRemoveItem) {
                    // add item to the removed list
                    aRemovedItemsList.push(aCurrentList[i]);
                };
            }
            // now remove the items from the Simulated Evidence Package
            for ( var k = 0; k < aRemovedItemsList.length; k++) {

                for ( var l = 0; l < aCurrentList.length; l++) {

                    if (aRemovedItemsList[k][sKeyName] == aCurrentList[l][sKeyName]) {
                        // remove item from evidence package
                        aCurrentList.splice(l, 1);
                        break;
                    }
                }
            }
        },

        /**
         * @namespace Machine Option Calculation Administration
         *            <p>
         *            Machine Option Codes calculation requests are triggerred and received without user notice. The following use cases lead to a
         *            machine option calculation request: - When a new DTC is added to the evidence package - When the filter in the evidence package
         *            is changed - When the user requests a recalculation of one or more DTCs at the evidence package summary view - When the user
         *            opens an evidence package in which machine option codes are not calculated yet
         *            </p>
         *            <p>
         *            Machine Option Code calculation requests are stopped if: - the user has closed the evidence package worksheet view and (if open)
         *            the evidence package summary view
         *            </p>
         *            <p>
         *            The object <code>jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation</code> traces the status of all
         *            triggered service requests for machine option calculation. This is needed to display the current service request status if the
         *            user is navigating to tab 'machine option codes' of the evidence package summary
         *            </p>
         * 
         * @name jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
         * @public
         */
        MachineOptionCalculation : /** @lends jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation */
        {

            // This attribute stores the current status of triggered machine option code services
            // the array contains the following object
            // DTCID : integer,
            // Status : value from jd.ui.eid.model.EidModel.Enum.MachineOptionCode
            // Ajax : the Ajax request for the DTCs
            _status : [],

            /**
             * setting a specific flag which will be saved in the evidence package. This flag remindes the application that the machine options for
             * this new added DTC are not yet calculated
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {object}
             *            mDTC the DTC to add to the new evidence package.
             * @param {int}
             *            mDTC.DTCID the DTC ID.
             * @param {string}
             *            mDTC.DTCCode the DTC code
             * @returns {object} an object of JSON structure AM-01-10-04
             * @public
             */
            getCalculationNotYetStarted : function(mDTC) {
                var oMachineOptionArrayItem = {
                    DTCID : mDTC.DTCID,
                    DTCCode : mDTC.DTCCode,
                    MachineOption : [{
                        MachineOptionCode : "-1",
                        Support : -1,
                        Confidence : -1,
                        Lift : -1,
                        OptionTakeRate : -1,
                        Description : "-1"
                    }]
                };
                return oMachineOptionArrayItem;
            },

            /**
             * returns a true, if the machine option calculation for a DTC has not yet started
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {object}
             *            mMachineOption the machine option code to add to the new evidence package.
             * @param {string}
             *            mMachineOption.MachineOptionCode the Machine Option Code
             * @param {float}
             *            mMachineOption.Support the support of Machine Option Code
             * @param {float}
             *            mMachineOption.Confidence the confidence of Machine Option Code
             * @param {float}
             *            mMachineOption.Lift the lift of Machine Option Code
             * @returns {boolean} true, if calculation has not yet started
             * @public
             */
            hasCalculationNotYetStarted : function(mMachineOption) {

                if (mMachineOption) {

                    if (mMachineOption.MachineOptionCode == "-1" && mMachineOption.Support == -1 && mMachineOption.Confidence == -1
                            && mMachineOption.Lift == -1) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            },

            /**
             * returns the service request status (inclusive ajax objects) for a given DTCID
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {integer}
             *            iDTCID the DTCID
             * @returns {object} returns the _status object with _status.DTCID, _status.Status, status.Ajax
             * @public
             */
            getStatusForDTC : function(iDTCID) {

                for ( var i = 0; i < this._status.length; i++) {
                    if (this._status[i].DTCID == iDTCID) {
                        return this._status[i];
                    }
                }
            },

            /**
             * Sets the status for all DTCs with pending calculated machine option codes requests and fires event. If a service request for a DTC is
             * already pending it will be aborted
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {array}
             *            aDTCIDList Array of DTCIDs
             * @param {$.ajax}
             *            oAjax the JQuery Ajax object
             * @public
             */
            startService : function(aDTCIDList, oAjax) {
                // check if one DTC is already listed
                for ( var i = 0; i < aDTCIDList.length; i++) {

                    var oDTC = this.getStatusForDTC(aDTCIDList[i]);

                    if (oDTC) {
                        // check if Status is pending
                        if (oDTC.Status == jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationPending) {
                            // Status to same DTC is pending, so we abort the previous one
                            oDTC.Ajax.abort();
                        }
                        // update status and ajax of DTC
                        oDTC.Status = jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationPending;
                        oDTC.Ajax = oAjax;
                    } else {
                        // not yet in the list
                        this._status.push({
                            DTCID : aDTCIDList[i],
                            Status : jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationPending,
                            Ajax : oAjax
                        });
                    };
                };
                // fire event
                sap.ui.getCore().getEventBus().publish('MachineOptionService', 'servicePending');
            },

            /**
             * Sets the status "Failed" for all DTCs with failed calculated machine option service requests and fires event
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {array}
             *            aDTCIDList Array of DTCIDs
             * @public
             */
            endServiceWithFailed : function(aDTCIDList) {

                for ( var i = 0; i < aDTCIDList.length; i++) {

                    var oDTC = this.getStatusForDTC(aDTCIDList[i]);

                    if (oDTC) {
                        oDTC.Status = jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationFailed;
                    }
                };

                sap.ui.getCore().getEventBus().publish('MachineOptionService', 'serviceFailed');
            },
            /**
             * Sets the status for all DTCs with failed calculated machine option codes and fires event
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * 
             * @param {array}
             *            aDTCIDList Array of DTCIDs
             * @public
             */
            endServiceWithSuccessfull : function(aDTCIDList) {

                for ( var i = 0; i < aDTCIDList.length; i++) {

                    var oDTC = this.getStatusForDTC(aDTCIDList[i]);

                    if (oDTC) {
                        oDTC.Status = jd.ui.eid.model.EidModel.Enum.MachineOptionCode.CalculationSuccessfull;
                    }
                };

                sap.ui.getCore().getEventBus().publish('MachineOptionService', 'serviceSuccessfull');
            },

            /**
             * Aborts all pending services and clears the attribute _status. This method should be used if the current evidence package is changing
             * 
             * @memberOf jd.ui.eid.service.EvidencePackageServiceFacade.MachineOptionCalculation
             * @public
             */
            abortAllServices : function() {
                for ( var i = 0; i < this._status.length; i++) {
                    this._status[i].Ajax.abort();
                }

                this._status = [];
            }
        }
    });

})();