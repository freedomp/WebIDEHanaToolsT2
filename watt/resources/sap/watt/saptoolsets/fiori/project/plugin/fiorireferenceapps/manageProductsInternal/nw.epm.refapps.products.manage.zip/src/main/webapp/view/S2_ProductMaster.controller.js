jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.formatter");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.TableOperations");
jQuery.sap.require("nw.epm.refapps.products.manage.view.fragment.SubControllerForFGS");

sap.ca.scfld.md.controller.ScfldMasterController.extend("nw.epm.refapps.products.manage.view.S2_ProductMaster", {
    _sCurrentS3RouteName : "",
    _oSelectedProduct : {
        iCurrentIndex : -1, // Remembers the last selection index for the "Delete" use case
        sContextPath : "" // Remembers the last context path for the "Cancel Editing" use case
    },
    _oHelper : null,
    _oItemTemplate : null,
    _oTableOperations : null,
    _oSubControllerForFGS : null,
    _oHeaderFooterOptions : null,
    _bReadDraftAfterStart : false,
    _oResourceBundle : null,
    _oComponent : null,
    _oEventBus : null,
    _sIdentity : "nw.epm.refapps.product.manage",

    onInit : function() {
        this._oItemTemplate = this.byId("objectListItem").clone();
        this._oResourceBundle = this.oApplicationFacade.getResourceBundle();
        var oDataModel = this.getView().getModel();
        oDataModel.setRefreshAfterChange(false);
        // Object that holds the active sorters in the product list. It makes sure that setting
        // a new sort order using "Sort List" does not break a sorting that was previously set by
        // "grouping".
        // Sorting and grouping on the product table follows a certain logic that is outsourced to a
        // helper class:
        // 1. Selecting a sorter on the table adds the new sorter as the main sorter to all existing
        // sorters.
        // 2. If grouping and sorting are both set for the same attribute, then the direction
        // (ascending/descending) has to be aligned.
        this._oTableOperations = new nw.epm.refapps.lib.reuse.util.TableOperations(jQuery.proxy(this.rebindMasterTable,
                this));

        // Initializes the sub-controller for handling filter, grouping, and sorting dialogs
        this._oSubControllerForFGS = new nw.epm.refapps.products.manage.view.fragment.SubControllerForFGS(this
                .getView(), this._oTableOperations, jQuery.proxy(this._applyTableOperations, this));

        // Initializes for the cross-navigation use case, start app using product ID
        var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
        this._oComponent = sap.ui.component(sComponentId);
        var oComponentData = this._oComponent.getComponentData();
        if (oComponentData && oComponentData.startupParameters) {
            var oStartupParameters = oComponentData.startupParameters;
            if (jQuery.isArray(oStartupParameters.productID) && oStartupParameters.productID.length > 0) {
                var sProductID = oStartupParameters.productID[0];
                this._oTableOperations.addFilter(new sap.ui.model.Filter("Id", sap.ui.model.FilterOperator.EQ,
                        sProductID));
            }
        }
        this._oEventBus = this._oComponent.getEventBus();
        this._oEventBus.subscribe(this._sIdentity, "navToUpdatedProduct", this.navToUpdatedProductDraftFromEdit, this);
        this._oEventBus.subscribe(this._sIdentity, "resetSelectedProduct", this.resetSelectedProduct, this);
        this._oEventBus.subscribe(this._sIdentity, "onCopyPressed", this.navToDraftForNewProductFromEdit, this);
        this._oEventBus.subscribe(this._sIdentity, "removeItemsFromMasterList",
                this.removeItemsFromMasterListFromDisplay, this);
        this._oEventBus.subscribe(this._sIdentity, "showEmptyView", this.showEmptyViewFromEdit, this);

        // Gets the oData operations helper instance
        this._oHelper = this._oComponent.getODataHelper(this._oResourceBundle, oDataModel);

        // Binds items to the products list
        this._applyTableOperations();
    },

    // This function is used as follows:
    // 1) For initial binding (normal start and cross-app start)
    // 2) After backend searches
    // 3) By the filter, grouping, and sorting dialogs to apply the current sorters to the binding. It
    // uses the _oTableOperations object that contains the active sorters from both sorting and grouping and makes sure
    // that sorting does not break a parallel grouping.
    _applyTableOperations : function() {
        var oList = this.getList();
        this._oTableOperations.applyTableOperations();
        oList.attachEventOnce("updateFinished", function() {
            // Refreshes the product count in the master header
            this.registerMasterListBind(oList);
            if (oList.getItems().length > 0) {
                if (oList.getMode() === sap.m.ListMode.SingleSelectMaster) {
                    // Sets the list item selected if it is shown on the details page, the function is provided by
                    // scaffolding
                    this.selectItemMatchingTheLastNavigation();
                } else if (this._isListInMultiSelectMode()) {
                    // If multiselect mode and filters have been selected, this removes the selection to prevent user
                    // confusion when the selected items are no longer visible because they are further down the growing
                    // list
                    oList.removeSelections(true);
                    this._setDeleteButtonEnabled();
                }
            } else {
                // set the NoDataText
                var sNoDataText = this._oResourceBundle.getText("ymsg.noData");
                if (this._oTableOperations.getSearchTerm() || this._oTableOperations.getFilterTable()) {
                    sNoDataText = this._oResourceBundle.getText("ymsg.noDataAfterSerach");
                }
                oList.setNoDataText(sNoDataText);
            }
        }, this);
    },

    // Sets the binding
    rebindMasterTable : function(aSorters, oCustomSearch, aFilter) {
        var sSelect = "Id,ImageUrl,Name,Price,CurrencyCode,SubCategoryName,MainCategoryName,QuantityUnit,";
        sSelect = sSelect + "StockQuantity";
        this.getList().bindAggregation("items", {
            path : "/Products",
            sorter : aSorters,
            groupHeaderFactory : function(oGroup) {
                return new sap.m.GroupHeaderListItem({
                    title : oGroup.text,
                    upperCase : false
                });
            },
            parameters : {
                countMode : "Inline",
                select : sSelect,
                custom : oCustomSearch
            },
            template : this._oItemTemplate,
            filters : aFilter
        });
    },

    // --- Reads product draft after the application is launched. If the draft is available, the app navigates to the
    // draft first and sets the correct selection in the master list. Then the user is asked to resume editing or
    // discard changes.

    // This method is called by scaffolding after the master list is initially loaded. After this method
    // is executed,
    // scaffolding is to set the default list selection and navigate as follows to the S3 details page,
    // which is in
    // conflict with the available draft use case. The default selection can be only removed after the
    // user confirms
    // that he/she wants to stay on the draft page.
    onDataLoaded : function() {
        // Find the right time to read product draft after the application start?
        if (!this._bReadDraftAfterStart) {
            this._bReadDraftAfterStart = true;
            // If the user launches the S3 edit page directly, the app skips the read draft step, it
            // only handles the
            // normal start and detail page deeplink use case
            if (this._sCurrentS3RouteName === "" || this._isRouteInDetailView()) {
                // callback function for the case if there is product draft available, navigate to the
                // product draft
                // before the user is asked for resuming with editing
                var fnNavToProductDraft = function(oDraft) {
                    if (oDraft && oDraft.Id) {
                        // Navigates to the specific product draft
                        this._oComponent.navToProductEditPage(oDraft.Id);
                    }
                };
                // Callback function used if the user wants to resume editing; sets the list-item selection for the
                // product draft, since the scaffolding sets its own default selection
                var fnOkAction = function(oDraft) {
                    // Removes the default scaffolding selection, remembers/sets the new contextPath
                    var sContextPath = "/Products('" + oDraft.ProductId + "')";
                    // Checks if the corresponding product is available in the list
                    var oItem = this.findItemByContextPath(sContextPath);
                    if (!oItem) {
                        // Removes the selection if the item is still not visible in the master list
                        this.getList().removeSelections(true);
                    }
                };
                // Reads the product draft from backend if one is available; the user is asked to
                // confirm
                // that he/she wants to edit the product draft
                this._oHelper.handleProductDraft(this, jQuery.proxy(fnNavToProductDraft, this), jQuery.proxy(
                        fnOkAction, this), jQuery.proxy(this.resetSelectedProduct, this));
            }
        }
    },

    // --- Updates Header and Footer

    // Updates header and footer setting if required; triggers the refresh of header and footer
    _updateHeaderFooterOptions : function(bTriggerRefresh) {
        var bIsRouteInEditView = this._isRouteInEditView();
        // Defines the header and footer with common options
        var oHeaderFooterOptions = {
            sI18NMasterTitle : "xtit.productMasterProducts",
            onBack : jQuery.proxy(this.onBack, this),
            // Triggers the button on the right-hand side of the page header: Toggle list MultiSelect
            // mode
            oEditBtn : {
                sId : "editButton",
                bDisabled : bIsRouteInEditView,
                onBtnPressed : jQuery.proxy(this.onMultiSelectPressed, this)
            },
            // Inserts Filter, Sort, and Group buttons as common buttons
            oFilterOptions : {
                sId : "filterButton",
                bDisabled : bIsRouteInEditView,
                onFilterPressed : jQuery.proxy(this.onFilterPressed, this)
            },
            oSortOptions : {
                sId : "sortButton",
                bDisabled : bIsRouteInEditView,
                onSortPressed : jQuery.proxy(this.onSortPressed, this)
            },
            oGroupOptions : {
                sId : "groupButton",
                bDisabled : bIsRouteInEditView,
                onGroupPressed : jQuery.proxy(this.onGroupPressed, this)
            }
        };

        // Inserts other buttons based on whether or not the list mode is MultiSelect
        if (this._isListInMultiSelectMode()) {
            // Inserts the Delete button when the list mode is MultiSelect
            oHeaderFooterOptions.buttonList = [ {
                sId : "deleteButton",
                sI18nBtnTxt : "xbut.delete",
                // The Delete button is initially disabled, the button is enabled only once an item
                // is selected in the list
                bDisabled : (this.getList().getSelectedItems().length > 0 ? false : true),
                onBtnPressed : jQuery.proxy(this.onDeletePressed, this)
            } ];
        } else {
            // Inserts the Add button when the list mode is NOT MultiSelect
            oHeaderFooterOptions.oAddOptions = {
                sId : "addButton",
                bDisabled : bIsRouteInEditView,
                onBtnPressed : jQuery.proxy(this.onAddPressed, this)
            };
        }
        this._oHeaderFooterOptions = oHeaderFooterOptions;

        if (bTriggerRefresh) {
            // Triggers scaffolding refresh of header and footer on the UI
            this.refreshHeaderFooterForEditToggle();
        }
    },

    // Overwrites function from ScfldMasterController
    getHeaderFooterOptions : function() {
        if (!this._oHeaderFooterOptions) {
            this._updateHeaderFooterOptions();
        }
        return this._oHeaderFooterOptions;
    },

    // --- Handles Filtering, Grouping, and Sorting

    // User chooses the Filter button, app delegates the task to SubControllerForFGS to handle
    onFilterPressed : function() {
        this._oSubControllerForFGS.openDialog("ProductFilterDialog");
    },

    // User chooses the Sort button, app delegates the task to SubControllerForFGS to handle
    onSortPressed : function() {
        this._oSubControllerForFGS.openDialog("ProductSortDialog", "Name");
    },

    // User chooses the Group button, app delegates the task to SubControllerForFGS to handle
    onGroupPressed : function() {
        this._oSubControllerForFGS.openDialog("ProductGroupingDialog");
    },

    // --- Handle onSwipe event

    // User swipes on the list item
    onSwipe : function(oEvent) {
        // Gets swiped content (the button) from event
        var oSwipeContent = oEvent.getParameter("swipeContent");
        if (this._isRouteInEditView()) {
            // Makes the button invisible if the edit view is shown
            oSwipeContent.setVisible(false);
        } else {
            oSwipeContent.setVisible(true);
        }
    },

    // --- Handle navBack

    // User chooses the Back button
    onBack : function() {
        var fnNavBack = function() {
            window.history.go(-1);
        };
        // / Navigates back directly to display mode or on phone.
        if (this._isRouteInDetailView() || sap.ui.Device.system.phone) {
            fnNavBack();
            return;
        }
        // In the case of pending changes, asks and gets user confirmation before leaving the Edit page
        this._leaveEditPage(fnNavBack);
    },

    // Handles leaving Product Edit page from S3_ProductEdit.controller
    _leaveEditPage : function(fnAfterLeave, fnCancelLeave) {

        this._oEventBus.publish(this._sIdentity, "deleteProductDraft", {
            fnAfterLeave : fnAfterLeave,
            fnCancelLeave : fnCancelLeave
        });
    },

    // --- Handle the case that the Edit button in the header is chosen

    // User chooses the Edit button
    onMultiSelectPressed : function() {
        if (this._isListInMultiSelectMode()) {
            this._setToDeviceDefaultListMode();
        } else {
            this._checkAndSetToMultiSelectListMode();
        }
    },

    // Sets to device default list mode, such as none or singleSelectMaster
    _setToDeviceDefaultListMode : function() {
        var sListMode = this.getView().getModel("device").getData().listMode;
        // Sets MultiSelect mode back to the previous listMode defined in the "device" model
        // this.getList().setMode(this.getView().getModel("device").getData().listMode);
        this.getList().setMode(sListMode);
        // Sets list-item selection to the last selected item, the function is provided by scaffolding

        this._oEventBus.publish(this._sIdentity, "setListMode", {
            sListMode : sListMode
        });

        this.selectItemMatchingTheLastNavigation();
        // Enables the Edit button on the details page
        this._setFooterButtonEnabledOnS3DetailPage(true);
        // Updates HeaderFooterOptions and triggers scaffolding to refresh the UI
        this._updateHeaderFooterOptions(true);
    },

    // Tries to set multiSelect mode
    _checkAndSetToMultiSelectListMode : function() {
        if (this._isRouteInEditView()) {
            this._leaveEditPage(jQuery.proxy(function() {
                // Navigates to previously selected product display page
                this.resetSelectedProduct();
                // Sets multiSelect mode, the footer on the detail page does not need to be updated
                // because the detail
                // page footer may still not be there. After navigation, the footer on the detail page
                // is updated
                // anyway in S3.
                this._setToMultiSelectMode(false);
            }, this));
        } else {
            // Is already on detail page, set MultiSelectMode anyway
            this._setToMultiSelectMode(true);
        }
    },

    _setToMultiSelectMode : function(bUpdateDetailPageFooter) {
        var oList = this.getList();
        // Removes the list-item selection
        oList.removeSelections(true);
        // Sets list mode to MultiSelect
        oList.setMode(sap.m.ListMode.MultiSelect);

        this._oEventBus.publish(this._sIdentity, "setListMode", {
            sListMode : sap.m.ListMode.MultiSelect
        });

        oList.setIncludeItemInSelection(true);
        if (bUpdateDetailPageFooter) {
            this._setFooterButtonEnabledOnS3DetailPage(false);
        }
        // Updates HeaderFooterOptions and triggers scaffolding to refresh the UI
        this._updateHeaderFooterOptions(true);
    },

    _setFooterButtonEnabledOnS3DetailPage : function(bEnabled) {
        if (!sap.ui.Device.system.phone && this._isRouteInDetailView()) {
            this._oEventBus.publish(this._sIdentity, "enableEditingButton", {
                bEnabled : bEnabled
            });
        }
    },

    // --- Handles the case that the Delete button is chosen

    // User swipes the list item and confirms the deletion
    onSwipeDeleteItem : function() {
        this._deleteProduct(this.getList().getSwipedItem().getBindingContext(), true);
        this.getList().swipeOut();
    },

    // User chooses the Delete button on the footer as the list in multiSelect mode, this action could
    // trigger deletion
    // of one item or multiple items
    onDeletePressed : function() {
        var aItems = this.getList().getSelectedItems();
        if (aItems.length > 1) {
            var aProductsToBeDeleted = [];
            jQuery.each(aItems, function(iIndex, oSelectItem) {
                aProductsToBeDeleted.push(oSelectItem.getBindingContext().getPath());
            });
            this._oHelper.deleteProducts(aProductsToBeDeleted, jQuery.proxy(function(bSuccessful) {
                var sConfirmation = null;
                if (bSuccessful) {
                    sConfirmation = this._oResourceBundle.getText("ymsg.deleteMultipleConfirmation", aItems.length);
                }
                this.removeItemsFromMasterList(sConfirmation);
            }, this));
        } else { // // Deletes one selected product
            this._deleteProduct(this.getList().getSelectedItem().getBindingContext());
        }
    },

    // Handles deletion of one item
    _deleteProduct : function(oBindingContext, bWithoutConfirmationDialog) {
        var sProductName = oBindingContext.getProperty("Name");
        this._oHelper.deleteProduct(oBindingContext.getPath(), jQuery.proxy(function() {
            var sConfirmation = this._oResourceBundle.getText("ymsg.deleteConfirmation", sProductName);
            this.removeItemsFromMasterList(sConfirmation);
        }, this), bWithoutConfirmationDialog);
    },

    // Removes the deleted item(s) from the list by refreshing the list binding.
    // This method is also called by the ProductDetail controller after an item is deleted.
    removeItemsFromMasterList : function(sConfirmation) {
        var oList = this.getList();
        // It is currently not possible to remove the item only from the UI list, the app needs to
        // refresh/retrieve the list from the backend
        oList.getBinding("items").refresh();
        oList.attachEventOnce("updateFinished", function() {
            var iNumberOfItems = oList.getItems().length;
            if (iNumberOfItems === 0) {
                // There is no item available, app calls the scaffolding function noItemFoundForContext
                // and first
                // overwrites the default no data text
                oList.setNoDataText(this._oResourceBundle.getText("ymsg.noData"));
                this.noItemFoundForContext();
            } else {
                // Checks if the currently stored context path is available in the refreshed list, that
                // is, the item is
                // not deleted, this could happen in multiselect mode
                var oItem = this.findItemByContextPath(this._oSelectedProduct.sContextPath);
                if (!oItem) {
                    // Deleted, app moves to the next item
                    this._setNextAvailableItem();
                } else {
                    // Not deleted, app needs to trigger the navigation
                    this._navToItemSelected(oItem);
                }
                if (this._isListInMultiSelectMode() && sConfirmation) {
                    // Removes list selection
                    oList.removeSelections(true);
                }
            }
            if (sConfirmation) {
                // Deletion was successful and after list refresh and subsequent navigation, a success
                // toast
                // message appears for the user.
                jQuery.sap.require("sap.m.MessageToast");
                sap.m.MessageToast.show(sConfirmation);
            }
        }, this);
    },

    removeItemsFromMasterListFromDisplay : function(sChannel, sEvent, oParm) {
        var sConfirmation = oParm.sConfirmation;
        this.removeItemsFromMasterList(sConfirmation);
    },

    // The previous selected item is deleted, need to set the next available item; if the deleted item
    // is already the
    // last item, need to set back to the last available item.
    _setNextAvailableItem : function(bForceNavigation) {
        var oList = this.getList();
        var iNumberOfItems = oList.getItems().length;
        if (iNumberOfItems > 0) {
            // If the deleted item was not in the available master list (deeplink use case), set the
            // current index to 0
            if (this._oSelectedProduct.iCurrentIndex < 0) {
                this._oSelectedProduct.iCurrentIndex = 0;
            }
            var iStartIndex = this._oSelectedProduct.iCurrentIndex;
            // Sets the next available item. If the current index is already larger than the list
            // length, set the
            // current index back to the last item.
            if (this._oSelectedProduct.iCurrentIndex >= iNumberOfItems) {
                this._oSelectedProduct.iCurrentIndex = (iNumberOfItems - 1);
            }
            var oNextItem = oList.getItems()[this._oSelectedProduct.iCurrentIndex];
            // Check if the next item is ObjectListItem, it could be GroupHeaderListItem after grouping
            while (!(oNextItem instanceof sap.m.ObjectListItem) && this._oSelectedProduct.iCurrentIndex >= 0) {
                if (this._oSelectedProduct.iCurrentIndex <= (iStartIndex - 1)) {
                    // Backward again
                    this._oSelectedProduct.iCurrentIndex--;
                } else if (this._oSelectedProduct.iCurrentIndex >= iNumberOfItems) {
                    // Forward to the last item, sets backward again
                    this._oSelectedProduct.iCurrentIndex = iStartIndex - 1;
                } else {
                    // Forward again
                    this._oSelectedProduct.iCurrentIndex++;
                }
                if (this._oSelectedProduct.iCurrentIndex >= 0) {
                    oNextItem = oList.getItems()[this._oSelectedProduct.iCurrentIndex];
                }
            }

            if (oNextItem instanceof sap.m.ObjectListItem) {
                if (bForceNavigation || this._isRouteInDetailView() && !sap.ui.Device.system.phone) {
                    // Also triggers the navigation to the Detail page
                    this.setListItem(oList.getItems()[this._oSelectedProduct.iCurrentIndex]);
                } else {
                    // Sets selection but without navigation
                    oList.setSelectedItem(oList.getItems()[this._oSelectedProduct.iCurrentIndex]);
                }
            }
        }
    },

    // --- Handles the case that the Add(Product) button is chosen

    onAddPressed : function() {
        // new: Gets a promise object which is creating a product draft in backend, navigates to the new product draft
        // when the draft was created successfully
        this._oHelper.createProductDraft().done(jQuery.proxy(function(oProductDraftData) {
            this.navToDraftForNewProduct(oProductDraftData.Id);
        }, this));
        this._hideMasterinPortrait();
    },

    // This method is also called by S3 detail page
    navToDraftForNewProduct : function(oDraftId) {
        if (oDraftId && typeof oDraftId === "string") {
            this._oComponent.navToProductEditPage(oDraftId);
            // Removes the list selection
            this.getList().removeSelections(true);
        }
    },

    navToDraftForNewProductFromEdit : function(sChannel, sEvent, oParm) {
        var sDraftId = oParm.sDraftId;
        this.navToDraftForNewProduct(sDraftId);
    },
    // --- User selects the item in the list

    // User selects one item in the list (the handler replaces the scaffolding method _handleSelect)
    onSelectListItem : function(oEvent) {
        var oListItem = oEvent.getParameter("listItem");
        if (this._isListInMultiSelectMode()) {
            // List in multiselect mode: check if delete button needs to be enabled/disabled
            this._setDeleteButtonEnabled();
            // Check if app needs to navigate to the selected item (navigation only on desktop or
            // tablet)
            if (oEvent.getParameter("selected") && !sap.ui.Device.system.phone) {
                this._oComponent.showProductDetailPage(oListItem.getBindingContext().getProperty("Id"));
            }
        } else {
            // Checks the status of the S3 page before navigating to the selected item
            if (this._isRouteInDetailView()) {
                // Navigates to the selected item if S3 is already in display mode
                this._navToItemSelected(oListItem);
            } else if (this._isRouteInEditView()) {
                // If S3 is in edit mode, app needs to ask user if he/she wants to leave the edit page.
                // Reads the new selected item before opening message box.
                this._leaveEditPage(jQuery.proxy(function() {
                    // User confirms that he/she wants to leave the edit page
                    this._navToItemSelected(oListItem);
                }, this), jQuery.proxy(
                        function() {
                            // User does not want to leave the edit page, so app sets the selection back to the
                            // previous
                            // item
                            this.getList().removeSelections(true);
                            if (this._oSelectedProduct.iCurrentIndex > 0) {
                                this.getList().setSelectedItem(
                                        this.getList().getItems()[this._oSelectedProduct.iCurrentIndex]);
                            }
                        }, this));
            }
        }
    },

    _navToItemSelected : function(oListItem) {
        // Calls scaffolding setListItem default method
        this.setListItem(oListItem);
        if (!sap.ui.Device.system.phone) {
            // Note: this only applies when device is in portrait mode
            // Master is not automatically hidden
            this.getView().getParent().getParent().hideMaster();
        }
    },

    // Resets to the previously selected product. This method is called in the following cases:
    // 1) When the user discards the product draft that is shown when the application starts
    // 2) When leaving the edit page while multiselect button is clicked
    // 3) By S3_ProductEdit, if the user cancels the adding product action
    // 4) By S3_ProductEdit, if the requested draft is not available (deeplink use case)
    resetSelectedProduct : function() {
        // On phone, the master page is shown, there is no further navigation to detail page
        if (this._oComponent.navBackToMasterPageInPhone()) {
            return;
        }
        // On other devices, handles which item in the list should be selected
        var oItem = this.findItemByContextPath(this._oSelectedProduct.sContextPath);
        if (oItem) {
            this.setListItem(oItem);
        } else {
            this._setNextAvailableItem(true);
        }
    },

    // Navigate to the product that has just been edited and saved; this method is called by
    // S3_ProductEdit controller
    // after successfully saving the product draft.

    navToUpdatedProduct : function(sProductID, sProductName) {
        // Updates the master list first then navigates to the updated product
        var oList = this.getList();
        oList.getBinding("items").refresh();
        oList.attachEventOnce("updateFinished", jQuery.proxy(function() {
            // Updates S3 detail binding if necessary
            var oDetailPage = this._getDetailPage();
            if (oDetailPage && oDetailPage.getBindingContext() &&
                    oDetailPage.getBindingContext().getProperty("Id") === sProductID) {
                oDetailPage.getElementBinding().refresh();
            }

            // Navigates to the detail page
            this._oComponent.showProductDetailPage(sProductID);

            jQuery.sap.require("sap.m.MessageToast");
            sap.m.MessageToast.show(this._oResourceBundle.getText("ymsg.saveText", sProductName));
        }, this));
    },

    // Method to call navToUpdatedProduct from outside this controller using Event Bus
    navToUpdatedProductDraftFromEdit : function(sChannel, sEvent, oParm) {
        var sId = oParm.Id, sName = oParm.Name;
        this.navToUpdatedProduct(sId, sName);
    },

    // --- Overwrites scaffolding methods

    // Overwrites function from ScfldMasterController. The method is called while matching detail route,
    // in this
    // application it is called for all route patterns (S3DetailView and S3EditView).
    isDetailRoute : function(oEvent) {
        var sRouteName = oEvent.getParameter("name");
        // Detail and Edit, Copy, and Add pages are detail routes
        if (this._isRouteInDetailView(sRouteName) || this._isRouteInEditView(sRouteName)) {
            this._sCurrentS3RouteName = sRouteName;
            // Sets master page footer buttons to enabled or disabled on the desktop or tablet based on
            // the detail route
            if (!sap.ui.Device.system.phone) {
                this._setMasterFooterButtonsEnabled(this._isRouteInDetailView() ? true : false);
            }
            return true;
        }
        return false;
    },

    // Helper method to set the footer buttons to enabled or disabled
    _setMasterFooterButtonsEnabled : function(bEnabled) {
        this.setBtnEnabled("filterButton", bEnabled);
        this.setBtnEnabled("groupButton", bEnabled);
        this.setBtnEnabled("sortButton", bEnabled);
        this.setBtnEnabled("addButton", bEnabled);
        this.setBtnEnabled("editButton", bEnabled);
        this._updateHeaderFooterOptions();
    },

    // Overwrites function from ScfldMasterController, otherwise Scaffolding navigates to the empty page
    // on the desktop
    // or tablets if the context is not found in the local list;
    // In this app the navigation to the empty page is handled in the S3 page.
    applyFilterFromContext : function() {
        return;
    },

    // Uses standard scaffolding mechanism to indicate that search is implemented in backend
    isBackendSearch : function() {
        return true;
    },

    // Overwrites function from ScfldMasterController
    applyBackendSearchPattern : function(sSearchTerm) {
        // Adds subcategory/name and subcategory/main category/name when implemented in oData
        this._oTableOperations.setSearchTerm(sSearchTerm);
        this._applyTableOperations();
    },

    // Overwrites scaffolding method to use app-specific route parameters instead of contextPath;
    // This method is called each time when the S3 route pattern is matched.
    getDetailNavigationParameters : function(oListItem) {
        return {
            productID : encodeURIComponent(oListItem.getBindingContext().getProperty("Id"))
        };
    },

    // Overwrites scaffolding method to convert app-specific route parameters to contextPath
    getBindingContextPathFor : function(oArguments) {
        // Nothing matched, scaffolding expects "undefined"
        /* eslint-disable */
        this._oSelectedProduct.sContextPath = undefined;
        /* eslint-enable */
        if (oArguments.productID) {
            this._oSelectedProduct.sContextPath = "/Products('" + oArguments.productID + "')";
        }
        // Fallback use case for the product draft, so that scaffolding can set the list selection based
        // on the product
        // binding context (only used for desktop and tablets)
        if (oArguments.productDraftID && !sap.ui.Device.system.phone) {
            this._oSelectedProduct.sContextPath = "/Products('" + oArguments.productDraftID + "')";
        }

        // The context path is found in the master list, the current index is updated
        if (this._oSelectedProduct.sContextPath) {
            var oItem = this.findItemByContextPath(this._oSelectedProduct.sContextPath);
            if (oItem) {
                // Remembers the context path and selected item position
                this._oSelectedProduct.iCurrentIndex = this.getList().indexOfItem(oItem);
            }
        }

        return this._oSelectedProduct.sContextPath;
    },
    // --- Internal helper methods

    // Helper method to get the detail controller (S3_ProductDetail) via oRouter
    _getDetailPageController : function() {
        return this._getDetailPage().getController();
    },

    // Helper method to get the detail page view (S3_ProductDetail) via oRouter
    _getDetailPage : function() {
        return this.oRouter.getView("nw.epm.refapps.products.manage.view.S3_ProductDetail");
    },

    // Helper method to check if the current list is in the MultiSelect mode
    _isListInMultiSelectMode : function() {
        return this.getList().getMode() === sap.m.ListMode.MultiSelect;
    },

    // Helper method to set the footer delete button enabled/disabled
    _setDeleteButtonEnabled : function() {
        // set Delete button enabled only after one item is selected in the list
        this.setBtnEnabled("deleteButton", this.getList().getSelectedItems().length > 0);
    },

    // Checks if the route name specified or the current route name is the route name of the product
    // detail view
    _isRouteInDetailView : function(sName) {
        return (sName || this._sCurrentS3RouteName) === "detail";
    },

    // Checks if the route name specified or the current route name is the route name of the product
    // edit view
    _isRouteInEditView : function(sName) {
        return (sName || this._sCurrentS3RouteName) === "ProductEdit";
    },

    _hideMasterinPortrait : function() {
        if (!sap.ui.Device.system.phone) {
            this.getView().getParent().getParent().hideMaster();
        }
    },

    showEmptyViewFromEdit : function(sChannel, sEvent, oParm) {
        var sProduct = oParm.sProduct, sMessage = oParm.sMessage;
        this.showEmptyView(sProduct, sMessage);
    }
});