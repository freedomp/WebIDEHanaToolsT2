(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WorkSheetFormatter");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");

    /**
     * @class This formatter class provides methods for formatting DTC data.
     * @static
     * @name jd.ui.eid.common.formatter.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter = {};

    /**
     * Returns formatted Boolean for VNSM Recover
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatVNSMRecover = function(sVal) {
        switch (sVal) {
            case "true" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_RECOVER_YES');
            case "false" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_RECOVER_NO');
            default :
                return sVal;
        }
    };

    /**
     * Returns formatted Boolean for VNSM Derate
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatVNSMDerate = function(sVal) {
        switch (sVal) {
            case "true" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_DERATE_YES');
            case "false" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_DERATE_NO');
            default :
                return sVal;
        }
    };

    /**
     * Returns formatted Boolean for VNSM Display
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatVNSMDisplay = function(sVal) {
        switch (sVal) {
            case "true" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_DISPLAY_YES');
            case "false" :
                return jd.ui.eid.common.I18NHelper.getText('DTC_DETAILS_TXT_VNSM_DISPLAY_NO');
            default :
                return sVal;
        }
    };

    /**
     * Returns formatted DTC Description by concatenating Level1Text & Level2Text
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatDTCDescription = function(oDTCMasterData) {
        var sStr = "";
        if (oDTCMasterData && oDTCMasterData.Level1Text) {
            sStr += oDTCMasterData.Level1Text;
        }
        if (oDTCMasterData && oDTCMasterData.Level1Text && oDTCMasterData.Level2Text) {
            sStr += "\n\r";
        }
        if (oDTCMasterData && oDTCMasterData.Level2Text) {
            sStr += oDTCMasterData.Level2Text;
        }
        return sStr;
    };

    /**
     * Returns icon for trend value
     * 
     * @param {int}
     *            trend Value:
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getTrendIcon = function(trendValue) {
        switch (trendValue) {
            case 1 :
                return "jd/ui/eid/asset/img/trend_arrow_up_12x12.png";
                break;
            case 0 :
                return "jd/ui/eid/asset/img/trend_stable_12x12.png";
                break;
            case -1 :
                return "jd/ui/eid/asset/img/trend_arrow_down_12x12.png";
                break;

            default :
                return "jd/ui/eid/asset/img/trend_stable_12x12.png";
                break;
        }
    };

    /**
     * Returns icon for trend tooltip
     * 
     * @param {int}
     *            iTrendValue trend Value
     * @returns {string} the formatted string of the trend
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getTrendTooltip = function(iTrendValue) {
        var sTextKey = "";
        switch (iTrendValue) {
            case 1 :
                sTextKey = "KPI_DETAILS_TOL_TREND_UP";
                break;
            case 0 :
                sTextKey = "KPI_DETAILS_TOL_TREND_STABLE";
                break;
            case -1 :
                sTextKey = "KPI_DETAILS_TOL_TREND_DOWN";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Returns icon for warning light
     * 
     * @param {string}
     *            sWarningLight warning light
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getWarningLightIcon = function(sWarningLight) {
        // The values provided by the backend are: Service Alert, Info, Stop, No Lamp, NA (as of Jan 21, 2014)
        switch (sWarningLight) {
            case "Stop" :
                return "jd/ui/eid/asset/img/DTC_STOPAlert.png";
                break;
            case "Service Alert" :
                return "jd/ui/eid/asset/img/DTC_ServiceAlert.png";
                break;
            case "Info" :
                return "jd/ui/eid/asset/img/DTC_InfoOnlyAlert.png";
                break;
            case "NA" :
            default :
                return "jd/ui/eid/asset/img/DTC_Empty.png";
                break;
        }
    };

    /**
     * Returns small icon for warning light (for display in e.g. a table)
     * 
     * @param {string}
     *            sWarningLight warning light
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getWarningLightIconSmall = function(sWarningLight) {
        // The values provided by the backend are: Service Alert, Info, Stop, No Lamp, NA (as of Jan 21, 2014)
        switch (sWarningLight) {
            case "Stop" :
                return "jd/ui/eid/asset/img/DTC_STOPAlert_15x15.png";
                break;
            case "Service Alert" :
                return "jd/ui/eid/asset/img/DTC_ServiceAlert_15x15.png";
                break;
            case "Info" :
                return "jd/ui/eid/asset/img/DTC_InfoOnlyAlert_15x15.png";
                break;
            case "NA" :
            default :
                return "jd/ui/eid/asset/img/DTC_Empty_15x15.png";
                break;
        }
    };
    
    jd.ui.eid.common.formatter.DTCFormatter.getWarning = function(sWarningLight) {
    	return sWarningLight;
    };

    /**
     * 
     * return the name of a KPI by given KPI id
     * 
     * @param {int}
     *            KPIId: the id of KPI
     * @returns {String} the name of KPI
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getRawKPIName = function(sKPIId) {
        var oKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
        if (oKPIs != null) {
            for ( var i = 0; i < oKPIs.length; i++) {
                var oKPI = oKPIs[i];
                if (oKPI.KPIID == sKPIId) {
                    return oKPI.KPIName;
                }
            }
        }
        return sKPIId;
    };

    /**
     * 
     * return the name of a KPI by given KPI id together with ":"
     * 
     * @param {int}
     *            KPIId: the id of KPI
     * @returns {String} the name of KPI
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */
    jd.ui.eid.common.formatter.DTCFormatter.getKPIName = function(sKPIId) {

        return jd.ui.eid.common.formatter.DTCFormatter.getRawKPIName(sKPIId) + ':';
    };

    /**
     * Formats the KPI value to a decimal with two digits.
     * 
     * @param {float}
     *            fValue the KPI value
     * @returns {string} the formatted value.
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatKPIValue = function(fValue) {
        return jd.ui.eid.common.formatter.NumberFormatter.formatFloat(fValue, 4);
    };

    /**
     * Formats the affected tractors.
     * 
     * @param {int}
     *            iValue the number of affected tractors.
     * @returns {string} the formatted value.
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatAffectedTractors = function(iValue) {
        return jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iValue);
    };

    /**
     * 
     * Returns a label containing the number of DTCs in a list
     * 
     * @param {array}
     *            aDTCList a list of DTCs
     * @returns {String} a string containing the number of DTCs in the list
     * 
     * @memberOf jd.ui.eid.common.DTCFormatter
     */

    jd.ui.eid.common.formatter.DTCFormatter.getDTCNumberLabel = function(aDTCList) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(aDTCList ? aDTCList.length : "0", "DTC_BASKET_FLD_COUNT_MULTIPLE",
                "DTC_BASKET_FLD_COUNT_SINGLE");
    };

    /**
     * returns the Value for KPI Selector: KPI Name + by Capture Time
     * 
     * @param {string}
     *            sKPIName the KPI Name
     * @returns {String} the name of KPI + 'by Capture Time'
     */
    jd.ui.eid.common.formatter.DTCFormatter.KPINameWithByCaptureTime = function(sKPIName) {
        return jd.ui.eid.common.I18NHelper.getText("DTC_DETAILS_CHART_CAP_BY_CAPTURE_TIME", [sKPIName]);
    };

    /**
     * Formats the engine hour segment on a chart context.
     * 
     * @param {float}
     *            fLowerBound the lower bound of the engine hour segment.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted engine hour segment.
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatEngineHourSegmentForChart = function(fLowerBound, oContext) {
        if (oContext) {
            var fLow = oContext.getProperty("EngineHourLow");
            var fHigh = oContext.getProperty("EngineHourHigh");
            if (!fHigh || fHigh == "null" || fHigh == "unlimited") {
                return jd.ui.eid.common.I18NHelper.getText('ENGINE_HOURS_FORMAT_TXT_RANGE_OPEN', [fLow]);
            } else {
                return jd.ui.eid.common.I18NHelper.getText('ENGINE_HOURS_FORMAT_TXT_RANGE', [fLow, fHigh]);
            }
        } else {
            return "";
        }
    };

    /**
     * Format the DTC occurences segment
     * 
     * @param{float} fLowerBound the lower bound of the DTC Occurence segment.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted DTC Occurences segment.
     * 
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatDTCOccurenceSegmentForChart = function(fLowerBound, oContext) {
        if (oContext) {
            var fLow = oContext.getProperty("DTCOccurenceLow");
            var fHigh = oContext.getProperty("DTCOccurenceHigh");
            if (fHigh && fLow && fHigh != "null" && fHigh == fLow) {
                return fHigh;
            }

            if (!fHigh || fHigh == "null" || fHigh == "unlimited") {
                return jd.ui.eid.common.I18NHelper.getText('COMMON_FORMATTER_TXT_DTC_OCCURENCES_SEGMENT_OPEN_END', [fLow]);
            } else {
                return jd.ui.eid.common.I18NHelper.getText('COMMON_FORMATTER_TXT_DTC_OCCURENCES_SEGMENT', [fLow, fHigh]);
            }
        } else {
            return "";
        }
    };

    /**
     * Returns true of a DTC can be added to an evidence package
     * 
     * @param {string}
     *            sDTCCode the code of the DTC to be added
     * @returns {boolean} true if the DTC is not contained in the evidence package yet
     */
    jd.ui.eid.common.formatter.DTCFormatter.canDTCBeAddedToEvidencePackage = function(sDTCCode) {
        var aDtcCodeList = sap.ui.getCore().getModel().getData().EvidencePackageDetails.DTCCodeList;
        if (aDtcCodeList)
            for ( var i = 0; i < aDtcCodeList.length; ++i)
                if (aDtcCodeList[i] == aDtcCodeList)
                    return false;
        return true;
    };

    /**
     * Returns the '* DTC ID' if the DTC is new added to the Evidence Package
     * 
     * @param {string}
     *            sDTCCode The Code of DTC
     * @param {string}
     *            sAddedOn The Date when DTC is added to Evidence Package
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatNewAddedDTCID = function(sDTCCode) {
        var aDtcCodeList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/DTCCodeList") || [];
        var sAddedOn = "";
        for ( var i = 0; i < aDtcCodeList.length; i++) {
            if (sDTCCode == aDtcCodeList[i].DTCCode) {
                sAddedOn = aDtcCodeList[i].AddedOn;
                break;
            }
        };
        return jd.ui.eid.common.formatter.WorkSheetFormatter.formatNewAddedBasketItem(sAddedOn) + (sDTCCode || "");
    };

    /**
     * Returns true or false if the Delete Button is enabled in the DTC Details List in the Evidece Package
     * 
     * @param {int}
     *            iEnabled index for button enablement 1 = true, 0 = false
     * @return {boolean} enablement of delete button
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatButtonEnabled = function(iEnabled) {
        switch (iEnabled) {
            case 0 :
                return false;
                break;
            case 1 :
                return true;
                break;
        }
    };

    /**
     * Returns the DTC code for a given DTC id
     * 
     * @param {int}
     *            iDTCID DTC id
     * @return {string} sDTCCode DTCCode
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatDTCIDToDTCCode = function(iDTCID) {
        if (iDTCID) {
            return jd.ui.eid.model.EidModel.TransformationHelper.getDTCHeaderForDTCIDFromEvidencePackageDetails(iDTCID).DTCCode;
        } else {
            return "";
        }
    };

    /**
     * returns true if the DTCCodeList is empty otherwise false
     * 
     * @param{array} aDTCCodeList DTC Code List
     * @return {boolean}
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatDTCCount = function(aDTCCodeList) {
        if (aDTCCodeList && aDTCCodeList.length > 0) {
            return true;
        } else {
            return false;
        }
    };

    /**
     * Formats the chart title of chart <code>NumberOfPINsByBuildDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatNumberOfPINsByBuildDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "DTC_DETAILS_CHART_CAP_NUMBER_OF_PINS_BY_BUILD_MONTH";
                break;
            case "weeks" :
                sTextKey = "DTC_DETAILS_CHART_CAP_NUMBER_OF_PINS_BY_BUILD_WEEK";
                break;
            default :
                sTextKey = "DTC_DETAILS_CHART_CAP_NUMBER_OF_PINS_BY_BUILD_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats the chart title of chart <code>DTCOccurenceByBuildDate</code>.
     * 
     * @param {string}
     *            sTimeUnit the time unit, either <code>days</code>, <code>weeks</code>, or <code>months</code>.
     * @param {string}
     *            returns the title for the respective time unit.
     */
    jd.ui.eid.common.formatter.DTCFormatter.formatDTCOccurenceByBuildDateChartTitle = function(sTimeUnit) {
        var sTextKey = "";
        switch (sTimeUnit) {
            case "months" :
                sTextKey = "DTC_DETAILS_CHART_CAP_DTC_OCCURENCES_BY_BUILD_MONTH";
                break;
            case "weeks" :
                sTextKey = "DTC_DETAILS_CHART_CAP_DTC_OCCURENCES_BY_BUILD_WEEK";
                break;
            default :
                sTextKey = "DTC_DETAILS_CHART_CAP_DTC_OCCURENCES_BY_BUILD_DATE";
                break;
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

})();