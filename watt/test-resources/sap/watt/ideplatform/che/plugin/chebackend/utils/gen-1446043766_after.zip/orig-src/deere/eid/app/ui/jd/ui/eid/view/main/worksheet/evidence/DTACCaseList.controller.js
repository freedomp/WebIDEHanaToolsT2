(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");

    /**
     * The controller for the DTACCaseList view
     * 
     * @class
     * <p>
     * The DTAC Case List View provides the functionality to find DTAC cases for an evidence package. It consists of a filter area and a table of DTAC
     * cases.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers.
     * Moreover it sets the binding for all filteritem fragments and attaches the toolpopus to them.</li>
     * <li>{@link #.onExit} is usually called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.fetchDTACCaseList} is usually called to trigger a new service call.</li>
     * <li>{@link #.formatDTACCaseCountText} is called to format the DTAC case Count on top of the DTAC case list table </li>
     * <li>{@link #.initToolPopupFragments} is called during initialization of the view. It creates the DateRangeToolPopup and the
     * DateDistanceToolPopups of the FilterArea. By using two delegates (one for each ToolPopup) the responsibility for the ToolPopup functionality is
     * handled outside this controller.</li>
     * <ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>_handleJDLinkActiveValueChanged is called when the JDLinkActive/Inactive filter item changed. If JDLinkActive was selected, than all
     * fields at the Creation Date filter item are selectable, otherwise it is just able to change the date range list item.
     * <li>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>handleOpenDTACCaseDetails is called after a DTAC case was selected. It will open the DTAC Case Details view.</li>
     * <li>handleAddDTACCase is called for adding a DTAC case to the evidence package.</li>
     * <li>handleFilterAreaClear is called to clear the current filter area selection and to trigger a new service request.</li>
     * <li>handleFilterItemCleared is called to trigger a new service request after a filter item was cleared.</li>
     * <li>handleNavigation is called while navigating to the view by raising the event "navigating". It triggers a new service call by using the
     * method fetchDTACCaseList</li>
     * <li>handleRefreshDTACCaseList is called to update the table data.</li>
     * <li>handleDTCRemoved is called after a DTC has been removed from the evidence package</li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.evidence.DTACCaseList", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.worksheet.evidence.DTACCaseList */
    {
        _bRefresh : true,
        _bRenderedForTheFirstTime : false,
        _oDateDistanceToolPopup : null,
        _oDateDistanceToolPopupDelegate : null,
        _oDateRangeToolPopup : null,
        _oDateRangeToolPopupDelegate : null,
        _oDTACCaseService : null,
        _oEvidencePackageService : null,
        _oTable : null,
        _oView : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiEidViewWorksheetEvidenceDTACCaseList");
            this._oView.addStyleClass("jdUiEidScrollLayout jdUiEidScrollLayoutHorizontal jdUiEidScrollLayoutScrollBarOutside");

            // Get references to control
            this._oTable = this.byId("DTACCaseTable");

            // Subcribe to event bus
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            sap.ui.getCore().getEventBus().subscribe('Navigation', 'navigating', this.handleNavigation, this);
            sap.ui.getCore().getEventBus().subscribe('EvidencePackage', 'DTCRemoved', this.handleDTCRemoved, this);
            sap.ui.getCore().getEventBus().subscribe("EvidencePackage", "newDTCFiltersApplied", this.fetchDTACCaseList, this);

            // Get references to instances of DTACCaseServiceFacade
            // and EvidencePackageServiceFacade
            this._oDTACCaseService = this.getServiceFacade("DTACCase");
            this._oDTACCaseService.attachRequestFailed(this._onRequestFailed);
            this._oEvidencePackageService = this.getServiceFacade("EvidencePackage");
            this._oEvidencePackageService.attachRequestFailed(this._onRequestFailed);

            var sFilterAreaId = this.getView().createId("FilterArea");
            sap.ui.core.Fragment.byId(sFilterAreaId, "TagCloud").bindProperty("selection", "/DTACCaseFilters/FilterSelection/TagCloud");
            sap.ui.core.Fragment.byId(sFilterAreaId, "TextAnalysis").bindProperty("selection", "/DTACCaseFilters/FilterSelection/TextAnalysis");
            sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").bindProperty("selection", "/DTACCaseFilters/FilterSelection/CreationDate");
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHour").bindProperty("selection", "/DTACCaseFilters/FilterSelection/EngineHour");

            // Add the formatter functions to the creationDate filterItem
            var sFilterAreaId = this.getView().createId("FilterArea");
            sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").setDateRangeValueListItemTextFormatter(
                    jd.ui.eid.common.formatter.DateTimeFormatter.formatDateRangeValueListItemText);
            sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").setDateDistanceValueListItemTextFormatter(
                    jd.ui.eid.common.formatter.DateTimeFormatter.formatDateDistanceValueListItemText);

            // Initialize the date range toolpopup delegate
            this.initToolPopupFragments();

            // Assign an anonymous formatter to the enabled property of the DTAC case details opener element. Thus, the formatter is executed
            // in the
            // context of the
            // control, so we can manipulate the DOM around it to make the row appear disabled.
            var oLinkTemplate = this.byId("DTACCaseDetailsOpenerTemplate");
            var that = this;
            if (oLinkTemplate) {
                oLinkTemplate.bindProperty("enabled", {
                    path : '_canBeAddedToEvidencePackage',
                    formatter : function(bCanBeAddedToEvidencePackage) {
                        if (bCanBeAddedToEvidencePackage === false) {
                            // If the DTAC case is already in the evidence package, we will positively highlight the row
                            this.addStyleClass("jdUiEidTableRowSuccessRef");
                            this.$().closest("tr").addClass("jdUiEidTableRowSuccess");
                        } else {
                            // Otherwise, we remove the DOM attributes that might have been assigned previously. This for example is the case
                            // when the
                            // table pages to the next page, when only the binding is updated but the table is not rerenderd.
                            this.removeStyleClass("jdUiEidTableRowSuccessRef");
                            this.$().closest("tr").removeClass("jdUiEidTableRowSuccess");
                        }
                        // It should actually always be enabled.
                        return true;
                    }
                });
            }

            // And we need to add an event delegate to the table so when the table is rerendered, the tr's get the .jdUiEidTableRowInactive
            // class
            // again.
            this._oTable.addEventDelegate({
                onAfterRendering : function() {
                    that._oTable.$().find(".jdUiEidTableRowSuccessRef").closest("tr").addClass("jdUiEidTableRowSuccess");
                }
            });
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         */
        onAfterRendering : function() {
            if (!this._bRenderedForTheFirstTime || this._bRefresh) {
                this._bRenderedForTheFirstTime = true;
                this._bRefresh = false;
                this.fetchDTACCaseList();
            }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
         */
        onExit : function() {
            // Unsubcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
            oEventBus.unsubscribe('Navigation', 'navigating', this.handleNavigation, this);
            oEventBus.unsubscribe('EvidencePackage', 'DTCRemoved', this.handleDTCRemoved, this);
            oEventBus.unsubscribe('EvidencePackage', 'newDTCFiltersApplied', this.fetchDTACCaseList, this);

            // Detach events
            this._oDTACCaseService.detachRequestFailed(this._onRequestFailed);
            this._oEvidencePackageService.detachRequestFailed(this._onRequestFailed);

            // Destroy the delegates
            this._oDateRangeToolPopupDelegate.destroy();
            this._oDateDistanceToolPopupDelegate.destroy();

            // Destroy controls
            this._oDateRangeToolPopup.destroy();
            this._oDateDistanceToolPopup.destroy();

            // Set properties to null
            this._oDateDistanceToolPopupDelegate = null;
            this._oDateRangeToolPopupDelegate = null;
            this._oDTACCaseService = null;
            this._oEvidencePackageService = null;
            this._oTable = null;
            this._oView = null;
        },

        /**
         * Handles the navigating event.
         * 
         * @param {string}
         *            sChannelId the channel id
         * @param {string}
         *            sEventId the event name
         * @param {object}
         *            oData the data passed along with the event.
         * @see jd.ui.eid.Events#Navigation::navigating
         */
        handleNavigation : function(sChannelId, sEventId, oData) {
            if (oData.target == 'jd.ui.eid.view.main.worksheet.evidence.DTACCaseList') {
                this.fetchDTACCaseList();
            }
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the DTAC case list is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTACCaseList") {
                this.byId("DTACCaseTable").setBusy(true);

                var oTagCloudFilterItem = this.byId("FilterArea", "TagCloud");
                oTagCloudFilterItem.setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the DTAC case list has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTACCaseList") {
                this.byId("DTACCaseTable").setBusy(false);

                var oTagCloudFilterItem = this.byId("FilterArea", "TagCloud");
                oTagCloudFilterItem.setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Initialize all the toolPopups of the DTACCaseList
         * 
         * @memberOf jd.ui.eid.view.main.worksheet.evidence.DTACCaseList
         */
        initToolPopupFragments : function() {
            var sFilterAreaId = this.getView().createId("FilterArea");

            /*
             * Add the data range toolPopup
             */
            // Create an ID for the date range toolPopup fragment
            var sDateRangeToolPopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DateRangeToolPopup");
            // Create the data range toolPopup delegate object
            this._oDateRangeToolPopupDelegate = new jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate({
                fragmentId : sDateRangeToolPopupFragmentId
            });
            // If user clicks on cancel, the last visible selection needs to be restored. Since the model is not updated unless 'OK' is
            // clicked, it is
            // enough to refresh the binding
            this._oDateRangeToolPopupDelegate.attachCanceled(function() {
                var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").getCustomDateRangeItem();
                oOpener.onToolPopupCanceled();
            });

            // Create a date range toolPopup object and assign the delegate
            // object to it
            this._oDateRangeToolPopup = jd.ui.eid.xmlfragment(sDateRangeToolPopupFragmentId, "jd.ui.eid.fragment.filter.DateRangeToolPopup",
                    this._oDateRangeToolPopupDelegate);
            // Get the date range item object and assign it to the toolPopup as
            // an opener
            var oCustomDateRangeItem = sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").getCustomDateRangeItem();
            this._oDateRangeToolPopupDelegate.setOpener(oCustomDateRangeItem);
            // Assign date range toolPopup to the opener
            oCustomDateRangeItem.setToolPopup(this._oDateRangeToolPopup);

            /*
             * Add the data distance toolPopup
             */
            // Create an ID for the date distance toolPopup fragment
            var sDateDistanceToolPopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DateDistanceToolPopup");
            // Create the data distance toolPopup delegate object
            this._oDateDistanceToolPopupDelegate = new jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate({
                fragmentId : sDateDistanceToolPopupFragmentId
            });
            // If user clicks on cancel, the last visible selection needs to be restored. Since the model is not updated unless 'OK' is
            // clicked, it is
            // enough to refresh the binding
            this._oDateDistanceToolPopupDelegate.attachCanceled(function() {
                var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").getCustomDistanceItem();
                oOpener.onToolPopupCanceled();
            });

            // Create a date distance toolPopup object and assign the delegate
            // object to it
            this._oDateDistanceToolPopup = jd.ui.eid.xmlfragment(sDateDistanceToolPopupFragmentId, "jd.ui.eid.fragment.filter.DateDistanceToolPopup",
                    this._oDateDistanceToolPopupDelegate);
            // Get the date distance item object and assign it to the toolPopup as
            // an opener
            var oCustomDistanceItem = sap.ui.core.Fragment.byId(sFilterAreaId, "CreationDate").getCustomDistanceItem();
            this._oDateDistanceToolPopupDelegate.setOpener(oCustomDistanceItem);
            // Assign date distance toolPopup to the opener
            oCustomDistanceItem.setToolPopup(this._oDateDistanceToolPopup);
        },

        /**
         * Hook function for additional checks regarding the visibility in the classes.
         */
        _isVisible : function() {
            if (jd.ui.eid.common.OverlayHelper.getWorksheetOverlay().isOpen()
                    && !jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay().isOpen()) {
                return true;
            } else {
                return false;
            }
        },

        /**
         * Triggers a service call to get the list of DTAC Cases and update the model.
         */
        fetchDTACCaseList : function() {
            // Check whether the view has been initial
            if (this._bRenderedForTheFirstTime && this.isVisible()) {
                // Get binding and search term from UI
                var oBinding = this._oView.byId("DTACCaseTable").getBinding();
                var oModel = sap.ui.getCore().getModel();

                if (oBinding) {
                    var sSearchTerm = this._oView.byId("searchField").getValue();

                    // Get the custom DTAC filter selection
                    var oCustomFilter = oModel.getProperty("/DTACCaseFilters/FilterSelection");

                    // Prepare the oEvidencePackage parameter that the
                    // service call needs
                    var oDTCFilters = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterSelection");
                    var aDTCIDs = jd.ui.eid.model.EidModel.TransformationHelper.getDTCIDListFromEvidencePackageDetails();
                    var oEvidencePackage = {
                        DTCFilters : oDTCFilters,
                        DTCIDList : aDTCIDs
                    };

                    // Make the service call
                    this._oDTACCaseService.getDTACCaseList(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm, null, this._onRequestFailed);
                }
            } else {
                this._bRefresh = true;
            }
        },

        /**
         * Handler of the refresh list event. Triggers a service call to update the current list of DTAC Cases.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the button.
         */
        handleRefreshDTACCaseList : function(oEvent) {
            // Get binding and search term from UI
            var oBinding = this._oView.byId("DTACCaseTable").getBinding();
            oBinding.refreshData();
        },

        /**
         * Event handler for click on the 'Add' action of a DTAC Case
         * 
         * @param {sap.ui.base.Event}
         *            oEvent The event parameters provided by the framework
         */
        handleAddDTACCase : function(oEvent) {
            var mDTACCase = oEvent.getSource().getBindingContext().getProperty();
            var oModel = sap.ui.getCore().getModel();
            var oDTACCaseFilterSelection = oModel.getProperty("/DTACCaseFilters/FilterSelection");
            var oDTACCaseFilterState = oModel.getProperty("/DTACCaseFilters/FilterState");
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTACCase(mDTACCase, oDTACCaseFilterSelection, oDTACCaseFilterState);
        },

        /**
         * Event handler for click on DTAC case number
         */
        handleOpenDTACCaseDetails : function(oEvent) {
            var oSelectedDTACCaseListItem = oEvent.getSource().getBindingContext().getProperty();
            var iDTACCaseNumber = oSelectedDTACCaseListItem.DTACCaseNumber;
            var oDTACCaseDetailsOverlay = jd.ui.eid.common.OverlayHelper.getDTACCaseDetailsOverlay();
            oDTACCaseDetailsOverlay.setContext(iDTACCaseNumber);
            if (!oDTACCaseDetailsOverlay.isOpen()) {
                oDTACCaseDetailsOverlay.open();
            }
        },

        /**
         * Formatter for the 'xx DTAC Cases' text above the table.
         * 
         * @returns {string} The formatted text (for 'Number of DTAC Cases') to be shown on top of the table
         */
        formatDTACCaseCountText : function() {
            // Get the number of records. This is the 'Count'
            // value returned by the backend and stored as a
            // property of the binding.
            var sCount = "0";
            var oBinding = this._oView.byId("DTACCaseTable").getBinding();
            if (oBinding) {
                sCount = oBinding.getLength();
                sCount = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oBinding.getLength());
            }
            return jd.ui.eid.common.I18NHelper.getNumberChoiceText(sCount, "DTAC_CASE_TABLE_CAP_COUNT_MULTIPLE", "DTAC_CASE_TABLE_CAP_COUNT_SINGLE");
        },

        /**
         * Handles the clear action from the filter area's tool popup and clears the filter area.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleFilterAreaClear : function(oEvent) {
            // Clear the filter
            var oFilterArea = this.byId("FilterArea", "FilterArea");
            oFilterArea.clear();
            // Fetch the DTAC Case List
            this.fetchDTACCaseList();
        },

        /**
         * Handles the cleared event of the filter items to send a request.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired.
         */
        handleFilterItemCleared : function(oEvent) {
            // Fetch the DTAC Case List
            this.fetchDTACCaseList();
        },

        /**
         * Handles the event which is fired when a DTC was removed from the Evidence Package.
         * 
         * @param {string}
         *            sChannelId the channel id
         * @param {string}
         *            sEventId the event name
         * @param {object}
         *            mData the data passed along with the event.
         * @see jd.ui.eid.Events#EvidencePackage::DTCRemoved
         */
        handleDTCRemoved : function(sChannelId, sEventId, oData) {
            this.fetchDTACCaseList();
        }

    }));
})();