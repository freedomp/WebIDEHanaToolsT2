(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.customizing.shell.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * @class Base controller for customizing controllers to handle re-occuring view life cycle tasks, interaction with the customizing service
     *        facade, dialog handling, etc. A controller that incorporates the methods of this base controller has to provide the following
     *        configuration object as property:
     *        <ul>
     *        <li>_mConfig
     *        <ul>
     *        <li>mFetchData
     *        <ul>
     *        <li>sMethodName : string The name of the method to call on the service facade.</li>
     *        </ul>
     *        </li>
     *        <li>mSendData
     *        <ul>
     *        <li>sPath : string Model path which should be passed to the method</li>
     *        <li>sMethodName : string The name of the method to call on the service facade.</li>
     *        <li>sSuccessText : string Text key to be displayed upon success</li>
     *        </ul>
     *        </li>
     *        <li>mDialog
     *        <ul>
     *        <li>sId : string The id of the dialog.</li>
     *        <li>sFragment : string The name of the fragment containing the dialog.</li>
     *        <li>sContextPath : string The path for binding the dialog's context.</li>
     *        </ul>
     *        </li>
     *        <li>mHelpDialog
     *        <ul>
     *        <li>sLongTextKey : string Text key to be displayed in a formatted text view in a dialog.</li>
     *        <li>sTitleTextKey : string Text key to be displayed as the title of the dialog.</li>
     *        </ul>
     *        </li>
     *        <li>sTableId : string The if of the table (e.g. for busy indicators).</li>
     *        </ul>
     *        A data loss manager keeps (see {@link jd.ui.eid.common.DataLossManager}) keeps allows child controller to keep track of data changes.
     *        When a row is edit (see {@link #.handleEditRow}), the context of that row is cloned and assigned to the dialog model path maintained in
     *        the configuration (see above), so that the row in the table remains static while it's being added (cf. two-way binding).
     * @extends jd.ui.eid.view.BaseController
     * @static
     * @name jd.ui.eid.view.customizing.shell.BaseController
     */
    jd.ui.eid.view.customizing.shell.BaseController = {};

    // Inherit base controller
    $.extend(jd.ui.eid.view.customizing.shell.BaseController, jd.ui.eid.view.BaseController);

    /* Configuration */

    /**
     * Configuration object to be provided by subclasses.
     */
    jd.ui.eid.view.customizing.shell.BaseController._mConfig = {
        mFetchData : {
            // The name of the method to call on the service facade
            sMethodName : null
        },
        mSendData : {
            // Model path which should be passed to the method
            sPath : null,
            // The name of the method to call on the service facade
            sMethodName : null,
            // Text key to be displayed upon success
            sSuccessTextKey : null
        },
        mDialog : {
            // The id of the dialog
            sId : null,
            // The name of the fragment containing the dialog
            sFragment : null,
            // The path for binding the dialog's context
            sContextPath : null
        },
        mHelpDialog : {
            // Text key of the long text
            sLongTextKey : null,
            // Text key for the dialog title
            sTitleTextKey : null
        },
        // The id of the table (e.g. for busy indicators)
        sTableId : null
    };

    /* View Life Cycle */

    /**
     * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it is
     * displayed, to bind event handlers and do other one-time initialization.
     */
    jd.ui.eid.view.customizing.shell.BaseController.onInit = function() {
        var that = this;
        this._oView = this.getView();
        this._oView.addStyleClass("jdUiView jdUiEidViewAutoScroll");

        // Attach data loss manager so that we can check whether there's unsaved data on this
        // view.
        this._oDLM = jd.ui.eid.common.DataLossManager.createDataLossContextForControl(this._oView);
        this._oDLM.setSaveHandler(function(fnNavigationHandler) {
            that.sendData(fnNavigationHandler);
        });

        // Get references to instances of DTCBlacklistServiceFacade and
        // NotificationCenter
        this._oService = this.getServiceFacade("Customizing");
        this._oService.attachRequestFailed(this._onRequestFailed);

        this.onInitHookAfter();
    };

    /**
     * Hook method for scenario specific logic when initializing the controller.
     */
    jd.ui.eid.view.customizing.shell.BaseController.onInitHookAfter = function() {

    };

    /**
     * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
     */
    jd.ui.eid.view.customizing.shell.BaseController.onExit = function() {
        this.getDialogBox().destroy();
        this._oService.detachRequestFailed(this._onRequestFailed);
        this._oDLM.destroy();

        // Set properties to null
        this._oDialog = null;
        this._oDLM = null;
        this._oService = null;
        this._oView = null;
    };

    /**
     * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here. This
     * hook is the same one that SAPUI5 controls get after being rendered.
     */
    jd.ui.eid.view.customizing.shell.BaseController.onAfterRendering = function() {
        this.fetchData();
    };

    /* Misc */

    /**
     * This method returns the dialog box used by the controller.
     * 
     * @return {sap.ui.commons.Dialog}
     */
    jd.ui.eid.view.customizing.shell.BaseController.getDialogBox = function() {
        if (!this._oDialog) {
            this._oDialog = jd.ui.eid.xmlfragment(this._mConfig.mDialog.sId, this._mConfig.mDialog.sFragment, this);
            this._oDialog.bindElement(this._mConfig.mDialog.sContextPath);
            // Overwrite the open function so that we can call the hook method before the dialog actually opens.
            var that = this;
            this._oDialog.open = function() {
                that.handleDialogBeforeOpenHook.apply(that);
                sap.ui.commons.Dialog.prototype.open.apply(that._oDialog, arguments);
            };
        }
        return this._oDialog;
    };

    /* View Handling */

    /**
     * Handler for the edit control of a particular row
     * 
     * @param {sap.ui.base.Event}
     *            oEvent the event.
     */
    jd.ui.eid.view.customizing.shell.BaseController.handleEditRow = function(oEvent) {
        // Call hook for scenario specific stuff
        this.handleEditRowHookBefore(oEvent);

        var oDialogBox = this.getDialogBox();
        var oModel = sap.ui.getCore().getModel();

        // What we now do is take the remember the path of the row that we want to edit and copy the values into a separate path in the model. We do
        // this to prevent that the list item in the table is updated when the user changes the values in the dialog and to enable the cancel
        // functionality.
        this._sDialogPath = oEvent.getSource().getParent().getBindingContext().getPath();
        var sPath = this._mConfig.mDialog.sContextPath;
        var oCurrentValue = oModel.getProperty(this._sDialogPath);
        oModel.setProperty(sPath, jQuery.extend(true, {}, oCurrentValue));

        oDialogBox.open();

        // Call hook for scenario specific stuff
        this.handleEditRowHookAfter(oEvent);
    };

    /**
     * Hook method for scenario specific logic when handling editing a table row.
     * 
     * @param {sap.ui.base.Event}
     *            oEvent the event.
     */
    jd.ui.eid.view.customizing.shell.BaseController.handleEditRowHookBefore = function(oEvent) {

    };

    /**
     * Hook method for scenario specific logic when handling editing a table row.
     * 
     * @param {sap.ui.base.Event}
     *            oEvent the event.
     */
    jd.ui.eid.view.customizing.shell.BaseController.handleEditRowHookAfter = function(oEvent) {

    };

    /* Dialog Handling */

    /**
     * Closes dialog.
     */
    jd.ui.eid.view.customizing.shell.BaseController.handleDialogCancel = function() {
        this._oDialog.close();
    };

    /**
     * Hook method called before the dialog opens
     */
    jd.ui.eid.view.customizing.shell.BaseController.handleDialogBeforeOpenHook = function() {

    };

    /* Help Dialog Handling */

    jd.ui.eid.view.customizing.shell.BaseController.handleHelpButtonPress = function() {
        var sId = "HelpDialog";
        var oHelpDialog = null;
        oHelpDialog = new jd.ui.eid.xmlfragment(this.createId(sId), "jd.ui.eid.fragment.dialog.customizing.HelpDialog", {
            handleClose : function() {
                if (oHelpDialog.isOpen()) {
                    oHelpDialog.close();
                }
            },
            handleClosed : function(oEvent) {
                oEvent.getSource().detachClosed(this.handleClosed);
                oEvent.getSource().destroy();
            }
        });
        this.byId(sId, "Message").setHtmlText(jd.ui.eid.common.I18NHelper.getText(this._mConfig.mHelpDialog.sLongTextKey));
        oHelpDialog.setTitle(jd.ui.eid.common.I18NHelper.getText(this._mConfig.mHelpDialog.sTitleTextKey));
        oHelpDialog.open();
    };

    jd.ui.eid.view.customizing.shell.BaseController._getHelpDialog = function() {
    };

    /* Formatter */

    /**
     * Formats the visible row count from the given array.
     * 
     * @param {array}
     *            oArray Array of entries
     * @returns {int} the length of the array.
     */
    jd.ui.eid.view.customizing.shell.BaseController.formatVisibleRowCount = function(oArray) {
        if (oArray) {
            return oArray.length;
        }
    };

    /* Validation */

    /**
     * Validates the given text field for a mandatory numeric field.
     * 
     * @param {sap.ui.commons.TextField}
     *            oTextField the text field to validate.
     * @param {string}
     *            sRequiredTextKey text key to be displayed when the field is empty.
     * @param {string}
     *            sInvalidTextKey text key to be displayed when the field is invalid.
     * @returns {boolean} true if the field is valid, false otherwise.
     */
    jd.ui.eid.view.customizing.shell.BaseController.validateMandatoryNumericTextField = function(oTextField, sRequiredTextKey, sInvalidTextKey) {
        // oTextField.getValue() would return the value as displayed on the UI (formatted), so we use the binding to get the value from the model.
        var sValue = jQuery.trim(oTextField.getBinding("value").getValue());

        if (sValue != "" && (!isNaN(sValue))) {
            oTextField.setTooltip(null);
            oTextField.setValueState(sap.ui.core.ValueState.None);
            return true;
        } else {
            var sMsg;
            if (sValue == "") {
                sMsg = jd.ui.eid.common.I18NHelper.getText(sRequiredTextKey);
            } else {
                sMsg = jd.ui.eid.common.I18NHelper.getText(sInvalidTextKey);
            }

            var oCallout = new sap.ui.commons.Callout({
                content : new sap.ui.commons.TextView({
                    text : sMsg
                }).addStyleClass("jdUiTv")
            }).addStyleClass("jdUiClt");
            oTextField.setValueState(sap.ui.core.ValueState.Error);
            oTextField.setTooltip(oCallout);

            return false;
        }
    };

    /**
     * Validates the given text field for a mandatory field.
     * 
     * @param {sap.ui.commons.TextField}
     *            oTextField the text field to validate.
     * @param {string}
     *            sRequiredTextKey text key to be displayed when the field is empty.
     * @returns {boolean} true if the field is valid, false otherwise.
     */
    jd.ui.eid.view.customizing.shell.BaseController.validateMandatoryTextField = function(oTextField, sRequiredTextKey) {
        var sValue = jQuery.trim(oTextField.getValue());

        if (sValue != "") {
            oTextField.setTooltip(null);
            oTextField.setValueState(sap.ui.core.ValueState.None);
            return true;
        } else {
            var sMsg = jd.ui.eid.common.I18NHelper.getText(sRequiredTextKey);

            var oCallout = new sap.ui.commons.Callout({
                content : new sap.ui.commons.TextView({
                    text : sMsg
                }).addStyleClass("jdUiTv")
            }).addStyleClass("jdUiClt");
            oTextField.setValueState(sap.ui.core.ValueState.Error);
            oTextField.setTooltip(oCallout);

            return false;
        }
    };

    /* Service Interaction */

    /**
     * Sends the data back to the server in a generic fashion based on the data provided on <code>this._mConfig.mSendData</code>.
     * 
     * @param {function}
     *            [fnSuccess] Callback function called when data was successfully saved.
     */
    jd.ui.eid.view.customizing.shell.BaseController.sendData = function(fnSuccess) {
        var oModel = sap.ui.getCore().getModel();
        var oData = oModel.getProperty(this._mConfig.mSendData.sPath);

        var that = this;
        // Prepare callbacks
        var _fnSuccess = function() {
            var sSuccessText = jd.ui.eid.common.I18NHelper.getText(that._mConfig.mSendData.sSuccessTextKey);
            that.getNotificationCenter().success(sSuccessText);
            that._oDLM.reset();
            if (typeof fnSuccess == 'function') {
                fnSuccess();
            }
            that.getView().getParent().setBusy(false);
        };
        var fnError = function() {
            that.getView().getParent().setBusy(false);
            that._onRequestFailed.apply(this, arguments);
        };

        // Set shell (parent) to busy
        this.getView().getParent().setBusy(true);

        // Call the function
        var fnSend = this._oService[this._mConfig.mSendData.sMethodName];
        fnSend.apply(this._oService, [oData, _fnSuccess, fnError]);
    };

    /**
     * Fetches the data from the server in a generic fashion based on the data provided on <code>this._mConfig.mFetchData</code>.
     */
    jd.ui.eid.view.customizing.shell.BaseController.fetchData = function() {
        var that = this;
        var oTable = this.byId(this._mConfig.sTableId);
        // Prepare callbacks
        var fnSuccess = function() {
            oTable.setBusy(false);
        };
        var fnError = function() {
            var sErrorText = jd.ui.eid.common.I18NHelper.getText("MSG_REQUEST_FAILED");
            that.getNotificationCenter().alert(sErrorText);
            oTable.setBusy(false);
        };

        // set table to busy
        oTable.setBusy(true);

        // Call the function
        var fnFetch = this._oService[this._mConfig.mFetchData.sMethodName];
        fnFetch.apply(this._oService, [fnSuccess, fnError]);

        // Call hook method
        this.fetchDataHookAfter(fnError);
    };

    /**
     * Hook method for scenario specific logic when fetching data.
     * 
     * @param {function}
     *            fnError the error callback for possible reuse.
     */
    jd.ui.eid.view.customizing.shell.BaseController.fetchDataHookAfter = function(fnError) {
    };

    /* Utility */

    /**
     * Attaches an error text in a callout to the control provided and sets the value state.
     * 
     * @param {sap.ui.core.Control}
     *            oControl the control to attach the error to.
     * @param {string}
     *            sText the error text.
     */
    jd.ui.eid.view.customizing.shell.BaseController.attachErrorTooltipToControl = function(oControl, sText) {
        var oTooltip = oControl.getTooltip();
        if (oTooltip) {
            oTooltip.getContent()[0].setText(sMessage);
        } else {
            oControl.setTooltip(new sap.ui.commons.Callout({
                content : new sap.ui.commons.TextView({
                    text : sText
                }).addStyleClass("jdUiTv")
            })).addStyleClass("jdUiClt");
        }
        oControl.setValueState(sap.ui.core.ValueState.Error);

    };

    /**
     * Detaches and destroys callout assigned as tooltip for the control provided.
     * 
     * @param {sap.ui.core.Control}
     *            oControl the control to attach the error to.
     */
    jd.ui.eid.view.customizing.shell.BaseController.detachErrorTooltipFromControl = function(oControl) {
        var oTooltip = oControl.getTooltip();
        if (oTooltip) {
            oTooltip.destroy();
        }
        oControl.setTooltip(null);
        oControl.setValueState(sap.ui.core.ValueState.None);
    };

})();