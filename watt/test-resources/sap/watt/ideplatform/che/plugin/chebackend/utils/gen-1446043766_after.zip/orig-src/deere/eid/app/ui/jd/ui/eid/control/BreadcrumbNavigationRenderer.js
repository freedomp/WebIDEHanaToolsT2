(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.BreadcrumbNavigationRenderer");

    /**
     * @class Default renderer for control jd.ui.eid.control.BreadcrumbNavigation.
     * @static
     * @name jd.ui.eid.control.BreadcrumbNavigationRenderer
     */
    jd.ui.eid.control.BreadcrumbNavigationRenderer = {};

    /**
     * Render the control
     */
    jd.ui.eid.control.BreadcrumbNavigationRenderer.render = function(oRm, oControl) {

        // Initialize variable to save the breadcrumb navigation tooltip text
        var sBreadcrumbNavigationTooltip = "";
        var sBreadcrumbNavigationTooltipArrow = " > ";

        // Render bread crumb navigation bar
        oRm.write("<div ");
        oRm.addClass("jdUiEidBreadcrumbNavigation");
        oRm.writeClasses();
        oRm.writeControlData(oControl);
        oRm.write(">");

        // Get all items
        var aItems = oControl.getAggregation("breadcrumbs");

        // Check if items have been set
        if (aItems && aItems.length) {

            // Render first breadcrumb item
            oRm.write("<div");
            oRm.addClass("jdUiEidBreadcrumbContainer");
            oRm.writeClasses();

            // Additionally render the tooltip
            for ( var i = 0; i < aItems.length; i++) {
                if (i == 0) {
                    sBreadcrumbNavigationTooltip = aItems[i].getText();
                } else {
                    sBreadcrumbNavigationTooltip = sBreadcrumbNavigationTooltip + sBreadcrumbNavigationTooltipArrow + aItems[i].getText();
                }
            }

            oRm.writeAttribute("title", sBreadcrumbNavigationTooltip);

            oRm.write(">");
            oRm.write("<span");
            oRm.addClass("jdUiEidBreadcrumbStartingPoint");
            oRm.writeClasses();
            oRm.write("></span>");

            // Add an ellipsis item if the item length exceeds 2 items
            if (aItems.length > 2) {
                oRm.write("<span");
                oRm.addClass("jdUiEidBreadcrumbArrow");
                oRm.writeClasses();
                oRm.write(">");
                oRm.write("</span>");
                oRm.write("<span");
                oRm.writeAttribute("data-jd-ui-eid-breadcrumbId", i);
                oRm.write(">");
                oRm.write("&hellip;");
                oRm.write("</span>");
            }

            // Set the index of the first item that will be shown in the breadcrumb navigation
            var iIndex = 0;

            if (aItems.length > 2) {
                iIndex = aItems.length - 2;
            }

            // Render just the last 2 breadcrumbs
            for ( var i = iIndex; i < aItems.length; i++) {
                var oItem = aItems[i];
                oRm.write("<span");
                oRm.addClass("jdUiEidBreadcrumbArrow");
                oRm.writeClasses();
                oRm.write(">");
                oRm.write("</span>");
                oRm.write("<span");
                oRm.writeAttribute("data-jd-ui-eid-breadcrumbId", i);
                oRm.addClass("jdUiEidBreadcrumbItem");
                oRm.writeClasses();
                oRm.write(">");
                oRm.writeEscaped(oItem.getText());
                oRm.write("</span>");
            }

            oRm.write("</div>");
        }

        oRm.write("</div>");
    };

})();