DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_DTC_FILTER";

DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_ENGN_HOURS_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_TAG_CLOUD_FILTER";

-- Delete DTAC Item Records
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_ITEM";
  
-- Delete DTC Filters  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_BLD_FCTRY_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_BRANCH_CODE_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_DSGN_FCTRY_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_EMISSION_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_ENGN_HOURS_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_FUNCTIONAL_AREA_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_MACH_LOC_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_MODEL_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_PIN_FILTER";
  
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_DTC_FILTER";

-- Delete DTC Item records
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_ITEM";
    
-- Delete Warranty Filters 
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_WRNTY_ENGN_HOURS_FILTER";

-- Delete Warranty Item Records
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_ITEM";

-- Delete DTC Filter State
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTC_FILTER_STATE";

-- Delete Warranty Filter State	
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_FILTER_STATE";

-- Delete DTAC Filter State
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_FILTER_STATE";

-- Delete Evidence Package Machine Option Codes
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EP_MACHINE_OPTION_CODES";
  	
-- Delete Evidence Package header 
DELETE FROM "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H";
