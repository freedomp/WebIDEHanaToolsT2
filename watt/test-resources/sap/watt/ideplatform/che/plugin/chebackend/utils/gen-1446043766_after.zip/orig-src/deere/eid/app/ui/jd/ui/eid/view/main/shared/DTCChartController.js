(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.main.shared.DTCChartController");
    jQuery.sap.require("jd.ui.eid.common.chart.ChartHelper");

    /**
     * @class
     * <p>
     * The DTCChartController provides reusable functionality for the detail charts of a DTC.
     * </p>
     * <p>
     * The controller can be used in different scenarios. Either if there is only one set of charts (see {@link jd.ui.eid.view.main.shared.DTCDetails}).
     * Then, it needs to be initialized only once. If there are multiple sets of charts (e.g. {@link jd.ui.eid.view.main.evidencepackage.DTCSummary}
     * or {@link jd.ui.eid.view.print.EvidencePackage}), it can be initialized multiple times but with a different <code>_sParentFragmentId</code>
     * parameter.
     * </p>
     * <p>
     * The view has the following hook methods which need to be called from the consuming controller in the life cycle:
     * <ul>
     * <li>{@link #.initDTCChartController} has to be called from <code>onInit</code> after the <code>mDTCChartControllerConfig</code> has been
     * maintained. (Only applies if there is a set of charts.)</li>
     * <li>{@link #.onDTCChartControllerAfterRendering} has to be called from <code>onAfterRendering</code>.</li>
     * <li>{@link #.exitDTCChartController} has to be called from <code>onExit</code>. (Only applies if there is a set of charts).</li>
     * </ul>
     * </p>
     * <p>
     * Used in:
     * <ul>
     * <li>{@link jd.ui.eid.view.main.shared.DTCDetails}</li>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.DTCSummary}</li>
     * <li>{@link jd.ui.eid.view.print.EvidencePackage}</li>
     * </ul>
     * </p>
     * <p>
     * The merge controller provides the following config parameters under <code>mDTCChartControllerConfig</code>:
     * <ul>
     * <li>_bIsSetOfCharts : boolean (default: false) True if the controller serves a set of charts, false otherwise.</li>
     * <li>_fnKPISelectedCallback : function Callback function called when a KPI is selected from the menu of KPIs (for a KPI chart). The callback
     * receives the <code>sap.ui.base.Event</code> fired from the KPI menu and a reference to the DTCChartController.</li>
     * <li>_sKPIChart1Id : string the id assigned to the chart.</li>
     * <li>_sKPIChart2Id : string the id assigned to the chart.</li>
     * <li>_sAffectedPINsByEngineHourChartId : string the id assigned to the chart.</li>
     * <li>_sRelativeAmountOfAffectedPINsByDTCOccurencesChartId : string the id assigned to the chart.</li>
     * <li>_sNumberOfPINsByBuildDateChartId : string the id assigned to the chart.</li>
     * <li>_sDTCOccurenceByBuildDateChartId : string the id assigned to the chart.</li>
     * <li>_sAffectedPINsByCaptureTimeChartId : string the id assigned to the chart.</li>
     * <li>_sParentFragmentId : string (default: null) the id assigned to the fragment that contains the chart. All chart ids are resolved using this
     * parameter.</li>
     * </ul>
     * </p>
     * 
     * @static
     * @name jd.ui.eid.view.main.shared.DTCChartController
     */
    jd.ui.eid.view.main.shared.DTCChartController = {

        mDTCChartControllerConfig : {
            _bIsSetOfCharts : false,
            _fnKPISelectedCallback : null,
            _sKPIChart1Id : "DTCDetailsCompositeRanking",
            _sKPIChart2Id : "DTCDetailsCompositeRanking2",
            _sKPIIconRangeExceeded1Id : "iconRangeExceeded1",
            _sKPIIconRangeExceeded2Id : "iconRangeExceeded2",
            _sAffectedPINsByEngineHourChartId : "AffectedPINsByEngineHour",
            _sRelativeAmountOfAffectedPINsByDTCOccurencesChartId : "RelativeAmountOfAffectedPINsByDTCOccurences",
            _sNumberOfPINsByBuildDateChartId : "NumberOfPINsByBuildDate",
            _sDTCOccurenceByBuildDateChartId : "DTCOccurenceByBuildDate",
            _sAffectedPINsByCaptureTimeChartId : "AffectedPINsByCaptureTime",
            _sParentFragmentId : null
        },

        _aAllDTCCharts : null,
        _oAffectedPINsByCaptureTimeChart : null,
        _oAffectedPINsByEngineHourChart : null,
        _oDTCOccurenceByBuildDateChart : null,
        _oKPIChart1 : null,
        _oKPIChart1Title : null,
        _oKPIChart1RangeExceededIcon : null,
        _oKPIChart2 : null,
        _oKPIChart2Title : null,
        _oKPIChart2RangeExceededIcon : null,
        _oKPIMenu : null,
        _oKPIMenuAssociatedChart : null,
        _oKPIMenuAssociatedTitle : null,
        _oNumberOfPINsByBuildDateChart : null,
        _oRelativeAmountOfAffectedPINsByDTCOccurencesChart : null,
        _sKPIChart1KPIID : null,
        _sKPIChart2KPIID : null,

        /**
         * Initializes the DTCChartController. The can be initialized multiple times with different <code>_sParentFragmentId</code> parameters.
         */
        initDTCChartController : function() {
            $.sap.assert(!this.mDTCChartControllerConfig._bIsSetOfCharts, "initDTCChartController should only be called for a single set of charts");
            var sFragmentId = this.mDTCChartControllerConfig._sParentFragmentId;
            this.initDTCChartsInFragment(sFragmentId);
        },

        /**
         * Initializes the charts in the given fragment.
         * 
         * @param {string}
         *            sFragmentId the id assigned to the fragment containing the charts.
         */
        initDTCChartsInFragment : function(sFragmentId, sSelectedKPIID1, sSelectedKPIID2) {
            // Store references to all the charts
            this._oKPIChart1 = sap.ui.core.Fragment.byId(sFragmentId, this.mDTCChartControllerConfig._sKPIChart1Id);
            this._oKPIChart2 = sap.ui.core.Fragment.byId(sFragmentId, this.mDTCChartControllerConfig._sKPIChart2Id);
            this._oAffectedPINsByEngineHourChart = sap.ui.core.Fragment.byId(sFragmentId,
                    this.mDTCChartControllerConfig._sAffectedPINsByEngineHourChartId);
            this._oRelativeAmountOfAffectedPINsByDTCOccurencesChart = sap.ui.core.Fragment.byId(sFragmentId,
                    this.mDTCChartControllerConfig._sRelativeAmountOfAffectedPINsByDTCOccurencesChartId);
            this._oNumberOfPINsByBuildDateChart = sap.ui.core.Fragment.byId(sFragmentId,
                    this.mDTCChartControllerConfig._sNumberOfPINsByBuildDateChartId);
            this._oDTCOccurenceByBuildDateChart = sap.ui.core.Fragment.byId(sFragmentId,
                    this.mDTCChartControllerConfig._sDTCOccurenceByBuildDateChartId);
            this._oAffectedPINsByCaptureTimeChart = sap.ui.core.Fragment.byId(sFragmentId,
                    this.mDTCChartControllerConfig._sAffectedPINsByCaptureTimeChartId);
            this._aAllDTCCharts = [this._oKPIChart1, this._oKPIChart2, this._oAffectedPINsByEngineHourChart,
                    this._oRelativeAmountOfAffectedPINsByDTCOccurencesChart, this._oNumberOfPINsByBuildDateChart,
                    this._oDTCOccurenceByBuildDateChart, this._oAffectedPINsByCaptureTimeChart];
            this._oKPIChart1Title = sap.ui.core.Fragment.byId(sFragmentId, 'compositRankingTitle1');
            this._oKPIChart2Title = sap.ui.core.Fragment.byId(sFragmentId, 'compositRankingTitle2');

            this._oKPIChart1RangeExceededIcon = sap.ui.core.Fragment.byId(sFragmentId, this.mDTCChartControllerConfig._sKPIIconRangeExceeded1Id);
            this._oKPIChart2RangeExceededIcon = sap.ui.core.Fragment.byId(sFragmentId, this.mDTCChartControllerConfig._sKPIIconRangeExceeded2Id);
            this.turnOffDTCChartAnimations();
            this.bindKPICharts(sSelectedKPIID1, sSelectedKPIID2);
            this.setDTCChartHeight();
        },

        /**
         * Hook to be called in onAfterRendering.
         */
        onDTCChartControllerAfterRendering : function() {
            jd.ui.eid.common.chart.ChartHelper.rerenderCharts('jdDTCDetailsChart', this._aAllDTCCharts);
        },

        /**
         * Cleans up the merge controller. Should be called from <code>onExit</code>.
         */
        exitDTCChartController : function() {
            this._aAllDTCCharts = null;
            this._oAffectedPINsByCaptureTimeChart = null;
            this._oAffectedPINsByEngineHourChart = null;
            this._oDTCOccurenceByBuildDateChart = null;
            this._oKPIChart1 = null;
            this._oKPIChart1Title = null;
            this._oKPIChart1RangeExceededIcon = null;
            this._oKPIChart2 = null;
            this._oKPIChart2Title = null;
            this._oKPIChart2RangeExceededIcon = null;
            this._oKPIMenu = null;
            this._oKPIMenuAssociatedChart = null;
            this._oKPIMenuAssociatedTitle = null;
            this._oNumberOfPINsByBuildDateChart = null;
            this._oRelativeAmountOfAffectedPINsByDTCOccurencesChart = null;
            this._sKPIChart1KPIID = null;
            this._sKPIChart2KPIID = null;
        },

        /**
         * Turns the chart animations off.
         */
        turnOffDTCChartAnimations : function() {
            var bUseColorPalette = true;
            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oKPIChart1, "DECIMAL", bUseColorPalette);
            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oKPIChart2, "DECIMAL", bUseColorPalette);
            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oAffectedPINsByEngineHourChart, "INTEGER", bUseColorPalette);

            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oRelativeAmountOfAffectedPINsByDTCOccurencesChart, "PERCENTAGE",
                    bUseColorPalette);
            jd.ui.eid.common.chart.ChartHelper.prepareStackedVerticalBarChart(this._oNumberOfPINsByBuildDateChart, "INTEGER", bUseColorPalette);
            jd.ui.eid.common.chart.ChartHelper.prepareStackedVerticalBarChart(this._oDTCOccurenceByBuildDateChart, "INTEGER", bUseColorPalette);

            jd.ui.eid.common.chart.ChartHelper.prepareDualColumnChart(this._oAffectedPINsByCaptureTimeChart, bUseColorPalette, "PERCENTAGE",
                    "INTEGER");

        },

        /**
         * Set the height for charts
         */
        setDTCChartHeight : function() {
            this._aAllDTCCharts.forEach(function(oChart) {
                oChart.setHeight("300px");
            });
        },

        /**
         * Binds the KPI Charts with the correct path according the selected KPI.
         */
        bindKPICharts : function(sSelectedKPIID1, sSelectedKPIID2) {
            var mKPI1, mKPI2;
            if (sSelectedKPIID1) {
                mKPI1 = jd.ui.eid.model.EidModel.TransformationHelper.getKPIByKPIID(sSelectedKPIID1);
            } else {
                mKPI1 = jd.ui.eid.model.EidModel.TransformationHelper.getFirstActiveKPI();
            }
            if (sSelectedKPIID2) {
                mKPI2 = jd.ui.eid.model.EidModel.TransformationHelper.getKPIByKPIID(sSelectedKPIID2);
            } else {
                mKPI2 = jd.ui.eid.model.EidModel.TransformationHelper.getSecondActiveKPI();
            }

            this.updateKPIChartAndTitleFromKPI(mKPI1, this._oKPIChart1, this._oKPIChart1Title, this._oKPIChart1RangeExceededIcon);
            this.updateKPIChartAndTitleFromKPI(mKPI2, this._oKPIChart2, this._oKPIChart2Title, this._oKPIChart2RangeExceededIcon);
        },

        /**
         * Updates the binding and title of a KPI chart.
         * 
         * @param {object}
         *            mKPI
         * @param {sap.viz.ui5.BaseChart}
         *            oChart the chart to update.
         * @param {sap.ui.commons.TextView}
         *            the title control to update.
         * @param {sap.ui.common.Image}
         *            oIcon the icon for range exceeded
         */
        updateKPIChartAndTitleFromKPI : function(mKPI, oChart, oTitle, oIcon) {
            // Bind chart
            if (mKPI.KPIID) {
                var sPath = 'KPIsByCaptureTime/' + mKPI.KPIID + '/Records';
                oChart.getDataset().bindData(sPath);

                if (oChart == this._oKPIChart1) {
                    this._sKPIChart1KPIID = mKPI.KPIID;
                } else {
                    this._sKPIChart2KPIID = mKPI.KPIID;
                }

                // Update Range Exceeded Icon
                if (oIcon) {
                    // TODO add comment
                    var sIconPath = 'KPIsByCaptureTime/' + mKPI.KPIID + '/RangeExceeded';
                    oIcon.bindProperty('visible', sIconPath);
                }
            }
            // Update title
            oTitle.setText(jd.ui.eid.common.formatter.DTCFormatter.KPINameWithByCaptureTime(mKPI.KPIName));

        },

        /**
         * Updates the binding for the associated chart and its title.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the menu item.
         */
        handleKPISelect : function(oEvent) {
            var sSelectedKPIID = oEvent.getSource().getBindingContext().getProperty("KPIID");
            var sSelectedKPIName = oEvent.getSource().getBindingContext().getProperty("KPIName");
            this.updateKPIChartAndTitleFromKPI({
                KPIID : sSelectedKPIID,
                KPIName : sSelectedKPIName
            }, this._oKPIMenuAssociatedChart, this._oKPIMenuAssociatedTitle, this._oKPIMenuAssociatedIcon);

            if (typeof this.mDTCChartControllerConfig._fnKPISelectedCallback == "function") {
                this.mDTCChartControllerConfig._fnKPISelectedCallback(oEvent, this);
            }
        },

        /**
         * Opens the menu with KPI options and remembers the associated controls such as title and chart, so that they can be updated once a KPI is
         * selected.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the settings image.
         */
        handleOpenKPIMenu : function(oEvent) {
            var oImg = oEvent.getSource();
            var eDock = sap.ui.core.Popup.Dock;

            if (!this._oKPIMenu) {
                this._oKPIMenu = jd.ui.eid.xmlfragment("jd.ui.eid.fragment.dtc.details.DTCKPIMenu", this);
            }
            this._oKPIMenu.open(false, oImg.getFocusDomRef(), eDock.BeginTop, eDock.BeginBottom, oImg.getDomRef());

            // Remember the the chart and title associated to the menu.
            this._oKPIMenuAssociatedChart = oEvent.getSource().getParent().getContent()[3];
            this._oKPIMenuAssociatedTitle = oEvent.getSource().getParent().getContent()[0];
            this._oKPIMenuAssociatedIcon = oEvent.getSource().getParent().getContent()[2];
        },

        /**
         * Enables the legend for all charts in the panel rendered by the factory
         * 
         * @param {string}
         *            sId the prefix string used while instantiating the DTC summary template fragment.
         * @param {boolean}
         *            true, if legends should be shown. false, if legends should be hidden.
         */
        setDTCChartsLegendVisibility : function(sId, bVisible) {
            this._oKPIChart1.getLegend().setVisible(bVisible);
            this._oKPIChart2.getLegend().setVisible(bVisible);
            this._oAffectedPINsByEngineHourChart.getLegend().setVisible(bVisible);
            this._oRelativeAmountOfAffectedPINsByDTCOccurencesChart.getLegend().setVisible(bVisible);
            this._oNumberOfPINsByBuildDateChart.getLegend().setVisible(bVisible);
            this._oDTCOccurenceByBuildDateChart.getLegend().setVisible(bVisible);
            this._oAffectedPINsByCaptureTimeChart.getLegend().setVisible(bVisible);

        }

    };
})();