(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.TagCloudFilterItem");

    var oFilterItem = null;
    var oModel = null;
    var oTagTemplate = new jd.ui.eid.control.Tag({
        text : "{Tag}",
        weight : "{Score}"
    });
    var oData = {
        DomainValues : {
            TagCloud : [{
                Tag : "Engine",
                Score : 0.1
            }, {
                Tag : "Hydraulics",
                Score : 1
            }]
        },
        FilterSelection : {
            TagCloud : ["7s", "EIC", "R453Z", "Gear"]
        }
    };

    module("jd.ui.eid.control.TagCloudFilterItem", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(oData);
            oFilterItem = new jd.ui.eid.control.TagCloudFilterItem({
                tags : {
                    path : "/DomainValues/TagCloud",
                    template : oTagTemplate
                }
            });
            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    // *** TEST CASE #1 ***
    test("_clear() should set the selection property to an empty array.", function() {
        oFilterItem.bindProperty('selection', '/FilterSelection/TagCloud');

        // Initial assertions
        equals(oFilterItem.getSelection(), oData.FilterSelection.TagCloud);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertions
        deepEqual(oFilterItem.getSelection(), []);
    });

    // *** TEST CASE #2 ***
    test("_clear() should not call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertion
        ok(!spy.called);
    });

    // *** TEST CASE #3 ***
    test("addTag() should add a new tag to the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        var iOldTagCount = _tagCloud.getAggregation("tags").length;

        var oTag = new jd.ui.eid.control.Tag({
            text : "test3Tag",
            weight : 1
        });

        oFilterItem.addTag(oTag);
        var iNewTagCount = _tagCloud.getAggregation("tags").length;
        equal(iOldTagCount + 1, iNewTagCount);

    });

    // *** TEST CASE #4 ***
    test("destroyTags() should destroy all tags of the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        oFilterItem.destroyTags();
        var aTags = _tagCloud.getAggregation("tags");
        deepEqual(aTags, null);
    });

    // *** TEST CASE #5 ***
    test("getTags() should return all tags from the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        var aTags = _tagCloud.getTags();
        deepEqual(aTags, oFilterItem.getTags());
    });

    // *** TEST CASE #6 ***
    test("indexOfTag() should return the index of the tag in the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        var oTag = new jd.ui.eid.control.Tag({
            text : "test6Tag",
            weight : 1
        });
        _tagCloud.addTag(oTag);
        var iIndex = _tagCloud.indexOfTag(oTag);
        deepEqual(iIndex, oFilterItem.indexOfTag(oTag));
    });

    // *** TEST CASE #7 ***
    test("removeAllTags() should remove all tags from the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        oFilterItem.removeAllTags();
        var aTags = _tagCloud.getAggregation("tags");
        deepEqual(aTags, null);
    });

    // *** TEST CASE #8 ***
    test("removeTag() should remove a new tag from the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");
        var oTag = new jd.ui.eid.control.Tag({
            text : "test8Tag",
            weight : 1
        });
        _tagCloud.addTag(oTag);
        var iOldTagCount = _tagCloud.getAggregation("tags").length;
        oFilterItem.removeTag(oTag);
        var iNewTagCount = _tagCloud.getAggregation("tags").length;
        equal(iOldTagCount - 1, iNewTagCount);

    });

    // *** TEST CASE #9 ***
    test("insertTag() should add a tag to a specific index in the _tagCloud aggregation", function() {
        var _tagCloud = oFilterItem.getAggregation("_tagCloud");

        var oTag = new jd.ui.eid.control.Tag({
            text : "test9Tag",
            weight : 1
        });

        oFilterItem.insertTag(oTag, 1);
        var oTag2 = _tagCloud.getTags()[1];
        deepEqual(oTag, oTag2);

    });

    // *** TEST CASE #10 ***
    test("_handleTagSelected() should add a selected tag to the selection property", function() {
        var oEvent = new sap.ui.base.Event("TagCloudFilterItemTestCase10", this, {
            tag : {
                "Tag" : "test",
                "Score" : 12
            }
        });
        oFilterItem.setProperty('selection', []);
        oFilterItem._handleTagSelected(oEvent);
        var aSelection = oFilterItem.getSelection();
        equal(aSelection.length, 1);
    });

    // *** TEST CASE #11 ***
    test("_handleTagSelected() should raise the event valueChanged", function() {
        var fnHandleValueChanged = sinon.spy();
        oFilterItem.attachValueChanged(fnHandleValueChanged);
        var oEvent = new sap.ui.base.Event("TagCloudFilterItemTestCase11", this, {
            tag : {
                "Tag" : "test",
                "Score" : 12
            }
        });
        oFilterItem.setProperty('selection', []);
        oFilterItem._handleTagSelected(oEvent);
        ok(fnHandleValueChanged.called);
    });

    // *** TEST CASE #12 ***
    test("setSelection() should set the property selection", function() {
        oFilterItem.setProperty('selection', []);
        var aTags = ["7s", "EIC", "R453Z", "Gear"];
        oFilterItem.setSelection(aTags);
        var aSelection = oFilterItem.getProperty('selection');
        deepEqual(aSelection, aTags);
    });

    // *** TEST CASE #13 ***
    test("setSelection() should add the tags to the breadcrumb navigation", function() {
        oFilterItem.setProperty('selection', []);
        var aTags = ["7s", "EIC", "R453Z", "Gear"];
        oFilterItem.setSelection(aTags);
        var aBreadcrumbs = oFilterItem.getAggregation("_breadcrumbNavigation").getBreadcrumbs();
        deepEqual(aBreadcrumbs.length, aTags.length);
    });

})();