(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WorkSheetFormatter");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EvidencePackageSaveController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DTCFilterAreaDelegate");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    /**
     * @class
     * <p>
     * The worksheet view enables the user to work with a single evidence package.
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#WorksheetView::close} : Notifies the overlay to close the view</li>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} : Raised while navigating to another view</li>
     * <li>{@link jd.ui.eid.Events#EvidencePackage::newDTCFiltersApplied} : Notifies all views to update their data after the DTC filter changed</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.main.Worksheet
     */
    sap.ui.controller("jd.ui.eid.view.main.Worksheet", jQuery
            .extend(true, {}, jd.ui.eid.view.BaseController, jd.ui.eid.view.main.shared.EvidencePackageSaveController,

                    /** @lends jd.ui.eid.view.main.Worksheet */
                    {
                        /**
                         * Confiuration for the evidence basket tiles at the upper right corner.
                         */
                        mEvidencePackageBasketConfig : {
                            DTCBasket : {
                                fnTableHeaderFormatter : jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTCQuickviewTitle,
                                oQuickView : null,
                                sFragmentId : "DTCQuickViewFragment",
                                sFragmentName : "jd.ui.eid.fragment.worksheet.DTCQuickView",
                                sItems : "DTCCodeList",
                                sOpenerId : "DTCBasket"
                            },
                            DTACCaseBasket : {
                                fnTableHeaderFormatter : jd.ui.eid.common.formatter.WorkSheetFormatter.formatDTACCaseQuickviewTitle,
                                oQuickView : null,
                                sFragmentId : "DTACCaseQuickViewFragment",
                                sFragmentName : "jd.ui.eid.fragment.worksheet.DTACCaseQuickView",
                                sItems : "DTACCaseList",
                                sOpenerId : "DTACCaseBasket"
                            },
                            WarrantyClaimBasket : {
                                fnTableHeaderFormatter : jd.ui.eid.common.formatter.WorkSheetFormatter.formatWarrantyClaimQuickviewTitle,
                                oQuickView : null,
                                sFragmentId : "WarrantyClaimQuickViewFragment",
                                sFragmentName : "jd.ui.eid.fragment.worksheet.WarrantyClaimQuickView",
                                sItems : "WarrantyClaimList",
                                sOpenerId : "WarrantyClaimBasket"
                            }
                        },

                        _oDLM : null,
                        _oDialogEditPackageNameBeforeSave : null,
                        _oDialogSimulateNewDTCFilter : null,
                        _oDiscoverIssuesView : null,
                        _oDTACCaseQuickView : null,
                        _oDTCFilterAreaDelegate : null,
                        _oDTCQuickView : null,
                        _oEvidenceView : null,
                        _oEvidencePackageService : null,
                        _oFilterDomainValueService : null,
                        _oPersonalizationService : null,
                        _oProcessStep : null,
                        _oView : null,
                        _oWarrantyClaimQuickView : null,
                        _oWorksheet : null,
                        _oWorksheetContent : null,
                        _oWorksheetMode : null,
                        _sCurrentContentView : null,

                        /* SECTION - View Lifecycle - START */

                        /**
                         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify
                         * the View before it is displayed, to bind event handlers and do other one-time initialization.
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onInit : function() {
                            this._oView = this.getView();
                            this._oView.addStyleClass("jdUiEidViewWorksheet");
                            this._oWorksheet = this.byId("Worksheet");
                            this._oProcessStep = this.byId("ProcessStep");
                            this._oWorksheetContent = this.byId("WorksheetContent");

                            // Config
                            this.mEvidencePackageSaveControllerConfig.aBusyControls = [this._oView.getContent()[0]];
                            this.mEvidencePackageSaveControllerConfig.aDisabledControlsWhileSave = [this.byId("SAVEREVIEW"), this.byId("SAVE")];

                            // Subscribe to event which is triggered in the DTCList.controller if the filter area should be edited
                            var oEventBus = sap.ui.getCore().getEventBus();
                            oEventBus.subscribe('EvidencePackage', 'editDTCFilter', this.onDTCFilterChange, this);
                            oEventBus.subscribe('Navigation', 'navigating', this.handleNavigation, this);

                            this._oEvidencePackageService = this.getServiceFacade("EvidencePackage");
                            this._oFilterDomainValueService = this.getServiceFacade("FilterDomainValue");
                            this._oPersonalizationService = this.getServiceFacade("PersonalizationFilters");
                            this._oPersonalizationService.attachRequestFailed(this._onRequestFailed);

                            // Attach data loss manager so that we can check whether there's unsaved data on this
                            // view.
                            var that = this;
                            this._oDLM = jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance();
                            this._oDLM.setSaveHandler(function(fnNavigationHandler) {
                                that.onSaveSelected();
                            });

                            // Initialize merge controllers
                            this.initEvidencePackageSaveController();
                        },

                        /**
                         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onExit : function() {
                            // Exit merged controllers
                            this.exitEvidencePackageSaveController();

                            // Unsubcribe from event bus
                            var oEventBus = sap.ui.getCore().getEventBus();
                            oEventBus.unsubscribe('EvidencePackage', 'editDTCFilter', this.onDTCFilterChange, this);
                            oEventBus.unsubscribe('Navigation', 'navigating', this.handleNavigation, this);

                            // Detach events
                            this._oPersonalizationService.detachRequestFailed(this._onRequestFailed);

                            // Destroy delegates
                            this._oDTCFilterAreaDelegate.destroy();

                            // Destroy controls
                            if (this._oDialogEditPackageNameBeforeSave) {
                                this._oDialogEditPackageNameBeforeSave.destroy();
                            }
                            if (this._oDialogSimulateNewDTCFilter) {
                                this._oDialogSimulateNewDTCFilter.destroy();
                            }
                            if (this._oDiscoverIssuesView) {
                                this._oDiscoverIssuesView.destroy();
                            }
                            if (this._oDTACCaseQuickView) {
                                this._oDTACCaseQuickView.destroy();
                            }
                            if (this._oDTCQuickView) {
                                this._oDTCQuickView.destroy();
                            }
                            if (this._oEvidenceView) {
                                this._oEvidenceView.destroy();
                            }
                            if (this._oWarrantyClaimQuickView) {
                                this._oWarrantyClaimQuickView.destroy();
                            }

                            // Set properties to null
                            this._oDialogEditPackageNameBeforeSave = null;
                            this._oDialogSimulateNewDTCFilter = null;
                            this._oDiscoverIssuesView = null;
                            this._oDTACCaseQuickView = null;
                            this._oDTCFilterAreaDelegate = null;
                            this._oDTCQuickView = null;
                            this._oEvidenceView = null;
                            this._oEvidencePackageService = null;
                            this._oFilterDomainValueService = null;
                            this._oPersonalizationService = null;
                            this._oProcessStep = null;
                            this._oView = null;
                            this._oWarrantyClaimQuickView = null;
                            this._oWorksheet = null;
                            this._oWorksheetContent = null;
                            this._oWorksheetMode = null;
                        },

                        /* SECTION - View Lifecycle - END */

                        setContext : function(vParam) {
                            var oModel = sap.ui.getCore().getModel();
                            if (vParam instanceof Object) {
                                // We're lodaing an evidence package
                                var that = this;
                                var iEvidencePackageID = vParam.EvidencePackageID;

                                if (iEvidencePackageID == oModel.getProperty("/EvidencePackageDetails/Header/PackageID")) {
                                    // The evidence package has already been loaded, we're probably coming from the evidence package summary
                                    var sMode = oModel.getProperty("/EvidencePackageDetails/Header/LastView");
                                    // Open the evidence package with mode the last mode
                                    this._setModeAndView(sMode);
                                } else {
                                    var bIsCopy = vParam.Copy === true;

                                    // Set empty mode until we've loaded the evidence package
                                    this._setModeAndView(jd.ui.eid.view.main.Worksheet.Mode.NoContent);
                                    jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay().close();

                                    this._oEvidencePackageService.getEvidencePackageDetails(iEvidencePackageID, function(oData) {
                                        var sMode = oData.Result.LastView;

                                        if (bIsCopy) {
                                            var oModel = sap.ui.getCore().getModel();
                                            var oEvidencePackageDetailsHeader = oData.Result;

                                            // clear the evidence package id, so that save service creates a new id
                                            oEvidencePackageDetailsHeader.PackageID = -1;

                                            // set status to open (might be closed)
                                            var eOpen = jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Open;
                                            oEvidencePackageDetailsHeader.PackageStatus = eOpen;

                                            // make the package mine
                                            oEvidencePackageDetailsHeader.PackageOwnedByCurrentUser = 1;
                                            // rename package name to 'Copy of <Package Name>'
                                            var sOldPackageName = oEvidencePackageDetailsHeader.PackageName;
                                            var sNewPackageName = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_TXT_TITLE_COPY_OF",
                                                    [oEvidencePackageDetailsHeader.PackageName]);
                                            oEvidencePackageDetailsHeader.PackageName = sNewPackageName;

                                            oModel.setProperty("/EvidencePackgeDetails/Header", oEvidencePackageDetailsHeader);
                                            oModel.setProperty("/EvidencePackgeDetails/Header/PackageName", sNewPackageName);

                                            // Inform DLM about data change in
                                            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
                                        }

                                        // Open the evidence package with mode the last mode
                                        that._setModeAndView(sMode);

                                        // calculate missing machine option codes
                                        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.calculateMissingMachineOptionCodes();

                                    }, function() {
                                        // Error callback
                                        oModel.setProperty("/EvidencePackageDetails/Header", {});
                                        that._onRequestFailed.apply(that, arguments);
                                        sap.ui.getCore().getEventBus().publish("WorksheetView", "close");
                                    });
                                }
                            } else {
                                // We're just setting the mode
                                this._setModeAndView(vParam);
                            }
                        },

                        _setModeAndView : function(iMode) {
                            this.setMode(iMode);
                            switch (iMode) {
                                case jd.ui.eid.view.main.Worksheet.Mode.NoContent :
                                    this._oWorksheetContent.removeAllContent();
                                    this._oWorksheet.setBusy(true);
                                    break;
                                case jd.ui.eid.view.main.Worksheet.Mode.DTACCases :
                                case jd.ui.eid.view.main.Worksheet.Mode.WarrantyClaims :
                                    this._oWorksheet.setBusy(false);
                                    this.showLookForEvidence();
                                    break;
                                case jd.ui.eid.view.main.Worksheet.Mode.DTCs :
                                default :
                                    this._oWorksheet.setBusy(false);
                                    this.showDiscoverIssue();
                                    break;
                            }
                        },

                        /**
                         * Setting the mode for the work sheet. The mode decides which view should be displayed
                         * 
                         * @param {jd.ui.eid.view.main.Worksheet.Mode}
                         *            iMode the mode of the worksheet.
                         * @param {integer}
                         *            [iMode.EvidencePackageID] the evidence package id to load
                         * @param {boolean}
                         *            [iMode.Copy=false] true if the evidence package should be copied, false otherwise.
                         */
                        setMode : function(iMode) {
                            this._oWorksheetMode = iMode;
                            sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails/Header/LastView", iMode);

                        },

                        /**
                         * Returns mode (required when saving the "LastView" property of the evidence package)
                         * 
                         * @returns {jd.ui.eid.view.main.Worksheet.Mode}
                         */
                        getMode : function() {
                            // return to Evidence Package Review Overview
                            return this._oWorksheetMode;

                        },

                        /**
                         * Handles the navigating event of the content views DTAC Case List and Warranty Claim List. Maintains the worksheet's mode.
                         * 
                         * @param {string}
                         *            sChannelId the channel id
                         * @param {string}
                         *            sEventId the event name
                         * @param {object}
                         *            oData the data passed along with the event.
                         * @see jd.ui.eid.Events#Navigation::navigating
                         */
                        handleNavigation : function(sChannelId, sEventId, oData) {
                            // Check if the event was fired during the navigation between DTACCaseList and
                            // WarrantyClaimsByPrimePartList
                            if (oData.origin == "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList"
                                    && oData.target == "jd.ui.eid.view.main.worksheet.evidence.DTACCaseList") {
                                this.setMode(jd.ui.eid.view.main.Worksheet.Mode.DTACCases);
                            } else if (oData.origin == "jd.ui.eid.view.main.worksheet.evidence.DTACCaseList"
                                    && oData.target == "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList") {
                                this.setMode(jd.ui.eid.view.main.Worksheet.Mode.WarrantyClaims);
                            }
                        },

                        /**
                         * Prepares the worksheet for process step "Discover Issue"
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        showDiscoverIssue : function() {
                            // Set the process step in the header left area
                            this._oProcessStep.bindProperty("text", "i18n>WORKSHEET_HED_DISCOVER_ISSUES");

                            // Initializing Discover Issues view
                            var sDiscoverIssuesView = "jd.ui.eid.view.main.worksheet.discovery.DTCList";
                            if (!this._oDiscoverIssuesView) {
                                this._oDiscoverIssuesView = jd.ui.eid.xmlview("DiscoverIssues", sDiscoverIssuesView);
                            }
                            this._oWorksheetContent.removeAllContent();
                            this._oWorksheetContent.addContent(this._oDiscoverIssuesView);

                            // Raise the navigating event to notify the content view to update the data
                            sap.ui.getCore().getEventBus().publish("Navigation", "navigating", {
                                origin : this._sCurrentContentView,
                                target : sDiscoverIssuesView
                            });

                            // Set the current content view
                            this._sCurrentContentView = sDiscoverIssuesView;

                            // Maintain button states
                            this.byId("LOOK").setVisible(true);
                            this.byId("DISCOVER").setVisible(false);
                            this.byId("SAVEREVIEW").setVisible(false);
                        },

                        /**
                         * Prepares the worksheet for process step "Discover Issue"
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        showLookForEvidence : function() {
                            // Set the process step in the header left area
                            this._oProcessStep.bindProperty("text", "i18n>WORKSHEET_HED_LOOK_FOR_EVIDENCE");

                            // Set the evidence view as the worksheet content
                            var sEvidenceView = "jd.ui.eid.view.main.worksheet.Evidence";
                            if (this._oEvidenceView == null) {
                                this._oEvidenceView = jd.ui.eid.xmlview(sEvidenceView);
                            }
                            this._oWorksheetContent.removeAllContent();
                            this._oWorksheetContent.addContent(this._oEvidenceView);

                            // Determine the subview (content of the navigationitem) in the evidence view regarding the current mode
                            var sSubView = null;
                            if (this.getMode() == jd.ui.eid.view.main.Worksheet.Mode.DTACCases) {
                                sSubView = "jd.ui.eid.view.main.worksheet.evidence.DTACCaseList";
                            } else if (this.getMode() == jd.ui.eid.view.main.Worksheet.Mode.WarrantyClaims) {
                                sSubView = "jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList";
                            }

                            // Raise the navigating event to notify the content view to update the data. This is e.g. required when
                            // opening an
                            // existing
                            // evidence package in edit mode. Then, the user should see the screen where he last left off.
                            sap.ui.getCore().getEventBus().publish("Navigation", "navigating", {
                                origin : this._sCurrentContentView,
                                target : sEvidenceView,
                                parameters : sSubView
                            });

                            // Set the current content view
                            this._sCurrentContentView = sEvidenceView;

                            // Maintain button status
                            this.byId("LOOK").setVisible(false);
                            this.byId("DISCOVER").setVisible(true);
                            this.byId("SAVEREVIEW").setVisible(true);
                        },

                        /**
                         * Event handler for cancel button of the worksheet
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onCancel : function(oEvent) {
                            var that = this;
                            var oEvidencePackageSummaryOverlay = jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay();
                            // Raise Data Loss Manager only if the Summary is also closed
                            if (this._oDLM && !oEvidencePackageSummaryOverlay.isOpen()) {
                                // If data is clean, we will display the content view for the selected workset item.
                                this._oDLM.setNavigationHandler(function() {
                                    // When we continue to navigate, either the changes have been saved or they are deliberately
                                    // discarded, so reset
                                    // the DLM.
                                    that._oDLM.reset();

                                    if (!oEvidencePackageSummaryOverlay.isOpen()) {
                                        var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade(
                                                "EvidencePackage");
                                        oEvidencePackageServiceFacade.MachineOptionCalculation.abortAllServices();
                                    }

                                    that._closeWorksheetView();
                                });

                                // If data is dirty, we will reset the selected workset item on the shell.
                                this._oDLM.setCancelHandler(null);

                                this._oDLM.notifyOrNavigate();
                            } else {
                                that._closeWorksheetView();
                            }
                        },

                        /**
                         * Close the Worksheet View
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        _closeWorksheetView : function() {
                            // Abort all pending requests which have been fired at GetEvidencePackageDetails
                            var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");
                            oEvidencePackageServiceFacade.abortPendingGetEvidencePackageDetailsRequests();
                            // fire event mainly for WorksheetOverlayController
                            sap.ui.getCore().getEventBus().publish('WorksheetView', 'close');
                        },

                        /**
                         * Event handler for saving the evidence package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         */
                        onSaveSelected : function(oEvent) {
                            this.saveEvidencePackage(jd.ui.eid.view.main.shared.EvidencePackageSaveController.EvidencePackageSaveDialogButton.Save);
                        },

                        /**
                         * Event handler for save the evidence package and return to evidence package list
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         */
                        onSaveAndReviewSelected : function(oEvent) {
                            // This will be handeled in the overlay helper when openeing the overlay to check, whether it should be displayed as level
                            // 2 (i.e. intended overlay above the worksheet), or not. However, we want to evidence pacakge overlay to be a level 1
                            // overlay because we're closing the worksheet once the new overlay is visible.
                            jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay().data("forceLevel1", true);

                            var that = this;
                            this.saveEvidencePackage(
                                    jd.ui.eid.view.main.shared.EvidencePackageSaveController.EvidencePackageSaveDialogButton.SaveAndReview,
                                    function() {
                                        that.reviewEvidencePackageDetails();
                                        // If the user navigates to the evidence package view via 'save and review', we close the worksheet
                                        that._closeWorksheetView();
                                    });
                        },

                        /**
                         * Review the evidence package by opening the Evidence Package view for the current evidence package header.
                         */
                        reviewEvidencePackageDetails : function() {
                            var oModel = sap.ui.getCore().getModel();
                            var iEvidencePackageID = oModel.getProperty("/EvidencePackageDetails/Header/PackageID");
                            var oEvidencePackageDetailsOverlay = jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay();
                            oEvidencePackageDetailsOverlay.setContext(iEvidencePackageID);
                            if (!oEvidencePackageDetailsOverlay.isOpen()) {
                                oEvidencePackageDetailsOverlay.open();
                            }

                        },

                        /**
                         * Event handler for look for evidence view
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onShowLookForEvidenceSelected : function(oEvent) {
                            this.setMode(jd.ui.eid.view.main.Worksheet.Mode.DTACCases);
                            this.showLookForEvidence();
                        },

                        /**
                         * Event handler for issue discovery view
                         * 
                         * @param {sap.ui.base.Event}
                         * @memberOf jd.ui.eid.view.main.Worksheet oEvent the fired event
                         */
                        onBackToIssueDiscoverySelected : function(oEvent) {
                            this.setMode(jd.ui.eid.view.main.Worksheet.Mode.DTCs);
                            this.showDiscoverIssue();
                        },

                        /**
                         * Generic method to handle an evidence basket. Lazy-loads the basket fragment, prepares it for display and opens the popup.
                         * 
                         * @see jd.ui.eid.view.main.Worksheet.mEvidencePackageBasketConfig
                         * @param {object}
                         *            mConfig the config object for the basekt
                         */
                        _handleBasketSelected : function(mConfig) {
                            if (!mConfig.oQuickView) {
                                // Create the quick view instance in lazy-loading.
                                mConfig.oQuickView = jd.ui.eid.xmlfragment(mConfig.sFragmentId, mConfig.sFragmentName, this);
                                mConfig.oQuickView.setOpener(this.byId(mConfig.sOpenerId));

                                // This is some magic to add autoClose behavior which otherwise doesn't work properly in UI5 1.16.5
                                // when having a
                                // table (and sorting, problem: popups in popups).
                                // So what this basically does is that when the popup is open, and one clicks outside of the tool
                                // popup, it closes.
                                var fn = function(oEvent) {
                                    var bClickedOutside = true;
                                    var iPopupXMin = mConfig.oQuickView.$().offset().left;
                                    var iPopupXMax = iPopupXMin + mConfig.oQuickView.$().outerWidth(true);
                                    var iPopupYMin = mConfig.oQuickView.$().offset().top;
                                    var iPopupYMax = iPopupYMin + mConfig.oQuickView.$().outerHeight(true);
                                    if (oEvent.pageX >= iPopupXMin && oEvent.pageX <= iPopupXMax && oEvent.pageY >= iPopupYMin
                                            && oEvent.pageY <= iPopupYMax) {
                                        bClickedOutside = false;
                                    }
                                    if (mConfig.oQuickView.isOpen()
                                            && sap.ui.getCore().byId(mConfig.oQuickView.getOpener()).$().find($(oEvent.target)).length == 0
                                            && bClickedOutside) {
                                        mConfig.oQuickView.close();
                                    }
                                };
                                // We also register to buttons, because they would stop the event bubbling.
                                mConfig.oQuickView.attachOpen(function(oEvent) {
                                    $("body, button").bind("click", fn);
                                });
                                mConfig.oQuickView.attachClose(function(oEvent) {
                                    $("body, button").unbind("click", fn);
                                });
                            }

                            if (mConfig.oQuickView.isOpen()) {
                                mConfig.oQuickView.close();
                            } else {
                                mConfig.oQuickView.open(sap.ui.core.Popup.Dock.EndTop, sap.ui.core.Popup.Dock.CenterBottom);
                                // We set the toolbar after Quick View as a
                                // workaround to enable correct auto close behavior
                                // from ToolPopup
                                var oTable = sap.ui.core.Fragment.byId(mConfig.sFragmentId, "Table");
                                oTable.setToolbar(new sap.ui.commons.Toolbar({
                                    items : [new sap.ui.commons.TextView({
                                        text : {
                                            path : '/EvidencePackageDetails/Header/' + mConfig.sItems,
                                            formatter : mConfig.fnTableHeaderFormatter,
                                            parameters : {
                                                bIsArrayCountBinding : true
                                            }
                                        }
                                    }).addStyleClass("jdUiTv jdUiEidTableHeader")]
                                }).addStyleClass("jdUiTb"));
                            }
                        },

                        /**
                         * Event handler for clicking on the DTC Basket to show a Quick View of the basket items
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onDTCBasketSelected : function(oEvent) {
                            this._handleBasketSelected(this.mEvidencePackageBasketConfig.DTCBasket);
                        },

                        /**
                         * Event handler for clicking on the DTAC Basket to show a Quick View of the basket items
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         */
                        onDTACCaseBasketSelected : function(oEvent) {
                            return this._handleBasketSelected(this.mEvidencePackageBasketConfig.DTACCaseBasket);
                        },

                        /**
                         * Event handler for clicking on the Warranty Claim Basket to show a Quick View of the basket items
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onWarrantyClaimBasketSelected : function(oEvent) {
                            this._handleBasketSelected(this.mEvidencePackageBasketConfig.WarrantyClaimBasket);
                        },

                        /**
                         * Event handler to return to evidence package list
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onReviewEvidencePackage : function(oEvent) {
                            // return to Evidence Package Review Overview
                            this.reviewEvidencePackageDetails();
                        },

                        /**
                         * Event handler for clicking on the PIN Population Basket to edit the DTC Filter Area
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onDTCFilterChange : function(oEvent) {
                            // DTC Filter Change
                            if (this._oPINPopulationDialog == null) {
                                // We create the Dialog Fragment. Inside we bound the Filter Area Fragment as next step
                                var sPINPopulationDialogFragmentId = this.createId("PINPopulationFragment");
                                this._oPINPopulationDialog = jd.ui.eid.xmlfragment(sPINPopulationDialogFragmentId,
                                        "jd.ui.eid.fragment.worksheet.PINPopulationDialog", this);

                                var sFilterAreaFragmentId = sap.ui.core.Fragment.createId(sPINPopulationDialogFragmentId, "FilterArea");

                                this._oPINPopulationDialog.attachClosed(this.onCancelDTCFilterChange, this);

                                // Create the delegate object for the DTC Filter fragment
                                this._oDTCFilterAreaDelegate = new jd.ui.eid.common.delegate.DTCFilterAreaDelegate({
                                    fragmentId : sFilterAreaFragmentId,
                                    filterAreaCleared : [this.handleFilterAreaCleared, this],
                                    filterAreaReset : [this.handleFilterAreaReset, this],
                                    filterItemValueChanged : [this.handleFilterItemValueChanged, this],
                                    filterItemCleared : [this.handleFilterItemCleared, this],
                                    domainValuePath : "/SimulatedEvidencePackageDetails/_DTCFilters",
                                    selectionPath : "/SimulatedEvidencePackageDetails/Header/DTCFilterSelection",
                                    filterStatePath : "/SimulatedEvidencePackageDetails/Header/DTCFilterState"
                                }).setModel(sap.ui.getCore().getModel());

                                // Create the DTC Filter Area Fragment
                                var oFilterArea = jd.ui.eid.xmlfragment(sFilterAreaFragmentId, "jd.ui.eid.fragment.filter.DTCFilterArea",
                                        this._oDTCFilterAreaDelegate);

                                // we pass the fragment object to the delegate to work with
                                this._oDTCFilterAreaDelegate.setFilterArea(oFilterArea);

                                // finally we set the filter area into the Dialog
                                sap.ui.core.Fragment.byId(sPINPopulationDialogFragmentId, "FilterAreaPlaceholder").addContent(oFilterArea);
                            }
                            if (this._oPINPopulationDialog.isOpen()) {
                                this._oPINPopulationDialog.close();
                            } else {
                                // Change the Domain Value path of the FilterArea because we are just simulating
                                if (oFilterArea) {
                                    oFilterArea.bindElement("/SimulatedEvidencePackageDetails/_DTCFilters");
                                }

                                this._oPINPopulationDialog.open();
                                // We have to set the property after the Dialog is rendered as the bindProperty-method does not work
                                // when
                                // Possible Improvement: Defer the 'setProperty' method to the event handling of 'isOpened' once it is
                                // available
                                // in the next UI version
                                var oModel = sap.ui.getCore().getModel();
                                var oEvidencePackageFilterSelection = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterSelection");
                                var oEvidencePackageFilterState = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterState");
                                var oEvidencePackageDTCFilters = oModel.getProperty("/EvidencePackageDetails/_DTCFilters");
                                oModel.setProperty("/SimulatedEvidencePackageDetails/Header/DTCFilterSelection", jQuery.extend(true, {},
                                        oEvidencePackageFilterSelection));
                                oModel.setProperty("/SimulatedEvidencePackageDetails/Header/DTCFilterState", jQuery.extend(true, {},
                                        oEvidencePackageFilterState));
                                oModel.setProperty("/SimulatedEvidencePackageDetails/_DTCFilters", jQuery
                                        .extend(true, {}, oEvidencePackageDTCFilters));
                                // Switch on/off the filter area controls dependent of the platform and product line selection
                                this.handleControlStateBasedOnModelState();
                            }
                        },

                        /* SECTION - Event Handler for Fragment "PINPopulationDialog" - START */

                        /**
                         * Handles the valueChanged event of the filter items to send a request if the user edits the DTC Filter Area inside the
                         * evidence package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event fired.
                         */
                        handleFilterItemValueChanged : function(oEvent) {
                            var that = this;
                            var oModel = sap.ui.getCore().getModel();
                            // Due to the fact that the /SimulatedEvidencePackageDetails/Header is just a subset of the complete
                            // /EvidencePackageDetails/Header we merge them for the payload of service call getEvidencePackagePINPopulation().
                            var oEvidencePackageDetailsHeader = jQuery.extend(true, {}, oModel.getProperty("/EvidencePackageDetails/Header"));
                            var oSimulatedEvidencePackageDetailsHeader = oModel.getProperty("/SimulatedEvidencePackageDetails/Header");
                            var oEvidencePackageHeader = jQuery.extend(true, oEvidencePackageDetailsHeader, oSimulatedEvidencePackageDetailsHeader);

                            if (this._oDTCFilterAreaDelegate.isReadyToFetchDependentData()) {
                                // Get the Id of the Fragement
                                var sPINPopulationDialogFragmentId = this.createId("PINPopulationFragment");
                                // Get the Id of the FilterArea
                                var sFilterAreaId = this._oDTCFilterAreaDelegate.getFragmentId();
                                if (oEvent.getParameter("filterFragment") == sap.ui.core.Fragment.byId(sFilterAreaId, "Platforms")) {

                                    // Get the Dialog object
                                    var oDialog = sap.ui.core.Fragment.byId(sPINPopulationDialogFragmentId, "Dialog");

                                    // Set the dialog to busy until we have the new domain values
                                    oDialog.setBusy(true);

                                    // The 'platform and product line' filter item changed, so we need to retrieve the domain values
                                    // anew.
                                    var oSelection = oEvent.getParameter("filterFragment").getSelection();
                                    var sPlatform = oSelection[0].PlatformID;
                                    var sProductLine = oSelection[0].ProductLine[0];

                                    // Also, let's reset the DTC filter selection model of the dependent filters.
                                    jd.ui.eid.model.EidModel.TransformationHelper.initializeDepedentDTCFilterSelection(this._oDTCFilterAreaDelegate
                                            .getSelectionPath());

                                    /*
                                     * Trigger service call to update the DTCFilterDomainValues
                                     */
                                    // call service to fetch the new domain values for the model path "/SimulatedEvidencePackageDetails/_DTCFilters"
                                    var mParameters = {
                                        "sAlternateTargetPath" : "/SimulatedEvidencePackageDetails/_DTCFilters/DomainValues"
                                    };
                                    var $getDTCFilterDomainValues = this._oFilterDomainValueService.getDTCFilterDomainValues(sPlatform, sProductLine,
                                            null, this._onRequestFailed, mParameters);

                                    /*
                                     * Trigger service call to get the new PINPopulation
                                     */
                                    // Therefore we are calling getEvidencePackagePINPopulation
                                    // Execute the service call
                                    var $getEvidencePackagePINPopulation = this._oEvidencePackageService.getEvidencePackagePINPopulation(
                                            oEvidencePackageHeader, "/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", null,
                                            that._onRequestFailed);

                                    // Once both requests have completed successfully call the passed success function
                                    $.when($getDTCFilterDomainValues, $getEvidencePackagePINPopulation).done(function() {
                                        oDialog.setBusy(false);
                                    });
                                } else {
                                    /*
                                     * Trigger service call to get the new PINPopulation
                                     */
                                    this._oEvidencePackageService.getEvidencePackagePINPopulation(oEvidencePackageHeader,
                                            "/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", null, that._onRequestFailed);
                                }
                            }
                            // Switch on/off the filter area controls dependent of the platform and product line selection
                            this.handleControlStateBasedOnModelState();
                        },

                        /**
                         * Handles the event if user changes the package description
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event.
                         */
                        onDescriptionChanged : function(oEvent) {
                            // Inform DLM about data change in
                            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
                        },

                        /**
                         * Handles the event if user changes the package name
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event.
                         */
                        onTitleChanged : function(oEvent) {
                            // Inform DLM about data change in
                            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
                        },

                        /**
                         * Handles the clear action from the filter area's tool popup and clears the filter area.
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event.
                         */
                        handleFilterAreaCleared : function(oEvent) {
                            sap.ui.getCore().getModel().setProperty("/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", 0);
                            this.handleFilterItemValueChanged(oEvent);
                        },

                        /**
                         * Handles the cleared event of the filter items to send a request.
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event fired.
                         */
                        handleFilterItemCleared : function(oEvent) {
                            this.handleFilterItemValueChanged(oEvent);
                        },

                        /**
                         * Initializes/Resets the filter domain/selection values and applies the user's filter personalization settings
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the event.
                         */
                        handleFilterAreaReset : function(oEvent) {

                            var sFilterAreaId = this._oDTCFilterAreaDelegate.getFragmentId();
                            var oController = this;
                            var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "FilterArea");
                            if (oController.getApplication().getParameters().applyPersonalization) {
                                oFilterArea.setBusy(true);
                            }

                            // Define the error function for the service calls
                            var fnError = function() {
                                // If an error occurred
                                sap.ui.getCore().getModel().setProperty("/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", 0);
                                oController._onRequestFailed();
                                oFilterArea.setBusy(false);
                            };

                            // Define the success function for the getPlatformAndProductLine service call
                            var fnSuccess = function() {
                                if (oController.getApplication().getParameters().applyPersonalization) {
                                    // Apply personalization
                                    oController._oPersonalizationService.applyPersonalization(
                                            "/SimulatedEvidencePackageDetails/Header/DTCFilterSelection",
                                            "/SimulatedEvidencePackageDetails/Header/DTCFilterState", function(oData) {
                                                // If pers. was applied
                                                oController.handleControlStateBasedOnModelState();
                                                /*
                                                 * Trigger service call to get the new PINPopulation
                                                 */
                                                // Due to the fact that the /SimulatedEvidencePackageDetails/Header is just a subset of the complete
                                                // /EvidencePackageDetails/Header we merge them for the service call which fetches the new
                                                // PINPopulation
                                                var oEvidencePackageDetailsHeader = jQuery.extend(true, {}, sap.ui.getCore().getModel().getProperty(
                                                        "/EvidencePackageDetails/Header"));
                                                var oSimulatedEvidencePackageDetailsHeader = sap.ui.getCore().getModel().getProperty(
                                                        "/SimulatedEvidencePackageDetails/Header");
                                                var oEvidencePackageHeader = jQuery.extend(true, oEvidencePackageDetailsHeader,
                                                        oSimulatedEvidencePackageDetailsHeader);

                                                // Execute the service call
                                                oController._oEvidencePackageService.getEvidencePackagePINPopulation(oEvidencePackageHeader,
                                                        "/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", function(oData) {
                                                            oFilterArea.setBusy(false);
                                                        }, fnError);
                                            }, function() {
                                                // If pers. is unavailable
                                                oController.handleControlStateBasedOnModelState();
                                                sap.ui.getCore().getModel().setProperty("/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation",
                                                        0);
                                                oFilterArea.setBusy(false);
                                            }, function() {
                                                // If an error occurred
                                                oController.handleControlStateBasedOnModelState();
                                                fnError();
                                            });
                                } else {
                                    oController.handleControlStateBasedOnModelState();
                                };
                            };

                            /*
                             * Trigger service call to reset the filter area
                             */
                            this._oFilterDomainValueService.getPlatformAndProductLine(fnSuccess, fnError);
                        },

                        /**
                         * Handles the states of the controls on the work sheet based on the current state of the model. This covers setting filter
                         * items to invisible if no platform and product line have been selected.
                         */
                        handleControlStateBasedOnModelState : function() {
                            // Get the reference to the simulate button
                            var oButtonSimulate = sap.ui.core.Fragment.byId(this.createId("PINPopulationFragment"), "SimulateButton");

                            if (this._oDTCFilterAreaDelegate.isPlatformAndProductlineSelected()) {

                                // Platform and Product line selected. So make the controls visible
                                this._oDTCFilterAreaDelegate.setVisibilityOfDependentFilterItems(true);
                                // enable the simulate button
                                oButtonSimulate.setEnabled(true);

                            } else {

                                // no platform and product line have been selected, so let's make all other filter items invisible.
                                this._oDTCFilterAreaDelegate.setVisibilityOfDependentFilterItems(false);
                                // clear the PINPopulation
                                sap.ui.getCore().getModel().setProperty("/SimulatedEvidencePackageDetails/_DTCFilters/PINPopulation", 0);
                                // disable the simulate button
                                oButtonSimulate.setEnabled(false);

                            }
                        },

                        /**
                         * Event handler for simulating the DTC Filter change inside the Evidence Package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onSimulateDTCFilterChange : function(oEvent) {
                            // set filter to busy and disable the button 'siumlate' while backend service is running
                            this.setPINPopulationDialogToBusy(true);

                            // load fragment
                            if (this._oDialogSimulateNewDTCFilter == null) {
                                this._oDialogSimulateNewDTCFilter = jd.ui.eid.xmlfragment("DialogSimulateNewDTCFilter",
                                        "jd.ui.eid.fragment.worksheet.DialogSimulateNewDTCFilter", this);
                            }
                            var that = this;

                            var oNewDTCSelection = sap.ui.getCore().getModel().getProperty(
                                    "/SimulatedEvidencePackageDetails/Header/DTCFilterSelection");
                            var oNewDTCFilterState = sap.ui.getCore().getModel()
                                    .getProperty("/SimulatedEvidencePackageDetails/Header/DTCFilterState");
                            var oEvidencePackageDetails = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");
                            // we call the dialog within the success function
                            var fnSuccess = function() {
                                // close DTC Filter Area popup
                                if (that._oPINPopulationDialog.isOpen()) {
                                    that._oPINPopulationDialog.close();
                                }
                                that.setPINPopulationDialogToBusy(false);
                                // open the result dialog popup
                                if (!that._oDialogSimulateNewDTCFilter.isOpen()) {
                                    that._oDialogSimulateNewDTCFilter.open();
                                }
                            };

                            var fnFailed = function() {
                                that.setPINPopulationDialogToBusy(false);
                                that._onRequestFailed();
                            };
                            // call backend service
                            this._oEvidencePackageService.simulateNewDTCFilters(oNewDTCSelection, oNewDTCFilterState, oEvidencePackageDetails,
                                    fnSuccess, fnFailed);
                        },

                        setPINPopulationDialogToBusy : function(bBusy) {
                            /**
                             * Sets DTC Filter Area to busy/not busy and Button "Simulate" to enabled/disabled
                             * 
                             * @param {boolean}
                             *            bBusy when true, DTC filter area gets white and button 'simulate' is disabled. When false, otherwise
                             * 
                             * @memberOf jd.ui.eid.view.main.Worksheet
                             */
                            var oButtonSimulate = sap.ui.core.Fragment.byId(this.createId("PINPopulationFragment"), "SimulateButton");

                            if (bBusy) {
                                oButtonSimulate.setEnabled(false);
                                // this._oDTCFilterAreaDelegate.setBusy(true);
                                this._oPINPopulationDialog.setBusy(true);
                            } else {
                                oButtonSimulate.setEnabled(true);
                                // this._oDTCFilterAreaDelegate.setBusy(false);
                                this._oPINPopulationDialog.setBusy(false);
                            }
                        },
                        /* SECTION - Event Handler for Fragment "PINPopulationDialog" - END */

                        /* SECTION - Event Handler for Fragment "DialogSimulateNewDTCFilter" - START */
                        /**
                         * Event handler for applying the changed DTC Filter for the Evidence Package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onApplyDTCFilterChange : function(oEvent) {
                            var oModel = sap.ui.getCore().getModel();
                            var oEvidencePackageServiceFacade = this.getServiceFacade("EvidencePackage");

                            // applySimulatedEvidencePackage to path '/EvidencePackageDetails/Header'
                            jd.ui.eid.model.EidModel.TransformationHelper.applySimulatedEvidencePackage();

                            // recalculate machine option codes
                            var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
                            var aDTCIDList = oEvidencePackageServiceFacade.convertDTCCodeList(oEvidencePackageDetailsHeader.DTCCodeList);
                            oEvidencePackageServiceFacade.calculateMachineOptionCodesForDTC(aDTCIDList,
                                    oEvidencePackageDetailsHeader.DTCFilterSelection);

                            // Inform DLM about data change in
                            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);

                            if (this._oDialogSimulateNewDTCFilter.isOpen()) {
                                this._oDialogSimulateNewDTCFilter.close();
                                // cancel backend service request (to prevent the second dialog popping up)
                                this._oEvidencePackageService.cancelPendingRequestForServicePath("xs/evidence/EvidencePackageApplyFilter.xsjs");
                                this.setPINPopulationDialogToBusy(false);
                            }

                            // Publish the DTCFiltersChanged event
                            sap.ui.getCore().getEventBus().publish("EvidencePackage", "newDTCFiltersApplied");
                        },

                        /**
                         * Event handler for canceling the DTC Filter change
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onCancelDTCFilterChange : function(oEvent) {
                            // Close the Dialog PINPopulation if it is open
                            if (this._oPINPopulationDialog && this._oPINPopulationDialog.isOpen()) {
                                this._oPINPopulationDialog.close();
                            };
                        },

                        /**
                         * Event handler for canceling the simulation of changed DTC Filters for the Evidence Package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onCancelApplyDTCFilterChange : function(oEvent) {
                            // Close the Dialog SimulateNewDTCFilter if it is open
                            if (this._oDialogSimulateNewDTCFilter && this._oDialogSimulateNewDTCFilter.isOpen()) {
                                this._oDialogSimulateNewDTCFilter.close();
                                // cancel backend service request (to prevent the second dialog popping up)
                                this._oEvidencePackageService.cancelPendingRequestForServicePath("xs/evidence/EvidencePackageApplyFilter.xsjs");
                            }

                            // Always close the Dialog PINPopulation if it is open
                            if (this._oPINPopulationDialog && this._oPINPopulationDialog.isOpen()) {
                                this._oPINPopulationDialog.close();
                            };
                        },

                        /* SECTION - Event Handler for Fragment "DialogSimulateNewDTCFilter" - END */
                        /**
                         * Event handler for clicking a DTC inside the Quick View
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onDTCSelected : function(oEvent) {
                            var oSelectedDTCListItem = oEvent.getSource().getBindingContext().getProperty();
                            var oDTCDetailOverlayRegular = jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayRegular();
                            oDTCDetailOverlayRegular.setContext(oSelectedDTCListItem.DTCID);
                            if (!oDTCDetailOverlayRegular.isOpen()) {
                                oDTCDetailOverlayRegular.open();
                            }
                        },

                        /**
                         * Event handler for clicking a DTAC Case inside the Quick View
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onDTACCaseSelected : function(oEvent) {
                            var oSelectedDTACCaseListItem = oEvent.getSource().getBindingContext().getProperty();
                            var oDTACCaseDetailsOverlay = jd.ui.eid.common.OverlayHelper.getDTACCaseDetailsOverlay();
                            oDTACCaseDetailsOverlay.setContext(oSelectedDTACCaseListItem.DTACCaseNumber);
                            if (!oDTACCaseDetailsOverlay.isOpen()) {
                                oDTACCaseDetailsOverlay.open();
                            }
                        },

                        /**
                         * Event handler for clicking a Warranty Claim inside the Quick View
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        onWarrantyClaimSelected : function(oEvent) {
                            var oSelectedWarrantyClaimListItem = oEvent.getSource().getBindingContext().getProperty();
                            var oWarrantyClaimDetailsOverlay = jd.ui.eid.common.OverlayHelper.getWarrantyClaimDetailsOverlay();
                            oWarrantyClaimDetailsOverlay.setContext(oSelectedWarrantyClaimListItem.WarrantyClaimSequenceNumber,
                                    oSelectedWarrantyClaimListItem.JDLinkActive);
                            if (!oWarrantyClaimDetailsOverlay.isOpen()) {
                                oWarrantyClaimDetailsOverlay.open();
                            }
                        },

                        /**
                         * Event handler to remove a DTC from the evidence package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        handleDeleteDTCfromBasket : function(oEvent) {

                            var oSelectedDTCListItem = oEvent.getSource().getBindingContext().getProperty();

                            // Callback function for confirmation to delete dialog
                            var fnOnDeleteConfirmation = function(bConfirmed) {
                                if (bConfirmed) {
                                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTC(oSelectedDTCListItem.DTCID);
                                }
                            };

                            // Get confirmation from user before proceeding
                            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CONFIRM_DELETE_DTC",
                                    [oSelectedDTCListItem.DTCCode]);
                            this.getNotificationCenter().confirm(sConfirmationMessage, $.proxy(fnOnDeleteConfirmation, this));
                        },

                        /**
                         * Event handler to remove a DTAC from the evidence package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        handleDeleteDTACCasefromBasket : function(oEvent) {

                            var oSelectedDTACListItem = oEvent.getSource().getBindingContext().getProperty();
                            var fnOnDeleteConfirmation = function(bConfirmed) {
                                if (bConfirmed) {
                                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTACCase(oSelectedDTACListItem);
                                }
                            };
                            // Get confirmation from user before proceeding
                            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CONFIRM_DELETE_DTAC_CASE",
                                    [oSelectedDTACListItem.DTACCaseNumber]);
                            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);
                        },

                        /**
                         * Event handler to remove a Warranty Claim from the evidence package
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event
                         * 
                         * @memberOf jd.ui.eid.view.main.Worksheet
                         */
                        handleDeleteWarrantyClaimfromBasket : function(oEvent) {

                            var oSelectedWarrantyClaimListItem = oEvent.getSource().getBindingContext().getProperty();
                            var fnOnDeleteConfirmation = function(bConfirmed) {
                                if (bConfirmed) {
                                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeWarrantyClaim(oSelectedWarrantyClaimListItem);
                                }
                            };
                            // Get confirmation from user before proceeding
                            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CONFIRM_DELETE_WARRANTY_CLAIM",
                                    [oSelectedWarrantyClaimListItem.WarrantyClaimNumber]);
                            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);
                        },

                        /* Formatter */

                        /**
                         * Handles the change event of the evidence package name InPlaceEdit control and updates the model. This cannot be done via
                         * two-way binding because of the formatter.
                         */
                        handleEvidencePackageNameChange : function(oEvent) {
                            var sValue = oEvent.getParameter("newValue");
                            if (sValue == jd.ui.eid.common.I18NHelper.getText("WORKSHEET_TXT_TITLE_PLACEHOLDER")) {
                                sValue = "";
                            }
                            sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails/Header/PackageName", sValue);
                        },

                        /**
                         * Handles the change event of the evidence package description InPlaceEdit control and updates the model. This cannot be done
                         * via two-way binding because of the formatter.
                         */
                        handleEvidencePackageDescriptionChange : function(oEvent) {
                            var sValue = oEvent.getParameter("newValue");
                            if (sValue == jd.ui.eid.common.I18NHelper.getText("WORKSHEET_TXT_DESCRIPTION_PLACEHOLDER")) {
                                sValue = "";
                            }
                            sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails/Header/PackageDescription", sValue);
                        },

                        /**
                         * Formats the evidence package name for the InPlaceEdit functionality. Returns a placeholder text if the actual name is
                         * empty.
                         * 
                         * @param {string}
                         *            sEvidencePackageName the name of the evidence package.
                         * @returns {string} the name of the evidence package or a placeholder text.
                         */
                        formatEvidencePackageNameForIPE : function(sEvidencePackageName) {
                            sEvidencePackageName = $.trim(sEvidencePackageName);
                            if (!sEvidencePackageName) {
                                return jd.ui.eid.common.I18NHelper.getText("WORKSHEET_TXT_TITLE_PLACEHOLDER");
                            } else {
                                return sEvidencePackageName;
                            }
                        },

                        /**
                         * Formats the evidence package description for the InPlaceEdit functionality. Returns a placeholder text if the actual
                         * description is empty.
                         * 
                         * @param {string}
                         *            sEvidencePackageDescription the description of the evidence package.
                         * @returns {string} the description of the evidence package or a placeholder text.
                         */
                        formatEvidencePackageDescriptionForIPE : function(sEvidencePackageDescription) {
                            sEvidencePackageDescription = $.trim(sEvidencePackageDescription);
                            if (!sEvidencePackageDescription) {
                                return jd.ui.eid.common.I18NHelper.getText("WORKSHEET_TXT_DESCRIPTION_PLACEHOLDER");
                            } else {
                                return sEvidencePackageDescription;
                            }
                        }
                    }));

    // The mode is saved with the evidence package details header data.
    // The mode decides which view should be opened when the user likes to edit a saved evidence package
    jd.ui.eid.view.main.Worksheet = {};

    jd.ui.eid.view.main.Worksheet.Mode = {
        NoContent : "0", // this mode is needed to display the worksheet while the content of the worksheet is still loading
        DTCs : "1", // Discovery Issue
        DTACCases : "2", // Look for Evidence -> Part DTAC Cases
        WarrantyClaims : "3" // Look for Evidence -> Part Warranty Claims
    };
})();