(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.chart.ChartHelper");
    jQuery.sap.require("jd.ui.eid.common.DateHelper");
    /**
     * This helper class provides methods for rendering charts
     * 
     * @name jd.ui.eid.common.chart.ChartHelper
     * @extends sap.ui.base.Object
     */
    jd.ui.eid.common.chart.ChartHelper = {};

    /**
     * This function rerenders the viz charts with time out, this is required as workaround, otherwise viz.chart will not be displayed within overlay
     * container, details see note 1932686
     * 
     * 
     * @param {string}
     *            sClass css class of the charts
     * @param {array}
     *            aCharts array of chart objects
     */
    jd.ui.eid.common.chart.ChartHelper.rerenderCharts = function(sClass, aCharts) {
        var $charts = $('.' + sClass);
        var bChartNotDisplayed = false;
        for ( var i = 0; i < $charts.length; i++) {
            var $chart = $charts[i];
            if ($chart && $($chart).children('div').css("display") == "none") {
                bChartNotDisplayed = true;
                break;
            }
        }

        if (true || bChartNotDisplayed) {
            setTimeout(function() {
                for ( var i = 0; i < aCharts.length; i++) {
                    aCharts[i].invalidate();
                }
            }, 0);
        }
    };

    /**
     * create the plotArea for different chart, in which the animation shall be turned off
     * 
     * currently is not possible to turn off the animation of sap viz Chart in the XMLview definition, hence we need to define the aggregation of
     * plotArea w/o animation and assign this aggregation to viz. control programmatically.
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param {string}
     *            sChartType chart type like Column, Pie,Line
     * @param {bool}
     *            bUsseColorPalette usage of Color Palette
     */
    jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation = function(oChart, sChartType, bUseColorPalette) {
        var oPlotArea = null;
        var oAnimation = null;

        switch (sChartType) {
            case "VerticalBar" || "DualColumn" :
                oPlotArea = new sap.viz.ui5.types.VerticalBar();
                if (bUseColorPalette) {
                    oPlotArea.setColorPalette(["#477998"]);
                }
                oAnimation = new sap.viz.ui5.types.VerticalBar_animation();
                break;
            case "StackedVerticalBar" :
                oPlotArea = new sap.viz.ui5.types.StackedVerticalBar();
                if (bUseColorPalette) {
                    oPlotArea.setColorPalette(["#477998", "#CC051C", "#291F1E", "#F64740"]);
                }
                oAnimation = new sap.viz.ui5.types.StackedVerticalBar_animation();
                break;
            case "DualColumn" :
                oPlotArea = new sap.viz.ui5.types.VerticalBar();
                if (bUseColorPalette) {
                    oPlotArea.setColorPalette(["#477998", "#CC051C"]);
                    oPlotArea.setPrimaryValuesColorPalette(["#291F1E", "#CC051C", "#291F1E", "#F64740"]);
                    oPlotArea.setSecondaryValuesColorPalette(["#F64740", "#291F1E", "#CC051C", "#291F1E"]);
                }
                oAnimation = new sap.viz.ui5.types.VerticalBar_animation();
                break;
            case "Line" :
                oPlotArea = new sap.viz.ui5.types.Line();
                oPlotArea.setColorPalette(["#477998", "#CC051C", "#291F1E", "#F64740"]);
                oAnimation = new sap.viz.ui5.types.Line_animation();
                break;
            case "Pie" :
                oPlotArea = new sap.viz.ui5.types.Pie();
                oPlotArea.setColorPalette(["#477998", "#CC051C", "#291F1E", "#F64740"]);
                oAnimation = new sap.viz.ui5.types.Pie_animation();
                break;
            case "DualCombination" :
                oPlotArea = new sap.viz.ui5.types.Combination();
                oPlotArea.setPrimaryValuesColorPalette(["#291F1E", "#CC051C", "#291F1E", "#F64740"]);
                oPlotArea.setSecondaryValuesColorPalette(["#F64740", "#291F1E", "#CC051C", "#291F1E"]);
                oAnimation = new sap.viz.ui5.types.Combination_animation();

        };
        oAnimation.setResizing(false);
        oAnimation.setDataLoading(false);
        oAnimation.setDataUpdating(false);

        oPlotArea.setAnimation(oAnimation);

        return oChart.setPlotArea(oPlotArea);
    };

    /**
     * set the value format of in Y-axis and in tooltip for given chart object
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param{string} sFormatName name of measure format: "Integer", "DECIMAL", "PERCENTAGE"
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareChartWithSingleValueFormat = function(oChart, sFormatName) {
        var sFormat = jd.ui.eid.common.chart.ChartHelper.getFormat(sFormatName);
        var oTooltip = oChart.getToolTip();
        var oYAxis = oChart.getYAxis();

        var oLabel = oYAxis.getLabel();
        oLabel.setFormatString([[sFormat]]);
        oTooltip.setFormatString([[sFormat]]);
        return oChart;
    };

    /**
     * set the value format both in primary and secondary Y-axis and in tooltip for given chart object
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param{string} sFormatName1 name of format of first measure: "Integer", "DECIMAL", "PERCENTAGE"
     * @param{string} sFormatName1 name of format for second measure: "Integer", "DECIMAL", "PERCENTAGE"
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareChartWithDualValueFormat = function(oChart, sFormatName1, sFormatName2) {
        var sFormat1 = jd.ui.eid.common.chart.ChartHelper.getFormat(sFormatName1);
        var sFormat2 = jd.ui.eid.common.chart.ChartHelper.getFormat(sFormatName2);
        var oTooltip = oChart.getToolTip();
        var oYAxis1 = oChart.getYAxis();
        var oYAxis2 = oChart.getYAxis2();

        var oLabel1 = oYAxis1.getLabel();
        var oLabel2 = oYAxis2.getLabel();

        oLabel1.setFormatString([[sFormat1]]);
        oLabel2.setFormatString([[sFormat2]]);
        oTooltip.setFormatString([[sFormat1], [sFormat2]]);
        return oChart;
    };

    /**
     * convert the format name into internal format specification
     * 
     * @param{string} sFormatName: the name of format
     * @return{string} the internal format specification
     */
    jd.ui.eid.common.chart.ChartHelper.getFormat = function(sFormatName) {
        var sIntegerFormat = "";
        var sDecimalFormat = "";
        var sPercentageFormat = "";

        var sLanguage = jd.ui.eid.common.DateHelper.getLocale();
        // setup the languate dependent format for values
        switch (sLanguage) {
            case "en" :
                sIntegerFormat = "##,##0";
                sDecimalFormat = "##,##0.00%";
                sPercentageFormat = "##,##0.00%";
                break;
            case "de" :
                sIntegerFormat = "##.##0";
                sDecimalFormat = "##.##0,00%";
                sPercentageFormat = "##.##0,00%";
                break;
            default :
                sIntegerFormat = "##,##0";
                sDecimalFormat = "##,##0.00%";
                sPercentageFormat = "##,##0.00%";
                break;
        }

        // return the format
        switch (sFormatName) {
            case "INTEGER" :
                return sIntegerFormat;
                break;
            case "DECIMAL" :
                return sDecimalFormat;
                break;
            case "PERCENTAGE" :
                return sPercentageFormat;
                break;
            default :
                return sIntegerFormat;
                break;
        }
    };

    /**
     * prepare the vertical bar chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param{string[]} oColorPalette array of color palette
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart = function(oChart, sFormat, bUseColorPallete) {
        oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithSingleValueFormat(oChart, sFormat);
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'VerticalBar', bUseColorPallete);
    };

    /**
     * prepare the dual vertical bar chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param{string[]} oColorPalette array of color palette
     * @param{string} sFormatName1 the format of the first measure
     * @param{string} sFormatName2 the format of the second measure
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareDualColumnChart = function(oChart, bUseColorPallete, sFormatName1, sFormatName2) {
        oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithDualValueFormat(oChart, sFormatName1, sFormatName2);
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'DualColumn', bUseColorPallete);
    };

    /**
     * prepare the stacked vertical bar chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @param{string[]} oColorPalette array of color palette
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareStackedVerticalBarChart = function(oChart, bUseColorPallete) {
        oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithSingleValueFormat(oChart);
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'StackedVerticalBar', bUseColorPallete);
    };

    /**
     * prepare the Line chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareLineChart = function(oChart) {
        oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithSingleValueFormat(oChart);
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'Line', null);
    };

    /**
     * prepare the Pie chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.preparePieChart = function(oChart) {
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'Pie', null);
    };

    /**
     * prepare the dual combination chart: set the value format and turn off the animation
     * 
     * @param{sap.viz.ui5.core.BaseChart} oChart the chart object
     * @return{sap.viz.ui5.core.BaseChart} the chart object
     */
    jd.ui.eid.common.chart.ChartHelper.prepareDualCombinationChart = function(oChart) {
        // oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithSingleValueFormat(oChart);
        oChart = jd.ui.eid.common.chart.ChartHelper.prepareChartWithDualValueFormat(oChart);
        return jd.ui.eid.common.chart.ChartHelper.createPlotAreaWithoutAnimation(oChart, 'DualCombination', true);
    };

    /**
     * Adds a CSS class to the column at the given index of the column chart.
     * 
     * @param {sap.viz.ui5.Column}
     *            oChart the column chart.
     * @param {int}
     *            iColumnIndex the column to which the class should be assigned (starting with 0).
     * @param {string}
     *            sClassName the class name.
     */
    jd.ui.eid.common.chart.ChartHelper.addClassToNthColumnOfColumnChart = function(oChart, iColumnIndex, sClassName) {
        var $chart = oChart.$();
        var iNthColumn = iColumnIndex + 1;
        if ($chart[0]) {
            var el = $chart.find(".v-column:nth-child(" + iNthColumn + ") .v-datapoint")[0];
            if (el) {
                // jQuery's addClass doesn't work :( Neither does prop(). attr() would work, but that's deprecated, so let's go with native JS to
                // append a class.
                el.setAttribute("class", el.getAttribute("class") + " " + sClassName);
            }
        }
    };

})()