(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.WaitPrintStep");
    jQuery.sap.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new WaitPrintStep.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>chartRenderAreaId : string (default: '') the id of the chart area element (should be hidden, the chart control will be rendered there).</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>chartPrintContainer : jd.ui.eid.control.ChartPrintContainer the chart print container to be managed by the step.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The WaitPrintStep manages a single {@link jd.ui.eid.control.ChartPrintContainer} control and triggers the rendering and manipulation of
     *        a chart for printing (in {@link #._process}). The step is notified via the <code>chartRendered</code> event of the chart print
     *        container when the chart is rendered. This event also indicates that the print step is complete and triggers the
     *        <code>processed</code event.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.WaitPrintStep
     */
    jd.ui.eid.common.print.PrintStep.extend("jd.ui.eid.common.print.WaitPrintStep", /** @lends jd.ui.eid.common.print.WaitPrintStep */
    {
        metadata : {
            properties : {
                timeout : {
                    type : "int",
                    defaultValue : 500
                }
            }
        },

        /**
         * Triggers the rendering of the chart association with the chart print container.
         */
        _process : function() {
            $.sap.log.debug("Wait step");
            var that = this;
            setTimeout(function() {
                that.fireProcessed();
            }, this.getTimeout());
        }
    });
})();