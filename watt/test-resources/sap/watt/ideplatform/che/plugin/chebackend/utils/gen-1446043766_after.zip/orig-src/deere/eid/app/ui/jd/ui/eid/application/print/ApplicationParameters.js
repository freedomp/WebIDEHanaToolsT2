(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.application.print.ApplicationParameters");

    jd.ui.eid.application.print.ApplicationParameters = {

        // Root content
        root : "content", // The id of the element to assign the root content
        getRootContent : function() {
            return jd.ui.eid.xmlview("jd.ui.eid.view.print.EvidencePackage");
        },

        // Service facades
        serviceFacades : {
            "FilterDomainValue" : "jd.ui.eid.service.FilterDomainValueServiceFacade",
            "DTCBlacklist" : "jd.ui.eid.service.DTCBlacklistServiceFacade",
            "DTC" : "jd.ui.eid.service.DTCServiceFacade",
            "EvidencePackage" : "jd.ui.eid.service.EvidencePackageServiceFacade",
            "PersonalizationFilters" : "jd.ui.eid.service.PersonalizationFiltersServiceFacade",
            "DTACCase" : "jd.ui.eid.service.DTACCaseServiceFacade",
            "Customizing" : "jd.ui.eid.service.CustomizingServiceFacade",
            "WarrantyClaim" : "jd.ui.eid.service.WarrantyClaimServiceFacade"
        },

        // Notification Center
        notificationCenter : {
            alertTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_ALERT_TITLE}",
            confirmationTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_CONFIRM_TITLE}",
            successTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_SUCCESS_TITLE}"
        },

        // Callbacks
        onBeforeDisplayRoot : function() {
        },
        onBeforeExit : function() {
        },

        onExit : function() {
        },

        // Data source
        useTestData : false,
        applyPersonalization : false,

        serverUrl : "../",
        eidRootPath : "./jd/ui/eid/"

    };

})();