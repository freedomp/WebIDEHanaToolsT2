(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer for control {@link jd.ui.eid.control.FilterItem}.
     * 
     * @class Default renderer for control {@link jd.ui.eid.control.FilterItem}.
     * @static
     * @name jd.ui.eid.control.FilterItemRenderer
     */
    jd.ui.eid.control.FilterItemRenderer = {};

    /**
     * Renders the control.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer.render = function(oRm, oControl) {
        // Don't render if visible = false
        if (!oControl.getVisible()) {
            return;
        }

        oRm.write("<div");
        oRm.writeControlData(oControl);
        oRm.addClass("jdUiEidFilterItem");
        if (oControl.getCollapsed() === true) {
            oRm.addClass("jdUiEidFilterItemCollapsed");
        }
        oRm.writeClasses();
        oRm.write(">");

        this.renderHeader(oRm, oControl);
        this.renderContent(oRm, oControl);

        oRm.write("</div>");
    };

    /**
     * Render the header consisting of the collapse & expand icon, the caption and header items to
     * the right such as the clear control.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer.renderHeader = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeader");
        oRm.writeClasses();
        oRm.write(">");

        this.renderCollapseIcon(oRm, oControl);

        // Wrapper so that the caption is displayed with an ellipsis if it's too long
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderWrapper");
        oRm.writeClasses();
        oRm.write(">");

        this.renderHeaderItems(oRm, oControl);

        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderTextWrapper");
        oRm.writeClasses();
        oRm.write(">");

        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemCaption");
        oRm.writeClasses();
        var sTooltip = oControl.getCaption() + "&#013;"/* Linebreak */
                + (oControl.getCollapsed() ? oControl.getExpandTooltip() : oControl.getCollapseTooltip());
        oRm.writeAttribute('title', sTooltip);
        oRm.write(">");
        oRm.writeEscaped(oControl.getCaption());
        oRm.write("</div>");

        // All items in this div will be docked to the right of the header wrapper if the caption
        // needs to be truncated and displayed with an ellipsis.
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderDockRight");
        oRm.writeClasses();
        oRm.write(">");

        if (oControl.getAggregation("_help").getTooltip()) {
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterItemTooltipOpener");
            oRm.writeClasses();
            oRm.write(">");
            oRm.renderControl(oControl.getAggregation("_help"));
            oRm.write("</div>");
        }

        if (oControl.getShowSelectionIndicator() && oControl.getSelectionIndicator()) {
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterItemSelectionIndicator");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getSelectionIndicator());
            oRm.write("</div>");
        }

        oRm.write("</div>"); // dock right
        oRm.write("</div>"); // text wrapper
        oRm.write("</div>"); // wrapper
        oRm.write("</div>"); // header
    };

    /**
     * Render the collapse icon.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer.renderCollapseIcon = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemCollapseIcon");
        oRm.writeClasses();
        oRm.writeAttributeEscaped('title', (oControl.getCollapsed() ? oControl.getExpandTooltip() : oControl.getCollapseTooltip()));
        oRm.write(">");
        oRm.write("</div>");
    };

    /**
     * Render the header items such as the clear control.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer.renderHeaderItems = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderItems");
        oRm.writeClasses();

        oRm.write(">");
        oRm.renderControl(oControl.getAggregation("_clear").addStyleClass('jdUiEidFilterItemClear'));

        oRm.write("</div>");
    };

    /**
     * Render the content.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer.renderContent = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemContent");
        oRm.writeClasses();
        oRm.write(">");

        this._renderContent(oRm, oControl);

        oRm.write("</div>");
    };

    /**
     * Hook method for sub classes for their content.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.FilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.FilterItemRenderer._renderContent = function(oRm, oControl) {

    };

})();