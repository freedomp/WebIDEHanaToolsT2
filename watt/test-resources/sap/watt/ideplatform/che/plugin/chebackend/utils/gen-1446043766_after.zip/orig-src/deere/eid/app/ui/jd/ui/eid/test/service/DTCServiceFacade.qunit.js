(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.DTCServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oDTCServiceFacade = new jd.ui.eid.service.DTCServiceFacade("http://sap.com", "/folder/to/test/data", oModel, true);
    var oListBindingDTCList = new jd.ui.eid.model.EidModelListBinding(oModel, "/DTCList");
    var oDataGetDTCList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTCList_Response.json").data;

    var oDataGetDTCDetails = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTCDetails_Response.json").data;

    // Module for getDTCBlacklist()
    module("jd.ui.eid.service.DTCServiceFacade", {
        setup : function() {
            // Start spying request
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };
        },
        teardown : function() {
            this.xhr.restore();
        }
    });

    // *** TEST CASE #1 ***
    test("getDTCList() should make an AJAX request.", function() {
        equal(0, this.requests.length);
        var oCustomFilter = {};
        oDTCServiceFacade.getDTCList(oListBindingDTCList, oCustomFilter, "selectedKPIID", "sSearchTerm", function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    // *** TEST CASE #2***
    test("getDTCList() should call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();
        var oCustomFilter = {};

        // Trigger the ajax request
        oDTCServiceFacade.getDTCList(oListBindingDTCList, oCustomFilter, "selectedKPIID", "sSearchTerm", fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCList));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataGetDTCList));

    });

    // *** TEST CASE #3 ***
    test("getDTCList() should update the paths '/DTCList' successfully", function() {
        // for testing no filter values are given
        var oCustomFilter = {};
        var oValue;

        // Trigger the ajax request
        oDTCServiceFacade.getDTCList(oListBindingDTCList, oCustomFilter, "selectedKPIID", "sSearchTerm", function() {
        }, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCList));

        // Assertion
        oValue = oModel.getProperty("/DTCList");
        // test one value from the table path of the response
        deepEqual(oValue[1].DTCCode, oDataGetDTCList.Result.DTCList.Records[1].DTCCode);
    });

    // *** TEST CASE #3.1 ***
    test("getTop10DTCs() should update the path 'TopDTCChart' successfully", function() {
        // for testing no filter values are given
        var oCustomFilter = {};
        var oValue;

        // Trigger the ajax request
        oDTCServiceFacade.getTop10DTCs(oListBindingDTCList, oCustomFilter, "selectedKPIID", "sSearchTerm", function() {
        }, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCList));

        oValue = oModel.getProperty("/Top10DTCs/Records");
        // test one value from the top10DTC chart of the response
        deepEqual(oValue[1].DTCCode, oDataGetDTCList.Result.Top10DTCs.Records[1].DTCCode);
    });

    // *** TEST CASE #4 ***
    test("getDTCDetails() should make an AJAX request.", function() {
        equal(0, this.requests.length);
        oDTCServiceFacade.getDTCDetails();
        equal(1, this.requests.length);
    });

    // *** TEST CASE #5 ***
    test("getDTCDetails() should update the path '/DTCDetails' from the file getDTCDetails_Response.json", function() {
        // for testing no filter values are given
        var CustomFilter = {};
        var oValue;

        // Trigger the ajax request
        oDTCServiceFacade.getDTCDetails(CustomFilter, "selectedDTC", function() {
        }, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCDetails));

        // Assertion
        oValue = oModel.getProperty("/DTCDetails");
        // test one value from the response
        deepEqual(oValue.DTCMasterData.DTCID, 23432543);
    });

})();
