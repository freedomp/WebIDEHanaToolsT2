(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TextAnalysisFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");

    /**
     * The TextAnalysisFilterItem control provides the general filter functionality for text analysis.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>compareSearchLabel : string This property defines the text of the first item in the listbox.</li>
     * <li>exactSearchLabel : string This property defines the text of the second item in the listbox.</li>
     * <li>nearSearchLabel : string This property defines the text of the third item in the listbox.</li>
     * <li>subListCaption : string This property defines the caption of the sub listbox.</li>
     * <li>enabled : (default: true) boolean This property defines whether the filteritem is enabled or not.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>subListItems : sap.ui.core.Item[] This aggregation defines the items in the sub listbox.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.TextAnalysisFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.TextAnalysisFilterItem"/** @lends jd.ui.eid.control.TextAnalysisFilterItem */
    , {
        metadata : {
            properties : {
                compareSearchLabel : {
                    type : "string"
                },
                exactSearchLabel : {
                    type : "string"
                },
                nearSearchLabel : {
                    type : "string"
                },
                subListCaption : {
                    type : "string"
                },
                subListCounter : {
                    type : "string"
                },
                enabled : {
                    type : "boolean",
                    defaultValue : true
                }
            },

            aggregations : {
                _listBox : {
                    type : "sap.ui.commons.ListBox",
                    multiple : false,
                    visibility : "hidden"
                },
                _subListBox : {
                    type : "sap.ui.commons.ListBox",
                    multiple : false,
                    visibility : "hidden"
                },
                subListItems : {
                    type : "sap.ui.core.Item",
                    multiple : true,
                    singularName : "subListItem"
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the listbox style class here so that we don't have to do any unnecessary
            // overwrites in
            // the renderer
            this.addStyleClass("jdUiEidListBoxFilterItem");
            this.addStyleClass("jdUiEidTextAnalysisFilterItem");

            // Initialize listbox control
            var that = this;
            this.setAggregation("_listBox", new jd.ui.eid.control.ListBox({
                enableSimpleMultiSelect : true,
                select : [this._handleListBoxSelect, this]
            }));

            // Set constancts
            this.CompareSearchMode = "Similarity";
            this.ExactSearchMode = "Exact";
            this.NearSearchMode = "Fuzzy";

            // Add default items to listbox control
            this._oItemCompareSearch = new sap.ui.core.Item({
                key : this.CompareSearchMode
            });
            this.getAggregation("_listBox").addItem(this._oItemCompareSearch);

            this._oItemExactSearch = new sap.ui.core.Item({
                key : this.ExactSearchMode
            });
            this.getAggregation("_listBox").addItem(this._oItemExactSearch);

            this._oItemNearSearch = new sap.ui.core.Item({
                key : this.NearSearchMode
            });
            this.getAggregation("_listBox").addItem(this._oItemNearSearch);

            // Initialize sublistbox control
            this.setAggregation("_subListBox", new jd.ui.eid.control.ListBox({
                allowMultiSelect : true,
                enableMandatorySelection : true,
                enableSimpleMultiSelect : true,
                select : [this._handleSubListBoxSelect, this]
            }).addEventDelegate({
                onBeforeRendering : function() {
                    // If we reload the evidence package, it's possible that the selection is assigned before the domain values are actually bound. So
                    // for that case, the selection on the inner list box control would get lost. Thus, we check in onBeforeRendering.
                    if (that.getAggregation("_subListBox").getSelectedIndices().length == 0 && that.getSelection().SelectedValues.length != 0) {
                        var oSelection = that.getSelection();
                        // Call the overridden TextAnalysis setSelection method to set the listbox values as well
                        that.setSelection(oSelection);
                    }
                }
            }));
        },

        /*
         * Internal Event Handlers
         */

        /**
         * This event handler indicates the selection of a listbox item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        _handleListBoxSelect : function(oEvent) {
            var aSubList = this.getAggregation("_subListBox").getSelectedKeys();

            if (aSubList.length == 0) {
                this.getAggregation("_subListBox").setSelectedIndex(0);
            }

            this._updateSelection();
        },

        /**
         * This event handler indicates the selection of a sub listbox item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleSubListBoxSelect : function(oEvent) {
            this._updateSelection();
        },

        /*
         * Custom Getter & Setter
         */

        /**
         * Set the default selection
         * 
         * @param {object}
         *            oSelection Selection object
         * @param {string}
         *            oSelection.SearchMode Constant of the search mode
         * @param {array}
         *            oSelection.SelectedValues Array with selected keys
         */
        setSelection : function(oSelection) {
            // Clear the old selection
            this.getAggregation("_listBox").clearSelection();
            this.getAggregation("_subListBox").clearSelection();

            this.setProperty('selection', oSelection);

            if (oSelection !== undefined) {
                // Initialize values: Get listbox with all items
                var oListbox = this.getAggregation("_listBox");
                oListbox.setSelectedKeys([oSelection.SearchMode]);

                // Update sub-listbox selection if searchmode and sublist items are set
                var aConvertedSubList = [];
                if (oSelection.SearchMode) {
                    // Convert the selected keys from integer to string
                    var aSubList = oSelection.SelectedValues;
                    $.each(aSubList, function(iIndex, iValue) {
                        aConvertedSubList.push(iValue.toString());
                    });
                }

                // Initialize values: Get sublistbox with all items
                var oSubListbox = this.getAggregation("_subListBox");
                oSubListbox.setSelectedKeys(aConvertedSubList);
                this.setActive(aConvertedSubList.length > 0);
                this._updateSubListCounterString();
            } else {
                this.setActive(false);
            }
        },

        /**
         * Sets the enabled/disabled state
         * 
         * @param {boolean}
         *            bEnabled new value for property enabled
         * @returns {jd.ui.eid.control.TextAnalysisFilterItem} This for method chaining
         */
        setEnabled : function(bEnabled) {
            var bOldEnabled = this.getProperty("enabled");

            if (bOldEnabled != bEnabled) {
                this.setProperty("enabled", bEnabled);
                // Disable all items of the _listbox object
                // We do this manually for all items, so the items are getting the right inactive styling
                var aListBoxItems = this.getAggregation("_listBox").getItems();
                $.each(aListBoxItems, function(iIndex, oListBoxItem) {
                    oListBoxItem.setEnabled(bEnabled);
                });
                // Clear the selection of the listboxs
                // This will also hide the sublistbox
                this.getAggregation("_listBox").clearSelection();
                this.getAggregation("_subListBox").clearSelection();
            }
            return this;
        },

        /**
         * This function updates the counter of the sublist
         */
        _updateSubListCounterString : function() {
            if (this.getSelection().SelectedValues !== undefined) {
                var iSelectionSubItemCount = this.getSelection().SelectedValues.length;
                var iTotalSubItemCount = this.getAggregation("_subListBox").getItems().length;
                this.setProperty("subListCounter", "(" + iSelectionSubItemCount + "/" + iTotalSubItemCount + ")");
            } else {
                this.setProperty("subListCounter", "(0/0)");
            }
        },

        /**
         * Update the filter selection model
         */
        _updateSelection : function() {
            var oSelection = {};

            // Get control values
            var oListbox = this.getAggregation("_listBox");
            oSelection.SearchMode = oListbox.getSelectedKeys()[0] || "";
            var aSubList = this.getAggregation("_subListBox").getSelectedKeys();

            // Update sub-listbox selection if searchmode and sublist items were selected
            if (oSelection.SearchMode) {
                // Convert the key string values into integer values
                var aConvertedSubList = [];
                $.each(aSubList, function(iIndex, sValue) {
                    aConvertedSubList.push(parseInt(sValue));
                });

                oSelection.SelectedValues = aConvertedSubList; // Set model sublist values
                this.setActive(aConvertedSubList > 0)
            } else {
                oSelection.SelectedValues = []; // Reset model sublist values
                this.setActive(false);
            }

            // Set selection property directly to avoid setter logic
            this.setProperty("selection", oSelection);
            this._updateSubListCounterString();
            this.fireValueChanged();
        },

        /**
         * Set the compare search text
         * 
         * @param {string}
         *            sCompareSearchLabel The label for the compare search
         * @returns {jd.ui.eid.control.TextAnalysisFilterItem} This for method chaining
         */
        setCompareSearchLabel : function(sCompareSearchLabel) {
            this.setProperty("compareSearchLabel", sCompareSearchLabel);
            this._oItemCompareSearch.setText(sCompareSearchLabel);
            return this;
        },

        /**
         * Set the exact search text
         * 
         * @param {string}
         *            sExactSearchLabel The label for the exact search
         * @returns {jd.ui.eid.control.TextAnalysisFilterItem} This for method chaining
         */
        setExactSearchLabel : function(sExactSearchLabel) {
            // Set property
            this.setProperty("exactSearchLabel", sExactSearchLabel);
            this._oItemExactSearch.setText(sExactSearchLabel);
            return this;
        },

        /**
         * Set the near search text
         * 
         * @param {string}
         *            sNearSearchLabel The label for the near search
         * @returns {jd.ui.eid.control.TextAnalysisFilterItem} This for method chaining
         */
        setNearSearchLabel : function(sNearSearchLabel) {
            // Set property
            this.setProperty("nearSearchLabel", sNearSearchLabel);
            this._oItemNearSearch.setText(sNearSearchLabel);
            return this;
        },

        /**
         * Override default getter/setter of subListBox aggregation
         */
        addSubListItem : function(oItem) {
            this.getAggregation("_subListBox").addItem(oItem);
            this._updateSubListCounterString();
            return this;
        },

        /**
         * @see jd.ui.eid.control.ListBox#destroyItems
         */
        destroySubListItems : function() {
            this.getAggregation("_subListBox").destroyItems();
            this._updateSubListCounterString();
            return this;
        },

        /**
         * @see jd.ui.eid.control.ListBox#getItems
         */
        getSubListItems : function() {
            return this.getAggregation("_subListBox").getItems();
        },

        /**
         * @see jd.ui.eid.control.ListBox#indexOfItem
         */
        indexOfSubListItem : function(oItem) {
            return this.getAggregation("_subListBox").indexOfItem(oItem);
        },

        /**
         * @see jd.ui.eid.control.ListBox#insertItem
         */
        insertSubListItem : function(oItem, iIndex) {
            this.getAggregation("_subListBox").insertItem(oItem, iIndex);
            this._updateSubListCounterString();
            return this;
        },

        /**
         * @see jd.ui.eid.control.ListBox#removeAllItems
         */
        removeAllSubListItems : function() {
            var aItems = this.getAggregation("_subListBox").removeAllItems();
            this._updateSubListCounterString();
            return aItems;
        },

        /**
         * @see jd.ui.eid.control.ListBox#removeItem
         */
        removeSubListItem : function(oItem) {
            var oDeletedItem = this.getAggregation("_subListBox").removeItem(oItem);
            this._updateSubListCounterString();
            return oDeletedItem;
        },

        /* Control Logic */

        /**
         * @see jd.ui.eid.control.FilterItem
         */
        _clear : function() {
            var oCurrentSelection = this.getSelection();
            var oEmptySelection = {};
            oEmptySelection.SelectedValues = [];
            oEmptySelection.SearchMode = "";

            if (!$.sap.equal(oCurrentSelection, oEmptySelection)) {
                this.getAggregation("_listBox").clearSelection();
                this.getAggregation("_subListBox").clearSelection();
                this._updateSubListCounterString();

                // Clear internal state
                this.setSelection(oEmptySelection);
                this._updateSubListCounterString();

                // Remove the filteritem active flag to indicate that the selection was deleted
                this.setActive(false);

                return true;
            } else {
                return false;
            }
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.TextAnalysisFilterItemRenderer"

    });

})();