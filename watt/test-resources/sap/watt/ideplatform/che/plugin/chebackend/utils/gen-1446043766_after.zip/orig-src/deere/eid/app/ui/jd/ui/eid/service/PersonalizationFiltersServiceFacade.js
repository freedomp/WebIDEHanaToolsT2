(function() {
    "use strict";

    // Requires BaseServiceFacade
    jQuery.sap.declare("jd.ui.eid.service.PersonalizationFiltersServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.FilterDomainValueServiceFacade");

    /**
     * @class Service class for personalization of 'DTC Filters'. Note : As 'User ID' is available in the session, it does not need to be passed
     *        explicitly by any of this class's methods.
     * 
     * @name jd.ui.eid.service.PersonalizationFiltersServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     * 
     */
    jd.ui.eid.service.BaseServiceFacade
            .extend(
                    "jd.ui.eid.service.PersonalizationFiltersServiceFacade",
                    /** @lends jd.ui.eid.service.PersonalizationFiltersServiceFacade */
                    {
                        /**
                         * Get the DTC filter personalization for the current user and update the model
                         * 
                         * @memberOf jd.ui.eid.service.PersonalizationFiltersServiceFacade
                         * 
                         * @public
                         * 
                         * @param {function}
                         *            fnSuccess Callback to be executed when the service call is successful
                         * @param {function}
                         *            fnError Callback to be executed when the service call is not successful
                         * 
                         */
                        getPersonalizationFilters : function(fnSuccess, fnError) {
                            // Prepare arguments for service call
                            var sModelPath = "/PersonalizedDTCFilters";
                            var sServicePath = "xs/personal/default_filters/GetPersonalisationFilters.xsjs";
                            var oData = {};
                            var sModelFileName = "getPersonalizationFilters.json";
                            var fnGetData = function(oData) {
                                return oData.Result.PersonalizationFilters;
                            };

                            // Call the service
                            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName);
                        },

                        /**
                         * Save the DTC filter personalization for the current user.
                         * 
                         * @memberOf jd.ui.eid.service.PersonalizationFiltersServiceFacade
                         * 
                         * @param {object}
                         *            oData The object with the model's data about the user's personalized filters
                         * @param {function}
                         *            fnSuccess The callback to be executed when the service call is successful.
                         * @param {function}
                         *            fnError The callback to be executed when the service call is not successful.
                         * @public
                         */
                        savePersonalizationFilters : function(oData, fnSuccess, fnError) {
                            // Prepare arguments for the service call
                            var sServicePath = "xs/personal/default_filters/SetPersonalisationFilters.xsjs";
                            var oArgs = {
                                PersonalizationFilters : oData
                            };

                            // Call the service
                            this._send(sServicePath, fnSuccess, fnError, oArgs);
                        },

                        /**
                         * Updates the DTCFilters path of the model with information from the user's filter personalization settings.
                         * 
                         * @param {function}
                         *            fnSuccess The callback to be executed when all steps are completed successfully
                         */
                        applyPersonalization : function(sSelectionPath, sFilterStatePath, fnSuccess, fnPersonalizationUnavailable, fnError,
                                fnPersonalizationObsolete) {
                            var oApp = jd.ui.eid.application.Application.getInstance();
                            var oFilterDomainValueService = oApp.getServiceFacade("FilterDomainValue");
                            var oPersonalizationService = this;

                            // Get the user's filter personalization settings and proceed on success
                            this
                                    .getPersonalizationFilters(function() {
                                        // Check if the user has maintained personalization. If not, stop processing.
                                        // Is this check enough?
                                        var oModel = sap.ui.getCore().getModel();
                                        var sPlatformId = "", sProductLineId = "";
                                        if (oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine")[0]) {
                                            sPlatformId = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine")[0].PlatformID;
                                            if (sProductLineId = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine")[0].ProductLine) {
                                                sProductLineId = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine")[0].ProductLine[0];
                                            }
                                        }
                                        if (!sPlatformId || !sProductLineId) {
                                            // Without this line, the model isn't updated if Personalization filters are not maintained. If the user
                                            // makes changes
                                            // to the DTC Filters and then applies personalization (when no personalization exists), the Platform &
                                            // Product Line in
                                            // /DTCFilters needs to be reset. The call to _applyPersonazationDeep updates /DTCFilters with null.
                                            // (Null, because the user has
                                            // no personalization maintained)
                                            oPersonalizationService._checkAndApplyPersonalizationDeep(sSelectionPath, "PlatformAndProductLine",
                                                    "Platforms");
                                            if (fnPersonalizationUnavailable) {
                                                fnPersonalizationUnavailable();
                                            }
                                            return;
                                        }

                                        // Now check if the Platform & ProductLine selected in personalization is actually available in the
                                        // Platform/Product line domain
                                        // values. These domain values have already been fetched (in the Dashboard controller) and can safely be
                                        // assumed to be available in
                                        // the model. If invalid, do nothing.
                                        if (!oPersonalizationService._isValidPlatformAndProductLine(sPlatformId, sProductLineId)) {
                                            if (fnPersonalizationObsolete) {
                                                fnPersonalizationObsolete();
                                            }
                                        }

                                        // Now get the domain values for the filter items, based on the selected Platform ID & Product Line ID.
                                        // Proceed after the model
                                        // (/DTCFilters/DomainValues) has been updated.
                                        oFilterDomainValueService.getDTCFilterDomainValues(sPlatformId, sProductLineId, function() {
                                            // Now -> Update /DTCFilter/FilterSelection based on /PersonalizedDTCFilters/FilterSelection, if the value
                                            // is available in
                                            // /DTCFilter/DomainValues
                                            oPersonalizationService._checkAndApplyPersonalizationDeep(sSelectionPath, "PlatformAndProductLine",
                                                    "Platforms"); // For
                                            // PlatformAndProductLine
                                            // and
                                            // Model. Couldn't
                                            // think of a good name.
                                            oPersonalizationService._checkAndApplyPersonalizationDeep(sSelectionPath, "Model", "Models");
                                            oPersonalizationService._applyPersonalizationBuildWeek(sSelectionPath);
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "BuildFactory",
                                                    "BuildFactories");
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "DesignFactory",
                                                    "DesignFactories");
                                            oPersonalizationService._applyPersonalizationDTCCaptureTime(sSelectionPath);
                                            oPersonalizationService._checkAndApplyPersonalizationEngineHours(sSelectionPath);
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "MachineLocation",
                                                    "MachineLocations");
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "BranchCode", "BranchCodes");
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "FunctionalArea",
                                                    "FunctionalAreas");
                                            oPersonalizationService._copyManualPinListDomainValues(sSelectionPath); // For ManualPinList, also copy
                                            // over the domain values
                                            // from
                                            // /PersonalizedDTCFilters to /DTCFilters
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "ManualPinList",
                                                    "ManualPinList");
                                            oPersonalizationService._checkAndApplyPersonalizationById(sSelectionPath, "EmissionLevel",
                                                    "EmissionLevels");
                                            oPersonalizationService._applyPersonalizationByValue(sSelectionPath, "NoiseReduction");
                                            oPersonalizationService._applyPersonalizationByValue(sSelectionPath, "TestMachine");

                                            // Now also apply the 'filter state' personalization
                                            oPersonalizationService._applyFilterStatePersonalization(sFilterStatePath);

                                            // Trigger success callback
                                            if (fnSuccess) {
                                                fnSuccess();
                                            }
                                        }, function() {
                                            if (fnError) {
                                                fnError();
                                            }
                                        });

                                    });
                        },

                        /**
                         * Checks if the supplied Platform ID and Product Line ID are permitted, by verifying that they are included in the domain
                         * values.
                         * 
                         * @private
                         * @param {string}
                         *            sPlatformId The Platform ID
                         * @param {string}
                         *            sProductLineId The Product Line ID
                         * @returns {Boolean} True if the supplied Platform ID and Product Line are permitted values
                         * 
                         */
                        _isValidPlatformAndProductLine : function(sPlatformId, sProductLineId) {
                            // Get the domain values for platform & product line.
                            var aDomainValues = sap.ui.getCore().getModel().getProperty("/DTCFilters/DomainValues/Platforms");
                            var bValid = false;

                            // Check if sPlatformId and sProductLineId are available in the domain values
                            $.each(aDomainValues, function(i, domainValuePlatform) {
                                if (domainValuePlatform.ID == sPlatformId) {
                                    $.each(domainValuePlatform.ProductLines, function(i, domainValueProductLine) {
                                        if (domainValueProductLine.ID == sProductLineId) {
                                            bValid = true;
                                            return false;
                                        }
                                    });
                                    // Already verified validity? Get out of the $.each
                                    if (bValid) {
                                        return false;
                                    }
                                }
                            });
                            // Done
                            return bValid;
                        },

                        /**
                         * Updates the <i>/DTCFilters/FilterSelection/<u>sPropertySelection</u></i> path in the model from
                         * <i>/PersonalizedDTCFilters/FilterSelection/<u>sPropertySelection</u></i> after checking if it exists in
                         * <i>/DTCFilters/DomainValues/<u>sPropertyDomainValue</u></i>
                         * 
                         * @private
                         * @param {string}
                         *            sPropertySelection The name of the property in the /FilterSelection path.
                         * @param {string}
                         *            sPropertyDomainValue The name of the property in the /DomainValues path
                         * 
                         * @param {boolean}
                         *            bCopyEntireValue If false, only the ID is copied to the /FilterSelection path. If true, the entire object is
                         *            copied.
                         */
                        _checkAndApplyPersonalizationById : function(sSelectionPath, sPropertySelection, sPropertyDomainValue, bCopyEntireValue) {
                            // Get the DomainValues and FilterSelection
                            var oModel = sap.ui.getCore().getModel();
                            var aDomainValues = oModel.getProperty("/DTCFilters/DomainValues/" + sPropertyDomainValue);
                            var aPersonalizationSelection = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/" + sPropertySelection);

                            // Proceed only if required
                            if (!aDomainValues || !aPersonalizationSelection || aDomainValues.length == 0 || aPersonalizationSelection.length == 0) {
                                return;
                            }

                            // If an ID in aPersonalizationSelection matches with aDomainValues, store the ID in aSelectionList.
                            var aSelectionList = [];
                            $.each(aPersonalizationSelection, function(i, sDefaultSelection) {
                                $.each(aDomainValues, function(i, oDomainValue) {
                                    if (oDomainValue.ID === sDefaultSelection) {
                                        if (bCopyEntireValue) {
                                            aSelectionList.push(oDomainValue);
                                        } else {
                                            aSelectionList.push(sDefaultSelection);
                                        }
                                    }
                                });
                            });

                            // Now copy the list of IDs to /DTCFilters/FilterSelection
                            oModel.setProperty(sSelectionPath + "/" + sPropertySelection, aSelectionList);
                        },

                        /**
                         * Updates the <i>/DTCFilters/FilterSelection/<u>sProperty</u></i> path in the model by copying from
                         * <i>/PersonalizedDTCFilters/FilterSelection/<u>sProperty</u></i>
                         * 
                         * @private
                         * @param {string}
                         *            sProperty The property for which personalization is to be applied
                         */
                        _applyPersonalizationByValue : function(sSelectionPath, sProperty) {
                            // Get the personalization value to be copied.
                            var oModel = sap.ui.getCore().getModel();
                            var oSelection = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/" + sProperty);

                            // Copy..
                            oModel.setProperty(sSelectionPath + "/" + sProperty, oSelection);
                        },

                        /**
                         * Private helper method. Applies personalization for BuildWeek
                         * 
                         * @private
                         */
                        _applyPersonalizationBuildWeek : function(sSelectionPath) {
                            // Get the personalization settings for BuildWeek
                            // NOTE : For BuildWeek, the dates need to be in YYYY-MM-DD format
                            var oModel = sap.ui.getCore().getModel();
                            var sType = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/Type");
                            var sAbsoluteStartDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/AbsoluteStartDate").slice(
                                    0, 10);
                            var sAbsoluteEndDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/AbsoluteEndDate").slice(0,
                                    10);
                            var sSinceDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/SinceDate").slice(0, 10);
                            var iDuration = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/Duration");
                            var sUnit = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/BuildWeek/Unit");
                            var sTodayDate = jd.ui.eid.common.DateHelper.DateToJSONDate(FAKE_TODAY()).slice(0, 10);

                            // Depending on sType, derive the start and end dates.
                            var sStartDate = "", sEndDate = "";
                            if (sType == "absolute" && sAbsoluteStartDate && sAbsoluteEndDate) {
                                sStartDate = sAbsoluteStartDate;
                                sEndDate = sAbsoluteEndDate;
                            } else if (sType == "sinceDate" && sSinceDate) {
                                sStartDate = sSinceDate;
                                sEndDate = sTodayDate; // Set today as end date
                            } else if ((sType == "duration" || sType == "customDuration") && (iDuration >= 0)) {
                                // Start date is 'iDuration' days/weeks/months in the past
                                switch (sUnit) {
                                    case "day" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayDate, iDuration).slice(0, 10);
                                        break;
                                    case "week" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayDate, iDuration * 7).slice(0, 10);
                                        break;
                                    case "month" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractMonths(sTodayDate, iDuration).slice(0, 10);
                                        break;
                                }
                                sEndDate = sTodayDate;
                            }

                            // Set the BuildWeek filter selection
                            oModel.setProperty(sSelectionPath + "/BuildWeek", {
                                Start : sStartDate,
                                End : sEndDate
                            });
                        },

                        /**
                         * Private helper method. Applies personalization for Engine Hours.
                         * 
                         * @private
                         */
                        _checkAndApplyPersonalizationEngineHours : function(sSelectionPath) {
                            // Separate method for engine hours, because here the 'LowerBound' is the key for each entry
                            // Get the DomainValues and FilterSelection
                            var oModel = sap.ui.getCore().getModel();
                            var aDomainValues = oModel.getProperty("/DTCFilters/DomainValues/EngineHours");
                            var aPersonalizationSelection = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/EngineHour");

                            // Proceed only if required
                            if (!aDomainValues || !aPersonalizationSelection || aDomainValues.length == 0 || aPersonalizationSelection.length == 0) {
                                return;
                            }

                            // If an ID in aPersonalizationSelection matches with aDomainValues, store the ID in aSelectionList.
                            var aSelectionList = [];
                            $.each(aPersonalizationSelection, function(i, sDefaultSelection) {
                                $.each(aDomainValues, function(i, oDomainValue) {
                                    if (oDomainValue.LowerBound === sDefaultSelection.LowerBound) {
                                        aSelectionList.push(oDomainValue); // FilterSelection items need to have the whole {LowerBound, UpperBound}
                                        // object, not
                                        // just the key.
                                    }
                                });
                            });

                            // Now copy the list of IDs to /DTCFilters/FilterSelection
                            oModel.setProperty(sSelectionPath + "/EngineHour", aSelectionList);
                        },

                        /**
                         * Private helper method. Applies personalziation for DTC Capture Time
                         * 
                         * @private
                         */
                        _applyPersonalizationDTCCaptureTime : function(sSelectionPath) {
                            // Get the personalization settings for BuildWeek
                            var oModel = sap.ui.getCore().getModel();
                            var sType = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/Type");
                            var sAbsoluteStartDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/AbsoluteStartDate");
                            var sAbsoluteEndDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/AbsoluteEndDate");
                            var sSinceDate = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/SinceDate");
                            var iDuration = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/Duration");
                            var sUnit = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime/Unit");
                            var sTodayDate = jd.ui.eid.common.DateHelper.DateToJSONDate(FAKE_TODAY());
                            var sFilterAreaSelectionType; // This type determines whether the {Start:, End:} needs to be shown as a static item
                            // selection or a
                            // 'range' selection on the Dashboard FilterItem for DTC Capture Time. "static" means a matching static
                            // ValueListItem must be selected. "custom" means the ToolPopup opener must be marked as selected

                            // Depending on sType, derive the start and end dates.
                            var sStartDate = "", sEndDate = "";
                            if (sType == "absolute") {
                                sStartDate = sAbsoluteStartDate;
                                sEndDate = sAbsoluteEndDate;
                                sFilterAreaSelectionType = "custom";
                            } else if (sType == "sinceDate") {
                                sStartDate = sSinceDate;
                                sEndDate = sTodayDate; // Set today as end date
                                sFilterAreaSelectionType = "custom";
                            } else if ((sType == "duration") || (sType == "customDuration")) {
                                // Start date is 'iDuration' days/weeks/months in the past
                                // Start date determination is same for both sType == duration AND customDuration
                                switch (sUnit) {
                                    case "day" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayDate, iDuration);
                                        break;
                                    case "week" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayDate, iDuration * 7);
                                        break;
                                    case "month" :
                                        sStartDate = jd.ui.eid.common.DateHelper.subtractMonths(sTodayDate, iDuration);
                                        break;
                                }
                                sEndDate = sTodayDate;

                                // Set sFilterAreaSelectionType based on whether sType is 'duration' or 'customDuration'
                                if (sType == "duration") {
                                    sFilterAreaSelectionType = "static";
                                } else if (sType == "customDuration") {
                                    sFilterAreaSelectionType = "custom";
                                }
                            }

                            // Set the DTCCaptureTime filter selection
                            // TODO : Do something to make the commented lines work.
                            if (sStartDate && sEndDate) {
                                // Don't setProperty if there is no start/end date, because it will then unnecessarily overwrite the default '6
                                // months' for DTC
                                // Capture Time (Which is set in the EidModel.js)
                                oModel.setProperty(sSelectionPath + "/DTCCaptureTime", {
                                    Start : sStartDate,
                                    End : sEndDate,
                                    _Type : sFilterAreaSelectionType,
                                });
                            }
                            // oModel.setProperty("/DTCFilters/FilterSelection/DTCCaptureTime/Start", sStartDate);
                            // oModel.setProperty("/DTCFilters/FilterSelection/DTCCaptureTime/End", sEndDate);
                        },

                        /**
                         * Private helper method. Applies personalization for PlatformAndProductLine and Model
                         * 
                         * @private
                         * @param {string}
                         *            sProperty Must be either 'PlatformAndProductLine' or 'Model'
                         */
                        _checkAndApplyPersonalizationDeep : function(sSelectionPath, sPropertySelection, sPropertyDomainValue) {
                            // Get the property's personalization setting
                            var oModel = sap.ui.getCore().getModel();
                            var aDefaultSelection = oModel.getProperty("/PersonalizedDTCFilters/FilterSelection/" + sPropertySelection);
                            var aDomainValues = oModel.getProperty("/DTCFilters/DomainValues/" + sPropertyDomainValue);
                            var sOuterAttr, sInnerAttr, sInnerDomainValueAttr;
                            switch (sPropertySelection) {
                                case "PlatformAndProductLine" :
                                    sOuterAttr = "PlatformID";
                                    sInnerAttr = "ProductLine";
                                    sInnerDomainValueAttr = "ProductLines";
                                    break;
                                case "Model" :
                                    sOuterAttr = "ModelID";
                                    sInnerAttr = "SubModel";
                                    sInnerDomainValueAttr = "SubModels";
                                    break;
                            }

                            // Add if 'sOuterAttr' of FilterSelection matches 'ID' of DomainValue, then add 'sOuterAttr' to
                            // /DTCFilters/FilterSelection. If added, for
                            // each object check its 'sInnerAttr' array elements. If they match the 'ID' of an element in 'sInnerDomainValueAttr', add
                            // the ID to the
                            // 'sInnerAttr' array in /DTCFilters/FilterSelection
                            var aValidatedSelectionEntries = [];
                            $.each(aDefaultSelection, function(i, oSelection) {
                                var oEntry = {}; // We will add this to /DTCFilters/FilterSelection
                                $.each(aDomainValues, function(i, oDomainValue) {
                                    if (oSelection[sOuterAttr] == oDomainValue["ID"]) {
                                        oEntry[sOuterAttr] = oSelection[sOuterAttr]; // e.g PlatformID
                                        oEntry[sInnerAttr] = []; // e.g ProductLine

                                        // Now look for matching 'sInnerAttr's (e.g ProductLines)
                                        $.each(oSelection[sInnerAttr], function(i, sInnerSelectionId) {
                                            $.each(oDomainValue[sInnerDomainValueAttr], function(i, oInnerDomainValue) {
                                                if (sInnerSelectionId == oInnerDomainValue.ID) {
                                                    oEntry[sInnerAttr].push(sInnerSelectionId);
                                                }
                                            });
                                        });
                                    }
                                });

                                // If for the current oSelection, we find something to add to /DTCFilters/FilterSelection, update the model.
                                if (!$.isEmptyObject(oEntry)) {
                                    aValidatedSelectionEntries.push(oEntry);
                                }
                            });

                            // Update the /DTCFilters/FilterSelection path with validated filter selection entries
                            oModel.setProperty(sSelectionPath + "/" + sPropertySelection, aValidatedSelectionEntries);
                        },

                        /**
                         * Private helper method. Copies <i>/PersonalizedDTCFilters/DomainValues/ManualPinList</i> to
                         * <i>/DTCFilters/DomainValues/ManualPinList</i>
                         * 
                         * @private
                         */
                        _copyManualPinListDomainValues : function() {
                            var oModel = sap.ui.getCore().getModel();
                            var aDomainValues = oModel.getProperty("/PersonalizedDTCFilters/DomainValues/ManualPinList");
                            oModel.setProperty("/DTCFilters/DomainValues/ManualPinList", aDomainValues);
                        },

                        /**
                         * Copies the 'FilterState' path from <i>/PersonalizedDTCFilters/FilterState</i> to <i>/DTCFilters/FilterState</i>
                         * 
                         * @private
                         */
                        _applyFilterStatePersonalization : function(sFilterStatePath) {
                            var oModel = sap.ui.getCore().getModel();
                            var oDefaultFilterState = oModel.getProperty("/PersonalizedDTCFilters/FilterState");
                            oModel.setProperty(sFilterStatePath, oDefaultFilterState);
                        }

                    });

})();