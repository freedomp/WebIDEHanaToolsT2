(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.jd-ui-eid-core");

    module("jd.ui.eid", {
        setup : function() {
        },
        teardown : function() {
        }
    });

    test("dummy", function() {
        ok(true)
    });

})();