(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");

    var oModel = null;
    var oData = null;
    var oTemplateData = {
        StringProperty : 'String',
        IntegerProperty : 1,
        FloatProperty : 1.1,
        ArrayProperty : [1, 2, 3],
        ObjectProperty : {
            FirstProperty : 'first',
            SecondProperty : 'second'
        }
    };

    // Module for DTC Blacklist
    module("jd.ui.eid.model.EidModel", {
        setup : function() {
            oModel = new jd.ui.eid.model.EidModel();
            // Make a copy of the template data
            oData = jQuery.extend(true, {}, oTemplateData);
        },
        teardown : function() {
            oModel = null;

        }
    });

    test(
            "setProperty() should fire the binding's change event of array property bindings if an element of the array is updated (with parameter bIsArrayCountBinding).",
            function() {
                oModel.setData(oData);

                // Create a binding
                var oBinding = oModel.bindProperty("/ArrayProperty", null, {
                    bIsArrayCountBinding : true
                });
                makeSureBindingIsKnownToModel(oBinding, oModel);
                var spy = sinon.spy();
                oBinding.attachChange(spy);
                ok(!spy.called);

                // Update model
                oModel.setProperty("/ArrayProperty/0", 9);

                ok(spy.called);
            });

    test(
            "setProperty() should fire the binding's change event of array property bindings if the array is updated (with parameter bIsArrayCountBinding).",
            function() {
                oModel.setData(oData);

                // Create a binding
                var oBinding = oModel.bindProperty("/ArrayProperty", null, {
                    bIsArrayCountBinding : true
                });
                makeSureBindingIsKnownToModel(oBinding, oModel);
                var spy = sinon.spy();
                oBinding.attachChange(spy);
                ok(!spy.called);

                // Update model
                oModel.setProperty("/ArrayProperty", [3, 4]);

                ok(spy.called);
            });

    test("setProperty() should fire the binding's change event of object property bindings if the object is updated with new values.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindProperty("/ObjectProperty");
        makeSureBindingIsKnownToModel(oBinding, oModel);
        var spy = sinon.spy();
        oBinding.attachChange(spy);
        ok(!spy.called);

        // Update model
        var oObject = {
            FirstProperty : 'newFirst',
            SecondProperty : 'newSecond'
        }; // This is a copy of the object property from the model
        oModel.setProperty('/ObjectProperty', oObject);

        ok(spy.called);
    });

    test(
            "setProperty() should not fire the binding's change event of object property bindings if the object is updated but still has the same values.",
            function() {
                oModel.setData(oData);

                // Create a binding
                var oBinding = oModel.bindProperty("/ObjectProperty");
                makeSureBindingIsKnownToModel(oBinding, oModel);
                var spy = sinon.spy();
                oBinding.attachChange(spy);
                ok(!spy.called);

                // Update model
                var oObject = {
                    FirstProperty : 'first',
                    SecondProperty : 'second'
                }; // This is a copy of the object property from the model
                oModel.setProperty('/ObjectProperty', oObject);

                ok(!spy.called);
            });

    test("setProperty() should fire the binding's change event of object property bindings if a property of the object is updated.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindProperty("/ObjectProperty", null, {
            bIsObjectPropertyBinding : true
        });
        makeSureBindingIsKnownToModel(oBinding, oModel);
        var spy = sinon.spy();
        oBinding.attachChange(spy);
        ok(!spy.called);

        // Update model
        oModel.setProperty('/ObjectProperty/FirstProperty', 'newValue');

        ok(spy.called);
    });

    test("bindProperty() should return an object that has a refresh() method.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindProperty("/ObjectProperty");
        makeSureBindingIsKnownToModel(oBinding, oModel);
        ok(oBinding.refresh);
        equal(typeof oBinding.refresh, 'function');
    });

    test("bindList() should return an instance of EidModelListBinding by default.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindList("/ArrayBinding");
        makeSureBindingIsKnownToModel(oBinding, oModel);
        ok(oBinding);
        ok(oBinding instanceof jd.ui.eid.model.EidModelListBinding);
    });

    test("bindList() should return an instance of JSONListBinding of the parameter bIsLocal is set to false.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindList("/ArrayBinding", null, null, null, {
            bIsLocal : false
        });
        makeSureBindingIsKnownToModel(oBinding, oModel);
        ok(oBinding);
        ok(oBinding instanceof jd.ui.eid.model.EidModelListBinding);
    });

    test("bindList() should return an instance of JSONListBinding of the parameter bIsLocal is set to true.", function() {
        oModel.setData(oData);

        // Create a binding
        var oBinding = oModel.bindList("/ArrayBinding", null, null, null, {
            bIsLocal : true
        });
        makeSureBindingIsKnownToModel(oBinding, oModel);
        ok(oBinding);
        ok(oBinding instanceof sap.ui.model.json.JSONListBinding);
        ok(!(oBinding instanceof jd.ui.eid.model.EidModelListBinding));
    });

    test("pathsEqual() should return true if the given paths have the same structure and values.", function() {
        oModel.setData({
            left : {
                a : "a",
                b : 2
            },
            right : {
                a : "a",
                b : 2
            }
        });

        ok(oModel.pathsEqual("/left", "/right"));
    });

    test("pathsEqual() should return false if the given paths have the same structure and values.", function() {
        oModel.setData({
            left : {
                a : "a",
                b : 2
            },
            right : {
                a : "b",
                b : 4
            }
        });

        ok(!oModel.pathsEqual("/left", "/right"));
    });

    // Test Utilities

    var makeSureBindingIsKnownToModel = function(oBinding, oModel) {
        // Attach dummy change listener to binding. It looks like only then, the binding is refreshed by the default model implementation.
        oBinding.attachChange(function() {

        });
    };

})();