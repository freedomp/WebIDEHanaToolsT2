(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.GripperWrapper");

    /**
     * Constructor of a new GripperWrapper.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>collapsed : boolean (default: true) true if collapsed, false otherwise.</li>
     * <li>collapseTooltip : string (default: "") the tooltip displayed if the gripper would collapse.</li>
     * <li>expandTooltip : string (default: "") the tooltip displayed if the gripper would expand.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>content : sap.ui.core.Control[] The controls to display.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>gripped : raised when the gripper is clicked.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class This control adds a gripper at the at the center top of the content.
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.GripperWrapper
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.GripperWrapper",
    /** @lends jd.ui.eid.control.GripperWrapper */
    {
        metadata : {
            properties : {
                collapsed : {
                    type : "boolean",
                    defaultValue : true
                },
                collapseTooltip : {
                    type : "string",
                    defaultValue : ""
                },
                expandTooltip : {
                    type : "string",
                    defaultValue : ""
                }
            },
            aggregations : {
                content : {
                    type : "sap.ui.core.Control",
                    multiple : true
                }
            },
            events : {
                gripped : {}
            }
        },

        /**
         * Add style class to control for branding.
         */
        init : function() {
            this.addStyleClass("jdUiEidGripperWrapper");
        },

        /**
         * Handle clicks on the close icon.
         * 
         * @param {jQuery.Event}
         *            the jquery event.
         */
        onclick : function(oEvent) {
            if (oEvent.target.id == this.getId() + "-close") {
                this.setCollapsed(!this.getCollapsed());
                this.fireGripped();
            }
        },

        /**
         * @ignore
         */
        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            if (!oControl.getCollapsed()) {
                oRm.addClass("jdUiEidGripperWrapperExpanded");
            }
            oRm.writeClasses(oControl);
            oRm.write(">");

            // close icon
            oRm.write("<div id='" + oControl.getId() + "-close' title='"
                    + (oControl.getCollapsed() ? oControl.getExpandTooltip() : oControl.getCollapseTooltip())
                    + "' class='jdUiEidGripperWrapperIcon'></div>");

            // render contents
            oRm.write("<div class='jdUiEidGripperWrapperContent'>");
            var aContent = oControl.getContent();
            for ( var i = 0; i < aContent.length; ++i) {
                oRm.renderControl(aContent[i]);
            }
            oRm.write("</div>");

            oRm.write("</div>");
        }
    });
})();