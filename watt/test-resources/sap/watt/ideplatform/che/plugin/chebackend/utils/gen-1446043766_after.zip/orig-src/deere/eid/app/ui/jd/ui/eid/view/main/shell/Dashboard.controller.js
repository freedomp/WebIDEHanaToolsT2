(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCTableController");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DTCFilterAreaDelegate");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.FilterAreaFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");
    jd.ui.eid.require("jd.ui.eid.common.TableHelper");
    jd.ui.eid.require("jd.ui.eid.common.chart.ChartHelper");

    /**
     * 
     * @class
     * <p>
     * The DTC dashboard View displays a filter area, a toolbar, an overview part where a Top 10 DTC Column chart and an Overview DTC List table can
     * be toggled, and a detail area where the details of selected DTC can be displayed as modal view.
     * </p>
     * <p>
     * The view uses the following <strong>delegates</strong>:
     * <ul>
     * <li>{@link jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate} : the responsible delegate for the trend range tool popup (DTC table
     * <li>{@link jd.ui.eid.common.delegate.DTCFilterAreaDelegate} : the responsible delegate for the filter area fragment.</li>
     * tool bar).</li>
     * </ul>
     * </p>
     * <h2>Top 10 DTCs Chart</h2>
     * <p>
     * <strong>Chart Manipulation</strong> is done via three event delegates which are hooked into <code>onAfterRendering</code> of the Top 10 DTCs
     * chart:
     * <ul>
     * <li>Selected Column: A delegate is registered to highlight the selected column if the DTC details area is visible and to set the opacity on
     * all other columns. This is done directly on the columns by changing their CSS. (see {@link #._markColumnAsSelected}).</li>
     * <li>Warning Light Color: A delegate is registered to set the fill color of the column based on the warning light of the related DTC. The
     * colors for that are coded into this controller and cannot be maintained via CSS/LESS.</li>
     * <li>Blacklisted DTC: A delegate is registered to set the fill color of a column associated with a DTC that was just added to the DTC
     * blacklist.</li>
     * </ul>
     * They are all registered in {@link #.onInit}.
     * </p>
     * <h2>DTC Details View</h2>
     * <p>
     * The {@link jd.ui.eid.view.main.shared.DTCDetails DTC details view} is displayed in an overlay if a DTC is selected from the Top 10 chart or the
     * table. The overlay is positioned to appear right below the chart and table after their height as been reduced. This is triggered in
     * {@link #.openDTCDetailsOverlay}. If the overlay is closed, the original height of chart and table is re-established (see
     * {@link #.closeDTCDetailsOverlay}). Also, if the overlay is visible, the filter area is disabled so that the user can focus on the header area
     * (chart and table) and the details. If anything about the table changes (filtering, sorting, searching, KPI selection), the DTC details overlay
     * is closed.
     * </p>
     * <h2>Personalization</h2>
     * <p>
     * When entering the dashboard, the user's personalized DTC filters are retrieved (see {@link #.initFiltersWithPersonalization}). There are four
     * different outcomes:
     * <ul>
     * <li>Personalization applied successfully: The filter selection for has been pre-populated based on the stored personalization and the
     * available domain values.</li>
     * <li>Communication error: Personalization couldn't be retrieved due to e.g. network error. This is handled by {@link #._onRequestFailed}.</li>
     * <li>Personalization not available: The user hasn't maintained any personalization. This can trigger a dialog to prompt the user to do so (if
     * not surpressed in the browser's local storage, see {@link #.showMaintainPersonalizationDialog}).<br />
     * The flag <em>_bAutoRefreshDTCFilters</em> is set when the user navigates to the Personalization view via the 'Missing personalization' popup.
     * This is done, so that once the user returns to the Dashboard view, the DTC filters can be refreshed automatically. This refresh (in
     * onAfterRendering) is done only if the _bAutoRefreshDTCFilters flag is true. </li>
     * <li>Persoanlization is obsolete: This happens if the available domain values have changed in the backend and e.g. platform and product line
     * cannot be applied anymore. The user is prompted to update his personlized filters (see {@link #.showObsoletePersonalizationDialog}).</li>
     * </ul>
     * <h2>Raised Events</h2>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#Shell::navigate} : Raised while navigating to another view</li>
     * </ul>
     * </p>
     * </p>
     * <h2>Event Handling</h2>
     * <p>
     * The following event bus events are handled by the controllers:
     * <ul>
     * <li>{@link jd.ui.eid.Events#BusinessProcess::addedDTCToBlacklist} - handled by {@link #._handleAddedDTCToBlacklist}</li>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} - handled by {@link #._handleNavigating}</li>
     * <li>{@link jd.ui.eid.Events#DTCDetailsOverlayDashboard::closed} - handled by {@link #.handleDTCDetailsOverlayClosed}</li>
     * <li>{@link jd.ui.eid.Events#Worksheet::open} - handled by {@link #._handleOpenWorksheet}</li>
     * <li>{@link jd.ui.eid.Events#EidModel::fetchingData} - handled by {@link #.handleModelFetchingData}</li>
     * <li>{@link jd.ui.eid.Events#EidModel::dataFetched} - handled by {@link #.handleModelDataFetched}</li>
     * </ul>
     * </p>
     * <h2>Merge Controllers</h2>
     * <p>
     * The controller inherits all methods from the following merge controllers:
     * <ul>
     * <li>{@link jd.ui.eid.view.BaseController}</li>
     * <li>{@link jd.ui.eid.view.main.shared.DTCTableController} to manage the table of DTCs, KPI selection, data retrieval, etc.</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @augments jd.ui.eid.view.main.shared.DTCTableController
     * @name jd.ui.eid.view.main.shell.Dashboard
     */
    sap.ui.controller("jd.ui.eid.view.main.shell.Dashboard", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.DTCTableController,
            /** @lends jd.ui.eid.view.main.shell.Dashboard */
            {

                _aIndicesOfInactiveColumns : [],
                _bDashboardHeadAreaHeightReduced : false,
                _bIsDTCDetailsOpen : false,
                _bAutoRefreshDTCFilters : false,
                _iDTCListTableExpandedRowCount : 15,
                _iDTCListTableReducedRowCount : 5,
                _sCsColumnChartHeightExpanded : "400px",
                _sCssColumnChartHeightReduced : "240px",
                _eHeaderArea : 'Table', // Table, Chart
                _iMarkedChartColumnIndex : null,
                _oDTCColumnChart : null,
                _oDTCFilterAreaDelegate : null,
                _oDTCFilterArea : null,
                _oDTCTable : null,
                _oMaintainPersonalizationDialog : null,
                _oObsoletePersonalizationDialog : null,
                _oPersonalizationService : null,
                _oService : null,
                _oTrendRangeToolPopupDelegate : null,
                _oOverlay : null,
                _oView : null,
                _sPersonalizationDialogFragmentId : "MaintainPersonalizationDialog",
                _sPersonalizationDialogStorageKey : "MaintainPersonalizationDontShowThisAgain",
                _sViewName : "jd.ui.eid.view.main.shell.Dashboard",

                /* SECTION - View Life Cycle - START */

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 */
                onInit : function() {
                    var that = this;
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewShellDashboard");
                    this._oView.addStyleClass("jdUiEidScrollLayout jdUiEidScrollLayoutHorizontal jdUiEidScrollLayoutScrollBarOutside");

                    // Config
                    this.mDTCTableControllerConfig.mFetchDTCList.sFilterSelectionPath = "/DTCFilters/FilterSelection";
                    this.mDTCTableControllerConfig.bHighlightDTCsInBasket = false;

                    // Subscribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.subscribe("BusinessProcess", "addedDTCToBlacklist", this._handleAddedDTCToBlacklist, this);
                    oEventBus.subscribe("Navigation", "navigating", this._handleNavigating, this);
                    oEventBus.subscribe('DTCDetailsOverlayDashboard', 'closed', this.handleDTCDetailsOverlayClosed, this);
                    oEventBus.subscribe("Worksheet", "open", this._handleOpenWorksheet, this);
                    oEventBus.subscribe("WorksheetOverlay", "closed", this.handleWorksheetOverlayClosed, this);
                    oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

                    // Get references to relevant service facades.
                    this._oService = this.getServiceFacade("FilterDomainValue");
                    this._oService.attachRequestFailed(this._onRequestFailed);
                    this._oPersonalizationService = this.getServiceFacade("PersonalizationFilters");
                    this._oPersonalizationService.attachRequestFailed(this._onRequestFailed);

                    // this._eHeaderArea = jd.ui.eid.view.main.shell.Dashboard.HeaderArea.Chart;
                    this._oDTCTable = this.byId("DTCListTable");
                    // Chart init
                    this._oDTCColumnChart = this.byId("DTCColumnChart");
                    // value in decimal and with colore palette
                    jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oDTCColumnChart, "DECIMAL", true);
                    // Register chart delegates
                    this._oDTCColumnChart.attachInitialized(this._markColumnAsSelected, this);
                    this._oDTCColumnChart.addEventDelegate(this._markColumnAsSelected, this);
                    this._oDTCColumnChart.addEventDelegate({
                        onAfterRendering : function() {
                            var aTop10Charts = sap.ui.getCore().getModel().getProperty("/Top10DTCs/Records");
                            var mWarningLightStyles = {
                                "Info" : {
                                    fill : "#7b97b7",
                                    stroke : "#0A51A1"
                                },
                                "Service Alert" : {
                                    fill : "#FFF3A8",
                                    stroke : "#FFDE00"
                                },
                                "Stop" : {
                                    fill : "#D1999B",
                                    stroke : "#D2232A"
                                },
                                "Default" : {
                                    fill : "#cccccc",
                                    stroke : "#777777"
                                }
                            };
                            $.each(aTop10Charts, function(iIdx, mDTC) {
                                var $rect = that._oDTCColumnChart.$().find(".v-column:nth-child(" + (iIdx + 1) + ") .v-datapoint");
                                var mStyle = mWarningLightStyles.Default;
                                if (mWarningLightStyles[mDTC.WarningLight]) {
                                    mStyle = mWarningLightStyles[mDTC.WarningLight];
                                }
                                $rect.css("fill", mStyle.fill);
                                $rect.css("stroke", mStyle.stroke);
                                $rect.css("stroke-width", "2px");
                            });
                        }
                    });

                    this._oDTCColumnChart.addEventDelegate({
                        onAfterRendering : function() {
                            // Hook into on after rendering so that we can highlight the column associated with a DTC was has just been added
                            // to the blacklist.Lzhlmcl1hblsqt

                            $.each(that._aIndicesOfInactiveColumns, function(iIdx, iColumnIndex) {
                                jd.ui.eid.common.chart.ChartHelper.addClassToNthColumnOfColumnChart(that._oDTCColumnChart, iColumnIndex,
                                        "jdUiEidChartColumnInactive");

                            });
                        }
                    });

                    this.initFilterArea();
                    this.initTrendRangeToolPopup();
                    this.initDTCTableController();
                    // Load master filter domain values (platform and product line).
                    this.initFiltersWithPersonalization();
                },

                /**
                 * Initializes/Resets the filter domain/selection values and applies the user's filter personalization settings
                 */
                initFiltersWithPersonalization : function() {
                    var oController = this;

                    if (oController.getApplication().getParameters().applyPersonalization) {
                        // Before beginning, set busy state on filter area and chart/table area.
                        this._oDTCFilterAreaDelegate.setBusy(true);
                        this._oDTCTable.setBusy(true);
                        this._oDTCColumnChart.setBusy(true);
                    }

                    var that = this;
                    this._oService.getPlatformAndProductLine(function() {
                        if (oController.getApplication().getParameters().applyPersonalization) {
                            // First initialize (before applying personalization)
                            jd.ui.eid.model.EidModel.TransformationHelper.initializeDepedentDTCFilterSelection(oController._oDTCFilterAreaDelegate
                                    .getSelectionPath());

                            // Apply personalization
                            oController._oPersonalizationService.applyPersonalization(oController._oDTCFilterAreaDelegate.getSelectionPath(),
                                    oController._oDTCFilterAreaDelegate.getFilterStatePath(), function() {
                                        // If pers. was applied
                                        // Don't change the busy state here of the the table/chart as the data for those will be fetched now.
                                        oController.fetchDTCList();
                                        oController.fetchTop10DTCs();
                                        oController.handleControlStateBasedOnModelState();
                                        oController._oDTCFilterAreaDelegate.setBusy(false);
                                    }, function() {
                                        oController.handleControlStateBasedOnModelState();
                                        // If pers. is unavailable
                                        that.showMaintainPersonalizationDialog();
                                        oController._oDTCFilterAreaDelegate.setBusy(false);
                                        oController._oDTCTable.setBusy(false);
                                        oController._oDTCColumnChart.setBusy(false);
                                    }, function() {
                                        // If an error occurred
                                        oController._oDTCFilterAreaDelegate.setBusy(false);
                                        oController._oDTCTable.setBusy(false);
                                        oController._oDTCColumnChart.setBusy(false);
                                        oController.handleControlStateBasedOnModelState();
                                        oController._onRequestFailed();
                                    }, function() {
                                        // Personalization deprecated
                                        oController.showObsoletePersonalizationDialog();
                                        oController._oDTCFilterAreaDelegate.setBusy(false);
                                        oController._oDTCTable.setBusy(false);
                                        oController._oDTCColumnChart.setBusy(false);
                                        oController.handleControlStateBasedOnModelState();
                                    });
                        } else {
                            oController.handleControlStateBasedOnModelState();
                        };
                    });
                },

                /**
                 * Initializes the filter area fragment the using the {@link jd.ui.eid.common.delegate.DTCFilterAreaDelegate}.
                 */
                initFilterArea : function() {
                    var sFilterAreaFragmentId = this.createId("FilterArea");

                    // Create the delegate object for the DTC Filter fragment
                    this._oDTCFilterAreaDelegate = new jd.ui.eid.common.delegate.DTCFilterAreaDelegate({
                        fragmentId : sFilterAreaFragmentId,
                        domainValuePath : "/DTCFilters",
                        selectionPath : "/DTCFilters/FilterSelection",
                        filterStatePath : "/DTCFilters/FilterState",
                        filterAreaCleared : [this.handleFilterAreaCleared, this],
                        filterAreaReset : [this.handleFilterAreaReset, this],
                        filterItemValueChanged : [this.handleFilterItemValueChanged, this],
                        filterItemCleared : [this.handleFilterItemCleared, this]

                    }).setModel(sap.ui.getCore().getModel());

                    // Create the DTC Filter Area Fragment
                    this._oFilterArea = jd.ui.eid.xmlfragment(sFilterAreaFragmentId, "jd.ui.eid.fragment.filter.DTCFilterArea",
                            this._oDTCFilterAreaDelegate);

                    // we pass the fragment object to the delegator to work with
                    this._oDTCFilterAreaDelegate.setFilterArea(this._oFilterArea);

                    // finally we set the filter area into the Dialog
                    this.byId("FilterAreaPlaceholder").addContent(this._oFilterArea);
                },

                /**
                 * Initializes the trend range tool popup (available via the respective button on top of the DTC table) using the
                 * {@link jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate}.
                 */
                initTrendRangeToolPopup : function() {
                    // Initialize Date Range Tool Popup for KPI Trend Range on Table Toolbar
                    this._oTrendRangeToolPopupDelegate = new jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate({
                        allowEmpty : true,
                        fragmentId : this.createId("TrendDateToolPopup"),
                        modelPathFrom : "/DTCFilters/FilterSelection/TrendRange/Start",
                        modelPathTo : "/DTCFilters/FilterSelection/TrendRange/End",
                        modelUpdated : [this.handleTrendRangeChanged, this]
                    }).setModel(sap.ui.getCore().getModel());
                    var oPopup = jd.ui.eid.xmlfragment(this.createId("TrendDateToolPopup"), "jd.ui.eid.fragment.filter.DateRangeToolPopup",
                            this._oTrendRangeToolPopupDelegate);
                    oPopup.bindProperty("title", "i18n>TREND_RANGE_TOOL_POPUP_HED_TITLE");
                    var oOpener = this.byId('trendDateRangeButton');
                    oPopup.setOpener(oOpener);
                    oOpener.attachPress(function() {
                        if (oPopup.isOpen()) {
                            oPopup.close();
                        } else {
                            oPopup.open();
                        }
                    });
                },

                /**
                 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered (NOT before the first rendering!
                 * onInit() is used for that one!).
                 */
                onBeforeRendering : function() {
                    this.onDTCTableControllerBeforeRendering();
                    this.handleControlStateBasedOnModelState();
                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 */
                onAfterRendering : function() {
                    this.onDTCTableControllerAfterRendering();

                    // The _bAutoRefreshDTCFilters flag is set if the user navigated to the Personalization view from the 'Maintain Personalization'
                    // dialog. Once the user returns to the Dashboard, the filters are refreshed automatically.
                    if (this._bAutoRefreshDTCFilters) {
                        this._bAutoRefreshDTCFilters = false;
                        this.initFiltersWithPersonalization();
                    }
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 */
                onExit : function() {
                    // Exit mered controllers
                    this.exitDTCTableController();

                    // Unsubscribe to event bus
                    var oEventBus = sap.ui.getCore().getEventBus();
                    oEventBus.unsubscribe("BusinessProcess", "addedDTCToBlacklist", this._handleAddedDTCToBlacklist, this);
                    oEventBus.unsubscribe("Navigation", "navigating", this._handleNavigating, this);
                    oEventBus.unsubscribe('DTCDetailsOverlayDashboard', 'closed', this.handleDTCDetailsOverlayClosed, this);
                    oEventBus.unsubscribe("Worksheet", "open", this._handleOpenWorksheet, this);
                    oEventBus.unsubscribe("WorksheetOverlay", "closed", this.handleWorksheetOverlayClosed, this);
                    oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

                    // Detach event listener
                    this._oPersonalizationService.detachRequestFailed(this._onRequestFailed);
                    this._oService.detachRequestFailed(this._onRequestFailed);

                    // Destroy controls
                    this.byId("TrendDateToolPopup", "DateRangeToolPopup").destroy();
                    if (this._oMaintainPersonalizationDialog) {
                        this._oMaintainPersonalizationDialog.destroy();
                    }
                    if (this._oObsoletePersonalizationDialog) {
                        this._oObsoletePersonalizationDialog.destroy();
                    }
                    if (this._oOverlay) {
                        this._oOverlay.destroy();
                    }

                    // Destroy delegates
                    this._oDTCFilterAreaDelegate.destroy();
                    this._oTrendRangeToolPopupDelegate.destroy();

                    // Set properties to null
                    this._aIndicesOfInactiveColumns = null;
                    this._oDTCColumnChart = null;
                    this._oDTCFilterAreaDelegate = null;
                    this._oDTCFilterArea = null;
                    this._oDTCTable = null;
                    this._oMaintainPersonalizationDialog = null;
                    this._oObsoletePersonalizationDialog = null;
                    this._oPersonalizationService = null;
                    this._oService = null;
                    this._oOverlay = null;
                    this._oView = null;
                    this.mDTCTableControllerConfig = null;
                },

                /* SECTION - View Life Cycle - END */

                /* SECTION - Maintain Personalization Dialog - START */

                /**
                 * Shows the dialog that asks the user to maintain the personalization (only if the 'do not show again' flag is not stored in the
                 * local storage of the browser.
                 */
                showMaintainPersonalizationDialog : function() {
                    var bDontShowThisAgain = localStorage.getItem(this._sPersonalizationDialogStorageKey);
                    if (bDontShowThisAgain !== "true") {
                        if (!this._oMaintainPersonalizationDialog) {
                            this._oMaintainPersonalizationDialog = jd.ui.eid.xmlfragment(this._sPersonalizationDialogFragmentId,
                                    "jd.ui.eid.fragment.dialog.main.MaintainPersonalizationDialog", this);
                        }
                        this._oMaintainPersonalizationDialog.open();
                    }
                },

                /**
                 * Handles the 'Go to personalization' button of the 'maintain personalization' dialog and sends the
                 * {@link jd.ui.eid.Events#Shell::navigate} event to navigate to the personalization. Also updates the browser's local storage based
                 * on the checkbox selection.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the press event fired by the dialog's button.
                 */
                handleMaintainPersonalizationDialogGo : function(oEvent) {
                    sap.ui.getCore().getEventBus().publish("Shell", "navigate", {
                        target : 'wiPersonalization'
                    });

                    // Refresh the filters automatically when the user returns to the Dashboard
                    this._bAutoRefreshDTCFilters = true;

                    localStorage.setItem(this._sPersonalizationDialogStorageKey, sap.ui.core.Fragment.byId(this._sPersonalizationDialogFragmentId,
                            "Checkbox").getChecked());
                    this._oMaintainPersonalizationDialog.close();
                },

                /**
                 * Handles the 'Cancel' button of the 'maintain personalization' dialog and closes it. Also updates the browser's local storage based
                 * on the checkbox selection.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the press event fired by the dialog's button.
                 */
                handleMaintainPersonalizationDialogCancel : function(oEvent) {
                    if (this._oMaintainPersonalizationDialog.isOpen()) {
                        localStorage.setItem(this._sPersonalizationDialogStorageKey, sap.ui.core.Fragment.byId(
                                this._sPersonalizationDialogFragmentId, "Checkbox").getChecked());
                        this._oMaintainPersonalizationDialog.close();
                    }
                },

                /* SECTION - Maintain Personalization Dialog - END */

                /* SECTION - Obsolte Personalization Dialog - START */

                showObsoletePersonalizationDialog : function() {
                    if (!this._oObsoletePersonalizationDialog) {
                        this._oObsoletePersonalizationDialog = jd.ui.eid.xmlfragment("jd.ui.eid.fragment.dialog.main.ObsoletePersonalizationDialog",
                                this);
                    }
                    this._oObsoletePersonalizationDialog.open();
                },

                handleObsoletePersonalizationDialogAction : function(oEvent) {
                    var oSrc = oEvent.getSource();
                    if (this._oObsoletePersonalizationDialog && this._oObsoletePersonalizationDialog.indexOfButton(oSrc) == 0) {
                        // Go to personalization
                        sap.ui.getCore().getEventBus().publish("Shell", "navigate", {
                            target : 'wiPersonalization'
                        });
                    }
                    // Anyway, we close the dialog eventually
                    if (this._oObsoletePersonalizationDialog.isOpen()) {
                        this._oObsoletePersonalizationDialog.close();
                    }
                },

                /* SECTION - Obsolte Personalization Dialog - END */

                /**
                 * Handles the event fired when a DTC has successfully been added to the DTC blacklist. Checks whether the DTC is shown in the top 10
                 * DTC chart and highlights the corresponding column.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                _handleAddedDTCToBlacklist : function(sChannelId, sEvent, oData) {
                    var iIndexInTop10 = oData.iIndexInTop10;
                    if (iIndexInTop10 != -1) {
                        jd.ui.eid.common.chart.ChartHelper.addClassToNthColumnOfColumnChart(this._oDTCColumnChart, iIndexInTop10,
                                "jdUiEidChartColumnInactive");
                        this._aIndicesOfInactiveColumns.push(iIndexInTop10);
                    }
                },

                /**
                 * Handles the <code>navigating</code> event from channel <code>Navigation</code>. If navigating away from the current view, the
                 * DTC details overlay is closed (if open). If we navigate back to the dashboard and the DTC details overlay was open, we re-open it
                 * again.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                _handleNavigating : function(sChannelId, sEvent, oData) {
                    if (oData.origin == this._sViewName && this._bIsDTCDetailsOpen) {
                        // Navigating away from the dashboard, so hide the DTC details
                        jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayDashboard().close(true);
                    } else if (oData.target == this._sViewName && this._bIsDTCDetailsOpen) {
                        // Navigating back to the dashboard, so show the DTC details
                        jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayDashboard().open();
                    }
                },

                /**
                 * Handles the <code>open</code> event on channel <code>Worksheet</code> and opens the {@link jd.ui.eid.view.main.Worksheet} view
                 * in an overlay.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                _handleOpenWorksheet : function(sChannelId, sEvent, oData) {
                    var oOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
                    oOverlay.setContext(jd.ui.eid.view.main.Worksheet.Mode.DTCs);
                    if (!oOverlay.isOpen()) {
                        oOverlay.open();
                    }
                },

                /**
                 * Hook method for {@link #handleWorksheetOverlayClosed}, refreshes the DTC list.
                 */
                handleWorksheetOverlayClosed : function() {
                    $.sap.log.debug("Handling WorksheetOverlay::closed event", null, this._sViewName);
                    this.fetchDTCList();
                    this.fetchTop10DTCs();
                },

                /* SECTION - Event Handler for Filter Area and Filter Items - START */

                /**
                 * Handles the valueChanged event of the filter items to send a request.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired.
                 */
                handleFilterItemValueChanged : function(oEvent) {
                    if (this._oDTCFilterAreaDelegate.isReadyToFetchDependentData()) {
                        var sFilterAreaId = this._oDTCFilterAreaDelegate.getFragmentId();
                        if (oEvent.getParameter("filterFragment") == sap.ui.core.Fragment.byId(sFilterAreaId, "Platforms")) {
                            // Set table and chart to busy
                            this.byId("DTCListTable").setBusy(true);
                            this._oDTCColumnChart.setBusy(true);

                            // The 'platform and product line' filter item changed, so we need to retrieve the domain values anew.
                            var oSelection = oEvent.getParameter("filterFragment").getSelection();
                            var sPlatform = oSelection[0].PlatformID;
                            var sProductLine = oSelection[0].ProductLine[0];

                            // Also, let's reset the DTC filter selection model of the dependent filters.
                            jd.ui.eid.model.EidModel.TransformationHelper.initializeDepedentDTCFilterSelection(this._oDTCFilterAreaDelegate
                                    .getSelectionPath());

                            var that = this;
                            this._oFilterArea.setBusy(true);
                            this._oService.getDTCFilterDomainValues(sPlatform, sProductLine, function() {
                                that._oFilterArea.setBusy(false);
                                that.fetchDTCList();
                                that.fetchTop10DTCs();
                            }, function() {
                                that._oFilterArea.setBusy(false);
                                that._onRequestFailed.apply(this, arguments);
                            });
                        } else {
                            this.fetchDTCList();
                            this.fetchTop10DTCs();
                        }
                    }

                    // Make sure that the UI has a consitent state
                    this.handleControlStateBasedOnModelState();
                },

                /**
                 * Handles the cleared event of the filter items to send a request.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired.
                 */
                handleFilterItemCleared : function(oEvent) {
                    this.handleFilterItemValueChanged(oEvent);
                },

                /**
                 * Handles the clear action from the filter area's tool popup and clears the filter area.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event.
                 */
                handleFilterAreaCleared : function(oEvent) {
                    // Let's make sure that the search term is also cleared, because the table will be refreshed
                    var oModel = sap.ui.getCore().getModel();
                    oModel.setProperty("/SearchTerms/DashboardDTCListSearchTerm", "");

                    this._resetWarningLightFilter();
                    this.handleControlStateBasedOnModelState();
                },

                /**
                 * Handles the reset action from the filter area's tool popup and resets the filter area.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event.
                 */
                handleFilterAreaReset : function(oEvent) {
                    // Let's make sure that the search term is also cleared, because the table will be refreshed
                    var oModel = sap.ui.getCore().getModel();
                    oModel.setProperty("/SearchTerms/DashboardDTCListSearchTerm", "");

                    this._resetWarningLightFilter();
                    this.initFiltersWithPersonalization();
                },

                /**
                 * reset the Warning Light Filter and remove the filter binding from table rows
                 */
                _resetWarningLightFilter : function() {
                    this.byId('WarningLightColumn').setFiltered(false);
                    this.byId('WarningLightColumn').setFilterValue("");
                    this.byId("DTCListTable").getBinding("rows").filter([]);
                },

                /**
                 * Handles the modeUpdated events fromhandleKPISelectionChangeHookAfter the trend range tool popup delegate. Closes the overlay if
                 * open and fetches the data.
                 */
                handleTrendRangeChanged : function(oEvent) {
                    this.closeDTCDetailsOverlay();
                    this.handleFilterItemValueChanged(oEvent);
                },

                /* SECTION - Event Handler for Filter Area and Filter Items - END */

                /* SECTION - Fetching of Data - START */

                /**
                 * Hook method called before the DTC list is fetched.
                 * 
                 * @see jd.ui.eid.view.shared.DTCTableController#fetchDTCListHookBefore
                 */
                fetchDTCListHookBefore : function() {
                    if (!this._oDTCFilterAreaDelegate.isReadyToFetchDependentData()) {
                        return false;
                        // Interrupt execution
                    }
                    // As new DTC will be displayed afterwards and the ones which have just been added to the blacklist won't be among them anymore,
                    // let's reset the array that keeps track of them.
                    this._aIndicesOfInactiveColumns.length = 0;
                },

                /**
                 * Hook method called before the refresh of the DTC list is triggered and also refreshes the data of the Top 10 DTCs chart and hides
                 * the detail area.
                 * 
                 * @see jd.ui.eid.view.shared.DTCTableController#handleRefreshDTCListHookBefore
                 */
                handleRefreshDTCListHookBefore : function() {
                    this.closeDTCDetailsOverlay();
                    this.fetchTop10DTCs();
                },

                /**
                 * Fetches the top 10 DTCs for the given filters.
                 */
                fetchTop10DTCs : function() {
                    if (this.fetchDTCListHookBefore() === false) {
                        // Interupt execution
                        return;
                    }

                    var oCustomFilter = sap.ui.getCore().getModel().getProperty(this.mDTCTableControllerConfig.mFetchDTCList.sFilterSelectionPath);
                    var sSelectedKPIID = this.byId(this.mDTCTableControllerConfig.sKPIComboBoxId).getSelectedKey();
                    var that = this;
                    this._oDTCColumnChart.setBusy(true);
                    this.getServiceFacade('DTC').getTop10DTCs(oCustomFilter, sSelectedKPIID, function() {
                        that._oDTCColumnChart.setBusy(false);
                    }, function() {
                        that._oDTCColumnChart.setBusy(false);
                    });
                },

                /**
                 * Handles the event fired when data for the Top 10 DTCs chart is fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                handleModelFetchingData : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/Top10DTCs") {
                        this._oDTCColumnChart.setBusy(true);
                    }
                },

                /**
                 * Handles the event fired when data for the Top 10 DTCs chart has been fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                handleModelDataFetched : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/Top10DTCs") {
                        this._oDTCColumnChart.setBusy(false);
                    }
                },

                /* SECTION - Fetching of Data - END */

                /**
                 * Handles the states of the controls on the dashboard based on the current state of the model. This covers setting filter items to
                 * invisible if no platform and product line have been selected, etc.
                 */
                handleControlStateBasedOnModelState : function() {
                    var oColumnChart = this._oDTCColumnChart;
                    var oTable = this.byId("DTCListTable");
                    var oModel = sap.ui.getCore().getModel();

                    if (this._oDTCFilterAreaDelegate.isPlatformAndProductlineSelected()) {
                        // Platform and Product line selected. So make the controls visible
                        this._oDTCFilterAreaDelegate.setVisibilityOfDependentFilterItems(true);
                        this.byId("dashboardSearchField").setEnabled(true);
                        this.byId("RefreshDTCListButton").setEnabled(true);

                        // update noData texts for chart and table
                        var sText = jd.ui.eid.common.I18NHelper.getText("DTC_DASHBOARD_TXT_NO_DATA_DUE_TO_EMPTY_RESULT");
                        oColumnChart.getNoData().setText(sText);
                        oTable.getNoData().setText(sText);
                    } else {
                        // Cancel any pending request for DTC list and make sure chart and table are not busy
                        this.getServiceFacade("DTC").abortPendingDTCRequests();
                        oColumnChart.setBusy(false);
                        oTable.setBusy(false);

                        // no platform and product line have been selected, so let's make all other filter items invisible.
                        this._oDTCFilterAreaDelegate.setVisibilityOfDependentFilterItems(false);
                        this.byId("dashboardSearchField").setEnabled(false);
                        this.byId("RefreshDTCListButton").setEnabled(false);

                        // update noData texts for chart and table
                        var sText = jd.ui.eid.common.I18NHelper.getText("DTC_DASHBOARD_TXT_NO_DATA_DUE_TO_MISSING_MANDATORY_FILTERS");
                        oColumnChart.getNoData().setText(sText);
                        oTable.getNoData().setText(sText);

                        // remove data from model
                        oModel.setProperty("/Top10DTCs/Records", []);
                        oModel.setProperty("/DTCList", []);
                        oModel.setProperty("/DTCFilters/PINPopulation", 0);

                        // Reset the table's list binding length so that it doesn't show the pages nor the rows of the table
                        // oTable.getBinding("rows").setLength(0);
                        oTable.getBinding("rows").reset();
                    }
                },

                /**
                 * This function toggles the visibility of chart and table area
                 * 
                 * @private
                 * @param {boolean}
                 *            bVisible boolean value which specifies if the table area is visible, if table area is visible, the top10 chart will be
                 *            hidden and vice versa
                 */
                _toggleDTCListTableVisible : function(bVisible) {
                    var chartArea = this.byId("DTCTopChartArea");
                    var tableArea = this.byId("DTCListTableArea");
                    var searchField = this.byId('dashboardSearchField');

                    // set the Area visibility
                    chartArea.setVisible(!bVisible);
                    tableArea.setVisible(bVisible);
                    searchField.setVisible(bVisible);

                    // Because the 'table header' which shows the count of distinct DTCs has some weired binding, we need to refresh it. Thus, the
                    // formatter will be triggered and update the header's value based on the the currently displayed header area (chart vs. table).
                    this.byId("TableHeader").getBinding("text").refresh(true);
                },

                /**
                 * Scrolls the shell's content to the top so that if the dtc details view is visible, the minified chart and table are displayed
                 * above.
                 */
                _scrollToTop : function() {
                    $(".jdUiEidShellContent").scrollTop(0);
                },

                /**
                 * Set Top 10 DTC Chart area visible
                 */
                handleSwitchColumnChartVisible : function() {
                    this._eHeaderArea = 'Chart';
                    this._toggleDTCListTableVisible(false);
                },

                /**
                 * Set DTC List Table area visible
                 */
                handleSwitchDTCListVisible : function() {
                    this._eHeaderArea = 'Table';
                    this._toggleDTCListTableVisible(true);
                },

                /**
                 * This function handles the event triggered by the click on one column of top 10 chart
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent event triggered by clicking on Chart column
                 */
                handleChartColumnClick : function(oEvent) {
                    // restore the selection mark
                    if (oEvent != null) {
                        this._iMarkedChartColumnIndex = oEvent.getParameter("data")[0].data[0].ctx.path.dii_a1;
                        var aTop10DTCs = sap.ui.getCore().getModel().getProperty("/Top10DTCs/Records");
                        var oSelectedDTC = aTop10DTCs[this._iMarkedChartColumnIndex];
                        var sDTCID = oSelectedDTC.DTCID;
                        jd.ui.eid.model.EidModel.TransformationHelper.bufferExpensiveDTCListItemDataToDTCDetails(oSelectedDTC);
                        this.openDTCDetailsOverlay(sDTCID);
                    }

                    this._markColumnAsSelected();
                },

                /**
                 * Mark one chart Column as selected
                 * 
                 * @private
                 * @param columnIndex:
                 *            the number of the column that needs to be marked as selected
                 */
                _markColumnAsSelected : function() {
                    if (this._iMarkedChartColumnIndex != null) {
                        var that = this;
                        var aDTCTop10ChartColumns = this._oDTCColumnChart.$().find('.v-column .v-datapoint');
                        $.each(aDTCTop10ChartColumns, function(iIdx, column) {
                            var $column = $(column);
                            if (iIdx == that._iMarkedChartColumnIndex) {
                                $column.css("fill-opacity", "1").css("stroke-opacity", "1").prop("class",
                                        "v-datapoint v-morphable-datapoint v-datapoint-selected");
                            } else {
                                $column.css("fill-opacity", "0.4").css("stroke-opacity", "0.4").prop("class", "v-datapoint v-morphable-datapoint");
                            }
                        });
                    }
                },

                /**
                 * This function handles the event triggered by clicking on the link of DTC ID in DTC List table.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent event triggered by clicking on DTC Link
                 */
                handleOpenDTCDetails : function(oEvent) {
                    if (oEvent != null) {
                        var mDTC = oEvent.getSource().getBindingContext().getProperty();
                        jd.ui.eid.model.EidModel.TransformationHelper.bufferExpensiveDTCListItemDataToDTCDetails(mDTC);
                        this.openDTCDetailsOverlay(mDTC.DTCID);
                    }
                },

                /**
                 * This function handles the event that is triggered by clicking on "New Evidence Package" button
                 * 
                 * @param {object}
                 *            oEvent event triggered by clicking on "New Evidence Package"
                 */
                handleNewEvidencePackage : function(oEvent) {
                    var oContext = oEvent.getSource().getBindingContext().getProperty();
                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.startNewPackageInOverlay(oContext);
                },

                /**
                 * Hook for {@link jd.ui.eid.view.main.shared.DTCTableController#handleKPISelectionChange} and closes the DTC details overlay if open.
                 */
                handleKPISelectionChangeHookAfter : function() {
                    this.fetchTop10DTCs();
                    this.closeDTCDetailsOverlay();
                },

                /**
                 * This function handles the search event and triggers the data fetch using the specified search term
                 */
                handleSearch : function() {
                    this.closeDTCDetailsOverlay();
                    this.fetchDTCList();
                },

                /**
                 * Opens the DTC details in an overlay container and adjusts the dasboard UI (chart/table size, etc.) The counterpart is
                 * {@link #.closeDTCDetailsOverlay}.
                 * 
                 * @param {string}
                 *            sDTCID the DTC ID
                 */
                openDTCDetailsOverlay : function(sDTCID) {
                    // Disable the filter area
                    var sFilterAreaId = this._oDTCFilterAreaDelegate.getFragmentId();
                    sap.ui.core.Fragment.byId(sFilterAreaId, "FilterArea").setEnabled(false);

                    // Adjust view so that the overlay can be displayed below the master area (chart/table).
                    if (!this._bDashboardHeadAreaHeightReduced) {
                        this._reduceDashboardHeaderSize();
                    };

                    if (this._oOverlay == null) {
                        this._oOverlay = jd.ui.eid.common.OverlayHelper.getDTCDetailsOverlayDashboard();
                        // this._oOverlay.attachClose(this.handleOverlayClose, this);
                    }
                    this._oOverlay.setContext(sDTCID);

                    if (!this._oOverlay.isOpen()) {
                        this._oOverlay.open();
                        this._bIsDTCDetailsOpen = true;
                    };

                    this._scrollToTop();
                },

                /**
                 * Closes the DTC details view displayed in an overlay (if open) and adjusts the dashboard UI (chart/table size, etc.) The counterpart
                 * is {@link #.openDTCDetailsOverlay}.
                 */
                closeDTCDetailsOverlay : function() {
                    $.sap.log.debug("Closing DTC details overlay", null, this._sViewName);
                    if (this._bIsDTCDetailsOpen) {
                        this._bIsDTCDetailsOpen = false;

                        if (this._oOverlay && this._oOverlay.isOpen()) {
                            this._oOverlay.close();
                        }
                    }
                },

                /**
                 * Handles the {@link jd.ui.eid.Events#DTCDetailsOverlay::closed} event and restores the status of the dashboard (maximized header
                 * area and enabled filter area.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 */
                handleDTCDetailsOverlayClosed : function(sChannelId, sEvent, oData) {
                    $.sap.log.debug("Handling DTCDetails closed", null, this._sViewName);
                    this._bIsDTCDetailsOpen = false;
                    this._restoreDashboardHeaderSize();

                    // Enable the filter area
                    var sFilterAreaId = this._oDTCFilterAreaDelegate.getFragmentId();;
                    sap.ui.core.Fragment.byId(sFilterAreaId, "FilterArea").setEnabled(true);
                },

                /**
                 * Handles the close event of the overlay, fired when the 'X' in the upper right corner is clicked or the cancel button is pressed.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event.
                 */
                handleOverlayClose : function(oEvent) {
                    this.closeDTCDetailsOverlay();
                },

                /* SECTION - Master Area State Helper Methods - START */

                /**
                 * The selection of a column of Top 10 chart will reduce the initial chart height
                 * 
                 * @private
                 * @memberOf jd.ui.eid.view.main.shell.Dashboard
                 */
                _reduceDTCChartAreaSize : function() {
                    this._oDTCColumnChart.setHeight(this._sCssColumnChartHeightReduced);
                    this._oView.addStyleClass("jdUiEidScrollLayoutNoScroll");
                },

                /**
                 * The selection of an item in DTC List table will reduce the initial number of visible rows of table
                 */
                _reduceDTCListTableVisibleRowCount : function() {
                    this.byId("DTCListTable").setVisibleRowCount(this._iDTCListTableReducedRowCount);
                },

                /**
                 * The selection of a column of Top 10 chart will restored to the initial chart height
                 */
                _restoreDTCChartAreaSize : function() {
                    this._oDTCColumnChart.setHeight(this._sCsColumnChartHeightExpanded);
                    this._iMarkedChartColumnIndex = null;
                },

                /**
                 * Restores the DTC table's row count to the original size.
                 */
                _restoreDTCListTableVisibleRowCount : function() {
                    this.byId("DTCListTable").setVisibleRowCount(this._iDTCListTableExpandedRowCount);
                },

                /**
                 * this function restores the original height of Top 10 Chart and DTC List table visible rows
                 */
                _restoreDashboardHeaderSize : function() {
                    this._restoreDTCChartAreaSize();
                    this._restoreDTCListTableVisibleRowCount();
                    this._bDashboardHeadAreaHeightReduced = false;
                    this._oView.removeStyleClass("jdUiEidScrollLayoutNoScroll");

                },

                /**
                 * this function reduces the original height of Top 10 Chart and DTC List table visible rows
                 */
                _reduceDashboardHeaderSize : function() {
                    this._reduceDTCChartAreaSize();
                    this._reduceDTCListTableVisibleRowCount();
                    this._bDashboardHeadAreaHeightReduced = true;
                    this._oView.addStyleClass("jdUiEidScrollLayoutNoScroll");
                },

                /* SECTION - Master Area State Helper Methods - END */

                /**
                 * Formats the DTC count which is used as the table/chart header. If the table is displayed, the count is taken from the binding and
                 * shows the number of items in the table. If the chart is visible, then the total number of DTCs which match the filter criteria are
                 * displayed.
                 * 
                 * @param {array}
                 *            aDTCs an array of DTCs
                 * @param {int}
                 *            iCountFromTop10DTCsChart the number of DTCs that match the filter settings (displayed if the chart is visible)
                 * @returns {string} the formatted count
                 */
                formatDashboardDTCCount : function(aDTCs, iCountFromTop10DTCsChart) {
                    if (this._eHeaderArea == 'Table') {
                        // we pass it on to the merge controller
                        return this.formatDTCCount(aDTCs);
                    } else {
                        var iCount = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(iCountFromTop10DTCsChart);
                        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(iCount, "DTC_TABLE_CAP_COUNT_BY_KPI_MULTIPLE",
                                "DTC_TABLE_CAP_COUNT_BY_KPI_SINGLE");
                    }
                }

            }));
})();