(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CollectionInspectorWithSummary");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("sap.ui.core.Control");
    jd.ui.eid.require("sap.ui.core.delegate.ItemNavigation");

    /**
     * @class The CollectionInspectorWithSummary control is similar to the sap.ui.ux3.CollectionInspector, except that it has a 'summary' area above
     *        the scrolling sidebar. It also introudces a new 'allowSidebarCollapse' property that can be set to false (default value = false) to
     *        prevent the user from being able to collapse the sidebar (sidebar = summary + scrolling list of items).<br>
     *        This control is based on the sap.ui.ux3.CollectionInspector standard control from version 1.16.5. The entire control is copied (instead
     *        of extending sap.ui.ux3.CollectionInspector), to make sure it is not affected during a future upgrade of the installed UI5 version...
     *        <ul>
     *        <li>{@link #.positionSidebar} new method called from onAfterRendering to position the sidebar below the summary area.</li>
     *        <li>{@link #.onclick} changes so that the control also responds to clicks on the secondary text of the collection items.</li>
     *        <li>{@link #.openSidebar} to also animate the summary area when the sidebar opens.
     *        <li>
     *        <li>{@link #.closeSidebar} to also animate the summary area when the sidebar closes.
     *        <li>
     *        </ul>
     * 
     * 
     * @extends sap.ui.core.Control
     * 
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.CollectionInspectorWithSummary", /** @lends jd.ui.eid.control.CollectionInspectorWithSummary */
    {
        metadata : {
            properties : {
                "sidebarVisible" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                },
                "fitParent" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                },
                "allowSidebarCollapse" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                }
            },
            aggregations : {
                "collections" : {
                    type : "jd.ui.eid.control.Collection",
                    multiple : true,
                    singularName : "collection"
                },
                "content" : {
                    type : "sap.ui.core.Control",
                    multiple : true,
                    singularName : "content"
                },
                "summary" : {
                    type : "sap.ui.ux3.ThingGroup",
                    multiple : false,
                    singularName : "summaryContent"
                }
            },
            associations : {
                "selectedCollection" : {
                    type : "jd.ui.eid.control.Collection",
                    multiple : false
                }
            },
            events : {
                "collectionSelected" : {},
                "itemSelectionChanged" : {},
                "editCollection" : {}
            }
        }
    });

    jd.ui.eid.control.CollectionInspectorWithSummary.M_EVENTS = {
        'collectionSelected' : 'collectionSelected',
        'itemSelectionChanged' : 'itemSelectionChanged',
        'editCollection' : 'editCollection'
    };

    /**
     * Initialization the control
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.init = function() {

        var that = this;

        if (!this._oItemNavigation) {
            this._oItemNavigation = new sap.ui.core.delegate.ItemNavigation();
            this._oItemNavigation.setCycling(false);
            this.addDelegate(this._oItemNavigation);
        }

        var oToggleButton = new sap.ui.commons.ToggleButton(this.getId() + "-toggleButton");
        oToggleButton.setParent(this);
        oToggleButton.setTooltip(jd.ui.eid.common.I18NHelper.getText("COLLECTION_INSPECTOR_TOL_TOGGLE_BUTTON"));
        oToggleButton.attachPress(function() {
            if (oToggleButton.getPressed()) {
                that.openSidebar();
            } else {
                that.closeSidebar();
            }
        });
        this._oToggleButton = oToggleButton;

        var oCollectionSelector = new sap.ui.commons.SegmentedButton(this.getId() + "-selector").addStyleClass("jdUiSegmentedButton");

        oCollectionSelector.attachSelect(function(oEvent) {
            var iCollectionIndex = this.indexOfButton(sap.ui.getCore().byId(this.getSelectedButton()));
            var oCollection = that.getCollections()[iCollectionIndex];
            that.setSelectedCollection(oCollection);
            that.fireCollectionSelected({
                collection : oCollection
            });
            that.openSidebar();
        });

        this._oCollectionSelector = oCollectionSelector;

        var oEditButton = new sap.ui.commons.Button();
        oEditButton.addStyleClass("sapUiUx3EditCollectionButton");
        oEditButton.attachPress(function() {
            that.fireEditCollection();
        });
        this._oEditButton = oEditButton;
    };

    /**
     * Destroys elements created by the control
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.exit = function() {
        this._oToggleButton.destroy();
        this._oToggleButton = null;
        this._oEditButton.destroy();
        this._oEditButton = null;
        this._oCollectionSelector.destroy();
        this._oCollectionSelector = null;
        if (this._oItemNavigation) {
            this.removeDelegate(this._oItemNavigation);
            this._oItemNavigation.destroy();
            delete this._oItemNavigation;
        }
    };

    /**
     * called before the control will be rendered
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onBeforeRendering = function() {
        this._oToggleButton.setPressed(this.getSidebarVisible());
    };

    /**
     * called after control has been rendered
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onAfterRendering = function() {
        if (!this.getSelectedCollection()) {
            if (this.getCollections().length > 0) {
                this.setSelectedCollection(this.getCollections()[0]);
            }
        } else {
            var oSelectedCollection = sap.ui.getCore().byId(this.getSelectedCollection());
            if (oSelectedCollection.getSelectedItems().length == 0 && oSelectedCollection.getItems().length > 0) {
                oSelectedCollection.addSelectedItem(oSelectedCollection.getItems()[0]);
            }
        }
        this.setElementsHeight();
        this.updateItemNavigation();
        this.refreshSelectionHighlighting();
        this.positionSidebar();
    };

    /**
     * Called from onAfterRendering. Adjusts the 'top' CSS rule for the scrolling sidebar, so that it is exactly below the summary.
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.positionSidebar = function() {
        // Get the height of the rendered summary
        var iSummaryHeight = this.$().find(".jdUiEidCollectionInspectorSummary").outerHeight();

        // Adjust the 'top' CSS rule of the .jdUiEidCISidebar
        this.$().find(".jdUiEidCISidebar").css("top", iSummaryHeight);
    };

    /**
     * Called when the mouse is clicked anywhere within the CollectionInspectorWithSummary control.
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onclick = function(oEvent) {
        // If the click target doesn't have the jdUiEidCICollectionListItem class, the click event's target could be either the
        // jdUiEidCollectionInspectorCollectionItemText DIV or its parent DIV (the DIV that encloses each list item's text and secondary text)... so
        // we also check the target's parent and target's parent's parent.
        var $oTarget = jQuery(oEvent.target);
        if ($oTarget.hasClass("jdUiEidCICollectionListItem")) {
            // OK. The click event's target is the list item
        } else if ($oTarget.parent().hasClass("jdUiEidCICollectionListItem")) {
            // The click event's target is the DIV within the list item. This DIV contains the 'text' and 'secondaryText' of each CollectionItem
            $oTarget = $oTarget.parent();
        } else if ($oTarget.parent().parent().hasClass("jdUiEidCICollectionListItem")) {
            // The click event's target is the "DIV within the DIV within the list item" (either dUiEidCollectionInspectorCollectionItemText or
            // dUiEidCollectionInspectorCollectionItemSecondaryText)
            $oTarget = $oTarget.parent().parent();
        } else {
            return; // Don't process further. This click wasn't on a list item.
        }

        var oSelectedCollection = sap.ui.getCore().byId(this.getSelectedCollection());
        var iIndex = $oTarget.index();
        if (jQuery.inArray($oTarget.prop("id"), oSelectedCollection.getSelectedItems()) >= 0) {
            oSelectedCollection.removeSelectedItem($oTarget.prop("id"));
        } else {
            oSelectedCollection.addSelectedItem($oTarget.prop("id"));
        }
        this.refreshSelectionHighlighting();
        this.fireItemSelectionChanged({
            selectedItems : oSelectedCollection.getSelectedItems()
        });
    };

    /**
     * returns instance of toggle button
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.getToggleButton = function() {
        return this._oToggleButton;
    };

    /**
     * returns instance of collection selector
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.getCollectionSelector = function() {
        return this._oCollectionSelector;
    };

    /**
     * rerender the sidebar if different collection is selected
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.rerenderSidebar = function() {
        var oCurrentCollection = sap.ui.getCore().byId(this.getSelectedCollection());
        if (oCurrentCollection && oCurrentCollection.getEditable()) {
            this._oEditButton.setVisible(true);
        } else {
            this._oEditButton.setVisible(false);
        }
        var $Content = jQuery.sap.byId(this.getId() + "-sidebar");
        if ($Content.length > 0) {
            var rm = sap.ui.getCore().createRenderManager();
            this.getRenderer().renderSidebar(rm, this);
            rm.flush($Content[0]);
            rm.destroy();
        }
        if (oCurrentCollection && oCurrentCollection.getEditable()) {
            jQuery.sap.byId(this.getId() + "-sidebar").addClass("jdUiEidCIWithEditButton");
        } else {
            jQuery.sap.byId(this.getId() + "-sidebar").removeClass("jdUiEidCIWithEditButton");
        }
        this.updateItemNavigation();
        this.refreshSelectionHighlighting();
    };

    /**
     * load all dom refs to into the item navigation
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.updateItemNavigation = function() {
        var aItemDomRefs = [];
        var $Items = jQuery.sap.byId(this.getId() + "-sidebar").find('li');
        jQuery.each($Items, function(iIndex, $DomRef) {
            aItemDomRefs.push($DomRef);
        });
        this._oItemNavigation.setItemDomRefs(aItemDomRefs);
        this._oItemNavigation.setRootDomRef(jQuery.sap.byId(this.getId() + "-sidebar ul")[0]);
    };

    /**
     * rerender the content if different collection or collection item is selected
     * 
     * @param int
     *            Index of the collection that should be rendered
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.rerenderContent = function() {
        var $Content = jQuery.sap.byId(this.getId() + "-content");
        if ($Content.length > 0) {
            var rm = sap.ui.getCore().createRenderManager();
            this.getRenderer().renderContent(rm, this);
            rm.flush($Content[0]);
            rm.destroy();
        }
        this.setElementsHeight();
    };

    /**
     * Calculate height, so that both the sidebar and the content have the same height
     * 
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.setElementsHeight = function() {
        if (this.getFitParent())
            return;

        var oSidebar = jQuery.sap.byId(this.getId() + "-sidebar");
        var oContent = jQuery.sap.byId(this.getId() + "-content");

        var iContentHeight = oContent.outerHeight(true);
        var iContentMargin = oContent.outerHeight(true) - oContent.height();
        var iSidebarMargin = oSidebar.outerHeight(true) - oSidebar.height();

        oSidebar.height(Math.max(200, iContentHeight) - iSidebarMargin);
        oContent.height(Math.max(200, iContentHeight) - iContentMargin);
    };

    /**
     * Opens the sidebar
     * 
     * @public
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.openSidebar = function() {
        var $this = jQuery.sap.byId(this.getId());
        var $Sidebar = jQuery.sap.byId(this.getId() + "-sidebar");
        var $Content = jQuery.sap.byId(this.getId() + "-content");
        var $leftSection = jQuery.sap.byId(this.getId() + "-leftSection");

        // Custom change (start)
        $leftSection.stop(true, true).animate({
            width : 230
        }, 300, function() {
            $Sidebar.css('width', '');
        });
        // Custom change (end)

        $Sidebar.stop(true, true).animate({
            width : 230
        }, 300, function() {
            $Sidebar.css('width', '');
        });

        $Content.stop(true, true).animate({
            left : 230
        }, 300, function() {
            $Content.css('left', '');
        });
        $this.removeClass("jdUiEidCISidebarClosed");
        $this.addClass("jdUiEidCISidebarOpened");
        this._oToggleButton.setPressed(true);
    };

    /**
     * Closes the siedebar
     * 
     * @public
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.closeSidebar = function() {
        var $this = jQuery.sap.byId(this.getId());
        var $Sidebar = jQuery.sap.byId(this.getId() + "-sidebar");
        var $Content = jQuery.sap.byId(this.getId() + "-content");
        var $leftSection = jQuery.sap.byId(this.getId() + "-leftSection");

        // Custom change (start)
        $leftSection.stop(true, true).animate({
            width : 0
        }, 300, function() {
            $Sidebar.css('width', '');
        });
        // Custom change (end)

        $Sidebar.stop(true, true).animate({
            width : 0
        }, 300, function() {
            $Sidebar.css('width', '');
        });

        $Content.stop(true, true).animate({
            left : 0
        }, 300, function() {
            $Content.css('left', '');
        });
        $this.removeClass("jdUiEidCISidebarOpened");
        $this.addClass("jdUiEidCISidebarClosed");
        this._oToggleButton.setPressed(false);
    };

    /**
     * Inserts a collection into the aggregation named <code>collections</code>.
     * 
     * @param {jd.ui.eid.control.Collection}
     *            oCollection the collection to insert; if empty, nothing is inserted
     * @param {int}
     *            iIndex the <code>0</code>-based index the collection should be inserted at; for a negative value of <code>iIndex</code>, the
     *            collection is inserted at position 0; for a value greater than the current size of the aggregation, the collection is inserted at
     *            the last position
     * @return {jd.ui.eid.control.CollectionInspectorWithSummary} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#insertCollection
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.insertCollection = function(oCollection, iIndex) {
        var oButton = new sap.ui.commons.Button();
        oButton.setText(oCollection.getTitle());
        // This code was copied from the UI5 git repository, to fix the standard UI5 bug
        // Please remove this code after updating to UI5 1.16.9 or higher
        // START
        // FIXME
        oCollection.attachEvent('_titleChanged', function(oEvent) {
            oButton.setText(oEvent.getParameter("newTitle"));
        });
        // END
        var that = this;
        oCollection.attachSelectionChanged(function() {
            that.refreshSelectionHighlighting();
        });
        oCollection.attachPropertyChanged(function() {
            that.rerenderSidebar();
        });
        this._oCollectionSelector.insertButton(oButton, iIndex);
        return this.insertAggregation("collections", oCollection, iIndex);
    };

    /**
     * Adds some collection <code>oCollection</code> to the aggregation named <code>collections</code>.
     * 
     * @param {jd.ui.eid.control.Collection}
     *            oCollection the collection to add; if empty, nothing is inserted
     * @return {jd.ui.eid.control.CollectionInspectorWithSummary} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#addCollection
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.addCollection = function(oCollection) {
        var oButton = new sap.ui.commons.Button();
        oButton.setText(oCollection.getTitle());
        // This code was copied from the UI5 git repository, to fix the standard UI5 bug
        // Please remove this code after updating to UI5 1.16.9 or higher
        // START
        // FIXME
        oCollection.attachEvent('_titleChanged', function(oEvent) {
            oButton.setText(oEvent.getParameter("newTitle"));
        });
        // END
        var that = this;
        oCollection.attachSelectionChanged(function() {
            that.refreshSelectionHighlighting();
        });
        oCollection.attachPropertyChanged(function() {
            that.rerenderSidebar();
        });
        this._oCollectionSelector.addButton(oButton);
        return this.addAggregation("collections", oCollection);
    };

    /**
     * Removes an collection from the aggregation named <code>collections</code>.
     * 
     * @param {int |
     *            string | jd.ui.eid.control.Collection} vCollection the collection to remove or its index or id
     * @return {jd.ui.eid.control.Collection} the removed collection or null
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#removeCollection
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.removeCollection = function(vCollection) {
        var iIndex;
        if (typeof vCollection == "object") {
            iIndex = this.indexOfCollection(vCollection);
        } else {
            iIndex = this.indexOfCollection(sap.ui.getCore().byId(vCollection));
        }
        var oButton = this._oCollectionSelector.getButtons()[iIndex];
        this._oCollectionSelector.removeButton(oButton);

        var oResult = this.removeAggregation("collections", vCollection);
        if (oResult && this.getSelectedCollection() == oResult.getId()) {
            this.setSelectedCollection(null);
        }
        return oResult;
    };

    /**
     * Removes all the controls in the aggregation named <code>collections</code>.<br/> Additionally unregisters them from the hosting UIArea.
     * 
     * @return {jd.ui.eid.control.Collection[]} an array of the removed elements (might be empty)
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#removeAllCollections
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.removeAllCollections = function() {
        this._oCollectionSelector.removeAllButtons();
        this.setSelectedCollection(null);
        return this.removeAllAggregation("collections");
    };

    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.setSelectedCollection = function(oCollection) {
        this.setAssociation("selectedCollection", oCollection, true);
        if (!oCollection) {
            this._oEditButton.setVisible(false);
        } else {
            // Select the corresponding item in top navigation
            this._oCollectionSelector.setSelectedButton(this._oCollectionSelector.getButtons()[this.indexOfCollection(oCollection)]);
            // Select first item if no item is selected
            var oSelectedCollection = sap.ui.getCore().byId(this.getSelectedCollection());
            if (oSelectedCollection.getSelectedItems().length == 0 && oSelectedCollection.getItems().length > 0) {
                oSelectedCollection.addSelectedItem(oSelectedCollection.getItems()[0]);
            }
        }
        this.rerenderSidebar();
        this.refreshSelectionHighlighting();
    };

    /**
     * Inserts a content into the aggregation named <code>content</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oContent the content to insert; if empty, nothing is inserted
     * @param {int}
     *            iIndex the <code>0</code>-based index the content should be inserted at; for a negative value of <code>iIndex</code>, the
     *            content is inserted at position 0; for a value greater than the current size of the aggregation, the content is inserted at the last
     *            position
     * @return {jd.ui.eid.control.CollectionInspectorWithSummary} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#insertContent
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.insertContent = function(oContent, iIndex) {
        this.insertAggregation("content", oContent, iIndex, true);
        this.rerenderContent();
    }

    /**
     * Adds some content <code>oContent</code> to the aggregation named <code>content</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oContent the content to add; if empty, nothing is inserted
     * @return {jd.ui.eid.control.CollectionInspectorWithSummary} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#addContent
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.addContent = function(oContent) {
        this.addAggregation("content", oContent, true);
        this.rerenderContent();
    }

    /**
     * Removes an content from the aggregation named <code>content</code>.
     * 
     * @param {int |
     *            string | sap.ui.core.Control} vContent the content to remove or its index or id
     * @return {sap.ui.core.Control} the removed content or null
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#removeContent
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.removeContent = function(vContent) {
        this.removeAggregation("content", vContent, true);
        this.rerenderContent();
    }

    /**
     * Removes all the controls in the aggregation named <code>content</code>.<br/> Additionally unregisters them from the hosting UIArea.
     * 
     * @return {sap.ui.core.Control[]} an array of the removed elements (might be empty)
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#removeAllContent
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.removeAllContent = function() {
        this.removeAllAggregation("content", true);
        this.rerenderContent();
    }

    /**
     * Destroys all the content in the aggregation named <code>content</code>.
     * 
     * @return {jd.ui.eid.control.CollectionInspectorWithSummary} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.CollectionInspectorWithSummary#destroyContent
     * @function
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.destroyContent = function() {
        this.destroyAggregation("content", true);
        this.rerenderContent();
    }

    /**
     * When the CI looses the focus, this method is called.
     * 
     * @param {jQuery.Event}
     *            oEvent
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onfocusout = function(oEvent) {
        var $Target = jQuery(oEvent.target);
        if ($Target.hasClass("jdUiEidCICollectionListItem")) {
            $Target.removeClass("jdUiEidCISidebarFoc");
        }
    };

    /**
     * When the CI gets the focus, this method is called.
     * 
     * @param {jQuery.Event}
     *            oEvent
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onfocusin = function(oEvent) {
        var $Target = jQuery(oEvent.target);
        if ($Target.hasClass("jdUiEidCICollectionListItem")) {
            $Target.addClass("jdUiEidCISidebarFoc");
        }
    };

    /**
     * Handles the sapenter event does not bubble
     * 
     * @param {jQuery.Event}
     *            oEvent
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onsapenter = function(oEvent) {
        var $Target = jQuery(oEvent.target);
        if ($Target.hasClass("jdUiEidCISidebarFoc")) {
            this.onclick(oEvent);
        }
        oEvent.stopPropagation();
    };

    /**
     * Handles the sapspace event does not bubble
     * 
     * @param {jQuery.Event}
     *            oEvent
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.onsapspace = function(oEvent) {
        var $Target = jQuery(oEvent.target);
        if ($Target.hasClass("jdUiEidCISidebarFoc")) {
            this.onclick(oEvent);
        }
        oEvent.stopPropagation();
    };

    /**
     * Updates the css classes for the selected items
     * 
     * @param {jQuery.Event}
     *            oEvent
     * @private
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.refreshSelectionHighlighting = function() {
        var aItems = jQuery.sap.byId(this.getId() + "-sidebar").find('.jdUiEidCICollectionListItem');
        var aSelectedItems;
        if (this.getSelectedCollection()) {
            aSelectedItems = sap.ui.getCore().byId(this.getSelectedCollection()).getSelectedItems();
        } else {
            aSelectedItems = [];
        }
        jQuery.each(aItems, function(iIndex, oItem) {
            if (jQuery.inArray(oItem.id, aSelectedItems) >= 0) {
                jQuery(oItem).addClass("jdUiEidCICollectionListItemSelected");
                jQuery(oItem).prop("aria-selected", true);
            } else {
                jQuery(oItem).removeClass("jdUiEidCICollectionListItemSelected");
                jQuery(oItem).prop("aria-selected", false);
            }
        });
    };

    /**
     * Return the edit button
     * 
     * @public
     */
    jd.ui.eid.control.CollectionInspectorWithSummary.prototype.getEditButton = function() {
        return this._oEditButton;
    };
})();