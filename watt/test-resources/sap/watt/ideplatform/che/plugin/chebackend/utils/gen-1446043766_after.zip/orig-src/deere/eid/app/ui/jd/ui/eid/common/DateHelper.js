(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("sap.ui.core.format.DateFormat");

    /**
     * @class This helper class provides methods for handling Dates consistently throughout the application. There are four different kinds of date:
     *        <ul>
     *        <li>Date: a JavaScript Date object</li>
     *        <li>JSONDate: a string representing the date according to yyyy-MM-dd'T'HH:mm:ss.SSSz pattern</li>
     *        <li>HyphenizedDate: a string representing the date according to YYYY-MM-DD pattern</li>
     *        <li>YYYYMMDD: a string representing the date in the YYYYMMDD pattern</li>
     *        <li>Formatted date: the string representation of a date on the ui (e.g. "Jan 28, 2014")</li>
     *        </ul>
     * @static
     * @name jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper = {};

    /*
     * *************************** transform all other date formats to a JavaScript Date object *******************************************
     */

    /**
     * Converts a JSON string to a Date object
     * 
     * @param {string}
     *            sJSONDate
     * @returns the corresponding Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.JSONDateToDate = function(sJSONDate) {
        if (sJSONDate && sJSONDate.length > 9) {
            var oDate = jd.ui.eid.common.DateHelper._createDateTime(sJSONDate.substring(0, 4), sJSONDate.substring(5, 7), sJSONDate.substring(8, 10));
            return oDate;
        }
    };

    /**
     * Converts a JSON string containing a UTC-DateTime to a Date object refering to the local timezone
     * 
     * @param {string}
     *            sJSONDate
     * @returns the corresponding Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.JSONDateToLocalDateTime = function(sJSONDate) {
        if (sJSONDate && sJSONDate.length > 9) {
            // Split the JSONDate by none digits into bits
            var aDateBits = sJSONDate.split(/\D/);
            // Convert the bits into a UTC/GMT date object
            var oUTCDate = jd.ui.eid.common.DateHelper._createDateTime(aDateBits[0], aDateBits[1], aDateBits[2], aDateBits[3], aDateBits[4],
                    aDateBits[5], aDateBits[6]);
            // Get the offset between local datetime and UTC/GMT datetime
            // It's multiplied with 60000 to convert the getTimezoneOffset() from minutes into milliseconds
            var iOffset = new Date().getTimezoneOffset() * 60000;

            // Calculate the datetime refering to the local timezone
            // Hint: Negate it to a difference between UTC and LocalTime instead of LocalTime to UTC
            return new Date(Date.parse(oUTCDate) - iOffset);
        }
    };

    /**
     * Converts a YYYY-MM-DD string to a Date object
     * 
     * @param {string}
     *            a string containing the date as a YYYY-MM-DD string
     * @returns the corresponding Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.hyphenizedDateToDate = function(sHyphenizedDate) {
        if (sHyphenizedDate && sHyphenizedDate.length == 10) {
            var s = sHyphenizedDate.split('-');
            var oDate = jd.ui.eid.common.DateHelper._createDateTime(s[0], s[1], s[2]);
            return oDate;
        }
    };

    /**
     * Transforms a Yyyymmdd string into a JavaScript Date object
     * 
     * @param {string}
     *            a string respective the Yyyymmdd pattern
     * @returns {Date} a JavaScript Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.YyyymmddToDate = function(sYyyymmdd) {
        if (sYyyymmdd && sYyyymmdd.length == 8) {
            var oDate = jd.ui.eid.common.DateHelper._createDateTime(sYyyymmdd.substr(0, 4), sYyyymmdd.substr(4, 2), sYyyymmdd.substr(6, 2));
            return oDate;
        }
    };

    /*
     * *************************** transform all other date formats to a JSON date string ************************************************
     */

    /**
     * Transforms a JavaScript Date Object into a JSON date string in the local timezone.
     * 
     * @param {string}
     *            a JavaScript date object
     * @returns {string} a JSON date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.DateToJSONDate = function(oDate) {
        if (oDate) {
            // Extra effort is needed since oDate.toJSON() returns the equivalent date in UTC time. This is not sufficient, as this can return a
            // different
            // date (+/- 1) from what is expected.
            // Is user's timezone UTC? If so, we don't need to do any of this...
            if (oDate.getTimezoneOffset() == 0) {
                return oDate.toJSON();
            }

            // Since timezone is not UTC, form a JSON date string 'manually'.
            var sYear = oDate.getFullYear().toString();
            var sMonth = (oDate.getMonth() + 1) < 10 ? ("0" + (oDate.getMonth() + 1)) : (oDate.getMonth() + 1).toString();
            var sDate = oDate.getDate() < 10 ? ("0" + oDate.getDate()) : oDate.getDate().toString();
            var sHour = oDate.getHours() < 10 ? ("0" + oDate.getHours()) : oDate.getHours().toString();
            var sMinutes = oDate.getMinutes() < 10 ? ("0" + oDate.getMinutes()) : oDate.getMinutes().toString();
            var sSeconds = oDate.getSeconds() < 10 ? ("0" + oDate.getSeconds()) : oDate.getSeconds().toString();
            var sMilliseconds;
            var iMilliseconds = oDate.getMilliseconds();
            if (iMilliseconds < 10) {
                sMilliseconds = "00" + iMilliseconds;
            } else if (iMilliseconds < 100) {
                sMilliseconds = "0" + iMilliseconds;
            } else {
                sMilliseconds = iMilliseconds.toString();
            }

            // Get the offset from UTC. Get the delta in hours & mins separately, and then form the string..
            var iOffset = oDate.getTimezoneOffset(); // e.g -120 for GMT +0200
            var sTimezone = (iOffset < 0) ? "+" : "-";

            var iTimezoneHours = Math.floor(Math.abs(iOffset) / 60);
            var sTimezoneHours = (iTimezoneHours < 10) ? ("0" + iTimezoneHours) : iTimezoneHours.toString();
            var iTimezoneMinutes = Math.abs(iOffset) % 60;
            var sTimezoneMinutes = (iTimezoneMinutes) < 10 ? ("0" + iTimezoneMinutes) : iTimezoneMinutes.toString();
            sTimezone = sTimezone + sTimezoneHours + sTimezoneMinutes;

            var sResult = sYear + "-" + sMonth + "-" + sDate + "T" + sHour + ":" + sMinutes + ":" + sSeconds + "." + sMilliseconds + sTimezone;
            return sResult;
        }
    };

    /**
     * Transforms a YYYY-MM-DD string date into a JSON date.
     * 
     * @param {string}
     *            a string respective to the YYYY-MM-DD pattern
     * @returns {string} a string respective to the defined JSON pattern.
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.hyphenizedDateToJSONDate = function(sHyphenizedDate) {
        if (sHyphenizedDate && sHyphenizedDate.length == 10) {
            var oDate = jd.ui.eid.common.DateHelper.hyphenizedDateToDate(sHyphenizedDate);
            return jd.ui.eid.common.DateHelper.DateToJSONDate(oDate);
        }
    };

    /**
     * Transforms a Yyyymmdd string into a JSON date
     * 
     * @param {string}
     *            a string respective the Yyyymmdd pattern
     * @returns {string} a JSON date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.YyyymmddToJSONDate = function(sYyyymmdd) {
        if (sYyyymmdd && sYyyymmdd.length == 8) {
            var oDate = jd.ui.eid.common.DateHelper.YyyymmddToDate(sYyyymmdd);
            return jd.ui.eid.common.DateHelper.DateToJSONDate(oDate);
        }
    };

    /*
     * *************************** transform all other date formats to a YYYY-MM-DD date string *****************
     */

    /**
     * Converts a date to a YYYY-MM-DD string
     * 
     * @param {Date}
     *            a JavaScript Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.dateToHyphenizedDate = function(oDate) {
        if (oDate) {
            var sJsonDate = jd.ui.eid.common.DateHelper.DateToJSONDate(oDate);
            return jd.ui.eid.common.DateHelper.JSONDateToHyphenizedDate(sJsonDate);
        }
    };

    /**
     * Transforms a JSON date into a hyphenized string date.
     * 
     * @param {string}
     *            JSON date string.
     * @returns {string} a string respective to the YYYY-MM-DD pattern.
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.JSONDateToHyphenizedDate = function(sJSONDate) {
        if (sJSONDate && sJSONDate.length > 9) {
            return sJSONDate.substring(0, 10);
        }
    };

    /**
     * Transforms a Yyyymmdd string into a YYYY-MM-DD string date.
     * 
     * @param {string}
     *            a string respective the Yyyymmdd pattern
     * @returns {string} a string respective to the YYYY-MM-DD pattern.
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.yyyymmddToHyphenizedDate = function(sYyyymmdd) {
        if (sYyyymmdd && sYyyymmdd.length == 8) {
            var sJsonDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sYyyymmdd);
            return jd.ui.eid.common.DateHelper.JSONDateToHyphenizedDate(sJsonDate);
        }
    };

    /*
     * *************************** transform all other date formats to a formatted Date string **************************************************
     */

    /**
     * Transforms a Date object into a formatted date string date
     * 
     * @param {Date}
     *            a Date object
     * @returns {string} a formatted date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.dateToFormattedDate = function(oDate) {
        if (oDate) {
            var oLocale = new sap.ui.core.Locale(jd.ui.eid.common.DateHelper.getLocale());
            return sap.ui.core.format.DateFormat.getDateInstance({
                style : "medium"
            }, oLocale).format(oDate);
        }
    };

    /**
     * Transforms a JSON date string into a formatted date string date
     * 
     * @param {string}
     *            a JSON string
     * @returns {string} a formatted date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.JSONDateToFormattedDate = function(sJSONDate) {
        if (sJSONDate && sJSONDate.length > 9) {
            var oDate = jd.ui.eid.common.DateHelper.JSONDateToDate(sJSONDate);
            return jd.ui.eid.common.DateHelper.dateToFormattedDate(oDate);
        }
    };

    /**
     * Transforms a hyphenized date string into a formatted date string date
     * 
     * @param {string}
     *            a hyphenized date string
     * @returns {string} a formatted date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.hyphenizedDateToFormattedDate = function(sHyphenizedDate) {
        if (sHyphenizedDate && sHyphenizedDate.length == 10) {
            var oDate = jd.ui.eid.common.DateHelper.hyphenizedDateToDate(sHyphenizedDate);
            return jd.ui.eid.common.DateHelper.dateToFormattedDate(oDate);
        }
    };

    /**
     * Transforms a Yyyymmdd string into a formatted date string date
     * 
     * @param {string}
     *            a Yyyymmdd string
     * @returns {string} a formatted date string
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.yyyymmddToFormattedDate = function(sYyyymmdd) {
        if (sYyyymmdd && sYyyymmdd.length == 8) {
            var oDate = jd.ui.eid.common.DateHelper.YyyymmddToDate(sYyyymmdd);
            return jd.ui.eid.common.DateHelper.dateToFormattedDate(oDate);
        }
    };

    /*
     * *************************** transform all other date formats to a YYYYMMDD string **************************************************
     */

    /**
     * Transforms a JavaScript Date object into a Yyyymmdd string.
     * 
     * @param {Date}
     *            a JavaScript Date object.
     * @returns {string} a string respective the Yyyymmdd pattern
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.DateToYyyymmdd = function(oDate) {
        if (oDate) {
            var sYear = oDate.getFullYear().toString();
            var sMonth = (oDate.getMonth() + 1).toString(); // getMonth() is zero-based
            var sDay = oDate.getDate().toString();

            // add leading zeros to month and day
            return sYear + (sMonth[1] ? sMonth : "0" + sMonth) + (sDay[1] ? sDay : "0" + sDay);
        }
    };

    /**
     * Transforms a JSON date into a Yyyymmdd string.
     * 
     * @param {string}
     *            JSON date string.
     * @returns {string} a string respective the Yyyymmdd pattern
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd = function(sJSONDate) {
        if (sJSONDate && sJSONDate.length > 9) {
            var oDate = jd.ui.eid.common.DateHelper.JSONDateToDate(sJSONDate);
            return jd.ui.eid.common.DateHelper.DateToYyyymmdd(oDate);
        }
    };

    /**
     * Transforms a YYYY-MM-DD date string into a Yyyymmdd string.
     * 
     * @param {string}
     *            a YYYY-MM-DD string
     * @returns {string} a string respective the Yyyymmdd pattern
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.hyphenizedDateToYyyymmdd = function(sHyphenizedDate) {
        // Do not use Date.parse, since it would result in a UTC Date displayed in the local time zone
        // This would imply a wrong date if the international date line happens to be between you and Greenwich
        if (sHyphenizedDate && sHyphenizedDate.length == 10) {
            var s = sHyphenizedDate.split('-');
            return s[0] + s[1] + s[2];
        }
    };

    /**
     * Get the locale.
     * 
     * @returns {string} the locale value.
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.getLocale = function() {
        return sap.ui.getCore().getConfiguration().getFormatLocale();
    };

    /**
     * Creates a Date object from a short date string in the current locale.
     * 
     * @param sDateString
     *            a short date string in the current locale
     * @returns {Date} a corresponding Date
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper.parseLocalShortDate = function(sDateString) {
        // if we use DateHelper.getLocale directly, we get an error: "Object de has no method 'hasPrivateUseSubtag'"
        var oLocale = new sap.ui.core.Locale(jd.ui.eid.common.DateHelper.getLocale().toString());
        var oDate = sap.ui.core.format.DateFormat.getDateInstance({
            style : "short"
        }, oLocale).parse(sDateString);
        return oDate;
    };

    /**
     * Checks whether an object is a valid Date
     * 
     * @param {Date}
     *            oDate the date object to be checked
     * @returns {Boolean} true if it is a valid date
     */
    jd.ui.eid.common.DateHelper.isValid = function(oDate) {
        return (oDate instanceof Date) && !isNaN(oDate.getTime());
    };

    /**
     * Compares two dates
     * 
     * @param {Date}
     *            oDate1
     * @param {Date}
     *            oDate2
     * @returns {Boolean} true if two date objects are valid dates and point to the same day, month and year
     */
    jd.ui.eid.common.DateHelper.isSameDay = function(oDate1, oDate2) {
        if (!jd.ui.eid.common.DateHelper.isValid(oDate1) || !jd.ui.eid.common.DateHelper.isValid(oDate2))
            return false;
        return jd.ui.eid.common.DateHelper.DateToYyyymmdd(oDate1) == jd.ui.eid.common.DateHelper.DateToYyyymmdd(oDate2);
    };

    /**
     * Subtracts a given number of days from the given date
     * 
     * @param {string}
     *            sJSONDate The date from which the days are to be subtracted
     * @param {integer}
     *            iDays The number of days to be subtracted
     * @returns {string} JSON date representing the result of the subtraction
     */
    jd.ui.eid.common.DateHelper.subtractDays = function(sJSONDate, iDays) {
        var oDate = jd.ui.eid.common.DateHelper.JSONDateToDate(sJSONDate);
        oDate.setDate(oDate.getDate() - iDays);
        return jd.ui.eid.common.DateHelper.DateToJSONDate(oDate);
    };

    /**
     * Subtracts a given number of months from a given date.
     */
    jd.ui.eid.common.DateHelper.subtractMonths = function(sJSONDate, iCount) {
        var oDate = jd.ui.eid.common.DateHelper.JSONDateToDate(sJSONDate);
        var iCurrentMonth = oDate.getMonth();

        // Subtract the months (a negative value for {iCurrentMonth - iCount} is OK)
        oDate.setMonth(iCurrentMonth - iCount);

        // Month numbers are from 0 - 11
        var iExpectedMonth;
        if (iCurrentMonth - iCount < 0) {
            iExpectedMonth = 12 - Math.abs((iCurrentMonth - iCount) % 12);
            if (iExpectedMonth == 12) {
                iExpectedMonth = 0;
            }
        } else {
            iExpectedMonth = iCurrentMonth - iCount;
        }

        // Javascript will make 31st December (minus) 1 month = 31st November, which then rolls over to 1st December. Check if this happened.
        if (oDate.getMonth() != iExpectedMonth) {
            oDate.setDate(0); // Set date to last day of previous month
        }
        return jd.ui.eid.common.DateHelper.DateToJSONDate(oDate);
    };

    /**
     * Creates a date with the given year, month and day
     * 
     * @param {string}
     *            sYear the full year
     * @param {string}
     *            sMonth the month value (ranging from 1-12)
     * @param {string}
     *            sDay the day of the month
     * @param {string}
     *            [sHours] the hours value
     * @param {string}
     *            [sMinutes] the minutes value
     * @param {string}
     *            [sSeconds] the seconds value
     * @param {string}
     *            [sMilliseconds] the milliseconds value
     * @returns {Date} a matching Date object
     * @memberOf jd.ui.eid.common.DateHelper
     */
    jd.ui.eid.common.DateHelper._createDateTime = function(sYear, sMonth, sDay, sHours, sMinutes, sSeconds, sMilliseconds) {
        var oDate = new Date();
        oDate.setFullYear(sYear);

        // Set the month twice. Setting it only once could have side effects if the new month is shorter than the original one:
        // e.g. suppose oDate would point to Dec 31, 2014.
        // oDate.setMonth(10) would set it to November 31, 2014 which is
        // immediately converted to Dec 1, 2014.
        oDate.setMonth(sMonth - 1);
        oDate.setMonth(sMonth - 1);
        oDate.setDate(sDay);

        // Check whether the time values where given otherwise just skip that
        if (sHours, sMinutes, sSeconds, sMilliseconds) {
            oDate.setHours(sHours, sMinutes, sSeconds, sMilliseconds);
        }

        return oDate;
    };
})();