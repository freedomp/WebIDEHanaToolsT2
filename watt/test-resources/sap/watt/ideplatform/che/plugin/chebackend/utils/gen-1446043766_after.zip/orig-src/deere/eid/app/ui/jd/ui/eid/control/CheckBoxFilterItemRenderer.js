(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CheckBoxFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer for control {@link jd.ui.eid.control.CheckBoxFilterItem}.
     * 
     * @class Default renderer for control {@link jd.ui.eid.control.CheckBoxFilterItem}
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     * @name jd.ui.eid.control.CheckBoxFilterItemRenderer
     */
    jd.ui.eid.control.CheckBoxFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.CheckBoxFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Renders the a div for the check box icon instead of the collapse & expand arrow.
     * 
     * @see jd.ui.eid.control.FilterItemRenderer#renderCollapseIcon
     */
    jd.ui.eid.control.CheckBoxFilterItemRenderer.renderCollapseIcon = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidCheckBoxFilterItemCheckBox");
        oRm.writeClasses();
        oRm.write(">");
        oRm.write("</div>");
    };

    /**
     * @see jd.ui.eid.control.FilterItemRenderer#renderHeaderItems
     */
    jd.ui.eid.control.CheckBoxFilterItemRenderer.renderHeaderItems = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderItems");
        oRm.writeClasses();
        oRm.write(">");

        if (oControl.getAggregation("rightItem")) {
            oRm.renderControl(oControl.getAggregation("rightItem"));
        }

        oRm.write("</div>");
    };

})();