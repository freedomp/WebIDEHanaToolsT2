(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate");

    /**
     * @class
     * <p>
     * The view displays the personalization for the DTC filters on the {@link jd.ui.eid.view.main.shell.Dashboard Dashboard view}.
     * </p>
     * <h2>Controls</h2>
     * <p>
     * The view comprises of a 'Save' button, and the DefaultFilterSettings fragment, which is very similar to the DTC Filters in the Dashboard view.
     * The fragment contains the FilterArea control with all FilterItems (children) bound to the /PersonalizedDTCFilters/ path in the model.
     * </p>
     * <h2>Functionality</h2>
     * <p>
     * Similar to the Dashboard's DTC Filters, only the 'Platform & Product Line' filter is available initially. Once a selection has been made, the
     * corresponding dependent filter items (like Design Factory, Build Factory etc.) are populated and made visible.
     * </p>
     * <p>
     * The user makes the filter selections that he wants to set as the default DTC filter selection and clicks on 'Save'. A message is shown when the
     * personalization is saved successfully.
     * </p>
     * <p>
     * On subsequent launches of the Dashboard view, this filter selection is applied by default.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.shell.personalization.FilterSettings
     */
    sap.ui.controller("jd.ui.eid.view.main.shell.personalization.FilterSettings", jQuery.extend(true, {}, jd.ui.eid.view.BaseController, /** @lends jd.ui.eid.view.main.shell.personalization.FilterSettings */
    {

        _oDLM : null,
        _oFilterDomainValueService : null,
        _oPersonalizationFiltersService : null,
        _oView : null,
        oBuildWeekDistancePopup : null,
        oBuildWeekDistancePopupDelegate : null,
        oBuildWeekRangePopup : null,
        oBuildWeekRangePopupDelegate : null,
        oDTCDateDistancePopup : null,
        oDTCDateDistancePopupDelegate : null,
        oDTCDateRangePopup : null,
        oDTCRangePopupDelegate : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.shell.personalization.FilterSettings
         */
        onInit : function() {
            this._oView = this.getView();
            // Add custom CSS to the view. Done here, because <core:View class="xyz"> doesn't work. This class makes the view have 100% height.
            // Required for the scrolling effect in this view (toolbar stays fixed)
            this._oView.addStyleClass("jdUiEidViewShellPersonalizationFilterSettings");
            // View is set to display:block. Without this, IE displays another scrollbar on the view's parent DIV even if the parent DIV's contents
            // fit within it. The default value for 'display' (from CSS class sapUiView) is inline-block.
            this._oView.addStyleClass("jdUiEidViewBlockDisplay");

            // Get the service facade instances
            this._oPersonalizationFiltersService = this.getServiceFacade("PersonalizationFilters");
            this._oPersonalizationFiltersService.attachRequestFailed(this._onRequestFailed);
            this._oFilterDomainValueService = this.getServiceFacade("FilterDomainValue");
            this._oFilterDomainValueService.attachRequestFailed(this._onRequestFailed);

            // Attach data loss manager so that we can check whether there's unsaved data on this
            // view.
            var that = this;
            this._oDLM = jd.ui.eid.common.DataLossManager.createDataLossContextForControl(this._oView);
            this._oDLM.setSaveHandler(function(fnNavigationHandler) {
                that.handleSave.apply(that);
            });

            // Subcribe to event bus
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

            // Do the property(object) bindings (e.g 'selection' of FilterItems) here.
            // Bind BuildWeek
            var sFilterAreaId = this.getView().createId("FilterArea");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").bindProperty("selection", "/PersonalizedDTCFilters/FilterSelection/BuildWeek");

            // Bind DTC CaptureTime
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/DTCCaptureTime");

            // Bind Platform & Product Line
            sap.ui.core.Fragment.byId(sFilterAreaId, "PlatformAndProductLine").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine");

            // Bind Models & Submodels
            sap.ui.core.Fragment.byId(sFilterAreaId, "Models").bindProperty("selection", "/PersonalizedDTCFilters/FilterSelection/Model");

            // Bind Engine Hours
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHours").bindProperty("selection", "/PersonalizedDTCFilters/FilterSelection/EngineHour");

            // Bind Design Factory
            sap.ui.core.Fragment.byId(sFilterAreaId, "DesignFactory").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/DesignFactory");

            // Bind Build Factory
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildFactory")
                    .bindProperty("selection", "/PersonalizedDTCFilters/FilterSelection/BuildFactory");

            // Bind Machine Location
            sap.ui.core.Fragment.byId(sFilterAreaId, "MachineLocation").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/MachineLocation");

            // Branch code
            sap.ui.core.Fragment.byId(sFilterAreaId, "BranchCode").bindProperty("selection", "/PersonalizedDTCFilters/FilterSelection/BranchCode");

            // Functional area
            sap.ui.core.Fragment.byId(sFilterAreaId, "FunctionalArea").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/FunctionalArea");

            // Manual Pin List
            sap.ui.core.Fragment.byId(sFilterAreaId, "ManualPinList").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/ManualPinList");

            // Emission Level
            sap.ui.core.Fragment.byId(sFilterAreaId, "EmissionLevel").bindProperty("selection",
                    "/PersonalizedDTCFilters/FilterSelection/EmissionLevel");

            // Instantiate the popup fragments for DTC Capture Time and Build Week.
            this.initToolPopupFragments();
        },

        /**
         * After the view is ready, binding the 'selection' property of the filter items, which can't be done in the XMl view. This method also
         * includes a call to initToolPopupFragments and a service request on the controller's PersonalizationFiltersServiceFacade instance
         * 
         * @memberOf jd.ui.eid.view.main.shell.personalization.FilterSettings
         */
        onAfterRendering : function() {
            this._loadPersonalization();
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.shell.personalization.FilterSettings
         */
        onExit : function() {
            // Unsubcribe to event bus
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);

            // Destroy the instantiated delegates and fragments
            this.oBuildWeekRangePopupDelegate.destroy();
            this.oBuildWeekRangePopup.destroy();
            this.oBuildWeekDistancePopupDelegate.destroy();
            this.oBuildWeekDistancePopup.destroy();
            this.oDTCRangePopupDelegate.destroy();
            this.oDTCDateRangePopup.destroy();
            this.oDTCDateDistancePopupDelegate.destroy();
            this.oDTCDateDistancePopup.destroy();
            this._oDLM.destroy();

            this.oBuildWeekRangePopupDelegate = null;
            this.oBuildWeekRangePopup = null;
            this.oBuildWeekDistancePopupDelegate = null;
            this.oBuildWeekDistancePopup = null;
            this.oDTCRangePopupDelegate = null;
            this.oDTCDateRangePopup = null;
            this.oDTCDateDistancePopupDelegate = null;
            this.oDTCDateDistancePopup = null;
            this._oDLM = null;
            this._oView = null;
        },

        /**
         * Handles the event fired when data for filter personalization is being fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/PersonalizedDTCFilters") {
                var sFilterAreaId = this.createId("FilterArea");
                var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "defaultSettingsFilterArea");
                var oSaveButton = this.byId("saveButton");

                oSaveButton.setEnabled(false);
                oFilterArea.setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for filter personalization has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/PersonalizedDTCFilters") {
                var sFilterAreaId = this.createId("FilterArea");
                var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "defaultSettingsFilterArea");
                var oSaveButton = this.byId("saveButton");

                oSaveButton.setEnabled(true);
                oFilterArea.setBusy(false);
            }
        },

        /**
         * Loads the user's personalization settings.
         * 
         * @private
         */
        _loadPersonalization : function() {
            // Fetch the user's filter personalization settings. Once filter selection has been fetched, fetch the domain values based on the Product
            // and Platform ID.
            var oController = this;
            var sFilterAreaId = this.createId("FilterArea");
            var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "defaultSettingsFilterArea");
            var oSaveButton = this.byId("saveButton");

            var fnOnSuccess = function() {
                var oPlatformAndProductLine = sap.ui.getCore().getModel().getProperty(
                        "/PersonalizedDTCFilters/FilterSelection/PlatformAndProductLine");
                oSaveButton.setEnabled(false);
                oFilterArea.setBusy(true);

                if (oPlatformAndProductLine && oPlatformAndProductLine.length > 0) {
                    var sPlatformId = oPlatformAndProductLine[0].PlatformID;
                    var sProductLineId = oPlatformAndProductLine[0].ProductLine[0];
                    var mParameters = {
                        sAlternateTargetPath : "/PersonalizedDTCFilters/DomainValues"
                    };

                    // Fetch the domain values
                    oController._oFilterDomainValueService.getDTCFilterDomainValues(sPlatformId, sProductLineId, function() {
                        // success
                        // Enable save button and filter area
                        oSaveButton.setEnabled(true);
                        oFilterArea.setBusy(false);
                    }, function() {
                        // error
                        oController._onRequestFailed();
                        oSaveButton.setEnabled(true);
                        oFilterArea.setBusy(false);
                    }, mParameters);
                } else {
                    // Enable save button and filter area
                    oSaveButton.setEnabled(true);
                    oFilterArea.setBusy(false);
                }
            };

            // Disable filter area and save button till backend returns results
            oSaveButton.setEnabled(false);
            oFilterArea.setBusy(true);
            this._oPersonalizationFiltersService.getPersonalizationFilters(fnOnSuccess);
        },

        /**
         * Initializes the popup fragments (for Build Week and DTC Capture Time) with their respective delegate instances
         * 
         * @memberOf jd.ui.eid.view.main.shell.personalization.FilterSettings
         */
        initToolPopupFragments : function() {
            var sFilterAreaId = this.getView().createId("FilterArea");

            // +++ 'BuildWeek' -> 'Custom Date Range...'
            // Get the ID of the popup fragment that we're going to instantiate
            var sWeekRangePopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "BuildWeekRangeToolPopup");

            // Instantiate the delegate that is going to handle events for this popup.
            if (!this.oBuildWeekRangePopupDelegate) {
                this.oBuildWeekRangePopupDelegate = new jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate({
                    fragmentId : sWeekRangePopupFragmentId,
                    allowEmpty : true
                });

                // ToolPopup's 'canceled' event to be handled by the ValueListItem
                this.oBuildWeekRangePopupDelegate.attachCanceled(function() {
                    var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDateRangeItem();
                    oOpener.onToolPopupCanceled();
                });
            }

            // Instantiate the fragment, passing the delegate instance.
            if (!this.oBuildWeekRangePopup) {
                this.oBuildWeekRangePopup = jd.ui.eid.xmlfragment(sWeekRangePopupFragmentId,
                        "jd.ui.eid.fragment.filter.DefaultFilterDateRangeToolPopup", this.oBuildWeekRangePopupDelegate);
            }

            // Set the 'opener' association of the delegate. This can't be done in the delegate's
            // constructor, as the opener is available only once the fragment has been instantiated.
            this.oBuildWeekRangePopupDelegate.setOpener(sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDateRangeItem());

            // Assign the created popup as the ToolPopup for the Build Week customd ate range item.
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDateRangeItem().setToolPopup(this.oBuildWeekRangePopup);

            // +++ 'BuildWeek' -> 'Custom Distance from Current Date...'
            // Same steps as above for the custom distance popup
            var sWeekDistancePopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "BuildWeekDistanceToolPopup");
            if (!this.oBuildWeekDistancePopupDelegate) {
                this.oBuildWeekDistancePopupDelegate = new jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate({
                    fragmentId : sWeekDistancePopupFragmentId,
                    allowEmpty : true
                });

                // ToolPopup's cancel should be handled by the ValueListItem
                this.oBuildWeekDistancePopupDelegate.attachCanceled(function() {
                    var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDistanceItem();
                    oOpener.onToolPopupCanceled();
                });
            }
            if (!this.oBuildWeekDistancePopup) {
                this.oBuildWeekDistancePopup = jd.ui.eid.xmlfragment(sWeekDistancePopupFragmentId,
                        "jd.ui.eid.fragment.filter.DefaultFilterDateDistanceToolPopup", this.oBuildWeekDistancePopupDelegate);
            }
            this.oBuildWeekDistancePopupDelegate.setOpener(sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDistanceItem());
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").getCustomDistanceItem().setToolPopup(this.oBuildWeekDistancePopup);

            // +++ 'DTC Capture Time' -> 'Custom Date Range...'
            var sDTCDateRangePopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DTCDateRangeToolPopup");
            if (!this.oDTCRangePopupDelegate) {
                this.oDTCRangePopupDelegate = new jd.ui.eid.common.delegate.DefaultFilterDateRangeToolPopupValueListItemDelegate({
                    fragmentId : sDTCDateRangePopupFragmentId,
                    allowEmpty : true
                });

                // ToolPopup's canceled should be handled by the ValueListItem
                this.oDTCRangePopupDelegate.attachCanceled(function() {
                    var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDateRangeItem();
                    oOpener.onToolPopupCanceled();
                });
            }
            if (!this.oDTCDateRangePopup) {
                this.oDTCDateRangePopup = jd.ui.eid.xmlfragment(sDTCDateRangePopupFragmentId,
                        "jd.ui.eid.fragment.filter.DefaultFilterDateRangeToolPopup", this.oDTCRangePopupDelegate);
            }
            this.oDTCRangePopupDelegate.setOpener(sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDateRangeItem());

            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDateRangeItem().setToolPopup(this.oDTCDateRangePopup);

            // +++ 'DTC Capture Time' -> 'Custom Distance from Current Date'
            var sDTCDateDistancePopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DTCDateDistanceToolPopup");
            if (!this.oDTCDateDistancePopupDelegate) {
                this.oDTCDateDistancePopupDelegate = new jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate({
                    fragmentId : sDTCDateDistancePopupFragmentId,
                    allowEmpty : true
                });

                // ToolPopup's canceled should be handled by ValueListItem
                this.oDTCDateDistancePopupDelegate.attachCanceled(function() {
                    var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDistanceItem();
                    oOpener.onToolPopupCanceled();
                });
            }
            if (!this.oDTCDateDistancePopup) {
                this.oDTCDateDistancePopup = jd.ui.eid.xmlfragment(sDTCDateDistancePopupFragmentId,
                        "jd.ui.eid.fragment.filter.DefaultFilterDateDistanceToolPopup", this.oDTCDateDistancePopupDelegate);
            }
            this.oDTCDateDistancePopupDelegate.setOpener(sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDistanceItem());
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").getCustomDistanceItem().setToolPopup(this.oDTCDateDistancePopup);

        },

        /**
         * Event handler for 'Platform and Product Line' HierarchyFilterItem. Once platform and product line are selected, the service to fetch the
         * other filter domain values is triggered.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent The event's parameters
         */
        onPlatformAndProductLineValueChanged : function(oEvent) {
            // Get a reference to the filter area.
            var sFilterAreaId = this.createId("FilterArea");
            var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "defaultSettingsFilterArea");
            var oController = this;

            // Get the selection in the HierarchyFilterItem
            var oSelection = oEvent.getSource().getSelection()[0];
            var sPlatformId = null, sProductLineId = null;
            if (oSelection) {
                sPlatformId = oSelection.PlatformID;
                sProductLineId = oSelection.ProductLine ? oSelection.ProductLine[0] : null;
            }

            // Make sure both 'Platform' and 'Product line' have been selected
            if (sPlatformId && sProductLineId) {
                oFilterArea.setBusy(true);
                var mParameters = {
                    sAlternateTargetPath : "/PersonalizedDTCFilters/DomainValues"
                };
                this._oFilterDomainValueService.getDTCFilterDomainValues(sPlatformId, sProductLineId, function() {
                    // success
                    oFilterArea.setBusy(false);
                }, function() {
                    // error
                    oFilterArea.setBusy(false);
                    oController._onRequestFailed();
                }, mParameters);
            }

            // Reset the FilterSelection for all filter items that are dependent on platform/product line. Reset all filter items except Build Week,
            // DTC Capture Time, Noise Reduction and Test Machines
            this._clearDependentFilterItems();

            this._oDLM.setDirty(true);
        },

        /**
         * Event handler for 'Clear' in the FilterArea.
         * 
         * @memberOf jd.ui.eid.view.main.shell.personalization.FilterSettings
         */
        handleFilterAreaClear : function() {
            this._oDLM.setDirty(true);
            sap.ui.core.Fragment.byId(this.createId("FilterArea"), "defaultSettingsFilterArea").clear();
        },

        /**
         * Clears the selection in all filter items that are depndent on the Platform & Product Line selection. This is invoked whenever the Platform &
         * Product Line selection changes.
         */
        _clearDependentFilterItems : function() {
            var sFilterAreaId = this.getView().createId("FilterArea");
            sap.ui.core.Fragment.byId(sFilterAreaId, "Models").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildFactory").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "DesignFactory").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHours").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "MachineLocation").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "BranchCode").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "FunctionalArea").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "ManualPinList").clear();
            sap.ui.core.Fragment.byId(sFilterAreaId, "EmissionLevel").clear();
        },

        /**
         * Formatter for 'visible' property of all FilterItems other than the 'Platform And Product Line' HierarchyFilterItem. Other filter items
         * should only be visible if 'Platform And Product Line' have been selected
         * 
         * @param aPlatformAndProductLineSelection
         *            {Array} Array representing the platform and product line selection
         * @returns {Boolean} Value represents whether filter items need to be visible
         */
        formatFilterItemVisibility : function(aPlatformAndProductLineSelection) {
            // Return true only if Platform and Product Line are already selected
            if (aPlatformAndProductLineSelection && aPlatformAndProductLineSelection.length > 0 && aPlatformAndProductLineSelection[0].PlatformID
                    && aPlatformAndProductLineSelection[0].ProductLine && aPlatformAndProductLineSelection[0].ProductLine[0]) {
                return true;
            }
            return false;
        },

        /**
         * Performs validation before the backend API for 'Save' is invoked.
         * 
         * @returns {Boolean} True if validation is successful. False otherwise.
         */
        _validateBeforeSave : function() {
            // If platform is selected (but not product line), do not allow save.
            var oPlatformSelection = sap.ui.core.Fragment.byId(this.createId("FilterArea"), "PlatformAndProductLine").getSelection()[0];
            var sPlatformId = null, sProductLineId = null;
            if (oPlatformSelection) {
                sPlatformId = oPlatformSelection.PlatformID;
                sProductLineId = oPlatformSelection.ProductLine ? oPlatformSelection.ProductLine[0] : null;
            }

            if (sPlatformId && !sProductLineId) {
                var sText = jd.ui.eid.common.I18NHelper.getText("FILTER_SETTINGS_MSG_PRODUCT_LINE_NOT_SELECTED");
                this.getNotificationCenter().alert(sText);
                return false;
            }

            return true;
        },

        /**
         * Event handler for the 'Save' button
         */
        handleSave : function() {
            // Get the personalization settings and save. For DomainValues, we only need to send the domain values for ManualPINList
            var oDefaultSettings = {};
            oDefaultSettings.DomainValues = {};
            oDefaultSettings.DomainValues.ManualPinList = sap.ui.getCore().getModel().getProperty(
                    "/PersonalizedDTCFilters/DomainValues/ManualPINListItems");
            oDefaultSettings.FilterSelection = sap.ui.getCore().getModel().getProperty("/PersonalizedDTCFilters/FilterSelection");
            oDefaultSettings.FilterState = sap.ui.getCore().getModel().getProperty("/PersonalizedDTCFilters/FilterState");

            var sFilterAreaId = this.createId("FilterArea");
            var oFilterArea = sap.ui.core.Fragment.byId(sFilterAreaId, "defaultSettingsFilterArea");
            var oController = this;
            var oSaveButton = this.byId("saveButton");

            // Validate before triggering backend API for Save
            var bValidated = this._validateBeforeSave();
            if (!bValidated) {
                return;
            }

            // Reset the DLM (view is no longer in 'dirty state'). This should ideally be done in the success handler of the
            // savePersonalizationFilters service call (below), but it is done before the service is even triggered because it optimistically assumes
            // that the 'Save' will succeed. If we wait till the save service returns successfully to reset the DLM, it is possible that the user
            // quickly navigates to a different Shell workset item before the success handler is invoked. As the state would still be 'dirty', the
            // user will get a 'Data loss' popup, even though the Save service has already been triggered.
            this._oDLM.reset();

            // Set busy state before invoking service
            oFilterArea.setBusy(true);
            oSaveButton.setEnabled(false);
            this._oPersonalizationFiltersService.savePersonalizationFilters(oDefaultSettings, function() {
                oFilterArea.setBusy(false);
                oSaveButton.setEnabled(true);
                var sSuccessText = jd.ui.eid.common.I18NHelper.getText("FILTER_SETTINGS_MSG_SAVE_SUCCESS");
                oController.getNotificationCenter().success(sSuccessText);
            }, function() {
                // If save fails
                oFilterArea.setBusy(false);
                oSaveButton.setEnabled(true);
                oController._onRequestFailed();
            });
        },

        /**
         * Handles the <code>duplicateIgnored</code> event of the manual PIN list filter item. Notifies the user about the number of duplicates
         * which have automatically been removed.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the manual PIN list filter item.
         */
        handleManualPINListDuplicatesIgnored : function(oEvent) {
            jd.ui.eid.application.Application.getInstance().getNotificationCenter().success(
                    jd.ui.eid.common.I18NHelper.getText("INTERACTIVE_LIST_BOX_FILTER_ITEM_MSG_BATCH_INSERT_TOOL_POPUP_DUPLICATES_IGNORED", [oEvent
                            .getParameter("numberOfDuplicates")]));
        },

        /**
         * Handles the <code>valueChanged</code> event of the filter items and sets the data loss manager to dirty.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the filter item.
         */
        handleFilterItemValueChanged : function(oEvent) {
            this._oDLM.setDirty(true);
        },

        /**
         * Handles the <code>itemCleared</code> event of the filter items and sets the data loss manager to dirty.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the filter item.
         */
        handleFilterItemCleared : function(oEvent) {
            this._oDLM.setDirty(true);
        }
    }));
})();