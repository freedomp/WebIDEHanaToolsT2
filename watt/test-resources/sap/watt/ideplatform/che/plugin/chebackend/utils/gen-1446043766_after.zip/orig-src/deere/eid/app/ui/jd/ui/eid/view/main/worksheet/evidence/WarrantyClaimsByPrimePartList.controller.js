(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateDistanceToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");

    /**
     * The controller for the WarrantyClaimsByPrimePartList view
     * 
     * @class
     * <p>
     * The Warranty Claim List View provides the functionality to find warranty claims for an evidence package. It consists of a filter area and a
     * table of warranty claims aggregated by prime part.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimsByPrimePartList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers.
     * Moreover it sets the binding for all filteritem fragments and attaches the toolpopus to them.</li>
     * <li>{@link #.onExit} is usually called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.fetchWarrantyClaimsByPrimePartList} is called to trigger a new service call.</li>
     * <li>{@link #.formatWarrantyClaimsByPrimePartCount} is called to format the Prime Part Count on top of the Warranty Claim list table</li>
     * <li>{@link #.initToolPopupFragments} is called during initialization of the view. It creates all required toolpopups.</li>
     * <ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>handleOpenPrimePartDetails is called after a Prime Part was selected. It will open the Warranty Claim Details view.</li>
     * <li>handleFilterAreaClear is called to clear the current filter area selection and to trigger a new service request.</li>
     * <li>handleFilterItemCleared is called to trigger a new service request after a filter item was cleared.</li>
     * <li>handleNavigation is called while navigating to the view by raising the event "navigating". It triggers a new service call by using the
     * method fetchWarrantyClaimsByPrimePartList</li>
     * <li>handleRefreshWarrantyClaimsByPrimePartList is called to update the table data </li>
     * <li>handleDTCRemoved is called after a DTC has been removed from the evidence package</li>
     * </ul>
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
     */
    sap.ui.controller("jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            {

                _bRefresh : true,
                _bRenderedForTheFirstTime : false,
                _oDateDistanceToolPopup : null,
                _oDateDistanceToolPopupDelegate : null,
                _oDateRangeToolPopup : null,
                _oDateRangeToolPopupDelegate : null,
                _oView : null,
                _oWarrantyClaimService : null,

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                onInit : function() {
                    // Get a reference to the view
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewWorksheetEvidenceWarrantyClaimsByPrimePartList");
                    this._oView.addStyleClass("jdUiEidScrollLayout jdUiEidScrollLayoutHorizontal jdUiEidScrollLayoutScrollBarOutside");

                    // Subscribe to event bus
                    sap.ui.getCore().getEventBus().subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
                    sap.ui.getCore().getEventBus().subscribe('Navigation', 'navigating', this.handleNavigation, this);
                    sap.ui.getCore().getEventBus().subscribe('EvidencePackage', 'DTCRemoved', this.handleDTCRemoved, this);
                    sap.ui.getCore().getEventBus()
                            .subscribe('EvidencePackage', 'newDTCFiltersApplied', this.fetchWarrantyClaimsByPrimePartList, this);

                    this._oWarrantyClaimService = this.getServiceFacade("WarrantyClaim");
                    this._oWarrantyClaimService.attachRequestFailed(this._onRequestFailed);

                    var sFilterAreaId = this._oView.createId("FilterArea");
                    sap.ui.core.Fragment.byId(sFilterAreaId, "TextAnalysis").bindProperty("selection",
                            "/WarrantyClaimFilters/FilterSelection/TextAnalysis");
                    sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").bindProperty("selection",
                            "/WarrantyClaimFilters/FilterSelection/FailureDate");
                    sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHour").bindProperty("selection",
                            "/WarrantyClaimFilters/FilterSelection/EngineHour");

                    // Add the formatter functions to the FailureDate FilterItem
                    var sFilterAreaId = this._oView.createId("FilterArea");
                    sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").setDateRangeValueListItemTextFormatter(
                            jd.ui.eid.common.formatter.DateTimeFormatter.formatDateRangeValueListItemText);
                    sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").setDateDistanceValueListItemTextFormatter(
                            jd.ui.eid.common.formatter.DateTimeFormatter.formatDateDistanceValueListItemText);

                    // Initialize the date range toolpopup delegate
                    this.initToolPopupFragments();
                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 */
                onAfterRendering : function() {
                    if (!this._bRenderedForTheFirstTime || this._bRefresh) {
                        this._bRenderedForTheFirstTime = true;
                        this._bRefresh = false;
                        this.fetchWarrantyClaimsByPrimePartList();
                    }
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                onExit : function() {
                    // Unsubcribe to event bus
                    var oEventBus = sap.ui.getCore();
                    oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
                    oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
                    oEventBus.unsubscribe('Navigation', 'navigating', this.handleNavigation, this);
                    oEventBus.unsubscribe('EvidencePackage', 'DTCRemoved', this.handleDTCRemoved, this);
                    oEventBus.unsubscribe('EvidencePackage', 'newDTCFiltersApplied', this.fetchWarrantyClaimsByPrimePartList, this);

                    // Detach events
                    this._oWarrantyClaimService.detachRequestFailed(this._onRequestFailed);

                    // Destroy delegates
                    this._oDateDistanceToolPopupDelegate.destroy();
                    this._oDateRangeToolPopupDelegate.destroy();

                    // Destroy controls
                    this._oDateDistanceToolPopup.destroy();
                    this._oDateRangeToolPopup.destroy();

                    // Set properties no null
                    this._oDateDistanceToolPopup = null;
                    this._oDateDistanceToolPopupDelegate = null;
                    this._oDateRangeToolPopup = null;
                    this._oDateRangeToolPopupDelegate = null;
                    this._oView = null;
                    this._oWarrantyClaimService = null;
                },

                /**
                 * Handles the navigating event.
                 * 
                 * @param {string}
                 *            sChannelId the channel id
                 * @param {string}
                 *            sEventId the event name
                 * @param {object}
                 *            oData the data passed along with the event.
                 * @see jd.ui.eid.Events#Navigation::navigating
                 */
                handleNavigation : function(sChannelId, sEventId, oData) {
                    if (oData.target == 'jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList') {
                        // Fetch the Warranty Claim list
                        this.fetchWarrantyClaimsByPrimePartList();
                    }
                },

                /**
                 * Hook function for additional checks regarding the visibility in the classes.
                 */
                _isVisible : function() {
                    if (jd.ui.eid.common.OverlayHelper.getWorksheetOverlay().isOpen()
                            && !jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay().isOpen()) {
                        return true;
                    } else {
                        return false;
                    }
                },

                /**
                 * Triggers a service call to get the list of Prime Parts aggregated byWarranty Claims and update the model.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                fetchWarrantyClaimsByPrimePartList : function() {
                    // Check whether the view has been initial
                    if (this._bRenderedForTheFirstTime && this.isVisible()) {
                        // Get binding and search term from UI
                        var oBinding = this._oView.byId("WarrantyClaimsTable").getBinding();
                        if (oBinding) {
                            var sSearchTerm = this._oView.byId("searchField").getValue();
                            var oModel = sap.ui.getCore().getModel();

                            // Get the custom Warranty Claim filter selection
                            var oCustomFilter = oModel.getProperty("/WarrantyClaimFilters/FilterSelection");

                            // Prepare the oEvidencePackage parameter that the
                            // service call needs
                            var oDTCFilters = oModel.getProperty("/EvidencePackageDetails/Header/DTCFilterSelection");
                            var aDTCIDs = jd.ui.eid.model.EidModel.TransformationHelper.getDTCIDListFromEvidencePackageDetails();
                            var oEvidencePackage = {
                                DTCFilters : oDTCFilters,
                                DTCIDList : aDTCIDs
                            };

                            // Make the service call
                            this._oWarrantyClaimService.getWarrantyClaimsByPrimePartList(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm,
                                    null, this._onRequestFailed);
                        }
                    } else {
                        this._bRefresh = true;
                    }
                },

                /**
                 * Handler of the refresh list event. Triggers a service call to update the current list of Prime Parts aggregated by Warranty Claims.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired by the button.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleRefreshWarrantyClaimsByPrimePartList : function(oEvent) {
                    // Get binding and search term from UI
                    var oBinding = this._oView.byId("WarrantyClaimsTable").getBinding();
                    oBinding.refreshData();
                },

                /**
                 * Formatter for the 'xx Warranty Claims by Prime Part' text above the table.
                 * 
                 * @returns {string} The formatted text for the number of warranty claims
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                formatWarrantyClaimsByPrimePartCount : function() {
                    var oBinding = this._oView.byId("WarrantyClaimsTable").getBinding();
                    if (oBinding) {
                        var iCount = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oBinding.getLength());
                        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(iCount.toString(), "PRIME_PART_TABLE_CAP_COUNT_MULTIPLE",
                                "PRIME_PART_TABLE_CAP_COUNT_SINGLE");
                    }
                    return jd.ui.eid.common.I18NHelper.getNumberChoiceText("0", "PRIME_PART_TABLE_CAP_COUNT_MULTIPLE",
                            "PRIME_PART_TABLE_CAP_COUNT_SINGLE");
                },

                /**
                 * Initialize all ToolPopups of the Warranty Claim Filters
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                initToolPopupFragments : function() {
                    var sFilterAreaId = this._oView.createId("FilterArea");

                    /*
                     * Add the data range toolPopup
                     */
                    // Create an ID for the date range toolPopup fragment
                    var sDateRangeToolPopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DateRangeToolPopup");
                    // Create the data range toolPopup delegate object
                    this._oDateRangeToolPopupDelegate = new jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate({
                        fragmentId : sDateRangeToolPopupFragmentId
                    });
                    // If user clicks on cancel, the last visible selection needs to be restored. Since the model is not updated unless 'OK' is
                    // clicked, it is
                    // enough to refresh the binding
                    this._oDateRangeToolPopupDelegate.attachCanceled(function() {
                        var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").getCustomDateRangeItem();
                        oOpener.onToolPopupCanceled();
                    });

                    // Create a date range toolPopup object and assign the delegate
                    // object to it
                    this._oDateRangeToolPopup = jd.ui.eid.xmlfragment(sDateRangeToolPopupFragmentId, "jd.ui.eid.fragment.filter.DateRangeToolPopup",
                            this._oDateRangeToolPopupDelegate);
                    // Get the date range item object and assign it to the toolPopup as
                    // an opener
                    var oCustomDateRangeItem = sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").getCustomDateRangeItem();
                    this._oDateRangeToolPopupDelegate.setOpener(oCustomDateRangeItem);
                    // Assign date range toolPopup to the opener
                    oCustomDateRangeItem.setToolPopup(this._oDateRangeToolPopup);

                    /*
                     * Add the data distance toolPopup
                     */
                    // Create an ID for the date distance toolPopup fragment
                    var sDateDistanceToolPopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaId, "DateDistanceToolPopup");
                    // Create the data distance toolPopup delegate object
                    this._oDateDistanceToolPopupDelegate = new jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate({
                        fragmentId : sDateDistanceToolPopupFragmentId
                    });
                    // If user clicks on cancel, the last visible selection needs to be restored. Since the model is not updated unless 'OK' is
                    // clicked, it is
                    // enough to refresh the binding
                    this._oDateDistanceToolPopupDelegate.attachCanceled(function() {
                        var oOpener = sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").getCustomDistanceItem();
                        oOpener.onToolPopupCanceled();
                    });

                    // Create a date distance toolPopup object and assign the delegate
                    // object to it
                    this._oDateDistanceToolPopup = jd.ui.eid.xmlfragment(sDateDistanceToolPopupFragmentId,
                            "jd.ui.eid.fragment.filter.DateDistanceToolPopup", this._oDateDistanceToolPopupDelegate);
                    // Get the date distance item object and assign it to the toolPopup as
                    // an opener
                    var oCustomDistanceItem = sap.ui.core.Fragment.byId(sFilterAreaId, "FailureDate").getCustomDistanceItem();
                    this._oDateDistanceToolPopupDelegate.setOpener(oCustomDistanceItem);
                    // Assign date distance toolPopup to the opener
                    oCustomDistanceItem.setToolPopup(this._oDateDistanceToolPopup);
                },

                /* SECTION - Event Bus Handling - START */

                /**
                 * Handles the event fired when data for the Warranty Claim list is fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleModelFetchingData : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/WarrantyClaimsByPrimePartList") {
                        this.byId("WarrantyClaimsTable").setBusy(true);
                    }
                },

                /**
                 * Handles the event fired when data for the Warranty Claim list has been fetched.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            oData data passed along with the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleModelDataFetched : function(sChannelId, sEvent, oData) {
                    if (oData.sPath == "/WarrantyClaimsByPrimePartList") {
                        this.byId("WarrantyClaimsTable").setBusy(false);
                    }
                },

                /* SECTION - Event Bus Handling - END */

                /**
                 * Handles the event fired when a Prime Part was clicked
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleOpenPrimePartDetails : function(oEvent) {
                    var oSelectedPrimePart = oEvent.getSource().getBindingContext().getProperty();
                    var sSearchTerm = this._oView.byId("searchField").getValue();
                    var oWarrantyClaimPrimePartOverlay = jd.ui.eid.common.OverlayHelper.getWarrantyClaimPrimePartOverlay();
                    oWarrantyClaimPrimePartOverlay.setContext(oSelectedPrimePart.PrimePartNumber, sSearchTerm);
                    if (!oWarrantyClaimPrimePartOverlay.isOpen()) {
                        oWarrantyClaimPrimePartOverlay.open();
                    }
                },

                /**
                 * Handles the clear action from the filter area's tool popup and clears the filter area.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleFilterAreaClear : function(oEvent) {
                    // Clear the filter
                    var oFilterArea = this.byId("FilterArea", "FilterArea");
                    oFilterArea.clear();
                    // Fetch the Warranty Claim List
                    this.fetchWarrantyClaimsByPrimePartList();
                },

                /**
                 * Handles the cleared event of the filter items to send a request.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired.
                 * 
                 * @memberOf jd.ui.eid.view.main.worksheet.evidence.WarrantyClaimsByPrimePartList
                 */
                handleFilterItemCleared : function(oEvent) {
                    // Fetch the Warranty Claim List
                    this.fetchWarrantyClaimsByPrimePartList();
                },

                /**
                 * Handles the event which is fired when a DTC was removed from the Evidence Package.
                 * 
                 * @param {string}
                 *            sChannelId the channel id
                 * @param {string}
                 *            sEventId the event name
                 * @param {object}
                 *            mData the data passed along with the event.
                 * @see jd.ui.eid.Events#EvidencePackage::DTCRemoved
                 */
                handleDTCRemoved : function(sChannelId, sEventId, oData) {
                    this.fetchWarrantyClaimsByPrimePartList();
                }

            }));
})();