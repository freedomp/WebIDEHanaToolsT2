(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.MachineOptionFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");

    /**
     * @class This formatter class provides methods for formatting MachineOption data
     * @static
     * @name jd.ui.eid.common.formatter.MachineOptionFormatter
     */
    jd.ui.eid.common.formatter.MachineOptionFormatter = {};

    /**
     * Formats text for the panel title of Machine Option View like: <DTC Code> - X Machine Options
     * 
     * @param {integer}
     *            iDTCID the DTCID
     * @param {string}
     *            sDTCCode the DTC Code
     * @param {array}
     *            aMachineOption array of Machine Options
     * @returns {string} the text for the Panel title
     * @memberOf jd.ui.eid.common.formatter.MachineOptionFormatter
     */
    jd.ui.eid.common.formatter.MachineOptionFormatter.formatPanelText = function(iDTCID, sDTCCode, aMachineOption) {
        var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");

        var iCountMachineOptions;
        if (aMachineOption) {
            iCountMachineOptions = aMachineOption.length;

            // if we have only one array item we have to check if the item indicates that machine option codes have not been calculated yet
            if (oEvidencePackageServiceFacade.MachineOptionCalculation.hasCalculationNotYetStarted(aMachineOption[0]) == true
                    && iCountMachineOptions == 1) {
                iCountMachineOptions = 0;
            }

        } else {
            iCountMachineOptions = 0;
        }

        var sTextMachineOptions = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iCountMachineOptions,
                "MACHINE_OPTION_CODE_TABLE_CAP_COUNT_MULTIPLE", "MACHINE_OPTION_CODE_TABLE_CAP_COUNT_SINGLE");

        return jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_CAP_DTC_CODE_AND_COUNT", [sDTCCode, sTextMachineOptions]);

    };

    /**
     * Formats visible rows for Machine Option Code View. Maximum row count is 15
     * 
     * @param {array}
     *            aArray the Array with table items
     * @return {integer} Visible Rows count
     * @memberOf jd.ui.eid.common.formatter.MachineOptionFormatter
     */
    jd.ui.eid.common.formatter.MachineOptionFormatter.formatVisibleRows = function(aArray) {
        if (aArray) {

            if (aArray.length > 15) {
                return 15;
            }

            else if (aArray.length == 0) {
                // we return 1 as 0 will produce a bug when setting it to property "visibleRowCount" of table control
                return 1;
            } else {
                return aArray.length;
            }
        } else {
            return 1;
        }
    };

    /**
     * Formats the no data text for the table
     * 
     * @param {object}
     *            oMachineOption the Machine Option
     * @return {string} the text
     * @memberOf jd.ui.eid.common.formatter.MachineOptionFormatter
     */
    jd.ui.eid.common.formatter.MachineOptionFormatter.formatNoData = function(oMachineOption) {
        if (oMachineOption) {
            var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");

            if (oEvidencePackageServiceFacade.MachineOptionCalculation.hasCalculationNotYetStarted(oMachineOption[0])) {
                return jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_NOT_YET_CALCULATED");
            } else {
                return jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_DO_NOT_EXIST");
            }
        } else {
            return "-";
        }

    };
})();