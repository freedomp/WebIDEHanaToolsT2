(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ChartPrintContainer");

    /**
     * @class The ChartPrintContainer serves as a placeholder for charts when printing.
     *        <p>
     *        <strong>The challenge</strong with charts is that they resize based on browser events which appear to be not properly triggered when
     *        printing a web site. Thus, the standard chart controls would be printed with the same dimensions as rendered in the browser and wouldn't
     *        change its dimensions when e.g. switching from portrait to landscape in a print preview.
     *        </p>
     *        <p>
     *        <strong>The solution<strong> looks as follows: The actual chart control is an aggregation of the print container. That chart should
     *        have a relative width and height. The ratio between the two should equal the ratio with that the chart shall be printed. Independently,
     *        the dimensions of the chart print container need to be maintained to specify the actual print size of the chart (the chart will later
     *        scale to the available space of the container while maintain the x/y ratio). The generation of the chart needs to be triggered
     *        externally via {@link #.renderChart}. When that method is called, the chart aggregation is rendered in the render area (parameter of
     *        the method). Once the chart has been rendered, its DOM sub tree is extracted and modified so that the containing SVG becomes scalable.
     *        The modified DOM sub tree is then appended to the content of the container control, before the <code>chartRendered</code> event is
     *        fired (which could for example notify a render manager).
     *        </p>
     * 
     * Constructor for a new ChartPrintContainer.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>height : CSSSize (default: '360px') the height of the container.
     * <li>
     * <li>width : CSSSize (default: '50%') the width of the container.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>chart : sap.viz.ui5.core.BaseChart the chart that should be printed.
     * <li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>chartRendered : fired when the chart was rendered inside the container.
     * <li>
     * <li>register : fired when the control is rendered for the first time and wants to register to a print manager.
     * <li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @name jd.ui.eid.control.ChartPrintContainer
     * @extends sap.ui.core.Control
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.ChartPrintContainer", /** @lends jd.ui.eid.control.ChartPrintContainer */
    {
        metadata : {
            properties : {
                height : {
                    type : "sap.ui.core.CSSSize",
                    defaultValue : "360px"
                },
                width : {
                    type : "sap.ui.core.CSSSize",
                    defaultValue : "50%"
                }
            },
            aggregations : {
                chart : {
                    type : "sap.viz.ui5.core.BaseChart",
                    multiple : false,
                }
            },
            events : {
                chartRendered : {},
                containerRendered : {},
                register : {}
            }
        },

        init : function() {
        },

        renderChart : function($renderArea) {
            $renderArea = this.$().find(".jdUiEidHiddenPrintArea");
            var that = this;
            var oChart = this.getChart();
            var bManualInvalidateCounter = 0;

            // Add event delegate to notify the container once the chart is done rendering.
            oChart.addEventDelegate({
                onAfterRendering : function() {
                    if (bManualInvalidateCounter == 1) {
                        $.sap.log.debug("chart rendered " + that.getId());
                        setTimeout(function() {
                            that._chartRendered($renderArea);
                        }, 200);
                    }
                }
            });

            setTimeout(function() {
                oChart.invalidate(true);
                bManualInvalidateCounter++;
            }, 200);
        },

        _chartRendered : function($renderArea) {
            var $chart = $($renderArea[0].innerHTML);// .find(">:first-child");
            if ($chart.find("svg").length == 0) {
                // No svg element found, perhaps because there isn't any data available for the chart
                this.$().css("height", "");
                this.$().append($("<span class='jdUiTv'>" + $chart.find(".sapVizNoDataDefault").text() + "</span>"));
                $.sap.log.debug("svg tag not found, chart might not have data.", null, "jd.ui.eid.control.ChartPrintContainer");
            } else {
                // Store svg dimensions
                var $svg = $chart.find("svg");
                var sSVGWidthCSS = $svg.attr("width");
                var sSVGHeightCSS = $svg.attr("height");
                var iSVGWidth = parseInt(sSVGWidthCSS);
                var iSVGHeight = parseInt(sSVGHeightCSS);

                // Manipulate chart
                // $chart.attr("style", function(i, s) {
                // return s + " width:100% !important; height:100% !important";
                // });
                $chart.css("width", "100%");
                $chart.css("height", "100%");
                $chart.find("*:not(canvas):not(svg *)").css("width", "100%").css("height", "100%");
                // Tell the svg what the original size is for which is was generated.
                $chart.find("svg")[0].setAttribute("viewBox", "0 0 " + iSVGWidth + " " + iSVGHeight);
                // Tell the svg that the ratio between the original size (see above) should be maintained.
                $chart.find("svg")[0].setAttribute("preserveAspectRatio", "xMinYMin meet");

                // Add chart into content
                this.$().append($chart);
            }

            this.fireChartRendered();
        },

        /* Rendering */

        _bFirstRendering : true,

        onBeforeRendering : function() {
            if (this._bFirstRendering) {
                this._bFirstRendering = false;
                this.fireRegister();
            } else {
                this.fireContainerRendered();
            }
        },

        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addStyle("width", oControl.getWidth());
            oRm.addStyle("height", oControl.getHeight());
            oRm.writeStyles();
            oRm.addClass("jdUiEidChartPrintContainer");
            oRm.writeClasses();
            oRm.write(">");
            oRm.write("<div id='" + oControl.getId() + "-hiddenPrintArea' class='jdUiEidHiddenPrintArea'>");
            oRm.renderControl(oControl.getChart());
            oRm.write("</div>");
            // oRm.renderControl(oControl.getChart());
            oRm.write("</div>");
        }
    });
})();