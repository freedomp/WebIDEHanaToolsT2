(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.validator.DateValidator");

    /**
     * @class This validator class provides methods for date validation.
     * @static
     * @name jd.ui.eid.common.validator.DateValidator
     */
    jd.ui.eid.common.validator.DateValidator = {};

    /**
     * Checks whether a specified date range is valid or not
     * 
     * @param {string}
     *            oFromDate as a "yyyymmdd" string
     * @param {string}
     *            oToDate as a "yyyymmdd" string
     * @returns {boolean} true for a valid date range otherwise false
     * @memberOf jd.ui.eid.common.validator.DateValidator
     */
    jd.ui.eid.common.validator.DateValidator.validateDateRange = function(oFromDate, oToDate) {
        // Check whether the date range is set correctly and from date is before to date
        if (oFromDate && oToDate && oFromDate <= oToDate) {
            return true;
        } else {
            return false;
        }
    };

})();