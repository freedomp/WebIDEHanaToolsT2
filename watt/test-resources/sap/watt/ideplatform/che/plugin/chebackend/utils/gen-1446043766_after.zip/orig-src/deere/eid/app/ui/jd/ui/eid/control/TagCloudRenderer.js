(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TagCloudRenderer");

    /**
     * @class Default renderer for control jd.ui.eid.control.TagCloud.
     * @static
     * @name jd.ui.eid.control.TagCloudRenderer
     */
    jd.ui.eid.control.TagCloudRenderer = {};

    /**
     * Render the control
     */
    jd.ui.eid.control.TagCloudRenderer.render = function(oRm, oControl) {

        // Render Tag Cloud container
        oRm.write("<div ");
        oRm.writeControlData(oControl);
        oRm.addClass("jdUiEidTagCloud");
        if (!oControl.getEnabled()) {
            oRm.addClass("jdUiEidTagCloudDisabled");
        }
        oRm.writeClasses();
        oRm.write(">");

        // Check whether tags are available
        if (oControl.getTags().length != 0) {

            // Get all tags
            var aTags = oControl.getAggregation("tags");

            // Check if tags have been set
            if (aTags && aTags.length) {

                var iMinFontSize = oControl.getMinFontSize();
                var iMaxFontSize = oControl.getMaxFontSize();
                var iFontSizeDiff = iMaxFontSize - iMinFontSize;
                var oWeightRange = this.computeWeightRange(aTags);
                var fWeightDiff = oWeightRange.fMaxWeight - oWeightRange.fMinWeight;

                // This function calculates the font size regarding the weight
                var getFontSize = function(fWeight) {
                    var fFontSize = ((fWeight - oWeightRange.fMinWeight) / fWeightDiff) * iFontSizeDiff + iMinFontSize;
                    return fFontSize;
                };

                // Render every tag item of the cloud
                for ( var i = 0; i < aTags.length; i++) {
                    var oTag = aTags[i];
                    oRm.write("<span");
                    oRm.addClass("jdUiEidTag");
                    oRm.writeClasses();
                    oRm.writeAttribute("data-jd-ui-eid-tagId", i);
                    oRm.writeAttribute("style", "font-size:" + getFontSize(oTag.getWeight()) + "px;");
                    oRm.write(">");
                    oRm.writeEscaped(oTag.getText());
                    oRm.write("</span>");
                }
            }

        } else {
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterItemNoData");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getNoData());
            oRm.write("</div>");
        }

        oRm.write("</div>");
    };

    /**
     * Compute the maximal/minimal weight ranges
     * 
     * @param {jd.ui.eid.control.Tag[]}
     *            Array of Tag-Elements
     * @return {object} Object with properties fMaxWeight and fMinWeight
     */
    jd.ui.eid.control.TagCloudRenderer.computeWeightRange = function(aTags) {
        // Initialize min/max values
        var oWeightRange = {};
        oWeightRange.fMinWeight = aTags[0].getWeight();
        oWeightRange.fMaxWeight = oWeightRange.fMinWeight;

        // Find highest and lowest weight by iteration of the tag weights
        for ( var i = 1; i < aTags.length; i++) {
            var fWeight = aTags[i].getWeight();

            if (fWeight > oWeightRange.fMaxWeight) {
                oWeightRange.fMaxWeight = fWeight;
            };

            if (fWeight < oWeightRange.fMinWeight) {
                oWeightRange.fMinWeight = fWeight;
            };
        }

        return oWeightRange;
    };

})();