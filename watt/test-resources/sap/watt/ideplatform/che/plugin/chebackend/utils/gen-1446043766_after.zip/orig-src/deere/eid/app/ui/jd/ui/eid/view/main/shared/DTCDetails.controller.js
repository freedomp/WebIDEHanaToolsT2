(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");

    jQuery.sap.require("jd.ui.eid.common.I18NHelper");
    jQuery.sap.require("jd.ui.eid.view.BaseController");
    jQuery.sap.require("jd.ui.eid.view.main.shared.DTCChartController");
    jQuery.sap.require("jd.ui.eid.common.formatter.DTCFormatter");
    jQuery.sap.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jQuery.sap.require("jd.ui.eid.common.chart.ChartHelper");

    /**
     * @class
     * <p>
     * The DTC Details View provides a Thing Viewer with DTC master data on the left side and DTC charts data in the content area. It has also an
     * action bar for further user actions.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.shared.DTCDetails
     */
    sap.ui.controller("jd.ui.eid.view.main.shared.DTCDetails", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.DTCChartController,
            /** @lends jd.ui.eid.view.main.shared.DTCDetails */
            {
                mDTCDetailsControllerConfig : {
                    sFilterSelectionPath : null
                },

                _oAddToPackageButton : null,
                _oChartFacetContent : null,
                _oDescriptionFacetContent : null,
                _oEngineeringFacetContent : null,
                _oNewEvidencePackageButton : null,
                _oTextsFacetContent : null,
                _oView : null,
                _sChartThingGroupFragmentId : null,
                _sDecriptionThingGroupFragmentId : null,
                _sDTCID : null,
                _sEngineeringTextThingGroupFragmentId : null,
                _sMode : null,
                _sTextsThingGroupFragmentId : null,

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 */
                onInit : function() {
                    this._oView = this.getView();
                    this._oView.addStyleClass("jdUiEidViewSharedDTCDetails");
                    this._oAddToPackageButton = this.byId("AddDTC");
                    this._oNewEvidencePackageButton = this.byId("NewEvidencePackage");
                    this._sChartThingGroupFragmentId = this.createId("CTFG");
                    this._sDecriptionThingGroupFragmentId = this.createId("DTGF");
                    this._sEngineeringTextThingGroupFragmentId = this.createId("ETTGF");
                    this._sTextsThingGroupFragmentId = this.createId("TTGF");

                    // Config
                    this.mDTCChartControllerConfig._sParentFragmentId = this._sChartThingGroupFragmentId;

                    // Make sure that we first show the facet so that the controls (i.e. charts) are created, so that we can afterwards initialize the
                    // DTCChartController.
                    this._showFacet("CHARTS");
                    this.initDTCChartController();
                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 */
                onAfterRendering : function() {
                    this.onDTCChartControllerAfterRendering();
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 */
                onExit : function() {
                    // Exit merged controllers
                    this.exitDTCChartController();

                    // Destroy controlls
                    if (this._oChartFacetContent) {
                        this._oChartFacetContent.destroy();
                    }
                    if (this._oDescriptionFacetContent) {
                        this._oDescriptionFacetContent.destroy();
                    }
                    if (this._oEngineeringFacetContent) {
                        this._oEngineeringFacetContent.destroy();
                    }
                    if (this._oTextsFacetContent) {
                        this._oTextsFacetContent.destroy();
                    }

                    // Set properties to null
                    this._oAddToPackageButton = null;
                    this._oChartFacetContent = null;
                    this._oDescriptionFacetContent = null;
                    this._oEngineeringFacetContent = null;
                    this._oNewEvidencePackageButton = null;
                    this._oView = null;
                    this.mDTCDetailsControllerConfig = null;
                },

                /**
                 * Set DTC Id to controller member attribute
                 * 
                 * @param {string}
                 *            sDTCID the selected DTC
                 */
                setContext : function(sDTCID) {
                    this._sDTCID = sDTCID;
                    this.loadDTCDetails(this._sDTCID);
                },

                /**
                 * Set Mode for Details View In Dashboard Mode the thing action "New Evidence Package" is available In Regular Mode the thing action
                 * "New Evidence Package" is hidden
                 * 
                 * @param {jd.ui.eid.view.main.shared.DTCDetails.Mode}
                 *            sMode the mode of the view
                 */
                setMode : function(sMode) {
                    this._sMode = sMode;

                    switch (sMode) {

                        case jd.ui.eid.view.main.shared.DTCDetails.Mode.Dashboard :
                            // Update the binding context of the view so that both views can work independently from one another
                            this._oView.bindElement("/DTCDetailsDashboard");
                            this._oView.getContent()[0].addStyleClass("jdUiEidUx3TVPopup");
                            this.mDTCDetailsControllerConfig.sFilterSelectionPath = "/DTCFilters/FilterSelection";

                            // Manage button visibility
                            this._oAddToPackageButton.setVisible(false);
                            this._oNewEvidencePackageButton.setVisible(true);
                            break;

                        case jd.ui.eid.view.main.shared.DTCDetails.Mode.Regular :
                            // Update the binding context of the view so that both views can work independently from one another
                            this._oView.bindElement("/DTCDetails");
                            this._oView.getContent()[0].removeStyleClass("jdUiEidUx3TVPopup");
                            this.mDTCDetailsControllerConfig.sFilterSelectionPath = "/EvidencePackageDetails/Header/DTCFilterSelection";

                            // Manage button visibility
                            this._oAddToPackageButton.setVisible(true);
                            this._oNewEvidencePackageButton.setVisible(false);
                            break;

                        default :
                            $.sap.log.error('Use only DASHBOARD or REGULAR as values!');
                    }
                },

                /**
                 * Load DTC Details from backend
                 * 
                 * @param {string}
                 *            sDTCID the selected DTC
                 */
                loadDTCDetails : function(sDTCID) {
                    var that = this;
                    var oView = this.getView();
                    var oModel = sap.ui.getCore().getModel();
                    var oCustomFilter = oModel.getProperty(this.mDTCDetailsControllerConfig.sFilterSelectionPath);

                    // Disable buttons before loading, so that if the request fails, the user cannot do anything stupid.
                    this._oAddToPackageButton.setEnabled(false);
                    this._oNewEvidencePackageButton.setEnabled(false);

                    // Clear model so that nothing is displayed on the UI. However, we set the blacklist flag to false to disable the blacklist
                    // button, which is bound to that property.
                    oModel.setProperty("/DTCDetails", {
                        _isNotOnBlacklist : false
                    });

                    // Disable button 'Add DTC' if current DTC is already in evidence package
                    var aDTCCodeList = oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList");
                    oView.getContent()[0].setBusy(true);
                    var bEnableAdd = true;
                    if (aDTCCodeList) {
                        for ( var i = 0; i < aDTCCodeList.length; i++) {
                            if (aDTCCodeList[i].DTCID == sDTCID) {
                                bEnableAdd = false;
                                break;
                            }
                        }
                    }

                    this.getServiceFacade("DTC").getDTCDetails(oCustomFilter, sDTCID, function() {
                        // Success handler
                        // Enable buttons
                        that._oNewEvidencePackageButton.setEnabled(true);
                        that._oAddToPackageButton.setEnabled(bEnableAdd);

                        // Set busy state and continue loading data if required
                        oView.getContent()[0].setBusy(false);
                        if (!that.hasExpensiveDTCDetailsData()) {
                            that.loadExpensiveDTCDetailsData(sDTCID);
                        }

                    }, function() {
                        // Error
                        // Reset model and undo busy state of view.
                        // If fetching failed, we don't want to display anything which is why we clear the dtc details model paths. Except for the
                        // blacklist flag, because that's bound to a button on the screen which should be disabled when the request failed.
                        oModel.setProperty("/DTCDetails", {
                            _isNotOnBlacklist : false
                        });
                        oView.getContent()[0].setBusy(false);
                        that._onRequestFailed.apply(that, arguments);
                    }, (this._sMode == jd.ui.eid.view.main.shared.DTCDetails.Mode.Dashboard ? {
                        sAlternateTargetPath : "/DTCDetailsDashboard"
                    } : undefined));

                },

                /**
                 * Loads the expensive properties such as KPIs and affected PINs.
                 * 
                 * @param {string}
                 *            sDTCID the DTC ID to fetch the properties for.
                 */
                loadExpensiveDTCDetailsData : function(sDTCID) {
                    var oModel = sap.ui.getCore().getModel();
                    var oCustomFilter = oModel.getProperty(this.mDTCDetailsControllerConfig.sFilterSelectionPath);
                    var oBusyControl = this.byId("DTCDetailsRanking");
                    oBusyControl.setBusy(true);
                    this.getServiceFacade("DTC").getDTCKPIs(oCustomFilter, sDTCID, function() {
                        // Success
                        oBusyControl.setBusy(false);
                    }, function() {
                        // Callback
                        oBusyControl.setBusy(false);
                    }, (this._sMode == jd.ui.eid.view.main.shared.DTCDetails.Mode.Dashboard ? {
                        sAlternateTargetPath : "/DTCDetailsDashboard"
                    } : undefined));
                },

                /**
                 * Checks whether expensive properties such as KPIs and affected PINs is there or not.
                 * 
                 * @returns {boolean} Returns true if KPIs and affected PINs are available in the DTC details model, false otherwise.
                 */
                hasExpensiveDTCDetailsData : function() {
                    var oModel = sap.ui.getCore().getModel();
                    var sRootPath = this._oView.getBindingContext().getPath();
                    var aKPIs = oModel.getProperty(sRootPath + "/DTCMasterData/KPIs");
                    var iAffectedPINs = oModel.getProperty(sRootPath + "/DTCMasterData/AffectedPINs");
                    return aKPIs && iAffectedPINs;
                },

                /**
                 * Called when user clicks on link to see DTC Description in full view
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event.
                 */
                onDTCDescriptionClick : function(oEvent) {
                    this._showFacet("TEXTS");
                },

                /**
                 * Called when user clicks on link to see Engineering Text in full view
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event.
                 */
                onEngineeringTextClick : function(oEvent) {
                    this._showFacet("TEXTS");
                },

                /**
                 * Called when user selects a Navigation Item
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the fired event.
                 */
                onFacetSelected : function(oEvent) {
                    this._showFacet(oEvent.getParameter("key"));
                },

                /**
                 * Getter for the DTCMasterData of the DTC that is currently displayed.
                 * 
                 * @returns {object} map of the DTC master data node.
                 */
                _getDTCMasterData : function() {
                    var oModel = sap.ui.getCore().getModel();
                    var oDTCMasterData = oModel.getProperty(this._oView.getBindingContext().getPath()/* e.g. /DTCDetails or /DTCDetailsDashboard */
                            + "/DTCMasterData");
                    return oDTCMasterData;
                },

                /**
                 * Handles the 'new evidence package' button and starts the business process.
                 */
                handleStartEvidencePackage : function() {
                    var oDTCMasterData = this._getDTCMasterData();
                    // SelectedKPI properties are coming from the DTCChartController
                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.startNewPackageInOverlay(oDTCMasterData, this._sKPIChart1KPIID,
                            this._sKPIChart2KPIID);
                },

                /**
                 * Handles the 'add to evidence package' button, adds the DTC and closes the view afterwards.
                 */
                handleAddDTCToBasket : function() {
                    var oDTCMasterData = this._getDTCMasterData();
                    // SelectedKPI properties are coming from the DTCChartController
                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTC(oDTCMasterData, this._sKPIChart1KPIID, this._sKPIChart2KPIID);
                    this._closeDTCDetails();
                },

                /**
                 * Handles the 'add to blacklist' button, adds the DTC and closes the view afterwards.
                 */
                handleAddDTCToBlacklist : function() {
                    var oDTCMasterData = this._getDTCMasterData();
                    jd.ui.eid.common.BusinessProcessHelper.DTCBlacklist.addDTC(oDTCMasterData);
                    this._closeDTCDetails();
                },

                /**
                 * Handles the 'close' button and closes the view.
                 */
                handleClose : function() {
                    this._closeDTCDetails();
                },

                /**
                 * Close DTC Details view
                 */
                _closeDTCDetails : function() {
                    if (this._sMode == jd.ui.eid.view.main.shared.DTCDetails.Mode.Dashboard) {
                        sap.ui.getCore().getEventBus().publish('DTCDetailsViewDashboard', 'close');
                    } else {
                        sap.ui.getCore().getEventBus().publish('DTCDetailsView', 'close');
                    }
                },

                /**
                 * Show facet content for selected Navigation Item
                 * 
                 * @param {string}
                 *            sKey the key of the selected navigation item
                 */
                _showFacet : function(sKey) {
                    var oThingViewer = this.byId("ThingViewer");
                    oThingViewer.removeAllFacetContent();

                    // Set Selected Facet in case of a clicked link
                    oThingViewer.setSelectedFacet(this.byId(sKey));

                    switch (sKey) {
                        case "CHARTS" :
                            if (this._oChartFacetContent == null) {
                                // this._oChartFacetContent = new jd.ui.eid.xmlview("jd.ui.eid.view.main.shared.DTCDetailsChart");
                                this._oChartFacetContent = jd.ui.eid.xmlfragment(this._sChartThingGroupFragmentId,
                                        "jd.ui.eid.fragment.dtc.details.ChartThingGroup", this);
                            }
                            oThingViewer.addFacetContent(this._oChartFacetContent);
                            break;
                        case "TEXTS" :
                            if (this._oTextsFacetContent == null) {
                                this._oTextsFacetContent = jd.ui.eid.xmlfragment(this._sTextsThingGroupFragmentId,
                                        "jd.ui.eid.fragment.dtc.details.TextsThingGroup", this);
                            }
                            oThingViewer.addFacetContent(this._oTextsFacetContent);
                            break;
                    }

                }
            }));

    /**
     * @namespace Enumerations for the DTC Details view.
     */
    jd.ui.eid.view.main.shared.DTCDetails = {

        /**
         * @namespace Mode Enumeration
         */
        Mode : {

            /**
             * @namespace Dashboard Mode
             */
            Dashboard : "DASHBOARD",

            /**
             * @namespace Regular Mode
             */
            Regular : "REGULAR"
        }
    };
})();
