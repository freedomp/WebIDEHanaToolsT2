(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.control.EllipsisableTextView");
    /**
     * EllipsisableTextView Control
     * 
     * The control extends the sap.ui.commons.TextView and displays a multi-line text view based on the numberOfLines property. If the text size
     * exceeds the available space, the text is truncated the ellipsis property is appended.
     * 
     * REMARK: The text view must have a css line-height property in pixels.
     * 
     * <ul>
     * <li> Properties
     * <ul>
     * <li> numberOfLines: int (default: 3) The number of lines to display.
     * <li> ellipsis: string (default: '...') The text displayed when the size exceeds the available space. </li>
     * </ul>
     * 
     * @class
     * @name jd.ui.eid.control.EllipsisableTextView
     * @extends sap.ui.commons.TextView
     */
    sap.ui.commons.TextView.extend("jd.ui.eid.control.EllipsisableTextView", /** @lends jd.ui.eid.control.EllipsisableTextView */
    {

        metadata : {
            properties : {
                numberOfLines : {
                    type : "int",
                    defaultValue : 3
                },
                ellipsis : {
                    type : "string",
                    defaultValue : "..."
                }
            }
        },
        /**
         * Add own style class for the text view
         */
        // 
        init : function() {
            this.addStyleClass("jdUiTv");
            this.addStyleClass("jdUiEidEllipsisableTv");
        },

        /**
         * Timeout for the loop that truncates the text.
         */
        _truncateTimeout : 1000,
        /**
         * Custom setter for the value property.
         * 
         * @param {int}
         *            iValue The value to set.
         * @returns The control instance.
         */
        setNumberOfLines : function(iValue) {
            if (iValue < 1) {
                iValue = 1;
            }
            this.setProperty("numberOfLines", iValue);

            return this;
        },

        /**
         * Overwrite Setter for TextView. Unlike the super method of sap.ui.commons.TextView we do a re- rendering when we set the text.
         * 
         * @param {string}
         *            sText The value to set.
         * @returns The control instance.
         */
        setText : function(sText) {

            this.setProperty("text", sText);

            // This is also done by super method, so we do it here also
            if (this._oPopup) {
                this._oPopup.destroy();
                delete this._oPopup;
            }
            return this;

        },

        /**
         * The method calculates the current number of lines by dividing the height of the dom html tag of this control by the line height defined in
         * the CSS. If the current lines are higher than the expected lines the text is truncated word by word until it fits.
         */
        onAfterRendering : function() {

            // call parent first, if method exists
            if (typeof (sap.ui.commons.TextView.prototype.onAfterRendering) == 'function') {
                sap.ui.commons.TextView.prototype.onAfterRendering.apply(this, arguments);
            }

            var iNumberOfLines = this.getNumberOfLines();
            var sEllipsis = " " + this.getEllipsis();
            var obj = this.$();
            var el = obj.get(0);
            var iLineHeight = obj.css("line-height").replace('px', '');
            var iCurrentNumberOfLines = el.scrollHeight / iLineHeight;
            $.sap.log.debug("scrollHeigt:" + el.scrollHeight);
            // Adjust height
            if (el.scrollHeight !== 0) {
                obj.height(iNumberOfLines * iLineHeight);
            }

            // Truncate text word by word until it fits
            var i = 0;
            while (iCurrentNumberOfLines > iNumberOfLines) {
                var sText = obj.html();

                sText = sText.replace(sEllipsis, '');
                // sText = sText.replace(/\s*[^\s]*$/, ''); // JSLint didn't like this
                sText = sText.replace(/\s*[\S]*$/, '');
                sText += sEllipsis;
                obj.html(sText);

                iCurrentNumberOfLines = el.scrollHeight / iLineHeight;

                i++;
                if (i == this._truncateTimeout) {
                    break;
                }
            }
        },
        /**
         * Renders control
         * 
         * @param {sap.ui.core.RenderManager}
         *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
         * @param {sap.ui.core.Control}
         *            oCmb an object representation of the control that should be rendered
         */
        renderer : "sap.ui.commons.TextViewRenderer"

    });
})();