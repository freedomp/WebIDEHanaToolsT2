(function() {
    "use strict";
    // Declare dependencies

    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.EvidencePackageServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/EvidencePackageList");
    var oListBindingPINPopulation = new jd.ui.eid.model.EidModelListBinding(oModel, "/EvidencePackageDetails/PINPopulationList");
    var oServiceFacade = new jd.ui.eid.service.EvidencePackageServiceFacade("http://sap.com", "jd/ui/eid/asset/data/", oModel, true);
    var oEvidencePackageDetail = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails.json").data; // Without Warranty Claim
    // Items
    var oEvidencePackageDetail2 = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails2.json").data; // With Warranty Claim
    // Items
    var oEvidencePackageSummary = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getEvidencePackageSummary_Response.json").data;
    var oGetEvidencePackageDetails = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/GetEvidencePackageDetails_Response.json").data;
    var oGetEvidencePackageAnalysisData = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getEvidencePackageAnalysisData_Response.json").data;
    var oGetEvidencePackagePINPopulationList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getEvidencePackagePINPopulationList_Response.json").data;
    var oApplyDTCFilters = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/ApplyDTCFilter_Response.json").data;
    var oCalculateMachineOptionCodesForDTC = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/CalculateMachineOptionCodesForDTC_Response.json").data;
    var oDataGetDTCDetailsList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTCDetailsList_Response.json").data;
    var oGetDTCFilterDomainValues = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTCFilterDomainValues_Response.json").data;

    var oDataGetDTACCaseDetailsList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTACCaseDetailsList_Response.json").data;
    var oDataGetWarrantyClaimDetailsList = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getWarrantyClaimDetailsList_Response.json").data;
    // Module for EvidencePackageServiceFacade Testing
    module("jd.ui.eid.service.EvidencePackageServiceFacade", {
        setup : function() {
            // Start spying on methods
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };

            sinon.spy(oServiceFacade, "_retrieveList");

            sinon.spy(oServiceFacade, "_send");
        },
        teardown : function() {
            // Stop spying on methods
            oServiceFacade._retrieveList.restore();
            oServiceFacade._send.restore();

        }
    });

    // *** TEST CASE #1 ***
    test(
            "getEvidencePackageList() should invoke _retrieveList() in BaseServiceFacade with search term as attribute 'SearchTerm', if search term is provided.",
            function() {
                // Invoke getEvidencePackageList()
                oServiceFacade.getEvidencePackageList(oListBinding, "MySearchTerm");

                // Check the custom payload
                equal(oServiceFacade._retrieveList.getCall(0).args[5].SearchTerm, "MySearchTerm");
            });

    // *** TEST CASE #2 ***
    test(
            "getEvidencePackageList() should invoke _retrieveList with empty string for 'SearchTerm' in custom payload, if no search term is available.",
            function() {
                // Invoke getEvidencePackageList()
                oServiceFacade.getEvidencePackageList(oListBinding, null);

                // Check the custom payload
                equal(oServiceFacade._retrieveList.getCall(0).args[5].SearchTerm, "");
            });

    // *** TEST CASE #3 ***
    test("deleteEvidencePackage() should invoke _send() with 'EvidencePackageID' as an attribute in the payload.", function() {
        // Invoke deleteEvidencePackage()
        oServiceFacade.deleteEvidencePackage("1234");

        // Check the custom payload
        equal(oServiceFacade._send.getCall(0).args[3].EvidencePackageID, 1234);
    });

    // *** TEST CASE #4 ***
    test("closeEvidencePackage() should invoke _send() with 'EvidencePackageID' as an attribute in the payload.", function() {
        // Invoke closeEvidencePackage()
        oServiceFacade.closeEvidencePackage("1234");

        // Check the custom payload
        equal(oServiceFacade._send.getCall(0).args[3].EvidencePackageID, 1234);
    });

    // *** TEST CASE #5 ***
    test("_processItemRemovalOfSimulatedEvidencePackageDetails() should remove old Evidence Package items from the Evidence Package list",
            function() {
                // the current list of items containing 3 different items
                var aCurrentItems = [{
                    "id" : 1
                }, {
                    "id" : 2
                }, {
                    "id" : 3
                }];

                // the new list of items -> Only the item with id 2 remains in the new list and a new items has been added to the new list
                var aNewItems = [2, 5];

                // this array should contain all items that have beens removed
                var aRemovedItems = [];

                oServiceFacade._processItemRemovalOfSimulatedEvidencePackageDetails(aCurrentItems, aNewItems, "id", aRemovedItems);

                // Assertion
                // check if only the item with id 2 remained in the current list
                deepEqual(aCurrentItems, [{
                    "id" : 2
                }]);

                // check if items with id 1 & 3 have been added to the removed list
                deepEqual(aRemovedItems, [{
                    "id" : 1
                }, {
                    "id" : 3
                }]);
            });

    // *** TEST CASE #5.1 ***
    test("_removeMachineOptionCodes should remove the Machines Options Codes which relate to the given DTCIDs", function() {
        // Set model data
        oModel.setProperty("/EvidencePackageDetails/Header", jQuery.extend(true, {}, oEvidencePackageDetail));
        var aMachineOptionCodeList = oModel.getProperty("/EvidencePackageDetails/Header/MachineOptionCodes"); // Get data from the model
        var aRemovedDTCList = [aMachineOptionCodeList[0].DTCID]; // Set the list of DTCID for which the MachineOptionCodes should be deleted
        var aResultMachineOptionCodeList = jQuery.extend(true, [], aMachineOptionCodeList); // Make a copy of the machine option codes for the
        // assertion
        aResultMachineOptionCodeList.splice(0, 1); // Remove the first item from the copy --> this is the required result

        // Call the function which should be tested
        oServiceFacade._removeMachineOptionCodes(aMachineOptionCodeList, aRemovedDTCList);

        // Assertions
        // Check if the right MachineOptionCode has been removed from the MachineOptionCodeList
        deepEqual(aMachineOptionCodeList, aResultMachineOptionCodeList);
    });

    // *** TEST CASE #5.2 ***
    test("simulateNewDTCFilters() should reduce the DTCs, DTAC Cases, Warranty Claims and Machine Option Codes in the application model path "
            + "'SimulatedEvidencePackageDetails' successfully while keeping path 'EvidencePackageDetails' unchanged", function() {
        // set evidence package in the application model first
        // In the mockup we have the following evidence package data:
        // DTCs: 1 , 2 , 3, 4, 5, 6
        // DTAC-Cases: 1, 2, 3
        // Warranty Claims: not exist

        oModel.setProperty("/EvidencePackageDetails/Header", jQuery.extend(true, {}, oEvidencePackageDetail));
        // In the response we receive the following data
        // DTCs: 1, 3
        // DTAC-Cases: 3
        // Warranty Claims: not exist

        // Trigger the ajax request
        oServiceFacade.simulateNewDTCFilters(undefined, undefined, oEvidencePackageDetail);
        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oApplyDTCFilters));

        // Assertion on DTCs:
        var oEvidencePackage = oModel.getProperty("/EvidencePackageDetails/Header");
        var oSimulatedEvidencePackage = oModel.getProperty("/SimulatedEvidencePackageDetails/Header");

        var oRootSimulatedEvidencePackage = oModel.getProperty("/SimulatedEvidencePackageDetails");

        // In path '/EvidencePackageDetails/Header' the values must remain unchanged
        deepEqual(oEvidencePackage.DTCCodeList[0].DTCID, 1);
        deepEqual(oEvidencePackage.DTCCodeList[1].DTCID, 2);
        deepEqual(oEvidencePackage.DTCCodeList[2].DTCID, 3);

        // In path '/SiumulatedEvidencePackageDetails' the values must be changed by new
        // filter
        deepEqual(oSimulatedEvidencePackage.DTCCodeList[0].DTCID, 1);
        deepEqual(oSimulatedEvidencePackage.DTCCodeList[1].DTCID, 3);
        // In path '/SimulatedEvidencePackageDetails' the DTC item 2 must be removed
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTCCodeList[0].DTCID, 2);
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTCCodeList[1].DTCID, 4);
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTCCodeList[2].DTCID, 5);
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTCCodeList[3].DTCID, 6);

        // In path '/EvidencePackageDetails/Header' the DTC filter and DTC filter state must remain
        // unchanged
        notDeepEqual(oEvidencePackage.DTCFilterSelection, undefined);
        notDeepEqual(oEvidencePackage.DTCFilterState, undefined);

        // In path '/SiumualtedEvidencePackageDetails' the DTC filter and DTC filter state
        // must be set
        deepEqual(oSimulatedEvidencePackage.DTCFilterSelection, undefined);
        deepEqual(oSimulatedEvidencePackage.DTCFilterState, undefined);

        // The PIN Population must be set
        var oRootSimulatedEvidencePackage = oModel.getProperty("/SimulatedEvidencePackageDetails");
        notDeepEqual(oRootSimulatedEvidencePackage._DTCFilters.PINPopulation, undefined);

        // the machine opion codes must be removed for DTC 2, so there are no left
        deepEqual(oSimulatedEvidencePackage.MachineOpionCodes, undefined);

        // Check existence of DTAC Cases
        deepEqual(oEvidencePackage.DTACCaseList[0].DTACCaseNumber, 1);
        deepEqual(oEvidencePackage.DTACCaseList[1].DTACCaseNumber, 2);
        deepEqual(oEvidencePackage.DTACCaseList[2].DTACCaseNumber, 3);

        // Check that we have only one DTAC Case left in the simulated Evidence Package
        deepEqual(oSimulatedEvidencePackage.DTACCaseList[0].DTACCaseNumber, 3);
        deepEqual(oSimulatedEvidencePackage.DTACCaseList.length, 1);

        // Check removed DTAC Cases
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTACCaseList[0].DTACCaseNumber, 1);
        deepEqual(oRootSimulatedEvidencePackage.RemovedDTACCaseList[1].DTACCaseNumber, 2);

        // Check initial existence of Warranty Claim
        deepEqual(oEvidencePackage.WarrantyClaimList.length, 3);
        // Check remaining Warranty Claims in Evidence Package
        deepEqual(oSimulatedEvidencePackage.WarrantyClaimList.length, 1);
        // Check removed Warranty Claims
        deepEqual(oRootSimulatedEvidencePackage.RemovedWarrantyClaimList.length, 2);
    });

    // *** TEST CASE #9 ***
    test("calculateMachineOptionCodesForDTC() should calculate machine options for DTC 2  and updates it in the application model path "
            + "EvidencePackageDetails successfully", function() {
        // set evidence package in the application model first
        // In the mockup we have the following evidence package data:
        // DTC 2 with two machine option codes "chassis" and "motor"
        oModel.setProperty("/EvidencePackageDetails/Header", jQuery.extend(true, {}, oEvidencePackageDetail));
        // In the response we receive the following data
        // DTC 2 two machine option codes "wheel" and "farmer"

        // Trigger the ajax request
        oServiceFacade.calculateMachineOptionCodesForDTC(2, undefined);
        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oCalculateMachineOptionCodesForDTC));

        var oEvidencePackage = oModel.getProperty("/EvidencePackageDetails/Header");

        // we expect two machine option codes
        deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption.length, 2);
        // with different values
        deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption[0].MachineOptionCode, "Engine");
        deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption[1].MachineOptionCode, "Chassis");
    });
    // *** TEST CASE #10 ***
    test(
            "calculateMachineOptionCodesForDTC() should calculate machine options for DTC 2  and create a new machine option code array it in the application model path "
                    + "EvidencePackageDetails successfully", function() {
                // set evidence package in the application model first
                // In the mockup we have no machine codes at all
                oModel.setProperty("/EvidencePackageDetails/Header", jQuery.extend(true, {}, oEvidencePackageDetail2));
                // In the response we receive the following data
                // DTC 2 two machine option codes "wheel" and "farmer"

                // Trigger the ajax request
                oServiceFacade.calculateMachineOptionCodesForDTC(2, undefined);
                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oCalculateMachineOptionCodesForDTC));

                var oEvidencePackage = oModel.getProperty("/EvidencePackageDetails/Header");

                // we expect two machine option codes
                deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption.length, 2);
                // with different values
                deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption[0].MachineOptionCode, "Engine");
                deepEqual(oEvidencePackage.MachineOptionCodes[0].MachineOption[1].MachineOptionCode, "Chassis");
            });

    // *** TEST CASE #11 ***
    test(
            "getEvidencePackageSummary() should update the path '/EvidencePackageDetails/Summary' and '/EvidencePackageDetails/AnalysisData from the file getEvidencePackageSummary_Response.json",
            function() {
                // Trigger the ajax request
                oServiceFacade.getEvidencePackageSummary(oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oEvidencePackageSummary));

                var oValue = oModel.getProperty("/EvidencePackageDetails/");

                // test value from the response
                deepEqual(oValue.Summary.RunningSumbyDate.Records[0].LineType,
                        oEvidencePackageSummary.Result.Summary.RunningSumbyDate.Records[0].LineType);
                deepEqual(oValue.AnalysisData.WarrantyClaimCount, oEvidencePackageSummary.Result.AnalysisData.WarrantyClaimCount);
            });

    // *** TEST CASE #12 ***
    test("getEvidencePackageDetails() should update the path '/EvidencePackageDetails/Header' from the file GetEvidencePackageDetails_Response.json",
            function() {
                // for testing no filter values are given
                var iPackageID = oEvidencePackageDetail.PackageID;

                // Trigger the ajax request
                oServiceFacade.getEvidencePackageDetails(iPackageID, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackageDetails));

                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackageDetails));

                var oValue = oModel.getProperty("/EvidencePackageDetails/Header");
                // test one value from the response
                deepEqual(oValue.AnalystName, "Rick Deckard");
            });

    // *** TEST CASE #12.1 ***
    test(
            "getEvidencePackageDetails() should set the DTAC Case filters by the last added DTAC Case from the file GetEvidencePackageDetails_Response.json",
            function() {
                // for testing no filter values are given
                var iPackageID = oEvidencePackageDetail.PackageID;

                // Trigger the ajax request
                oServiceFacade.getEvidencePackageDetails(iPackageID, function() {
                }, function() {
                });

                // That's how we respond to the ajax requests
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackageDetails));

                this.requests[1].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetDTCFilterDomainValues));

                // Get the DTAC Case which has been added as last
                var aDTACCaseList = oGetEvidencePackageDetails.Result.DTACCaseList;
                var oLatestDTACCase = aDTACCaseList[0];

                for ( var i = 1; i < aDTACCaseList.length; i++) {
                    if (new Date(oLatestDTACCase.AddedOn) < new Date(aDTACCaseList[i].AddedOn)) {
                        oLatestDTACCase = aDTACCaseList[i];
                    }
                }

                var oDTACCaseFilterSelection = oModel.getProperty("/DTACCaseFilters/FilterSelection");

                // test one value from the response
                deepEqual(oDTACCaseFilterSelection, oLatestDTACCase.DTACCaseFilterSelection);
            });

    // *** TEST CASE #12.2 ***
    test(
            "getEvidencePackageDetails() should set the Warranty Claim filters by the last added Warranty Claim from the file GetEvidencePackageDetails_Response.json",
            function() {
                // for testing no filter values are given
                var iPackageID = oEvidencePackageDetail.PackageID;

                // Trigger the ajax request
                oServiceFacade.getEvidencePackageDetails(iPackageID, function() {
                }, function() {
                });

                // That's how we respond to the ajax requests
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackageDetails));

                this.requests[1].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetDTCFilterDomainValues));

                // Get the DTAC Case which has been added as last
                var aWarrantyClaimList = oGetEvidencePackageDetails.Result.WarrantyClaimList;
                var oLatestWarrantyClaim = aWarrantyClaimList[0];

                for ( var i = 1; i < aWarrantyClaimList.length; i++) {
                    if (new Date(oLatestWarrantyClaim.AddedOn) < new Date(aWarrantyClaimList[i].AddedOn)) {
                        oLatestWarrantyClaim = aWarrantyClaimList[i];
                    }
                }

                var oWarrantyClaimFilterSelection = oModel.getProperty("/WarrantyClaimFilters/FilterSelection");

                // test one value from the response
                deepEqual(oWarrantyClaimFilterSelection, oLatestWarrantyClaim.WarrantyClaimFilterSelection);
            });

    // *** TEST CASE #13 ***
    test(
            "getEvidencePackageAnalysisData() should update the path '/EvidencePackageDetails/AnalysisData from the file getEvidencePackageAnalysisData_Response.json",
            function() {

                // Trigger the ajax request
                oServiceFacade.getEvidencePackageAnalysisData(oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackageAnalysisData));

                var oValue = oModel.getProperty("/EvidencePackageDetails/");

                // test value from the response
                deepEqual(oValue.AnalysisData.WarrantyClaimCount, 6);
            });

    // *** TEST CASE #14 ***
    test(
            "getEvidencePackagePINPopulationList() should update the path '/EvidencePackageDetails/PINPopulationList  from the file GetEvidencePackagePINPopulationList_Response.json",
            function() {
                oListBindingPINPopulation.sPath = "/EvidencePackageDetails/PINPopulationList";
                var oValue;

                // Trigger the ajax request
                oServiceFacade.getEvidencePackagePINPopulationList(oListBindingPINPopulation, "", oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oGetEvidencePackagePINPopulationList));

                // Assertion
                oValue = oModel.getProperty("/EvidencePackageDetails/PINPopulationList");
                // test one value from the table path of the response
                deepEqual(oValue[1].PINNumber, "ACF27");

            });

    // *** TEST CASE #15 ***
    test("getDTCDetailsList() should update the path 'EvidencePackageDetails/DTCDetailsList' from the file getDTCDetailsList_Response.json",
            function() {
                // Trigger the ajax request
                oServiceFacade.getDTCDetailsList(oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oDataGetDTCDetailsList));

                // Assertion
                var oValue = oModel.getProperty("/EvidencePackageDetails/DTCDetailsList");
                // test two returned DTCs from the response
                deepEqual(oValue[0].DTCMasterData.DTCID, oDataGetDTCDetailsList.Result.DTCDetails[0].DTCMasterData.DTCID);
                deepEqual(oValue[1].DTCMasterData.DTCID, oDataGetDTCDetailsList.Result.DTCDetails[1].DTCMasterData.DTCID);
                deepEqual(oValue[2].DTCMasterData.DTCID, oDataGetDTCDetailsList.Result.DTCDetails[2].DTCMasterData.DTCID);
            });

    // *** TEST CASE #15 ***
    test(
            "getDTACCaseDetailsList() should update the path 'EvidencePackageDetails/DTACCaseDetailsList' from the file getDTACCaseDetailsList_Response.json",
            function() {
                // for testing no filter values are given
                var oValue;

                // Trigger the ajax request
                oServiceFacade.getDTACCaseDetailsList(oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oDataGetDTACCaseDetailsList));

                // Assertion
                oValue = oModel.getProperty("/EvidencePackageDetails/DTACCaseDetailsList");
                // test the response
                deepEqual(oValue[0].DTACCaseNumber, oDataGetDTACCaseDetailsList.Result.DTACCaseDetails.Records[0].DTACCaseNumber);
                deepEqual(oValue[1].DTACCaseNumber, oDataGetDTACCaseDetailsList.Result.DTACCaseDetails.Records[1].DTACCaseNumber);
                deepEqual(oValue[2].DTACCaseNumber, oDataGetDTACCaseDetailsList.Result.DTACCaseDetails.Records[2].DTACCaseNumber);

            });
    // *** TEST CASE #16 ***
    test(
            "getWarrantyClaimDetailsList() should update the path 'EvidencePackageDetails/WarrantyClaimDetailsList' from the file getWarrantyClaimDetailsList_Response.json",
            function() {
                // for testing no filter values are given
                var oValue;

                // Trigger the ajax request
                oServiceFacade.getWarrantyClaimDetailsList(oEvidencePackageDetail2, function() {
                }, function() {
                });

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oDataGetWarrantyClaimDetailsList));

                // Assertion
                oValue = oModel.getProperty("/EvidencePackageDetails/WarrantyClaimDetailsList");
                // test the response
                deepEqual(oValue[0].WarrantyClaimSequenceNumber,
                        oDataGetWarrantyClaimDetailsList.Result.WarrantyClaimDetails.Records[0].WarrantyClaimSequenceNumber);
                deepEqual(oValue[1].WarrantyClaimSequenceNumber,
                        oDataGetWarrantyClaimDetailsList.Result.WarrantyClaimDetails.Records[1].WarrantyClaimSequenceNumber);
                deepEqual(oValue[2].WarrantyClaimSequenceNumber,
                        oDataGetWarrantyClaimDetailsList.Result.WarrantyClaimDetails.Records[2].WarrantyClaimSequenceNumber);

            });

})();
