(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.CustomizingServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    /**
     * @class The customizing service facade provides functionality to retrieve and save all customizing-related data. Although most of the data is
     *        tabular, {@link #._retrieveRecord} and all available data is retrieved so that filtering, paging, etc. can be done on the client. When
     *        saving, the application always sends the entire client data to the backend system without any information about what data has changed.
     * @name jd.ui.eid.service.CustomizingServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.CustomizingServiceFacade", /** @lends jd.ui.eid.service.CustomizingServiceFacade */
    {
        /**
         * Update customizing parameters.
         * 
         * @param {array}
         *            aKeyValues array contains key & value parameters
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        updateKeyValueParameters : function(aKeyValues, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/UpdateKeyValueParameters.xsjs";

            // Set test data file name
            var sModelDataFileName = "getKeyValueParameters_Response.json";
            // Prepare the custom payload
            var oArgs = {
                KeyValParameters : {
                    Records : aKeyValues
                }
            };
            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs, sModelDataFileName);
        },

        /**
         * Get the list customizing parameters.
         * 
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        getKeyValueParamters : function(fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/GetKeyValueParameters.xsjs";

            // Set test data file name
            var sModelDataFileName = "getKeyValueParameters_Response.json";

            // Argument field will be null in retrieveList function.
            var oArgs = {};

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of Parameters within this object.
            var fnGetListData = function(oData) {
                return oData.Result.KeyValParameters.Records;
            };

            // We can call _retrieveRecord here as we have a local binding.
            this._retrieveRecord(sServicePath, "/KeyValParameters", oArgs, fnSuccess, fnError, fnGetListData, sModelDataFileName, false);
        },

        /**
         * Update KPIs.
         * 
         * @param {array}
         *            aKeyValues array contains object of KPI names & its description
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        updateKPIs : function(aKPIs, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/UpdateKPIs.xsjs";
            // Set test data file name
            var sModelDataFileName = "getKPIs_Response.json";
            // Prepare the custom payload
            var oArgs = {
                KPIValues : {
                    Records : aKPIs
                }
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs, sModelDataFileName);
        },

        /**
         * Get the list of KPIs.
         * 
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        getKPIs : function(fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/GetKPIs.xsjs";

            // Set test data file name
            var sModelDataFileName = "getKPIs_Response.json";

            // Argument field will be null in retrieveList function.
            var oArgs = {};

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of Parameters within this object.
            var fnGetListData = function(oData) {
                return oData.Result.KPIValues.Records;
            };

            // We can call _retrieveRecord here as we have a local binding.
            this._retrieveRecord(sServicePath, "/KPIValues", oArgs, fnSuccess, fnError, fnGetListData, sModelDataFileName, false);
        },

        /**
         * Update severity rating and warning light mappings.
         * 
         * @memberOf jd.ui.eid.service.CustomizingServiceFacade
         * @param {array}
         *            aSeverity array contains object of Warning Light & Severity Rating
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        updateSeverity : function(aSeverity, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/UpdateSeverity.xsjs";
            // Set test data file name
            var sModelDataFileName = "getSeverity_Response.json";
            // Prepare the custom payload
            var oArgs = {
                SeverityValues : {
                    Records : aSeverity
                }
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs, sModelDataFileName);
        },

        /**
         * Get list of severity rating and warning light mappings.
         * 
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        getSeverity : function(fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/GetSeverity.xsjs";

            // Set test data file name
            var sModelDataFileName = "getSeverity_Response.json";

            // Argument field will be null in retrieveList function.
            var oArgs = {};

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of Parameters within this object.
            var fnGetListData = function(oData) {
                return oData.Result.SeverityValues.Records;
            };

            // We can call _retrieveRecord here as we have a local binding.
            this._retrieveRecord(sServicePath, "/SeverityValues", oArgs, fnSuccess, fnError, fnGetListData, sModelDataFileName, false);
        },

        /**
         * Update engine hour ranges.
         * 
         * @memberOf jd.ui.eid.service.CustomizingServiceFacade
         * @param {array}
         *            aEngineHourSegments array contains of platform, productline & bounds
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        updateEngineHourSegments : function(aEngineHourSegments, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/UpdateEngineHourSegments.xsjs";

            // Prepare the custom payload
            var oArgs = {
                EngineHourSegments : {
                    Records : aEngineHourSegments
                }
            };

            // Call this service
            this._send(sServicePath, fnSuccess, fnError, oArgs);
        },

        /**
         * Get list of engine hour ranges by platform/product line combination.
         * 
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         */
        getEngineHoursSegments : function(fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/custom/GetEngineHourSegments.xsjs";

            // Set test data file name
            var sModelDataFileName = "getEngineHourSegments_Response.json";

            // Argument field will be null in retrieveList function.
            var oArgs = {};

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of Parameters within this object.
            var fnGetListData = function(oData) {
                return oData.Result.EngineHourSegments.Records;
            };

            // We can call _retrieveRecord here as we have a local binding.
            this._retrieveRecord(sServicePath, "/EngineHourSegments", oArgs, fnSuccess, fnError, fnGetListData, sModelDataFileName, false);
        }
    });
})();