(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("sap.ui.core.format.NumberFormat");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    /**
     * @class This formatter class provides methods for formatting numbers and currencies.
     * @name jd.ui.eid.common.formatter.NumberFormatter
     * @static
     */
    jd.ui.eid.common.formatter.NumberFormatter = {};

    /**
     * Formats Float to a 2 digit fraction number with $ currency Example: 12454345.4564456 --> $12,454,345.45
     * 
     * @param {float}
     *            fFloatValue the float value
     * @returns {string} formatted float number with $ currency
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatFloatToUSDollarCurrency = function(fFloatValue) {
        return jd.ui.eid.common.formatter.NumberFormatter.formatFloat(fFloatValue, 2, true, "$");
    };

    /**
     * Formats Float to a 2 digit fraction number Example: 12454345.4564456 --> 12,45
     * 
     * @param {float}
     *            fFloatValue the float value
     * @returns {string} formatted float number
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatFloatTo2DigitFractionNumber = function(fFloatValue) {
        return jd.ui.eid.common.formatter.NumberFormatter.formatFloat(fFloatValue, 2, false);
    };

    /**
     * Formats Float to a digit number to display at UI Example: 12454345.4564456 --> 12,454,345.45
     * 
     * @param {float}
     *            fFloatValue the float value
     * @param {integer|object}
     *            iNumberOfFractionDigits number of fraction digits (default 2)
     * @param {integer}
     *            [iNumberOfFractionDigits.min] the min fraction digits.
     * @param {integer}
     *            [iNumberOfFractionDigits.max] the max fraction digits.
     * @param {boolean}
     *            [bWithCurrencySign] (default: false)
     * @param {string}
     *            [sCurrencySign] the currency sign (default: $)
     * @returns {string} formatted float number
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatFloat = function(fFloatValue, iNumberOfFractionDigits, bWithCurrencySign, sCurrencySign) {
        if (typeof (fFloatValue) == "number") {
            fFloatValue = jd.ui.eid.common.formatter.NumberFormatter.convertToDecimal(fFloatValue);

            var iMinFractionDigits, iMaxFractionDigits;
            if (iNumberOfFractionDigits instanceof Object) {
                iMinFractionDigits = iNumberOfFractionDigits.min;
                iMaxFractionDigits = iNumberOfFractionDigits.max;
            } else {
                iMinFractionDigits = iNumberOfFractionDigits;
                iMaxFractionDigits = iNumberOfFractionDigits;
            }

            var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
            var oFloat = sap.ui.core.format.NumberFormat.getFloatInstance({
                minFractionDigits : iMinFractionDigits,
                maxFractionDigits : iMaxFractionDigits
            }, oLocale);

            if (bWithCurrencySign) {
                return jd.ui.eid.common.formatter.NumberFormatter.addCurrencySign(oFloat.format(fFloatValue), sCurrencySign);
            } else {
                return oFloat.format(fFloatValue);
            }
        }
    };

    /**
     * Formats Integer to display at UI Example: 12454345 --> 12,454,345
     * 
     * @param {integer}
     *            iIntegerValue the integer value
     * @param {boolean}
     *            [bWithCurrencySign] (default: false)
     * @param {string}
     *            [sCurrencySign] the currency sign (default: $)
     * @returns {string} formatted integer number
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatInteger = function(iIntegerValue, bWithCurrencySign, sCurrencySign) {
        if (typeof (iIntegerValue) == "number") {
            var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
            var oInteger = sap.ui.core.format.NumberFormat.getIntegerInstance({
                groupingEnabled : true
            }, oLocale);

            if (bWithCurrencySign) {
                return jd.ui.eid.common.formatter.NumberFormatter.addCurrencySign(oInteger.format(iIntegerValue), sCurrencySign);
            } else {
                return oInteger.format(iIntegerValue);
            }
        }
    };

    /**
     * Adds currency sign to formatted number Example: 12,454,345 --> $12,454,345
     * 
     * @private
     * @param {string}
     *            sValue the formatted value
     * @param {string}
     *            [sCurrencySign] the currency sign like 'EUR' or '$' (default '$')
     * @returns {string} number with currency sign
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.addCurrencySign = function(sValue, sCurrencySign) {
        if (sCurrencySign == null || undefined) {
            sCurrencySign = '$';
        }
        // Call text bundle to decide if currency sign is right or left of the figure
        return jd.ui.eid.common.I18NHelper.getText("COMMON_FORMATTER_TXT_CURRENCY_SIGN_0_FIGURE_1_POSITION", [sCurrencySign, sValue]);
    };

    /**
     * Formats a Float to a percentage value
     * 
     * @param {float}
     *            fValue the the percentage value.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted percentage value.
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatPercentage = function(fValue, oContext) {
        fValue = fValue * 100; // Make it percentage.
        var iDigitsAfterSeparator = 3;
        var iFactor = Math.pow(10, iDigitsAfterSeparator);
        fValue = Math.round(fValue * iFactor) / iFactor;
        return fValue;
    };

    /**
     * Formats a Float to a percentage value with one fraction digit and puts a % behind the value
     * 
     * @param {float}
     *            fValue the the percentage value.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted percentage value with percentage sign.
     * @memberOf jd.ui.eid.common.formatter.NumberFormatter
     */
    jd.ui.eid.common.formatter.NumberFormatter.formatPercentageWithSign = function(fValue, oContext) {
        var fPercentageFloatValue = jd.ui.eid.common.formatter.NumberFormatter.formatPercentage(fValue, oContext);

        var fPercentageFloatValueOneFractionDigit = jd.ui.eid.common.formatter.NumberFormatter
                .formatFloatTo2DigitFractionNumber(fPercentageFloatValue);
        return jd.ui.eid.common.I18NHelper.getText("COMMON_FORMATTER_TXT_PERCENTAGE", fPercentageFloatValueOneFractionDigit);
    };

    /**
     * Converts a float to a decimal string while also considering notations like <code>1.344E-11</code> (tiny float).<br>
     * Note that this is a <strong>workaround</code> for a know bug in 1.18.6, which doesn't format tiny floats probably. In future releases, this
     * method can likely be removed. if there are any issues with this particular method, please create an OSS on the SAP UI5 component.
     * 
     * @private
     * @param {float}
     *            fValue float value to convert.
     * @returns {string} decimal representation of the float.
     */
    jd.ui.eid.common.formatter.NumberFormatter.convertToDecimal = function(fValue) {
        var sValue = "" + fValue, bNegative, sBase, iDecimalLength, iFractionLength, iExponent, iPos;
        if (sValue.indexOf("e") == -1 && sValue.indexOf("E") == -1) {
            return sValue;
        }
        var aResult = sValue.match(/^([+-]?)((\d+)(?:\.(\d+))?)[eE]([+-]?\d+)$/);
        bNegative = aResult[1] == "-";
        sBase = aResult[2].replace(/\./g, "");
        iDecimalLength = aResult[3] ? aResult[3].length : 0;
        iFractionLength = aResult[4] ? aResult[4].length : 0;
        iExponent = parseInt(aResult[5], 10);

        if (iExponent > 0) {
            if (iExponent < iFractionLength) {
                iPos = iDecimalLength + iExponent;
                sValue = sBase.substr(0, iPos) + "." + sBase.substr(iPos);
            } else {
                sValue = sBase;
                iExponent -= iFractionLength;
                for ( var i = 0; i < iExponent; i++) {
                    sValue += "0";
                }
            }
        } else {
            if (-iExponent < iDecimalLength) {
                iPos = iDecimalLength + iExponent;
                sValue = sBase.substr(0, iPos) + "." + sBase.substr(iPos);
            } else {
                sValue = sBase;
                iExponent += iDecimalLength;
                for ( var i = 0; i > iExponent; i--) {
                    sValue = "0" + sValue;
                }
                sValue = "0." + sValue;
            }
        }
        if (bNegative) {
            sValue = "-" + sValue;
        }
        return sValue;
    };

})();