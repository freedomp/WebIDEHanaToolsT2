(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.main.shared.DTCTableController");
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");

    /**
     * @class
     * <p>
     * The DTCTableController provides reusable functionality for the list of DTCs and the toolbar as well as fetching data (see
     * {@link #.fetchDTCList}, {@link #.handleRefreshDTCList}).
     * </p>
     * <p>
     * To <strong>highlight a DTC</code> if it's already in the evidence package or has been added to the blacklist, there is an anonymous formatter
     * function bound to the <code>enabled</code> property of the link control for the DTC code. By assigning the formatter in the controller, the
     * context of the formatter (<code>this</code>) points to the control itself. Thus, the CSS of the DOM element can be manipulated. As these
     * manipulations are lost once the control is rerendered, there is also, a CSS class is assigned to the link control (which survives rerendering)
     * as an anchor point. This anchor point is used to re-manipulate the DOM after the table is rerendered. This logic is implemented in
     * {@link #.initDTCTableController}.
     * </p>
     * <p>
     * The view has the following hook methods which need to be called from the consuming controller in the life cycle:
     * <ul>
     * <li>{@link #.initDTCTableController} has to be called from <code>onInit</code> after the <code>mDTCTableControllerConfig</code> has been
     * maintained.</li>
     * <li>{@link #.onDTCTableControllerBeforeRendering} has to be called from <code>onBeforeRendering</code>.</li>
     * <li>{@link #.onDTCTableControllerAfterRendering} has to be called from <code>onAfterRendering</code>.</li>
     * <li>{@link #.exitDTCTableController} has to be called from <code>onExit</code>.</li>
     * </ul>
     * </p>
     * <p>
     * Used in:
     * <ul>
     * <li>{@link jd.ui.eid.view.main.shell.Dashboard}</li>
     * <li>{@link jd.ui.eid.view.main.worksheet.discovery.DTCList</li>
     * </ul>
     * </p>
     * <p>
     * Example for merging:
     * 
     * <pre>
     * jd.ui.eid.require(&quot;jd.ui.eid.view.main.shared.DTCTableController&quot;);
     * sap.ui.controller(&quot;view.ViewName&quot;, jQuery.extend(true, {}, jd.ui.eid.view.main.shared.DTCTableController, {
     * // controller methods
     * }));
     * </pre>
     * 
     * </p>
     * 
     * @static
     * @name jd.ui.eid.view.main.shared.DTCTableController
     */
    jd.ui.eid.view.main.shared.DTCTableController = {

        mDTCTableControllerConfig : {
            mFetchDTCList : {
                sFilterSelectionPath : null,
                aAdditionalBusyControlIds : []
            },
            sDTCTableId : 'DTCListTable',
            sKPIComboBoxId : 'DTCKPISelection',
            sSearchFieldId : 'dashboardSearchField',
            sDTCTableKPIColumnLabelId : 'columnLabelKPIName',
            bHighlightDTCsInBasket : true
        },

        _bKPIComboBoxInitialized : false,

        /**
         * Initializes the DTC table. Should be invoked from a controller's <code>onInit</method>.
         */
        initDTCTableController : function() {
            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleDTCTableModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleDTCTableModelDataFeteched, this);
            oEventBus.subscribe("Model", "kpisRetrieved", this.handleKPIsRetrieved, this);

            // Buffer busy controls
            var that = this;
            var oTable = this.byId(this.mDTCTableControllerConfig.sDTCTableId);
            this._aDTCTableBusyControls = [oTable];
            $.each(this.mDTCTableControllerConfig.mFetchDTCList.aAdditionalBusyControlIds, function(sIdx, sId) {
                that._aDTCTableBusyControls.push(that.byId(sId));
            });

            // Assign an anonymous formatter to the enabled property of the DTC code element. Thus, the formatter is executed in the context of the
            // control, so we can manipulate the DOM around it to make the row appear disabled.
            var oLinkTemplate = this.byId("DTCTableDTCCodeLinkTemplate");
            var that = this;
            if (oLinkTemplate) {
                oLinkTemplate.bindProperty("enabled", {
                    parts : [{
                        path : '_isNotOnBlacklist'
                    }, {
                        path : '_canBeAddedToEvidencePackage'
                    }],
                    formatter : function(bIsNotOnBlacklist, bCanBeAddedToEvidencePackage) {
                        if (bIsNotOnBlacklist === false) {
                            // Don't use the DOM reference here, otherwise it will be lost when the control is rerendered.
                            // If the DTC is on the blacklist, will mark it as inactive
                            this.addStyleClass("jdUiEidTableRowInactiveRef");
                            this.$().closest("tr").addClass("jdUiEidTableRowInactive");
                        } else if (that.mDTCTableControllerConfig.bHighlightDTCsInBasket && bCanBeAddedToEvidencePackage === false) {
                            // If the DTC is already in the evidence package, we will positively highlight the row
                            this.addStyleClass("jdUiEidTableRowSuccessRef");
                            this.$().closest("tr").addClass("jdUiEidTableRowSuccess");
                        } else {
                            // Otherwise, we remove the DOM attributes that might have been assigned previously. This for example is the case when the
                            // table pages to the next page, when only the binding is updated but the table is not rerenderd.
                            this.removeStyleClass("jdUiEidTableRowInactiveRef");
                            this.$().closest("tr").removeClass("jdUiEidTableRowInactive");
                            this.removeStyleClass("jdUiEidTableRowSuccessRef");
                            this.$().closest("tr").removeClass("jdUiEidTableRowSuccess");
                        }
                        // Only return the blacklist flag because we don't want to disable the link of it's already in the evidence package, but we
                        // just want to highlight the row.
                        return bIsNotOnBlacklist !== false;
                    }
                });
            }

            // And we need to add an event delegate to the table so when the table is rerendered, the tr's get the .jdUiEidTableRowInactive class
            // again.
            oTable.addEventDelegate({
                onAfterRendering : function() {
                    oTable.$().find(".jdUiEidTableRowInactiveRef").closest("tr").addClass("jdUiEidTableRowInactive");
                    oTable.$().find(".jdUiEidTableRowSuccessRef").closest("tr").addClass("jdUiEidTableRowSuccess");
                }
            });
        },

        /**
         * Hook to be called in onBeforeRendering.
         */
        onDTCTableControllerBeforeRendering : function() {
            this.initKPIComboBox();
        },

        /**
         * Hook to be called in onAfterRendering.
         */
        onDTCTableControllerAfterRendering : function() {
            this.updateKPIColumnLabel();
        },

        /**
         * Hook to be called in onExit
         */
        exitDTCTableController : function() {
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleDTCTableModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleDTCTableModelDataFeteched, this);
            oEventBus.unsubscribe("Model", "kpisRetrieved", this.handleKPIsRetrieved, this);
        },

        /**
         * Initializes the KPI combo box with KPIs and an initial selection if KPIs ara available.
         */
        initKPIComboBox : function() {
            var aKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
            if (aKPIs && !this._bKPIComboBoxInitialized && this.byId(this.mDTCTableControllerConfig.sKPIComboBoxId).getItems().length > 0) {
                // Only if the KPI box hasn't been initialized and the items are available (already bound), we initialize the KPI combo box
                var mFirstKPI = aKPIs[0];
                var oKPIComboBox = this.byId(this.mDTCTableControllerConfig.sKPIComboBoxId);

                // Make sure that there is always a selectedKey (model is superior), so that the title of the table column can be updated afterwards.
                var sSelectedKPIID;
                if (!oKPIComboBox.getSelectedKey() && sap.ui.getCore().getModel().getProperty("/SelectedKPIID")) {
                    sSelectedKPIID = sap.ui.getCore().getModel().getProperty("/SelectedKPIID");
                } else {
                    sSelectedKPIID = mFirstKPI.KPIID;
                }
                oKPIComboBox.setSelectedKey(sSelectedKPIID);

                this._bKPIComboBoxInitialized = true;
            }
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the DTC list is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleDTCTableModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTCList") {
                $.each(this._aDTCTableBusyControls, function(sIdx, oControl) {
                    oControl.setBusy(true);
                });
            }
        },

        /**
         * Handles the event fired when data for the DTC list has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleDTCTableModelDataFeteched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTCList") {
                $.each(this._aDTCTableBusyControls, function(sIdx, oControl) {
                    oControl.setBusy(false);
                });
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Retrieves DTC Overview List data
         * 
         * @param {boolean}
         *            bRefreshData true if the available data chunk should be refreshed, false if data should be fetched based on e.g. updated filter
         *            criteria.
         */
        fetchDTCList : function(bRefreshData) {
            if (this.fetchDTCListHookBefore() === false) {
                // Interupt execution
                return;
            }

            var that = this;
            var oTable = this.byId(this.mDTCTableControllerConfig.sDTCTableId);
            // Return to first page of table
            oTable.setFirstVisibleRow(0);

            // retrieve DTC List values
            var oDTCListBinding = oTable.getBinding("rows");
            if (oDTCListBinding != null) {
                if (bRefreshData) {
                    oDTCListBinding.refreshData();
                } else {
                    var oCustomFilter = sap.ui.getCore().getModel().getProperty(this.mDTCTableControllerConfig.mFetchDTCList.sFilterSelectionPath);
                    var sSearchTerm = this.byId(this.mDTCTableControllerConfig.sSearchFieldId).getValue();
                    var sSelectedKPIID = this.byId(this.mDTCTableControllerConfig.sKPIComboBoxId).getSelectedKey();
                    this.getServiceFacade('DTC').getDTCList(oDTCListBinding, oCustomFilter, sSelectedKPIID, sSearchTerm, function() {
                        // Request successful
                    }, function() {
                        // Reuest failed
                        // Clear the data in the model and reset the control's busy states
                        var oModel = sap.ui.getCore().getModel();
                        oModel.setProperty("/Top10DTCs/Records", []);
                        oModel.setProperty("/DTCList", []);

                        that._onRequestFailed.apply(that, arguments);
                    });
                }
            }
        },

        /**
         * Hook method called before fetching the DTC list
         * 
         * @see #.fetchDTCList
         * 
         * @return {boolean} True to fetch the DTC list, false otherwise.
         */
        fetchDTCListHookBefore : function() {

        },

        /**
         * Handler of the refresh DTC List event. Triggers a service call to update the current list of DTC.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the button.
         */
        handleRefreshDTCList : function(oEvent) {
            this.handleRefreshDTCListHookBefore();
            // GetBinding and execute refresh
            var oTable = this.byId(this.mDTCTableControllerConfig.sDTCTableId);
            var oDTCListBinding = oTable.getBinding("rows");
            oDTCListBinding.refreshData();
        },

        /**
         * Hook method called before the refresh of the DTC list is triggered.
         * 
         * @see #.handleRefreshDTCList
         */
        handleRefreshDTCListHookBefore : function() {

        },

        /**
         * This function handles the event that is triggered by clicking on "add to DTC Blacklist" button
         * 
         * @param {object}
         *            oEvent event triggered by clicking on "add to blacklist"
         */
        handleAddToDTCBlacklist : function(oEvent) {
            var oContext = oEvent.getSource().getBindingContext();
            var mDTC = oContext.getProperty();
            jd.ui.eid.common.BusinessProcessHelper.DTCBlacklist.addDTC(mDTC);
            // sap.ui.getCore().getModel().setProperty("_isNotOnBlacklist", false, oContext);
        },

        /**
         * Handles the event fired when the available KPIs have been retrieved from the customizing to set the first selectedKey of the dropdown.
         * 
         * @param {string}
         *            sChannelId the name of the channel
         * @param {string}
         *            sEvent the name of the event
         * @param {object}
         *            oData the data passed with the event
         */
        handleKPIsRetrieved : function(sChannelId, sEvent, oData) {
            var aKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
            if (aKPIs) {
                this.initKPIComboBox();
                this.updateKPIColumnLabel();
            } else {
                $.sap.log.fatal("No KPIs available");
            }
        },

        /**
         * This function handles the change of KPI selection - the label of table column for KPI value will be updated - data will be fetched again
         * using the current KPI selection
         */
        handleKPISelectionChange : function() {
            this.updateKPIColumnLabel();
            this.fetchDTCList();
            this.handleKPISelectionChangeHookAfter();
        },

        /**
         * Hook method called after {@link #.handleKPISelectionChange}.
         */
        handleKPISelectionChangeHookAfter : function() {

        },

        /**
         * Updates the column label of the KPI column based on the current selection.
         */
        updateKPIColumnLabel : function() {
            var sKPIName = this.byId("DTCKPISelection").getValue();
            // set the table column label with the current KPI name
            this.byId('columnLabelKPIName').setText(sKPIName);
        },

        /* SECTION - Formatter - START */

        /**
         * Formatter that return the number of DTCs
         * 
         * @param {array}
         *            aDTCList the DTC set
         * @returns {string} the string consists of number of DTC + "DTC"
         */
        formatDTCCount : function(aDTCList) {
            var iLength = 0;
            var oListBinding = this.byId(this.mDTCTableControllerConfig.sDTCTableId).getBinding("rows");
            if (oListBinding && aDTCList.length > 0) {
                // Only if we already have a list binding and if the DTC list actually contains elements. For example, if the the filter area on the
                // dashboard is cleared, the list of DTC's is cleared but the binding cannot relaly be reset reliably. So let's only get the
                // information from the binding if we currently have DTCs on the client which we could potentially display.
                iLength = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oListBinding.getLength());
            }
            return jd.ui.eid.common.I18NHelper.getNumberChoiceText(iLength.toString(), "DTC_TABLE_CAP_COUNT_BY_KPI_MULTIPLE",
                    "DTC_TABLE_CAP_COUNT_BY_KPI_SINGLE");
        },

        /**
         * Formats the enabled property to false if DTC is on blacklist or in the evidence package.
         * 
         * @param {boolean}
         *            bCanBeAddedToBlacklist whether the DTC is on the blacklist.
         * @param {boolean}
         *            bCanBeAddedToEvidencePackage whether the DTC is in the evidence package.
         * @returns {boolean} true if the DTC is neither in the blacklist nor in the evidence package, false otherwise.
         */
        formatEnableAddToEvidencePackageButton : function(bCanBeAddedToBlacklist, bCanBeAddedToEvidencePackage) {
            return (bCanBeAddedToBlacklist || bCanBeAddedToBlacklist === undefined)
                    && (bCanBeAddedToEvidencePackage || bCanBeAddedToEvidencePackage === undefined);
        }

    /* SECTION - Formatter - End */
    };
})();