(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * @class
     * <p>
     * The view displays a list of DTCs which have been blacklisted by the user.
     * </p>
     * <h2>Controls</h2>
     * <p>
     * The view mainly consists of a table control. The search field control is in the table's toolbar. The 'DTC code' column uses the
     * {@link jd.ui.eid.control.TableActionCell TableActionCell} control as its template, to provide actions (delete) on mouse hover.
     * </p>
     * <h2>Functionality</h2>
     * <p>
     * When the user clicks on 'Delete' on a row, the {@link #.handleDeleteDTC} event handler in the controller is invoked and triggers a re-fetch of
     * the list if successful.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.shell.personalization.DTCBlacklist
     */
    sap.ui.controller("jd.ui.eid.view.main.shell.personalization.DTCBlacklist", jQuery.extend(true, {}, jd.ui.eid.view.BaseController, /** @lends jd.ui.eid.view.main.shell.personalization.DTCBlacklist */
    {

        _oService : null,
        _oView : null,

        /* SECTION - View Life Cycle - START */
        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiView jdUiEidViewAutoScroll");

            // Subcribe to event bus
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().subscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);

            this._oService = this.getServiceFacade("DTCBlacklist");
            this._oService.attachRequestFailed(this._onRequestFailed);
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         */
        onAfterRendering : function() {
            // UI has finished loading. Fetch the DTC Blacklist.
            this.fetchDTCBlacklist();
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         */
        onExit : function() {
            // Unsubcribe to event bus
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            sap.ui.getCore().getEventBus().unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);

            // Detach event listeners
            this._oService.detachRequestFailed(this._onRequestFailed);

            // Set properties to null
            this._oView = null;
            this._oService = null;
        },

        /* SECTION - View Life Cycle - END */

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the DTAC case list is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTCBlacklist") {
                this.byId("blacklistTable").setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the DTAC case list has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelDataFeteched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/DTCBlacklist") {
                this.byId("blacklistTable").setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Formatter that returns a formatted string with the number of entries in the user's blacklist
         */
        formatBlacklistCount : function(aDTCBlacklist) {
            var iLength = 0;
            var oListBinding = this.byId("blacklistTable").getBinding("rows");
            if (oListBinding) {
                iLength = oListBinding.getLength();
            }
            return jd.ui.eid.common.I18NHelper.getNumberChoiceText("" + iLength, "DTC_BLACKLIST_TABLE_CAP_COUNT_MULTIPLE",
                    "DTC_BLACKLIST_TABLE_CAP_COUNT_SINGLE");
        },

        /**
         * This is invoked by the UI when the user clicks on the 'delete' action button on a row.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent Object passed by the framework, containing information such as the source of the event.
         */
        handleDeleteDTC : function(oEvent) {
            // Get the event source
            var oSource = oEvent.getSource();

            // From the binding context, get the DTCID that needs to be deleted.
            var sDTCId = oSource.getBindingContext().getProperty("DTCID");
            var sDTCCode = oSource.getBindingContext().getProperty("DTCCode");

            // Store reference to the controller
            var oController = this;

            // Prepare the success handler
            var fnSuccess = function() {
                // Fetch the DTC blacklist again
                oController.fetchDTCBlacklist();

                // Notify user that DTC was successfully deleted
                var sSuccessText = jd.ui.eid.common.I18NHelper.getText("DTC_BLACKLIST_MSG_DELETE_SUCCESS", [sDTCCode]);
                oController.getNotificationCenter().success(sSuccessText); // EIC 200.9 has been
                // removed
                // from
                // your DTC blacklist.
            };

            // Prepare the error handler
            var fnError = function() {
                // Notify user that DTC could not be deleted
                var sErrorText = jd.ui.eid.common.I18NHelper.getText("DTC_BLACKLIST_MSG_DELETE_ERROR", [sDTCCode]);
                oController.getNotificationCenter().alert(sErrorText); // EIC 200.9 could not be
                // removed
                // from your DTC blacklist.
            };

            // Make the service call
            this._oService.removeDTCFromBlacklist(sDTCId, fnSuccess, fnError);
        },

        /**
         * This method fetches the blacklist for the current user and updates the model.
         */
        fetchDTCBlacklist : function() {
            // Get binding and search term from UI
            var oBinding = this._oView.byId("blacklistTable").getBinding();
            var sSearchTerm = this._oView.byId("searchField").getValue();

            // Make the service call (no extra action needed in case of success, so not passing a
            // callback)
            this._oService.getDTCBlacklist(oBinding, sSearchTerm, null, this._onRequestFailed);
        },

        /**
         * Handler of the refresh list event. Triggers a service call to update the DTC Blacklist.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the button.
         */
        handleRefreshDTCBlacklist : function(oEvent) {
            // Get binding and search term from UI
            var oBinding = this._oView.byId("blacklistTable").getBinding();
            oBinding.refreshData();
        },
    }));
})();