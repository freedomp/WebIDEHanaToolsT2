(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.TableHelper");

    var _mColumnStateBuffer = {};

    /**
     * @class Helper Class for tables.
     * @static
     * @name jd.ui.eid.common.TableHelper
     */
    jd.ui.eid.common.TableHelper = {};

    /**
     * Returns an object that represents the state of each column of the table. The state covers the sorting and filtering.
     * 
     * @param {sap.ui.table.Table}
     *            oTable the table object to return the column state for.
     * @returns {object} a map of the column states.
     */
    jd.ui.eid.common.TableHelper.getColumnsStateObject = function(oTable) {
        var mColumnsState = {
            Columns : []
        };

        var aColumns = oTable.getColumns();
        $.each(aColumns, function(iIdx, oColumn) {
            var mState = {
                Filtered : oColumn.getFiltered(),
                FilterValue : oColumn.getFilterValue(),
                Sorted : oColumn.getSorted(),
                SortOrder : oColumn.getSortOrder()
            };
            mColumnsState.Columns.push(mState);
        });

        return mColumnsState;
    };

    /**
     * Returns an object that represents the state of each column of the table. The state covers the sorting and filtering.
     * 
     * @param {sap.ui.table.Table}
     *            oTable the table object to return the column state for.
     * @param {string}
     *            sRef the reference in the buffer.
     * @returns {object} a map of the column states.
     */
    jd.ui.eid.common.TableHelper.bufferColumnsState = function(oTable, sRef) {
        _mColumnStateBuffer[sRef] = this.getColumnsStateObject(oTable);
    };

    /**
     * Applies the column state object to the given table.
     * 
     * @param {sap.ui.table.Table}
     *            oTable the table object to apply the column state to.
     * @param {object}
     *            a map of the column states.
     */
    jd.ui.eid.common.TableHelper.applyColumnsStateObject = function(oTable, mColumnsState) {
        var aColumns = oTable.getColumns();
        $.each(aColumns, function(iIdx, oColumn) {
            var mState = mColumnsState.Columns[iIdx];
            if (mState) {
                oColumn.setFiltered(mState.Filtered);
                oColumn.setFilterValue(mState.FilterValue);
                oColumn.setSorted(mState.Sorted);
                oColumn.setSortOrder(mState.SortOrder);
            }
        });
    };

    /**
     * Applies the column state object in the buffer to the given table.
     * 
     * @param {sap.ui.table.Table}
     *            oTable the table object to apply the column state to.
     * @param {string}
     *            sRef the reference in the buffer.
     */
    jd.ui.eid.common.TableHelper.applyColumnsStateFromBuffer = function(oTable, sRef) {
        this.applyColumnsStateObject(oTable, _mColumnStateBuffer[sRef]);
    };

    /**
     * Flushes the buffer of column states.
     * 
     * @param {string}
     *            [sRef] the reference in the buffer. If no reference is provided, the entire buffer will be flushed.
     */
    jd.ui.eid.common.TableHelper.flushColumnsStateBuffer = function(sRef) {
        if (sRef) {
            _mColumnStateBuffer[sRef] = null;
        } else {
            _mColumnStateBuffer = {};
        }
    };

})();