(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new MachineOptionTableRenderingPrintStep.
     * 
     * @class The class provides a mechanism for rendering the table of machine option codes for printing.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep
     */
    jd.ui.eid.common.print.PrintStep
            .extend(
                    "jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep",
                    /** @lends jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep */
                    {
                        metadata : {
                            associations : {
                                machineOptionTableRenderLayout : {
                                    type : "sap.ui.core.Control",
                                    multiple : false
                                }
                            }
                        },

                        /**
                         * _process method hook of this PrintStep. Initiates the rendering of the panels and tables.
                         * 
                         * @memberOf jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep
                         */
                        _process : function() {
                            var aMachineOptions = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/MachineOptionCodes");
                            if (aMachineOptions && (aMachineOptions.length > 0)) {
                                // The _createAndAttachHTMLNode method fires the 'processed' event once it is done.
                                this._createAndAttachHTMLNode(aMachineOptions);
                            } else {
                                this.fireProcessed();
                            }
                        },

                        /**
                         * Prepares all required content for the 'Machine Option Codes' section of the print view, and adds it to the 'content'
                         * aggregation of the layout that is used for the 'machineOptionTableRenderLayout' association.
                         * 
                         * @param {array}
                         *            aMachineOptions The array representing the machine option codes that need to be rendered.
                         * @memberOf jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep
                         */
                        _createAndAttachHTMLNode : function(aMachineOptions) {
                            // ***********************************************************************************************************************
                            // ------------------------------------------- HEAR YE, HEAR YE ----------------------------------------------------------
                            // The challenge that this method solves, is to render possibly huge tables (and possibly a huge number of tables) on the
                            // UI without blocking the UI thread for too long. This ensures that the browser is always responsive and the 'Cancel'
                            // button in the Print view is clickable throughout this time consuming task. This is achieved by creating a few rows of
                            // the table ('iChunk' number of rows) and then postponing further execution till the browser is free again, by using
                            // setTimeout() with an interval of 0.
                            // The function _fnCreateRows is intentionally defined inside _fnCreatePanels to create a closure. This preserves the
                            // 'state' for _createRows (like iCurrentRowIndex, bAllRowsRendered, sTableRowsHTML etc.) even when _createRows is called
                            // repeatedly with a setTimeout, while rendering large tables.
                            // The while(true) loop inside _fnCreateRows HTML for rows to be continuously prepared. This infinite loop breaks if one
                            // of 2 conditions is met.
                            // 1. 'iChunk' number of rows have been rendered continuously (blocking the UI thread), and it is time to take a break.
                            // 2. The HTML for all machine option codes for the current DTC has been prepared.
                            //
                            // If case (1) is true, then we queue another call to _createRows to the end of the event queue, using setTimeout.
                            // If case (2) is true, we check if there are more DTCs for which tables need to be created. If yes, a call to
                            // _createPanels is queued in the browser's event queue.
                            //
                            // Once all panels (each panel represents a DTC) have been prepared, they are added to the 'content' aggregation of the
                            // layout specified by the 'machineOptionTableRenderLayout' association.
                            // -----------------------------------------------------------------------------------------------------------------------
                            // ***********************************************************************************************************************
                            var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");
                            var oPrintStep = this;
                            var iNextPanelIndex = 0;
                            var iCurrentPanelIndex;
                            var aPanels = [];
                            var _fnCreatePanels = function() {
                                // What is the context for the Panel that is being currently rendered in this call of _fnCreatePanels?
                                iCurrentPanelIndex = iNextPanelIndex++;
                                var oMachineOption = aMachineOptions[iCurrentPanelIndex];

                                // Prepare the panel
                                var oPanel = new sap.ui.commons.Panel(
                                        {
                                            text : "{ parts: [{path: 'DTCID'}, {path:'DTCCode'}, {path: 'MachineOption'}], formatter: 'jd.ui.eid.common.formatter.MachineOptionFormatter.formatPanelText' }",
                                            showCollapseIcon : false
                                        }).addStyleClass("jdUiPanel").addStyleClass("jdUiEidPanelL2").bindElement(
                                        "/EvidencePackageDetails/Header/MachineOptionCodes/" + iCurrentPanelIndex);

                                // Prepare the table for each panel
                                var $tableRoot = oPrintStep._createTableRootNode();

                                // Now comes the function that will fill the above-created table with rows. This works in a non-blocking way so that
                                // the UI doesn't become unresponsive.
                                var iChunk = 100;
                                var iNextRowIndex = 0;
                                var iCurrentRowIndex;
                                var sTableRowsHTML = "";
                                var aMachineOptionCodes = oMachineOption.MachineOption;
                                var bAllRowsRendered = false;
                                var _fnCreateRows = function() {
                                    while (true) {
                                        // Are there any rows at all to be rendered?
                                        if (aMachineOptionCodes.length == 0) {
                                            // Case : "No machine option codes exist" for the current DTC
                                            var sText = jd.ui.eid.common.I18NHelper
                                                    .getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_DO_NOT_EXIST");
                                            var oLabel = new sap.ui.commons.Label({
                                                text : sText
                                            }).addStyleClass("jdUiLbl");
                                            oPanel.addContent(oLabel);
                                            aPanels.push(oPanel);
                                            bAllRowsRendered = true; // this flag will cause the logic to stop with this panel (DTC) and move on to
                                            // the next.
                                            break;
                                        } else if (aMachineOptionCodes.length == 1
                                                && oEvidencePackageServiceFacade.MachineOptionCalculation
                                                        .hasCalculationNotYetStarted(aMachineOptionCodes[0])) {
                                            // Case : "Machine options not yet calculated" for the current DTC
                                            var sText = jd.ui.eid.common.I18NHelper
                                                    .getText("MACHINE_OPTION_CODE_TABLE_TXT_MACHINE_CODES_NOT_YET_CALCULATED");
                                            var oLabel = new sap.ui.commons.Label({
                                                text : sText
                                            });
                                            oPanel.addContent(oLabel);
                                            aPanels.push(oPanel);
                                            bAllRowsRendered = true;
                                            break;
                                        }

                                        // Get the next code to be rendered..
                                        iCurrentRowIndex = iNextRowIndex++;
                                        var oCode = aMachineOptionCodes[iCurrentRowIndex];

                                        // Get the HTML for the current row
                                        var sRowHTML = oPrintStep._getRowHTML(oCode);

                                        // Append this row to our buffer
                                        sTableRowsHTML += sRowHTML;

                                        // Did we just render the last row in the list?
                                        if (iCurrentRowIndex == (aMachineOptionCodes.length - 1)) {
                                            $tableRoot.find("tbody").append($(sTableRowsHTML));
                                            var oPanelHTML = new sap.ui.core.HTML({
                                                content : $tableRoot.outerHTML()
                                            });
                                            oPanel.addContent(oPanelHTML);
                                            aPanels.push(oPanel);
                                            bAllRowsRendered = true;
                                            break;
                                        }

                                        // Did the user cancel the Print view? If so, then stop.
                                        if (oPrintStep.bIsDestroyed) {
                                            return;
                                        }

                                        // Time to take a break? If 'iChunk' number of rows have been rendered, then return control to the browser so
                                        // that the UI doesn't become unresponsive.
                                        if ((iCurrentRowIndex % iChunk) == 0) {
                                            break;
                                        }
                                    }

                                    // If it's time to take a break after rendering 'iChunk' rows, do it.
                                    if (!bAllRowsRendered) {
                                        window.setTimeout(_fnCreateRows, 0);
                                    } else {
                                        // All rows for the current panel have been rendered and the Panel is ready (with the HTML added to its
                                        // content)
                                        // Check if there are more panels to be rendered.
                                        if (iCurrentPanelIndex < (aMachineOptions.length - 1)) {
                                            window.setTimeout(_fnCreatePanels, 0);
                                        } else {
                                            // All panels are ready and added to aPanels!
                                            var oRenderLayout = oPrintStep._getMachineOptionTableRenderLayout();
                                            $.each(aPanels, function(i, oPanel) {
                                                oRenderLayout.addContent(oPanel);
                                            });
                                            oPrintStep.fireProcessed();
                                        }
                                    }
                                };
                                _fnCreateRows();
                            };

                            // Start!
                            _fnCreatePanels();
                        },

                        /**
                         * Returns a reference to the 'machineOptionTableRenderLayout' association
                         * 
                         * @returns {sap.ui.core.Control} the control (layout) into which the all machine option code panels have to be rendered.
                         */
                        _getMachineOptionTableRenderLayout : function() {
                            return sap.ui.getCore().byId(this.getMachineOptionTableRenderLayout());
                        },

                        /**
                         * Returns an HTML string for a row of the specified machine option code.
                         * 
                         * @param {object}
                         *            oCode The machine option code
                         */
                        _getRowHTML : function(oCode) {
                            var sTdMachineOptionCode = "<td>" + oCode.MachineOptionCode + "</td>";
                            var sTdDescription = "<td>" + oCode.Description + "</td>";
                            var sTdLift = "<td class='jdUiEidPrintTableQtyCell'>"
                                    + jd.ui.eid.common.formatter.NumberFormatter.formatFloatTo2DigitFractionNumber(oCode.Lift) + "</td>";
                            var sTdTakeRate = "<td class='jdUiEidPrintTableQtyCell'>"
                                    + jd.ui.eid.common.formatter.NumberFormatter.formatPercentageWithSign(oCode.OptionTakeRate) + "</td>";
                            return "<tr>" + sTdMachineOptionCode + sTdDescription + sTdLift + sTdTakeRate + "</tr>";

                            jd.ui.eid.common.formatter.NumberFormatter.formatPercentageWithSign
                        },

                        /**
                         * Creates and returns a new table root node (jQuery object) with \<thead\> already prepared and with an emtpy \<tbody\>
                         * 
                         * @returns {object} jQuery object representing a node to be used as the table's root
                         */
                        _createTableRootNode : function() {
                            var $tableRoot = $("<table/>").addClass("jdUiEidPrintTable");
                            var $headerRow = $("<thead><tr/></thead>");
                            var aHeaders = [jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_CODE"),
                                    jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_DESCRIPTION"),
                                    jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_LIFT"),
                                    jd.ui.eid.common.I18NHelper.getText("MACHINE_OPTION_CODE_TABLE_COL_TAKE_RATE")];
                            $.each(aHeaders, function(i, sHeader) {
                                $headerRow.find("tr").append($("<th>" + sHeader + "</th>"));
                            });
                            $tableRoot.append($headerRow);
                            $tableRoot.append("<tbody/>");
                            return $tableRoot;
                        }

                    });
})();