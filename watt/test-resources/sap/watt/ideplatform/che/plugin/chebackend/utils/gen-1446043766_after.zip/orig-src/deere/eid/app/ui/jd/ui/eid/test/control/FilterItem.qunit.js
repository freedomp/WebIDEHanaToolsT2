(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.FilterItem");

    var oFilterItem = null;

    module("jd.ui.eid.control.FilterItem", {
        setup : function() {
            oFilterItem = new jd.ui.eid.control.FilterItem();
        },
        teardown : function() {
            oFilterItem = null;
        }
    });

    test("clear() should call the hook method _clear().", function() {
        var spy = sinon.spy(oFilterItem, "_clear");

        // Initial assertions
        ok(!spy.called);

        // Execute the business logic
        oFilterItem.clear();

        // Final assertions
        ok(spy.calledOnce);
    });

})();