jQuery.sap.declare("nw.epm.refapps.products.manage.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.messages");

sap.ca.scfld.md.ConfigurationBase.extend("nw.epm.refapps.products.manage.Configuration", {
    oServiceParams : {
        serviceList : [ {
            name : nw.epm.refapps.products.manage.Component.getMetadata().getConfig().serviceConfig.name,
            masterCollection : "Products",
            serviceUrl : nw.epm.refapps.products.manage.Component.getMetadata().getConfig().serviceConfig.serviceUrl,
            sDefaultBindingMode : sap.ui.model.BindingMode.TwoWay,
            isDefault : true,
            mockedDataSource : "/nw.epm.refapps.products.manage/model/metadata.xml",
            useBatch : true,
            useV2ODataModel : true,
            fRequestFailed : nw.epm.refapps.lib.reuse.util.messages.showErrorMessage
        } ]
    },

    getServiceParams : function() {
        return this.oServiceParams;
    },

    getAppConfig : function() {
        return this.oAppConfig;
    },

    getServiceList : function() {
        return this.oServiceParams.serviceList;
    },

    getMasterKeyAttributes : function() {
        return [ "Id" ];
    },

    setApplicationFacade : function(oApplicationFacade) {
        nw.epm.refapps.products.manage.ApplicationFacade = oApplicationFacade;
    },

    // The list selections in the multiselect list mode will not removed by scaffolding automatically
    keepMultiSelection : function() {
        return true;
    }
});