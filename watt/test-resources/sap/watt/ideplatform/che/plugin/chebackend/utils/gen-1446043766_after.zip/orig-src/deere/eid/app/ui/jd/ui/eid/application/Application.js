(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.common.URLHandler");

    /**
     * Constructor for a new Application.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>root : string (default: '') the id of the HTML element where the root content should be placed at.</li>
     * <li>parameters : object (default: null) the parameters passed to the application at launch.</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>rootContent : sap.ui.core.Control the control that should be displayed as root content.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * <p>
     * The application class provides a singleton of the application that is currently running. The application needs to be launched (see method
     * {@link #.launch}) with a set of parameters.
     * </p>
     * <p>
     * The following parameters can be provided:
     * <ul>
     * <li>eidRootPath : string the root path of the application.</li>
     * <li>getRootContent : function a function that returns the root content (e.g. shell view).</li>
     * <li>notificationCenter : object configuration object for the application's notification center.</li>
     * <li>notificationCenter.alertTitle : string the default title of alert notifications.</li>
     * <li>notificationCenter.confirmationTitle : string the default title of confirmation notifications.</li>
     * <li>notificationCenter.successTitle : string the default title of success notifications.</li>
     * <li>onBeforeDisplayRoot : function (optional) the function executed before the root control is placed in the DOM.</li>
     * <li>onBeforeExit : function (optional) the function executed upon the beforeunload event.</li>
     * <li>onExit : function (optional) the function executed upon the unload event.</li>
     * <li>root : string the id of the HTML element where the root content should be placed at.</li>
     * <li>serverUrl : string the URL to the folder of the application (needs to end with '/').</li>
     * <li>serviceFacades : object the map of service facades, which will be accessible via method {@link #.getServiceFacade}.</li>
     * <li>useTestData : boolean true if the service facades should all access local test files of the <code>asset/data</code> folder, false to
     * access the web services.</li>
     * </ul>
     * </p>
     * <p>
     * The following parameters can be overruled when passed as URL parameters (see method {@link #._getWhitelistedUrlParameters}):
     * <ul>
     * <li>useTestData</li>
     * </ul>
     * </p>
     * <p>
     * The application initializes three different global models:
     * <ul>
     * <li>{@link jd.ui.eid.model.EidModel} : the main data model (no model name).</li>
     * <li>i18n : the resource model for text keys.</li>
     * <li>img : the resource model for images.</li>
     * </ul>
     * </p>
     * <p>
     * The application responds to the following event bus events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#DataLossManager::dataLossPending} - Displays a popup to ask the user whether to save or discard the data.</li>
     * <li>{@link jd.ui.eid.Events#JdUiEidCore::requireFailed} - Most likely due to a session timeout. Displays a popup to the user to open the login
     * dialog in a new window.</li>
     * </ul>
     * </p>
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.application.Application
     */

    sap.ui.base.ManagedObject.extend("jd.ui.eid.application.Application", /** @lends jd.ui.eid.application.Application */
    {
        metadata : {
            properties : {
                root : {
                    type : "string",
                    defaultValue : ""
                },
                parameters : {
                    type : "object",
                    defaultValue : null
                }
            },

            associations : {
                "rootContent" : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            }
        },

        /**
         * Internal cache for service facades, so that only one instance of each type needs to be created.
         * 
         * @private
         */
        _serviceFacades : {},

        /**
         * Internal reference to the notification center, so that only one instance needs to be created.
         * 
         * @private
         */
        _notificationCenter : null,

        _sXSRFToken : null,

        /**
         * Initializes application object.
         */
        init : function() {
            var that = this;
            // Let's register to the global ajax error event so that we can e.g. respond when the session has timed out or a file cannot be loaded.
            $(document).ajaxError($.proxy(this.handleAjaxError, this));
            $(window).on('unload', function() {
                that.destroy(); // Destroy the application
            });

            // Register for global events
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe("DataLossManager", "dataLossPending", this.handleDataLossPending, this);

            // Initialize parameters
            this.setParameters({});
        },

        /**
         * Clean up before application is destroyed.
         */
        destroy : function() {
            // Detach events
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe("DataLossManager", "dataLossPending", this.handleDataLossPending, this);
            $(document).off("ajaxError");

            // Destroy managed objects
            var oRootControl = sap.ui.getCore().byId(this.getRootContent());
            if (oRootControl) {
                oRootControl.destroy();
            }
            if (this._notificationCenter) {
                this._notificationCenter.destroy();
            }
            if (jd.ui.eid.common.DataLossManager) {
                // if DLM was ever required
                jd.ui.eid.common.DataLossManager.getRootInstance().destroy();
            }

            // Set properties/variables to null
            this._serviceFacades = null;
            instance = null;
        },

        /**
         * Launches the application with the given parameters.
         * 
         * @param {object}
         *            oParameters the parameter map for the application.
         */
        launch : function(oParameters) {
            // Merge parameters with the whitelisted ones from the url.
            var oWhitelistedUrlParameter = this._getWhitelistedUrlParameters();
            oParameters = jQuery.extend(true, oParameters, oWhitelistedUrlParameter);
            this.setParameters(oParameters);

            // Register callbacks
            if (oParameters.onBeforeExit) {
                jQuery(window).on('beforeunload', jQuery.proxy(oParameters.onBeforeExit, this));

            }
            if (oParameters.dataLossTextKey) {
                jQuery(window).on('beforeunload', jQuery.proxy(function() {
                    if (jd.ui.eid.common.DataLossManager.getRootInstance().isDirty()) {
                        return jd.ui.eid.common.I18NHelper.getText(oParameters.dataLossTextKey);
                    }
                }, this));
            }

            if (oParameters.onExit) {
                jQuery(window).on('unload', jQuery.proxy(oParameters.onExit, this));
            }

            // Init models
            this._initModels();

            if (oParameters.onBeforeDisplayRoot) {
                oParameters.onBeforeDisplayRoot();
            }

            // Get XSRF token from server before displaying the content.
            var that = this;
            this._retrieveXSRFToken(function(sXSRFToken) {
                // success callback
                that._sXSRFToken = sXSRFToken;

                // Continue displaying the root view
                // Set root content
                that.setRoot(oParameters.root);
                that.setRootContent(oParameters.getRootContent());
                var rootContent = sap.ui.getCore().byId(that.getRootContent());
                rootContent.addEventDelegate({
                    // this needs to wait till the application is rendered, else a popup cannot be displayed due to lacking root
                    onAfterRendering : function() {
                        // Point application to evidence package if corresponding parameter is present
                        jd.ui.eid.common.URLHandler.EvidencePackage.handleURLParameter();
                    }
                });

                rootContent.placeAt(that.getRoot(), "only");
            }, function() {
                // error callback
                document.writeln("Failed loading XSRF token. Please contact your system administrator.");
            });

        },

        /**
         * Initialize models based on parameter settings.
         * 
         * @private
         */
        _initModels : function() {
            // I18n model
            var oI18nModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl : "jd/ui/eid/asset/text/i18n.properties"
            });
            sap.ui.getCore().setModel(oI18nModel, 'i18n');

            // Data model
            jd.ui.eid.require("jd.ui.eid.model.EidModel");
            var oModel = new jd.ui.eid.model.EidModel();
            sap.ui.getCore().setModel(oModel);
        },

        /**
         * Retrieves an XSRF token from the server using the <code>GetToken.xsjs</code> service.
         * 
         * @param {function}
         *            fnSuccess success callback invoked if retrieval was successful. The token is passed to that callback as the first parameter.
         * @param {function}
         *            fnError error callback invoked if retrieval was unsuccessful.
         */
        _retrieveXSRFToken : function(fnSuccess, fnError) {
            if (!this.getParameters().useTestData) {
                $.sap.log.debug("Fetching XSRF token");
                $.ajax({
                    url : this.getParameters().serverUrl + "xs/util/GetToken.xsjs",
                    type : "GET",
                    beforeSend : function(xhr) {
                        xhr.setRequestHeader("X-CSRF-Token", "Fetch");
                    },
                    success : function(data, textStatus, XMLHttpRequest) {
                        $.sap.log.debug("XSRF token retrieved.")
                        var sToken = XMLHttpRequest.getResponseHeader("X-CSRF-Token");
                        if (fnSuccess) {
                            fnSuccess(sToken);
                        }
                    },
                    error : fnError
                });
            } else {
                if (fnSuccess) {
                    fnSuccess("DummyToken");
                }
            }
        },

        /**
         * Get url parameter with the given parameter name from the given url.
         * 
         * @param {string}
         *            sParam the name of the parameter.
         * @param {string}
         *            [sUrl] the url. If no url is provided, the method will try to read the current url.
         * @returns {string|null} the value of the parameter if provided, null otherwise.
         */
        _getUrlParameter : function(sParam, sUrl) {
            if (!sUrl) {
                sUrl = window.location.href;
            }

            var results = new RegExp('[\\?&]' + sParam + '=([^&#]*)').exec(sUrl);
            if (results == null) {
                return null;
            } else {
                return results[1] || 0;
            }
        },

        /**
         * Get whitelisted url parameters, which might influence the behavior of the application.
         * 
         * The following parameters are whitelisted:
         * <ul>
         * <li>useTestData : boolean</li>
         * </ul>
         * 
         * @returns {object} map of key-value pairs
         */
        _getWhitelistedUrlParameters : function() {
            var oParams = {};

            var bUseTestData = this._getUrlParameter("useTestData");
            if (bUseTestData !== null) {
                oParams["useTestData"] = bUseTestData == 'X' || bUseTestData == 'true';
            }
            var bApplyPersonalization = this._getUrlParameter("applyPersonalization");
            if (bApplyPersonalization !== null) {
                oParams["applyPersonalization"] = bApplyPersonalization == 'X' || bApplyPersonalization == 'true';
            }

            return oParams;
        },

        /**
         * Get the service facade for the given facade key.
         * 
         * @param {string}
         *            sKey the key of the service facade.
         * @returns {jd.ui.eid.service.BaseServiceFacade} the requested service facade or undefined.
         */
        getServiceFacade : function(sKey) {
            var oModel = sap.ui.getCore().getModel();
            var bUseTestData = this.getParameters().useTestData;
            var sServerUrl = this.getParameters().serverUrl;
            var sEidRootPath = this.getParameters().eidRootPath;
            var sDataFolderPath = sEidRootPath + "asset/data/";

            if (!this._serviceFacades[sKey]) {
                if (this.getParameters().serviceFacades[sKey]) {
                    var sClassName = this.getParameters().serviceFacades[sKey];
                    jd.ui.eid.require(sClassName);
                    var oObject = jQuery.sap.getObject(sClassName);
                    this._serviceFacades[sKey] = new oObject(sServerUrl, sDataFolderPath, oModel, bUseTestData, this._sXSRFToken);
                }
            }
            return this._serviceFacades[sKey];
        },

        /**
         * Get the notification center (central instance).
         * 
         * @returns {jd.ui.eid.common.NotificationCenter}
         */
        getNotificationCenter : function() {
            if (!this._notificationCenter) {
                // Create notification center from settings and link notification bar.
                jd.ui.eid.require("jd.ui.eid.common.NotificationCenter");
                var mNotificationCenterParameters = this.getParameters().notificationCenter || {};
                this._notificationCenter = new jd.ui.eid.common.NotificationCenter({
                    alertTitle : mNotificationCenterParameters.alertTitle,
                    confirmationTitle : mNotificationCenterParameters.confirmationTitle,
                    successTitle : mNotificationCenterParameters.successTitle
                });
                // As the notification center is standalone managed object, it cannot retrieve the models from e.g. its parent, so we need to assign
                // all relevant models
                this._notificationCenter.setModel(sap.ui.getCore().getModel());
                this._notificationCenter.setModel(sap.ui.getCore().getModel('i18n'), 'i18n');
            }

            return this._notificationCenter;
        },

        /**
         * Displays a confirmation dialog to the user to either save or discard the unsaved data before continuing.
         * 
         * @param {string}
         *            sChannelId the channel id
         * @param {string}
         *            sEventId the event name
         * @param {object}
         *            mData the data passed along with the event.
         * @see jd.ui.eid.Events#DataLossManager::dataLossPending
         */
        handleDataLossPending : function(sChannelId, sEventId, oData) {
            var oDataLossManager = oData.oDataLossManager;
            this.getNotificationCenter().confirmDataLoss(null, function(iButtonIndex) {
                if (iButtonIndex == 0) {
                    oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.SaveAndContinue);
                } else if (iButtonIndex == 1) {
                    oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.ContinueWithoutSaving);
                } else {
                    oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.Cancel);
                }
            });
        },

        /**
         * Handles all ajaxError events which could e.g. occor when a file is not found (e.g. *_en.properties), when a file cannot be loaded (e.g.
         * invalid XML in fragment or view) or when the session has timed out (e.g. request returns HANA login page instead of the requested file).
         * 
         * @see jQuery#ajaxError
         * @param {object}
         *            event
         * @param {object}
         *            jqXHR
         * @param {object}
         *            ajaxSettings
         * @param {string}
         *            thrownError
         */
        handleAjaxError : function(event, jqXHR, ajaxSettings, thrownError) {
            if (jqXHR.status === 404 /* Not found */&& ($.sap.endsWith(ajaxSettings.url, ".js") || $.sap.endsWith(ajaxSettings.url, ".xml"))) {
                // read: if a JS or XML file was requested but not found. This excludes e.g. *.properties files.
                // If this really happened, then we have a problem. This should not have happened.
                $.sap.log.fatal("Requested file " + ajaxSettings.url + " but file was not found on the server.");
            } else if (jqXHR.responseText && typeof jqXHR.responseText == 'string' && jqXHR.responseText.indexOf("login") > -1) {
                // read: if the response text contains the word 'login', then it's most likely a session timeout.
                this.getNotificationCenter().alert(jd.ui.eid.common.I18NHelper.getText("MSG_MSE_REQUEST_FAILED_DUE_TO_TIMEOUT"), function() {
                    // Callback, send the user to the login screen.
                    // Generate random url to send the user to the login screen.
                    var sURL = window.location.href;
                    var sKey = "jd-ui-eid-forcelogin";
                    var sValue = FAKE_TODAY().getTime();
                    if (sURL.indexOf(sKey) > -1) {
                        // the key already exists, so let's replace it
                        sURL = sURL.replace(new RegExp(sKey + "=([0-9^&]+)", "g"), sKey + "=" + sValue);
                    } else if (sURL.indexOf("?") > -1) {
                        // There are already parameters in the URL, so we attach the timestamp as additional parameter
                        sURL += "&" + sKey + "=" + sValue;
                    } else {
                        // There aren't any parameters yet, so we add the first one
                        sURL += "?" + sKey + "=" + sValue;
                    }
                    window.location.href = sURL;

                }, jd.ui.eid.common.I18NHelper.getText("MSG_HED_REQUEST_FAILED_DUE_TO_TIMEOUT"));
            } else {
                $.sap.log.warning("Requested file " + ajaxSettings.url + " but request failed.");
            }
        },

    });

    /* Static Methods */

    var instance = null;

    /**
     * Get the singleton instance of the application.
     * 
     * @returns {jd.ui.eid.application.Application} the singleton instance of the application.
     */
    jd.ui.eid.application.Application.getInstance = function() {
        if (instance == null) {
            instance = new jd.ui.eid.application.Application();
            // Hide the constructor so the returned objected can't be new'd...
            instance.constructor = null;
        }
        return instance;
    };
})();