(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");

    /**
     * Constructor for a new DateRangeToolPopupValueListItemDelegate.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>fragmentId : string (default: "") The ID of the toolpopup fragement </li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>opener : jd.ui.eid.control.ValueListItem The valueListItem that opens the toolPopup.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The DateRangeToolPopupValueListItemDelegate contains all necessary handlers of the date range toolpopup with a valueListItem as an
     *        opener.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate", /** @lends jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate */
    {

        metadata : {
            properties : {
                fragmentId : "string"
            },
            associations : {
                opener : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                }
            }
        },

        /**
         * Get the valueListItem that opens the toolPopup
         * 
         * @return {jd.ui.eid.control.ValueListItem} the opener object.
         */
        _getOpener : function() {
            return sap.ui.getCore().byId(this.getAssociation("opener"));
        },

        /**
         * Handles the change event of the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupRangeChanged : function(oEvent) {
            this._validateDateRangeToolPopupRange();
        },

        /**
         * Validates the date range toolpopup
         * 
         * @returns {boolean} True if valid, False otherwise.
         */
        _validateDateRangeToolPopupRange : function() {
            var sFragmentId = this.getFragmentId();
            var oFromDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "from");
            var oToDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "to");

            var bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange(oFromDatePicker.getYyyymmdd(), oToDatePicker.getYyyymmdd());

            if (!bValid) {
                // Create a callout to indicate an error with the
                // from-datepicker
                var oFromDatePickerText = new sap.ui.commons.TextView({
                    text : "{i18n>DATE_RANGE_TOL_INVALID_START_DATE}"
                }).addStyleClass("jdUiTv");
                var oFromCallout = new sap.ui.commons.Callout({
                    content : oFromDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the from-datepicker
                oFromDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oFromDatePicker.setTooltip(oFromCallout);

                // Create a callout to indicate an error with the
                // to-datepicker
                var oToDatePickerText = new sap.ui.commons.TextView({
                    text : "{i18n>DATE_RANGE_TOL_INVALID_END_STARTE}"
                }).addStyleClass("jdUiTv");
                var oToCallout = new sap.ui.commons.Callout({
                    content : oToDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the to-datepicker
                oToDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oToDatePicker.setTooltip(oToCallout);
            } else {
                // Set the datepickers as valid
                oFromDatePicker.setValueState(sap.ui.core.ValueState.None);
                oToDatePicker.setValueState(sap.ui.core.ValueState.None);

                // Remove the error callouts
                oFromDatePicker.setTooltip(null);
                oToDatePicker.setTooltip(null);
            }

            return bValid;
        },

        /**
         * Create the open event handler of the custom date range item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupOpen : function(oEvent) {
            var sFragmentId = this.getFragmentId();
            var oFromDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "from");
            var oToDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "to");

            // Set datepicker values
            oFromDatePicker.setYyyymmdd(this._getOpener().getValue().from);
            oToDatePicker.setYyyymmdd(this._getOpener().getValue().to);
            this._validateDateRangeToolPopupRange();

            // Select list item
            this._getOpener().setSelected(true);
        },

        /**
         * Handles the event of the "submit button pressed" / "enter pressed"-event at the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupSubmit : function(oEvent) {
            if (this._validateDateRangeToolPopupRange()) {
                var sFragmentId = this.getFragmentId();
                var oFromDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "from");
                var oToDatePicker = sap.ui.core.Fragment.byId(sFragmentId, "to");
                var oDateRangeToolPopup = this._getOpener().getToolPopup();
                this._getOpener().changeValue({
                    from : oFromDatePicker.getYyyymmdd(),
                    to : oToDatePicker.getYyyymmdd()
                });
                oDateRangeToolPopup.close(0);
            }
        },

        /**
         * Handles the cancel event of the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupCancel : function(oEvent) {
            var oDateRangeToolPopup = this._getOpener().getToolPopup();
            oDateRangeToolPopup.close(0);
        }
    });
})();