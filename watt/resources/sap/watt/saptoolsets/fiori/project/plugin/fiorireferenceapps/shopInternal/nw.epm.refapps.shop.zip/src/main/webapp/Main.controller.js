sap.ui.controller("nw.epm.refapps.shop.Main", {
    onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");
        if (!sap.ui.Device.support.touch) {
            this.getView().addStyleClass("sapUiSizeCompact");
        }
        sap.ca.scfld.md.Startup.init("nw.epm.refapps.shop", this);
    }
});