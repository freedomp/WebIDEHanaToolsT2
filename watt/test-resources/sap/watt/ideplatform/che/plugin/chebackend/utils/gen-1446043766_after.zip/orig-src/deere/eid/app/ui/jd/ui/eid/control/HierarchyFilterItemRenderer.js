(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.HierarchyFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * @class Default renderer for control jd.ui.eid.control.HierarchyFilterItem.
     * 
     * @name jd.ui.eid.control.HierarchyFilterItemRenderer
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     */
    jd.ui.eid.control.HierarchyFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.HierarchyFilterItemRenderer,
            jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     */
    jd.ui.eid.control.HierarchyFilterItemRenderer._renderContent = function(oRm, oControl) {
        oRm.renderControl(oControl.getAggregation("_selectionDisplay"));
    };

    /**
     * @see jd.ui.eid.control.FilterItemRenderer
     */
    jd.ui.eid.control.HierarchyFilterItemRenderer.renderCollapseIcon = function(oRm,
            oControl) {
        // only show collapse icon if not readonly
        if (!oControl.getReadOnly()) {
            jd.ui.eid.control.FilterItemRenderer.renderCollapseIcon.apply(this,
                    arguments);
        }
    };

    /**
     * @see jd.ui.eid.control.FilterItemRenderer
     */
    jd.ui.eid.control.HierarchyFilterItemRenderer.renderHeaderItems = function(oRm, oControl) {
        // only show collapse icon if not readonly
        if (!oControl.getReadOnly()) {
            jd.ui.eid.control.FilterItemRenderer.renderHeaderItems.apply(this, arguments
                    );
        }

    };
})();