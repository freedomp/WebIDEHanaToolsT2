jQuery.sap.declare("nw.epm.refapps.lib.reuse.test.ModulePathForTests");

nw.epm.refapps.lib.reuse.test.ModulePathForTests = {
    isInRiverRde : function() {
        var oUri = URI(window.location.href);
        return (oUri.path().indexOf("/src/test/uilib/qunit") > -1);
    },
    getPathToRoot : function() {
        /*
         * Calculate how many ../ are needed to reach a path with only one
         * segment This would either be /src for RDE or /<App Name> for Tomcat
         */
        var iGoUp = URI(window.location.href).segment().length - 2, sRel = "", i;
        for (i = 0; i < iGoUp; i++) {
            sRel += "../";
        }
        // check whether running in RDE -> i.e. path contains /src/test/qunit
        // Tomcat resources are under /<App name>
        // RDE => Resources are under /src/main/webapp
        if (this.isInRiverRde()) {
            sRel = sRel + "main/webapp";
        }
        return sRel;
    },
    registerModulePathForTests : function(sComponent) {
        var sRel = this.getPathToRoot();
        jQuery.sap.registerModulePath(sComponent, sRel);
    }
};