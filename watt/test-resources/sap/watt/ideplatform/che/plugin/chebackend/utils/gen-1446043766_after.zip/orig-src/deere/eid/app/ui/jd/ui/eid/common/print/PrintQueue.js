(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.PrintQueue");
    jQuery.sap.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new PrintQueue.
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>steps : jd.ui.eid.common.print.PrintStep[] the steps of the queue.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The PrintQueue is a simple queue that consists of one or many {@link jd.ui.eid.common.print.PrintStep} objects which are processed one
     *        after another. When the queue is processed, the <code>processed</code> event is fired.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.PrintQueue
     */
    jd.ui.eid.common.print.PrintStep.extend("jd.ui.eid.common.print.PrintQueue", /** @lends jd.ui.eid.common.print.PrintQueue */
    {
        metadata : {
            aggregations : {
                steps : {
                    type : "jd.ui.eid.common.print.PrintStep",
                    multiple : true,
                    singularName : "step"
                }
            }
        },

        /**
         * Initialize the queue.
         */
        init : function() {
            jd.ui.eid.common.print.PrintStep.prototype.init.apply(this, arguments);
        },

        /**
         * Handler for processed event of a step of the queue. Triggers the processing of the subsequent step if available.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the print step.
         */
        _handleStepProcessed : function(oEvent) {
            $.sap.log.debug("Step processed", null, this._sLogComponent);
            var oStep = oEvent.getSource();
            var iIndex = this.indexOfStep(oStep);
            var oSubsequentStep = this.getSteps()[iIndex + 1];
            this._processStepOrComplete(oSubsequentStep);
        },

        /**
         * Internal utility method to trigger the processing of the step if provided or if <code>null</code> to fire the <code>processed</code>
         * event of the queue.
         * 
         * @param {jd.ui.eid.common.print.PrintStep}
         *            [oStep] the print step to process.
         */
        _processStepOrComplete : function(oStep) {
            if (oStep) {
                oStep.process();
            } else {
                this._iState = jd.ui.eid.common.print.PrintStep.State.Completed;
                this.fireProcessed();
            }
        },

        /**
         * Adds a a print step to the queue.
         * 
         * @param {jd.ui.eid.common.print.PrintStep}
         *            oPrintStep the print step to add to the queue.
         * @returns {jd.ui.eid.common.print.PrintQueue} <code>this</code> for method chaining.
         */
        queue : function(oPrintStep) {
            oPrintStep.attachProcessed(this._handleStepProcessed, this);
            this.addStep(oPrintStep);
            return this;
        },

        /**
         * Internal hook method for starting to process the queue.
         */
        _process : function() {
            $.sap.log.debug("Processing queue " + this.getId(), null, this._sLogComponent);
            this._iState = jd.ui.eid.common.print.PrintStep.State.Processing;
            var aSteps = this.getSteps();
            var oFirstStep = aSteps[0];
            this._processStepOrComplete(oFirstStep);
        }
    });
})();