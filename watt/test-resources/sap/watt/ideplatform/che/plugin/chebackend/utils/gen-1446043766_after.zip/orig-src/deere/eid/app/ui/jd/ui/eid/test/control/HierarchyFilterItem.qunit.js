(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.HierarchyFilterItem");

    var oFilterItem = null;
    var oSetDefaultSelection = {
        "root1" : {
            "subitem1" : {}
        }
    };
    var oSetRootItem1 = null;

    module("jd.ui.eid.control.HierarchyFilterItem", {
        setup : function() {
            oSetRootItem1 = new sap.ui.ux3.ExactAttribute({
                text : "root1",
                attributes : [new sap.ui.ux3.ExactAttribute({
                    text : "subitem1"
                })]
            });
            oFilterItem = new jd.ui.eid.control.HierarchyFilterItem({
                items : [oSetRootItem1]
            });
            oFilterItem.placeAt("content");
            var oFilterItemOnAfterRendering = oFilterItem.onAfterRendering;
            oFilterItem.onAfterRendering = function() {
                oFilterItemOnAfterRendering.apply(this, arguments);
                start();
            };
            stop();
        },
        teardown : function() {
            fnTogglePopup();
            oFilterItem.destroy();
            oFilterItem = null;
            oSetRootItem1 = null;
        }
    });

    /**
     * Helper to toggle popup opne/closed state
     */
    var fnTogglePopup = function() {
        var oPopup = oFilterItem.getAggregation("_popup");
        if (oPopup.isOpen()) {
            oPopup.close();
        } else {
            oPopup.open();
        }
    };

    test("clear() should clear the selection property.", function() {
        assert.equal(oFilterItem.oPopup.isOpen(), false);

        fnTogglePopup();
        assert.equal(oFilterItem.oPopup.isOpen(), true);

        // set selection property
        var oSelectionOnlyRootItem1 = {};
        oSelectionOnlyRootItem1[oSetRootItem1.getText()] = {};
        oFilterItem.setSelection(oSelectionOnlyRootItem1);
        var oSelection = oFilterItem.getSelection();
        // check if selection was set
        deepEqual(oSelection, oSelectionOnlyRootItem1, "getSelection should container root item after setSelection");

        // test clear()
        oFilterItem.clear();
        var oSelection = oFilterItem.getSelection();

        deepEqual(oSelection, {}, "`selection` should be empty after clear()");
    });
})();
