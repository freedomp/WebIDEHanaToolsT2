(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");

    /**
     * Constructor for a new DateRangeToolPopupModelDelegate.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>modelPathFrom : string (default : "") The model path the from value in JSON date format should be written to/read from.</li>
     * <li>modelPathTo : string (default : "") The model path the to value in JSON date format should be written to/read from.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>modelUpdated : fired when the model has been updated.
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The DateRangeToolPopupModelDelegate contains handles a <code>jd.ui.eid.fragment.filter.DateRangeToolPopup</code> fragment and writes
     *        the data back to the model paths specified in the model set via {@link #.setModel}.
     * @extends jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate
     * @name jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate
     */
    jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate.extend("jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate",
    /** @lends jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate */
    {

        metadata : {
            properties : {
                modelPathFrom : {
                    type : "string",
                    defaultValue : ''
                },
                modelPathTo : {
                    type : "string",
                    defaultValue : ''
                }
            },
            events : {
                modelUpdated : {}
            }
        },

        /**
         * Gets the from value from the model.
         * 
         * @returns {string} the from value.
         */
        _getFrom : function() {
            return this.getModel().getProperty(this.getModelPathFrom());
        },

        /**
         * Gets the to value from the model.
         * 
         * @returns {string} the to value.
         */
        _getTo : function() {
            return this.getModel().getProperty(this.getModelPathTo());
        },

        /**
         * @see jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate#_isSourceEmpty
         */
        _isSourceEmpty : function() {
            if (!(this._getFrom() && this._getTo())) {
                return true;
            }
            return false;
        },

        /**
         * @see jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate#_populateToolPopupValues
         */
        _populateToolPopupValues : function() {
            this._getFromDatePicker().setYyyymmdd(jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(this._getFrom()));
            this._getToDatePicker().setYyyymmdd(jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(this._getTo()));
        },

        /**
         * @see jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate#_updateSource
         */
        _updateSource : function() {
            var sFrom = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(this._getFromDatePicker().getYyyymmdd()) || "";
            var sTo = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(this._getToDatePicker().getYyyymmdd()) || "";
            this.getModel().setProperty(this.getModelPathFrom(), sFrom);
            this.getModel().setProperty(this.getModelPathTo(), sTo);
            this.fireModelUpdated();
        }
    });
})();