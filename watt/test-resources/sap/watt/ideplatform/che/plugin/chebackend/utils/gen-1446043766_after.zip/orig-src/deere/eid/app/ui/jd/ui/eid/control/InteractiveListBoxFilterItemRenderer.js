(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.InteractiveListBoxFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.ListBoxFilterItemRenderer");

    /**
     * @class Default renderer for control {@link jd.ui.eid.control.InteractiveListBoxFilterItem}.
     * @extends jd.ui.eid.control.ListBoxFilterItemRenderer
     * @static
     * @name jd.ui.eid.control.InteractiveListBoxFilterItemRenderer
     */
    jd.ui.eid.control.InteractiveListBoxFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.InteractiveListBoxFilterItemRenderer, jd.ui.eid.control.ListBoxFilterItemRenderer);

    /**
     * @see jd.ui.eid.control.FilterItemRenderer#renderHeaderItems
     */
    jd.ui.eid.control.InteractiveListBoxFilterItemRenderer.renderHeaderItems = function(oRm, oControl) {
        oRm.write("<div");
        oRm.addClass("jdUiEidFilterItemHeaderItems");
        oRm.writeClasses();
        oRm.write(">");

        oRm.renderControl(oControl.getAggregation("batchAddIcon"));
        oRm.renderControl(oControl.getAggregation("addIcon"));
        oRm.renderControl(oControl.getAggregation("toggleSelectionIcon"));

        oRm.renderControl(oControl.getAggregation("_clear").addStyleClass('jdUiEidFilterItemClear'));

        oRm.write("</div>");
    };

})();