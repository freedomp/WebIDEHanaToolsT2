var cds = require('cds');
var winston = require('winston');
var async = require('async');

winston.level = process.env.winston_level || 'error';

var BOOK;
var ADDRESS;

function init(appCallback) {
    if (BOOK && ADDRESS) {
        appCallback();
    } else {
        async.waterfall([
            function (callback) {
                cds.importEntities([ {
                        $entity: "com.sap.xs2.samples::AddressBook.Book",
                        $fields: { // for convenience we add an association from books to addresses
                            addresses: {
                                $association: {
                                    $entity: "com.sap.xs2.samples::AddressBook.Address",
                                    $viaBacklink: "book"
                                }
                            }
                        }
                    },
                    {$entity: "com.sap.xs2.samples::AddressBook.Address"}
                ], callback);
            },
            function (entities, callback) {
                BOOK = entities["com.sap.xs2.samples::AddressBook.Book"];
                ADDRESS = entities["com.sap.xs2.samples::AddressBook.Address"];
                callback(null);
            }
        ], function (error) {
            appCallback(error);
        });
    }
}

function adressbookManager(dbConnection, appCallback) {
    //use database connection from hanacf pool
    cds.setConnection(dbConnection);
    async.waterfall([
        init,
        function queryBooksFromDatabase(asyncCallback) {
            BOOK.$query()
                .$project({
                    $all: true,
                    addresses: {id: true, first_name: true, last_name: true, phone: true, city: true}
                })
                .$execute({$factorized: true}, asyncCallback);
        }, function transformArrayToObject(databaseResult, asyncCallback) {
            asyncCallback(null, databaseResult.reduce(function (result, obj) {
                result[obj.id] = obj;
                delete obj.id;
                if (obj.addresses) {
                    obj.addresses.forEach(function (a) {
                        obj[a.id] = a;
                        a.name = a.first_name + " " + a.last_name;
                    });
                    delete obj.addresses;
                }
                return result;
            }, {name: "root"}));
        }
    ], function (error, result) {
        appCallback(error, result);
    });
}
module.exports = adressbookManager;
