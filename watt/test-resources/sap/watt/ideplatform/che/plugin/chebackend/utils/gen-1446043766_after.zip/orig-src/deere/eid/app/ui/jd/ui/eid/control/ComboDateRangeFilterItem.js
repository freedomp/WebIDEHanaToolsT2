(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ComboDateRangeFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.NotificationCenter");

    /**
     * i18n keys: * DATE_RANGE_FORMAT_TXT_RANGE
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.ComboDateRangeFilterItem", /** @lends jd.ui.eid.control.ComboDateRangeFilterItem */
    {
        metadata : {
            properties : {
                defaultCustomDateRangeLabel : {
                    type : "string",
                    defaultValue : ""
                },
                _customDateRangeFrom : {
                    type : "string",
                    defaultValue : ""
                },
                _customDateRangeTo : {
                    type : "string",
                    defaultValue : ""
                }
            },
            aggregations : {
                customDateRangeItem : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                },
                items : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : true,
                    singularName : "item"
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the listbox style class here so that we don't have to do any unnecessary
            // overwrites in
            // the renderer
            this.addStyleClass("jdUiEidListBoxFilterItem");
            this.addStyleClass("jdUiEidDateDistanceFilterItem");
        },

        /*
         * Internal Event Handlers
         */

        /**
         * 
         * Handler of CustomDateRange-valueChanged event: Update the internal state and fire valueChanged event
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeValueChanged : function(oEvent) {
            var oSelection = this.getProperty("selection");
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");

            // Get new dates from custom date range item
            var sFromDate = oCustomDateRangeItem.getValue().from;
            var sToDate = oCustomDateRangeItem.getValue().to;

            // Update internal properties
            this.set_customDateRangeFrom(sFromDate);
            this.set_customDateRangeTo(sToDate);

            // Format new date to JSON string.
            var sFromJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sFromDate);
            var sToJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sToDate);

            // Check whether the values changed
            if (sFromJSONDate != oSelection.Start || sToJSONDate != oSelection.End) {
                this.setSelection({
                    Start : sFromJSONDate,
                    End : sToJSONDate,
                    _Type : "custom"
                });
                this._updateCustomDateRangeItemText();
                this.fireValueChanged();
            }
        },

        /**
         * Updates the visible text of the custom date range ValueListItem control.
         */
        _updateCustomDateRangeItemText : function() {
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
            if (!this.getSelection().Start || !this.getSelection().End) {
                oCustomDateRangeItem.setText(this.getDefaultCustomDateRangeLabel());
            } else {
                var sFrom = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(this.getSelection().Start);
                var sTo = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(this.getSelection().End);
                var sText = jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FORMAT_TXT_RANGE", [sFrom, sTo]);
                oCustomDateRangeItem.setText(sText);
            }
        },

        _dateFormatter : null,

        /**
         * Sets the formatter function to convert a JSON date to a format displayed on the UI.
         * 
         * @param {function}
         *            fnFormatter
         */
        setDateFormatter : function(fnFormatter) {
            this._dateFormatter = fnFormatter;
        },

        /**
         * Formats the JSON date to a formated displayed on the UI.
         * 
         * @param {string}
         *            sJSONDate the date in JSON format
         * @returns {string} formatted date.
         */
        _formatDate : function(sJSONDate) {
            if (typeof this._dateFormatter == 'function') {
                return this._dateFormatter(sJSONDate);
            } else {
                return sJSONDate;
            }
        },

        /**
         * 
         * Handler of CustomDistance-select event: Unmark all items & mark custom distance item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeSelected : function(oEvent) {
            this._clearAllItemSelection();
            this.getAggregation("customDateRangeItem").setSelected(true);
        },

        /**
         * Handler of CustomDateRange-toolPopupCanceled event - Force-refresh the binding to make sure the rendered selection is according to the
         * 'selection' state
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event
         */
        _handleCustomDateRangeToolPopupCanceled : function(oEvent) {
            this.getBinding("selection").refresh(true);
        },

        /**
         * 
         * Select event handler of static ValueListItem: Fire valueChanged event if a static date distance item has been selected
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleItemSelected : function(oEvent) {
            var bNewSelectedState = !oEvent.getSource().getSelected(); // After this click, is this ValueListItem selected?
            // the clicked item
            // oEvent.getSource().setSelected(!bSelected); // Revert the selection of clicked item

            // Check selection state
            var mSelection = {
                Start : "",
                End : ""
            };

            if (bNewSelectedState) {
                var sTodayJSON = jd.ui.eid.common.DateHelper.DateToJSONDate(FAKE_TODAY());
                var mValue = oEvent.getSource().getValue();

                if (mValue.Type == 'today') {
                    mSelection.Start = sTodayJSON;
                    mSelection.End = sTodayJSON;
                } else if (mValue.Type == 'duration' && mValue.Unit == 'day') {
                    // from n days in the past up to today
                    var sDiffDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayJSON, mValue.Duration);
                    mSelection.Start = sDiffDate;
                    mSelection.End = sTodayJSON;
                } else if (mValue.Type == 'duration' && mValue.Unit == 'month') {
                    // Only difference in this 'else if' is that we use subtractMonths instead of subtractDays
                    var sDiffDate = jd.ui.eid.common.DateHelper.subtractMonths(sTodayJSON, mValue.Duration);
                    mSelection.Start = sDiffDate;
                    mSelection.End = sTodayJSON;
                }

                // Update internal state
                mSelection._Type = "static";
                this.setSelection(mSelection);
            } else {
                // Item has been unselected
                this.setSelection({
                    Start : "",
                    End : ""
                });
            }

            this.fireValueChanged();
        },

        /**
         * This function sets the custom distance list item.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oCustomDateRangeItem The custom distance list item.
         * @returns {jd.ui.eid.control.ComboDateRangeFilterItem} This for method chaining.
         */
        setCustomDateRangeItem : function(oCustomDateRangeItem) {
            this.setAggregation("customDateRangeItem", oCustomDateRangeItem);
            oCustomDateRangeItem.attachValueChanged($.proxy(this._handleCustomDateRangeValueChanged, this));
            oCustomDateRangeItem.attachSelect($.proxy(this._handleCustomDateRangeSelected, this));
            oCustomDateRangeItem.attachToolPopupCanceled($.proxy(this._handleCustomDateRangeToolPopupCanceled, this));
            return this;
        },

        /**
         * This function adds the static date distance list item to the items aggregation.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        addItem : function(oItem) {
            oItem.attachSelect($.proxy(this._handleItemSelected, this));
            this.addAggregation("items", oItem);
            return this;
        },

        /**
         * This function inserts another static date distance list item to the items aggregation at a fix position.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @param {int}
         *            iIndex The position in the aggregation.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        insertItem : function(oItem, iIndex) {
            oItem.attachSelect($.proxy(this._handleItemSelected, this));
            this.insertAggregation("items", oItem, iIndex);
            return this;
        },

        /**
         * Deselect all items
         */
        _clearAllItemSelection : function() {
            // Clear selection of custom date range item
            this.getAggregation("customDateRangeItem").setSelected(false);

            // Clear selection of all static items
            var aItems = this.getAggregation("items");
            if (aItems) {
                for ( var i = 0; i < aItems.length; i++) {
                    aItems[i].setSelected(false);
                }
            }
        },

        /*
         * Overridden methods of FilterItem class
         */

        /**
         * @see jd.ui.eid.control.FilterItem#_clear
         */
        _clear : function() {
            var oCurrentSelection = this.getSelection();
            if (oCurrentSelection.Start == "" && oCurrentSelection.End == "") {
                return false;
            } else {
                this._clearAllItemSelection();

                // Reset the custom date range
                var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
                // Check whether the date range popup is open
                if (oCustomDateRangeItem.getToolPopup().isOpen()) {
                    oCustomDateRangeItem.getToolPopup().close(0);
                }
                // Reset the date range item text
                oCustomDateRangeItem.setText(this.getDefaultCustomDateRangeLabel());
                // Reset the custom date range value
                oCustomDateRangeItem.setValue({
                    from : "",
                    to : ""
                });
                this.set_customDateRangeFrom("");
                this.set_customDateRangeTo("");

                this.setSelection({
                    Start : "",
                    End : ""
                });
                return true;
            }
        },

        /**
         * Set the default selection
         * 
         * @param {object}
         *            oSelection Selection object
         * @param {string}
         *            oSelection.Type Constant which indicates whether a date distance (Relative) or date range (Absolute) was selected
         * @param {string}
         *            oSelection.CustomStartDate Start date of the custom date range
         * @param {string}
         *            oSelection.CustomEndDate End date of the custom date range
         * @param {int}
         *            oSelection.CustomDuration Duration of the custom date distance
         * @param {string}
         *            oSelection.CustomUnit Indicates the unit of the custom date distance (day/week/month)
         * @param {int}
         *            oSelection.Duration Duration of the static date distance
         */
        setSelection : function(oSelection) {
            // Update the property
            this.setProperty("selection", oSelection);

            // Clear the item selection
            this._clearAllItemSelection();

            // Get the custom list items
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
            var aStaticItems = this.getAggregation("items");

            // Default values of custom items
            var oCustomDateRangeValue = {
                from : "",
                to : ""
            };

            // Are values available in the 'selection' binding? Get them.
            if (this.get_customDateRangeFrom()) {
                oCustomDateRangeValue.from = this.get_customDateRangeFrom();
            } else if (oSelection && oSelection.Start) {
                oCustomDateRangeValue.from = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.Start);
            }
            if (this.get_customDateRangeTo()) {
                oCustomDateRangeValue.to = this.get_customDateRangeTo();
            } else if (oSelection && oSelection.End) {
                oCustomDateRangeValue.to = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.End);
            }

            // Maintain control status based on selection
            if (oCustomDateRangeValue.from == "" && oCustomDateRangeValue.to == "") {
                this.setActive(false);
            } else {
                this.setActive(true);
            }

            // Now we have the values. Loop through the static items and find out if any of them matches the current internal state.
            // We know we've found a matching static item, if currentDate {minus} oItem.getValue().Duration (e.g months) = oSelection.Start
            // "Last x months" makes sense only if oSelection.End happens to be today. So check for that first.
            var oTodayDate = FAKE_TODAY();
            var sTodayJSON = jd.ui.eid.common.DateHelper.DateToJSONDate(oTodayDate);
            var oEndDate = jd.ui.eid.common.DateHelper.JSONDateToDate(oSelection.End);
            var oFromDate = jd.ui.eid.common.DateHelper.JSONDateToDate(oSelection.Start);
            var bStaticItemFound = false;
            var sSelectionType = oSelection._Type || "custom"; // _Type is set to either "custom" or "static" by applyPersonalization. This decides
            // whether oSelection.Start & oSelection.End should be shown as 'selected' in a static
            // ValueListItem (static) or in the 'Custom Range...' ValueListItem (custom)

            if (jd.ui.eid.common.DateHelper.isSameDay(oTodayDate, oEndDate) && (sSelectionType == "static")) {
                $.each(aStaticItems, function(i, oItem) {
                    switch (oItem.getValue().Type) {
                        case "duration" :
                            var sDiffDate; // JSONDate after subtracting the item's duration from the oSelection.End date
                            var oDiffDate; // Object representation of sDiffDate
                            if (oItem.getValue().Unit == "day") {
                                sDiffDate = jd.ui.eid.common.DateHelper.subtractDays(sTodayJSON, oItem.getValue().Duration);
                            } else if (oItem.getValue().Unit == "month") {
                                sDiffDate = jd.ui.eid.common.DateHelper.subtractMonths(sTodayJSON, oItem.getValue().Duration);
                            }
                            oDiffDate = jd.ui.eid.common.DateHelper.JSONDateToDate(sDiffDate);

                            if (jd.ui.eid.common.DateHelper.isSameDay(oDiffDate, oFromDate)) {
                                bStaticItemFound = true;
                                oItem.setSelected(true);
                                return false; // to exit the jQuery.each
                            }
                            break;

                        case "today" :
                            // We have already checked (a few lines above) if oSelection.End == today.
                            // To select the 'today' item, we need to ensure that oSelection.Start == oSelection.End == Today
                            if (jd.ui.eid.common.DateHelper.isSameDay(oTodayDate, oFromDate)) {
                                bStaticItemFound = true;
                                oItem.setSelected(true);
                                return false;
                            }
                    }
                });
            } else if ((sSelectionType == "custom") && oSelection.Start && oSelection.End) {
                oCustomDateRangeItem.setSelected(true);
                oCustomDateRangeItem.setValue(oCustomDateRangeValue);
                this._updateCustomDateRangeItemText();
            }

            return this;
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.DateDistanceFilterItemRenderer"

    });

})();