(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * @class
     * <p>
     * The shell view provides the outer frame of the application. It has a custom look and feel and consists of a custom shell (@link
     * jd.ui.eid.control.Shell}. The controller handles the navigation between the different tabs, such as Dashboard, Evidence Package List, DTC
     * Blacklist and Filter Personalization.
     * <p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#Model::kpisRetrieved} : Notifies the listeners about KPI retrieval</li>
     * <li>{@link jd.ui.eid.Events#Navigation::navigating} : Raised while navigating to another view</li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.Shell
     */
    sap.ui.controller("jd.ui.eid.view.main.Shell", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.Shell */
    {

        /**
         * Configuration map for the views related to the shell's navigation items.
         */
        _mWorksetItemViews : {
            wiDashboard : "jd.ui.eid.view.main.shell.Dashboard",
            wiEvidencePackageList : "jd.ui.eid.view.main.shell.EvidencePackageList",
            wiPersonalization : "jd.ui.eid.view.main.shell.personalization.FilterSettings",
            swiPersonalizationFilterSettings : "jd.ui.eid.view.main.shell.personalization.FilterSettings",
            swiPersonalizationDTCBlacklist : "jd.ui.eid.view.main.shell.personalization.DTCBlacklist"
        },

        /**
         * Map holding the cached view instances related to the navigation items.
         */
        _mWorksetItemViewCache : {},

        /**
         * The key of the current view.
         */
        _sCurrentViewKey : null,

        _sDefaultViewKey : "wiDashboard",

        /**
         * The method registers the shell's notification bar to the {@link jd.ui.eid.common.NotificationCenter} available on the
         * {@link jd.ui.eid.application.Application} singleton and displays the initial view inside the shell's content.
         */
        onInit : function() {
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe("Shell", "navigate", this._handleNavigate, this);
            // Load customizing from backend
            this.loadCustomizing();

            this.getNotificationCenter().setNotificationBar(this.byId("shell").getNotificationBar());
            this.displayContentView();
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         */
        onExit : function() {
            // Unsubscribe from event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe("Shell", "navigate", this._handleNavigate, this);

            // Detroy controls
            $.each(this._mWorksetItemViewCache, function(sProperty, oManagedObject) {
                if (oManagedObject) {
                    oManagedObject.destroy();
                }
                oManagedObject = null;
            });

            // Set properties to null
            this._mWorksetItemViewCache = null;
        },

        /**
         * Loads the necessary customizing values from the backend.
         */
        loadCustomizing : function() {
            var oServiceFacade = this.getServiceFacade("Customizing");
            oServiceFacade.getKPIs(function() {
                sap.ui.getCore().getEventBus().publish("Model", "kpisRetrieved");
            }, this._onRequestFailed);
        },

        /**
         * Event handler for the workItemSelected event of the shell control. The handler triggers the navigation to the selected view.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        onWorksetItemSelected : function(oEvent) {
            var that = this;
            var sKey = oEvent.getParameter("key");
            var sPreviousKey = this._sCurrentWorksetItemKey;

            // First, let's get the DLM attached to the current view.
            var oDLM = jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl(this.byId("shell").getContent()[0]);
            // And if the DLM is not null, let's attach the handlers and let the DLM to the rest.
            if (oDLM) {
                // If data is clean, we will display the content view for the selected workset item.
                oDLM.setNavigationHandler(function() {
                    // When we continue to navigate, either the changes have been saved or they are deliberately discarded, so reset the DLM.
                    oDLM.reset();
                    that.displayContentView(sKey);
                });

                // If data is dirty, we will reset the selected workset item on the shell.
                oDLM.setCancelHandler(function() {
                    // If the PreviousKey (aka the screen from which we're navigating away) is a sub item, we assign their parent as the currently
                    // selected workset item and afterwards, set the sub navigation items.
                    if (sPreviousKey == 'swiPersonalizationFilterSettings' || sPreviousKey == 'swiPersonalizationDTCBlacklist') {
                        sPreviousKey = 'wiPersonalization';
                    }
                    var aWorksetItems = that.byId("shell").getWorksetItems();
                    $.each(aWorksetItems, function(iIndex, oWorksetItem) {
                        if (oWorksetItem.getKey() == sPreviousKey) {
                            that.byId("shell").setSelectedWorksetItem(oWorksetItem);
                            return false;
                        }
                    });
                });

                oDLM.notifyOrNavigate();
            } else {
                this.displayContentView(sKey);
            }
        },

        /**
         * Get the content view related to the given key from the navigation item.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         * @returns {sap.ui.core.mvc.View} the related view.
         */
        _getContentView : function(sKey) {
            if (!sKey || !this._mWorksetItemViews[sKey]) {
                // Make sure that sKey is actually a valid navigation item key.
                sKey = this._sDefaultViewKey; // Default value
            }
            this._sCurrentWorksetItemKey = sKey;
            var sViewName = this._mWorksetItemViews[sKey];

            if (!this._mWorksetItemViewCache[sViewName]) {
                // If the view hasn't been created and cached yet, we will do that now. Essentially, this is lazy loading.
                this._mWorksetItemViewCache[sViewName] = jd.ui.eid.xmlview(sViewName);
            }

            return this._mWorksetItemViewCache[sViewName];
        },

        /**
         * Display the view related to the given key from the navigation item as the sole content of the shell.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         */
        displayContentView : function(sKey) {
            if (!sKey) {
                sKey = this._sDefaultViewKey;
            }

            var sCurrentViewName = this._mWorksetItemViews[this._sCurrentViewKey];
            var sTargetViewName = this._mWorksetItemViews[sKey];
            sap.ui.getCore().getEventBus().publish("Navigation", "navigating", {
                context : "jd.ui.eid.view.main.Shell",
                origin : sCurrentViewName,
                target : sTargetViewName
            });

            var oView = this._getContentView(sKey);
            this.byId("shell").setContent(oView);
            this._sCurrentViewKey = sKey;
            this.byId("shell").setSelectedWorksetItem(this.createId(sKey));
        },

        /**
         * Handles the <code>navigate</code> event of channel <code>Shell</code> and triggers a navigation to the workset item passed in
         * <code>target</code>.
         * 
         * @see jd.ui.eid.Events#Shell::navigate
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        _handleNavigate : function(sChannelId, sEvent, mData) {
            if (mData.target) {
                this.displayContentView(mData.target);
            }
        }

    }));
})();