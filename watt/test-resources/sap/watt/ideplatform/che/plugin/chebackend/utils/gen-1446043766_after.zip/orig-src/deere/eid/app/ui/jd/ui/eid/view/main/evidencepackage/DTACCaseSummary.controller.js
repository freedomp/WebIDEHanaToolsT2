(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * The DTAC case summary view is used to display the details of the DTAC cases that belong to the evidence package. It also allows the removal of
     * individual DTAC cases from the evidence packate
     * 
     * <p>
     * There are the following <strong>core methods</strong> of the DTAC case summary view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers.
     * Moreover it triggers a data fetch, to load all data from the backend.</li>
     * <li>{@link #.onExit} is called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.onAfterRendering} is called when the view has been rendered. It calls loadDTACCaseList to get the require data if it has not been
     * loaded already. </li>
     * <li>{@link #.loadDTACCaseList} is called to fetch the DTAC Case list from the backend.</li>
     * <ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleEvidencePackageContextChanged is called when a new evidence package was loaded and new data is required.</li>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>handleRemoveWarrantyClaim is called to remove Warranty Claim from the list of selected Warranty Claims.</li>
     * </ul>
     * </p>
     * 
     * @class
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
     */

    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.DTACCaseSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.evidencepackage.DTACCaseSummary */
    {

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        onInit : function() {
            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            oEventBus.subscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

            // Set refresh flag to get the data from the backend for the current evidence package
            this.bRefresh = true;
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        onAfterRendering : function() {
            if (this.bRefresh) {
                this.loadDTACCaseList();
                this.bRefresh = false;
            }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        onExit : function() {
            // Unsubscribe from the event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            oEventBus.unsubscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);
        },

        /**
         * Handles the evidence package context change by resetting the refresh flag
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        handleEvidencePackageContextChanged : function() {
            this.bRefresh = true;
        },

        /**
         * Handles the event fired when data for DTAC Case Details is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/DTACCaseDetailsList") {
                this.getView().setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for DTAC Case Details has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/DTACCaseDetailsList") {
                this.getView().setBusy(false);
            }
        },

        /**
         * Fetches DTACCases via the service facade
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        loadDTACCaseList : function() {
            var that = this;
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");

            this.getServiceFacade("EvidencePackage").getDTACCaseDetailsList(oEvidencePackageDetailsHeader, null, function() {
                // Error handler, make sure that there are no old DTAC cases sticking around in the list, so empty it.
                oModel.setProperty("/EvidencePackageDetails/DTACCaseDetailsList", []);
                that._onRequestFailed.apply(that, arguments);
            });
        },

        /**
         * Pops up a dialog and removes a single DTAC Case on user confirmation
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        handleRemoveDTACCase : function(oEvent) {
            this.oDTACCase = oEvent.getSource().getBindingContext().getProperty();
            var that = this;

            // Callback function for confirmation to delete dialog
            var fnOnDeleteConfirmation = function(bConfirmed) {
                if (bConfirmed) {
                    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTACCase(that.oDTACCase);
                }
            };
            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CONFIRM_DELETE_DTAC_CASE",
                    [this.oDTACCase.DTACCaseNumber]);
            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);
        },

        /**
         * Event handler for the 'onBeforeSectionOpening' event of the Accordion. The event is fired when a new AccordionSection is opened. This is
         * required because the filter selection for each DTAC Case (which is shown in a QuickView) is in a different path in the model. Most of the
         * fields in the Panel (except 'Filter Selection') are bound to /EvidencePackageDetails/DTACCaseDetailsList/, but the FilterSelection for each
         * DTAC Case is available in a different path (/EvidencePackageDetails/Header/DTACCaseList). This is why this binding is not directly possible
         * with XML, and we need this event to be handled to make the required changes within the template.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent
         * @memberOf jd.ui.eid.view.main.evidencepackage.DTACCaseSummary
         */
        handleOnBeforeAccordionSectionOpening : function(oEvent) {
            // Get the binding context of the DTAC Case Summary template that is about to become visible to the user
            var oTemplate = sap.ui.core.Fragment.byId(this.createId("DTACCaseSummaryTemplate"), "EvidencePackageDTACCaseDetailsMatrixLayout");
            var sContextPath = oTemplate.getBindingContext().getPath();
            var iDTACCaseNumber = sap.ui.getCore().getModel().getProperty(sContextPath).DTACCaseNumber;

            // Based on the context, determine the path for this DTAC case's filter selection.
            // Loop through /EvidencePackageDetails/Header/DTACCaseList to find the FilterSelection for the matching DTAC Case Number.
            var aDTACCaseList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/DTACCaseList");
            var iIndex, sFilterSelectionPath;
            $.each(aDTACCaseList, function(i, oDTACCase) {
                if (oDTACCase.DTACCaseNumber == iDTACCaseNumber) {
                    iIndex = i;
                    return false;
                }
            });
            sFilterSelectionPath = "/EvidencePackageDetails/Header/DTACCaseList/" + iIndex + "/DTACCaseFilterSelection";

            // Get the FilterArea and bind its root path accordingly
            var oFilterArea = sap.ui.core.Fragment.byId(this.createId("DTACCaseSummaryTemplate"), sap.ui.core.Fragment.createId("DTACCaseFilters",
                    "FilterArea"));
            oFilterArea.bindElement(sFilterSelectionPath);
        }

    }));

})();