/*
 * Util testsuite
 */
QUnit.config.testTimeout = 60000;

// test alias, relative path from testsuite.qunit.js to the test resources
jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse.test", "test-files");
jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse.util.test", "test-files/util");

// Register the code alias: relative path from my.qunit.testsuite.js to the
// application code
jQuery.sap.require("nw.epm.refapps.lib.reuse.test.ModulePathForTests");
nw.epm.refapps.lib.reuse.test.ModulePathForTests.registerModulePathForTests("nw.epm.refapps.lib.reuse");

if (nw.epm.refapps.lib.reuse.test.ModulePathForTests.isInRiverRde()) {
    // TODO: use correct paths
    jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse", "../../resources/nw/epm/refapps/lib/reuse/");
    jQuery.sap.registerModulePath("nw.epm.refapps.testhelpers", "../testhelpers/");
} else {
    jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse", "../../resources/nw/epm/refapps/lib/reuse/");
    jQuery.sap.registerModulePath("nw.epm.refapps.testhelpers", "../testhelpers/");
}

// tests to run
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.test.formatterTest");