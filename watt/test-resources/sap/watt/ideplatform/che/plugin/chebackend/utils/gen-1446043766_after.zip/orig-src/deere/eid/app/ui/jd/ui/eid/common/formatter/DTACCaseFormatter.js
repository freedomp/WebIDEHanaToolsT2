(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.DTACCaseFormatter");

    /**
     * @class This formatter class provides methods for formatting DTAC case data.
     * @static
     * @name jd.ui.eid.common.formatter.DTACCaseFormatter
     */
    jd.ui.eid.common.formatter.DTACCaseFormatter = {};

    /**
     * Formats the DTAC case detailed text which contains HTML.
     * 
     * @param {string}
     *            sText the detailed text.
     * @returns {string} the formatted text.
     */
    jd.ui.eid.common.formatter.DTACCaseFormatter.formatDetailedText = function(sText) {
        if (typeof sText === "string") {
            return sText;
        } else {
            return "";
        }
    }

})();