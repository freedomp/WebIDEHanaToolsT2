(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.ListBox");

    var oListBox = null;

    module("jd.ui.eid.control.ListBox", {
        setup : function() {
            oListBox = new jd.ui.eid.control.ListBox();
            oListBox.placeAt("content");
        },
        teardown : function() {
            $("#content").html();
            oListBox.destroy();
            oListBox = null;
        }
    });

    test("onclick() should pass the event object through to the implementation of the sap.ui.commons.ListBox's onclick method.", function() {
        // Prepare control
        var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");

        // Trigger event
        var oEvent = jQuery.Event('click');
        oListBox.onclick(oEvent);

        // Assertions
        ok(spy.called);
        var oActEvent = spy.args[0][0];
        ok(oActEvent);
        equals(oActEvent, oEvent);

        // Clean up
        spy.restore();
    });

    test("onclick() should set the ctrlKey property of the event to true if the enableSimpleSelect property is true.", function() {
        // Prepare control
        var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");
        oListBox.setEnableSimpleSelect(true);

        // Trigger event
        var oEvent = jQuery.Event('click');
        oListBox.onclick(oEvent);

        // Assertions
        var oActEvent = spy.args[0][0];
        ok(oActEvent.ctrlKey === true);

        // Clean up
        spy.restore();
    });

    test("onclick() should not change the ctrlKey property of the event if the enableSimpleSelect property is false.", function() {
        // Prepare control
        var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");
        oListBox.setEnableSimpleSelect(false);

        // Trigger event
        var oEvent = jQuery.Event('click', {
            ctrlKey : 'dontChangeMe'
        });
        oListBox.onclick(oEvent);

        // Assertions
        var oActEvent = spy.args[0][0];
        ok(oActEvent.ctrlKey === 'dontChangeMe');

        // Clean up
        spy.restore();
    });

    test(
            "onclick() should set the ctrlKey property of the event to true if the enableSimpleSelect property is true and the allowMultiSelect property is true.",
            function() {
                // Prepare control
                var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");
                oListBox.setEnableSimpleSelect(true);
                oListBox.setAllowMultiSelect(true);

                // Trigger event
                var oEvent = jQuery.Event('click');
                oListBox.onclick(oEvent);

                // Assertions
                var oActEvent = spy.args[0][0];
                ok(oActEvent.ctrlKey === true);

                // Clean up
                spy.restore();
            });

    test(
            "onclick() should set the ctrlKey property of the event to true if the enableSimpleSelect property is true and the allowMultiSelect property is false.",
            function() {
                // Prepare control
                var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");
                oListBox.setEnableSimpleSelect(true);
                oListBox.setAllowMultiSelect(false);

                // Trigger event
                var oEvent = jQuery.Event('click');
                oListBox.onclick(oEvent);

                // Assertions
                var oActEvent = spy.args[0][0];
                ok(oActEvent.ctrlKey === true);

                // Clean up
                spy.restore();
            });

    test(
            "onclick() should set the ctrlKey property of the event to false if the enableMandatorySelection property is true and the allowMultiSelect property is false.",
            function() {
                // Prepare control
                var spy = sinon.stub(sap.ui.commons.ListBox.prototype, "onclick");
                oListBox.setEnableMandatorySelection(true);
                oListBox.setAllowMultiSelect(false);

                // Trigger event
                var oEvent = jQuery.Event('click');
                oListBox.onclick(oEvent);

                // Assertions
                var oActEvent = spy.args[0][0];
                ok(oActEvent.ctrlKey === false);

                // Clean up
                spy.restore();
            });

})();