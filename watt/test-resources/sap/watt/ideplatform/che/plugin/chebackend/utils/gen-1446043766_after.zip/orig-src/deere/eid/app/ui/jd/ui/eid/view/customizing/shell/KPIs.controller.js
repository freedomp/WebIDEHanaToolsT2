(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.customizing.shell.BaseController");

    /**
     * @class The controller handles a table of KPIs retrieved from the backend that can be updated by the user. Editing a table row is done via a
     *        dialog (see <code>jd.ui.eid.fragment.dialog.customizing.EditKPIDialog.xml</code>), where all values can be changed. The only
     *        mandatory field is the KPI name. Validation is done in {@link #.handleDialogOk}.
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.customizing.shell.KPIs
     * @augments jd.ui.eid.view.customizing.shell.BaseController
     */
    sap.ui.controller("jd.ui.eid.view.customizing.shell.KPIs", jQuery.extend(true, {}, jd.ui.eid.view.customizing.shell.BaseController, /** @lends jd.ui.eid.view.customizing.shell.KPIs */
    {
        /* Configuration */

        _mConfig : {
            mFetchData : {
                sMethodName : "getKPIs"
            },
            mSendData : {
                sPath : "/KPIValues",
                sMethodName : "updateKPIs",
                sSuccessTextKey : "KPI_TABLE_MSG_SAVE_SUCCESSFUL"
            },
            mDialog : {
                sId : "EditKPIDialog",
                sFragment : "jd.ui.eid.fragment.dialog.customizing.EditKPIDialog",
                sContextPath : "/KPIDialog"
            },
            mHelpDialog : {
                sLongTextKey : "KPI_TABLE_EXP_HELP_TEXT",
                sTitleTextKey : "KPI_TABLE_HED_HELP_DIALOG"
            },
            sTableId : "table"
        },

        /* Dialog Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleDialogBeforeOpenHook
         */
        handleDialogBeforeOpenHook : function() {
            // Detach all error tooltips from controls
            var oKPIName = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "KPIName");
            var oDescription = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "Description");
            this.detachErrorTooltipFromControl(oKPIName);
            this.detachErrorTooltipFromControl(oDescription);
        },

        /**
         * Handles the change event of the check box in the dialog. Based on the state, the model is updated with either integer 1 or 0.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent of the control to be called
         */
        onCheckBoxChange : function(oEvent) {
            // To create object for checkbox
            var oSource = oEvent.getSource();
            var bChecked = oSource.getChecked();
            var oContext = oSource.getBindingContext();
            var sPath = oSource.getBinding("checked").getPath();
            // Checking if checkbox have been selected or not. On change it will change its binding
            // value correspondingly.
            oSource.getModel().setProperty(sPath, (bChecked ? 1 : 0), oContext);
        },

        /**
         * Sets back values to the given row.
         * 
         */
        handleDialogOk : function() {
            if (this.validateKPIName()) {
                var oModel = sap.ui.getCore().getModel();

                // Compare the values of the dialog with the values of the table. Only if the values are not the same, we need to change the state of
                // the data loss manager
                if (!oModel.pathsEqual(this._sDialogPath, "/KPIDialog")) {
                    this._oDLM.setDirty(true);
                }

                // Now we can go ahead and copy back the values from the dialog to the table.
                oModel.setProperty(this._sDialogPath, oModel.getProperty("/KPIDialog"));
                this._oDialog.close();
            }
        },

        /**
         * Handles the change event of the checkbox and manages the dirty state of the DLM.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        handleCheckboxChange : function(oEvent) {
            this.onCheckBoxChange(oEvent);
            this._oDLM.setDirty(true);
        },

        /* Validation */

        /**
         * Validates KPI name field of the edit dialog. The value is valid if it is not empty
         * 
         * @return {boolean} True of the value is valid, false otherwise.
         */
        validateKPIName : function() {
            var oKPINameField = sap.ui.core.Fragment.byId("EditKPIDialog", "KPIName");
            return this.validateMandatoryTextField(oKPINameField, "KPI_DETAILS_MSE_NAME_REQUIRED");
        },

        /* Formatter */

        /**
         * Formats an integer to boolean
         * 
         * @param {int}
         *            iInt the integer to convert
         * @returns {boolean}
         */
        formatIntegerToBoolean : function(iInt) {
            return iInt == 1;
        }

    }));
})();