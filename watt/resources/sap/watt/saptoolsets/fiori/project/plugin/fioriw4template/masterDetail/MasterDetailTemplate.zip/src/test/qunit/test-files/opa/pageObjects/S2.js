sap.ui.define(["sap/ui/test/Opa5", "./Common"], function (Opa5, Common) {
	"use strict";

	function withListItemsDo(iMinimumEntries, iMaximumEntries, fnSucessHandler, errorMessage){
		return this.waitFor({
			id: "list",
			viewName: "S2",
			success: function(oList) {
				return this.waitFor({
					controlType: "sap.m.ObjectListItem",
					viewName: "S2",
					matchers: new sap.ui.test.matchers.Ancestor(oList),
					check : function(aListItems){
						//have at least as many items as I want to select
						var bEnough = aListItems.length >= iMinimumEntries;
						var bTooMany = (iMaximumEntries === -1) ? false : aListItems.length > iMaximumEntries;
						return bEnough && !bTooMany;
					},
					success : function(aListItems){
						fnSucessHandler.call(this, oList, aListItems);
					},
					errorMessage : errorMessage
				});
			},
			errorMessage : "List (S2) missing"
		});
	}

	return Opa5.createPageObjects({
		onPageS2 : {
			baseClass : Common,

			actions : {
				iSelectEntry : function (iIndex) {
					return withListItemsDo.call(
							this,
							iIndex,
							-1,
							function(oList, aListItems){
								var oItem = aListItems[iIndex];
								this.getContext().selectedItem = oItem;
								ok(oItem, "Retrieved entry " + iIndex + " in list (S2)");
								oItem.firePress({
									listItem: oItem,
									srcControl: oList
								});
							}, 
							"Entry " + iIndex + " could not be selected (S2)"
					);
				},

				iSearchFor : function(sSearchText){
					return this.waitFor({
						controlType : "sap.m.SearchField",
						success : function(aSearchFields){
							var oSearchField = aSearchFields[0];
							oSearchField.setValue(sSearchText);
							oSearchField.fireLiveChange({newValue: sSearchText});
							oSearchField.fireSearch({query: sSearchText});
						},
						errorMessage : "Search Field missing"
					});
				},

				iClearTheSearch : function(){
					return this.waitFor({
						controlType : "sap.m.SearchField",
						success : function(aSearchFields){
							var oSearchField = aSearchFields[0];
							oSearchField.clear();
						},
						errorMessage : "Search Field missing"
					});
				},

				iSearchForTheLastEntry : function(){
					var sLastEntryTitle;

					withListItemsDo.call(
							this,
							10,
							-1,
							function(oList, aListItems){
								var oLastItem = aListItems[aListItems.length - 1];
								sLastEntryTitle = oLastItem.getTitle();
								this.getContext().selectedItem = oLastItem;
							}, 
							"Last Entry not found (S2)"
					);
					return this.waitFor({
						success : function(){
							return this.iSearchFor(sLastEntryTitle);
						}
					});
				}
			},

			assertions : {
				theListIsFilledWithData : function() {
					return withListItemsDo.call(
							this,
							1,
							-1,
							function(oList, aListItems){
								ok(true,"List is filled with entries");
								this.getContext().selectedItem = aListItems[0];
							}, 
							"List has no entries (S2)"
					);
				},
				theListShowsOnlyThisEntry: function() {
					return withListItemsDo.call(
							this,
							1,
							1,
							function(oList, aListItems){
								var oExpectedListItem = this.getContext().selectedItem;

								strictEqual(aListItems.length, 1 ,"List has only one entry");

								strictEqual(aListItems[0].id, oExpectedListItem.id, "List shows only this entry (id)");
								strictEqual(aListItems[0].getTitle(), oExpectedListItem.getTitle(), "List shows only this entry (id)");
							}, 
							"List has no entries (S2)"
					);
				}
			}
		}
	});

});