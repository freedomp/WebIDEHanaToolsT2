jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ui.comp.odata.MetadataAnalyser");
jQuery.sap.require("sap.ui.comp.providers.ValueHelpProvider");
jQuery.sap.require("nw.epm.refapps.products.manage.util.Products");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.messages");

sap.ca.scfld.md.controller.BaseDetailController.extend("nw.epm.refapps.products.manage.view.S3_ProductEdit", {
	_oComponent: null,
	_oHelper: null,
	_oView: null,
	_oResourceBundle: null,
	_oInitialObject: null,
	_sContextPath: null,
	_aInputFields: [],
	_aMandatoryFields: [],
	_bIsDraftDirty: false,
	_oProduct: null,
	_oEventBus: null,
	_sIdentity: "nw.epm.refapps.product.manage",

	onInit: function() {
		this._oResourceBundle = this.oApplicationFacade.getResourceBundle();
		this._oView = this.getView();
		// Creates the products helper instance
		// We want to replace this.getView() with this._oView, but code formatter introduces new indentation
		// oHelper will probably be renamed and the bug should disappear...
		var oModel = this._oView.getModel();
		oModel.setDeferredBatchGroups(["editproduct"]);
		oModel.setChangeBatchGroups({
			"ProductDraft": {
				batchGroupId: "editproduct"
			}
		});
		// Gets and stores array of input fields and mandatory fields
		this._aInputFields = this._getInputFields();
		this._aMandatoryFields = this._getMandatoryFields();
		this.setHeaderFooterOptions(this._buildButtons());

		// Gets the application component and the data operation helper instance
		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
		this._oComponent = sap.ui.component(sComponentId);
		this._oEventBus = this._oComponent.getEventBus();
		this._oHelper = this._oComponent.getODataHelper(this._oResourceBundle, oModel);

		// Initialize the Sub-View which included the sap.m.UploadCollection control to handle uploading and removing
		// images
		this._initSubViewImageUpload();

		this.oRouter.attachRoutePatternMatched(this.onRoutePatternMatched, this);

		this._oEventBus.subscribe(this._sIdentity, "deleteProductDraft", this.deleteProductDraftFromMaster, this);

		// This facilitates the value help generated from annotations only
		var oInput = this.byId("supplier");
		var oMetadataAnalyzer = new sap.ui.comp.odata.MetadataAnalyser(this._oView.getModel());
		var sField = "SupplierName";
		var sAnnotationPath = "EPM_REF_APPS_PROD_MAN_SRV.ProductDraft/" + sField;
		var oValueListAnnotations = oMetadataAnalyzer.getValueListAnnotation(sAnnotationPath);

		// This is created for side effects Search Help Dialog
		/* eslint-disable */
		new sap.ui.comp.providers.ValueHelpProvider({
			annotation: oValueListAnnotations.primaryValueListAnnotation,
			additionalAnnotations: oValueListAnnotations.additionalAnnotations,
			control: oInput,
			model: oModel,
			preventInitialDataFetchInValueHelpDialog: true,
			supportMultiSelect: false,
			supportRanges: false,
			fieldName: sField,
			title: sField
		});
		/* eslint-enable */
		oInput.setShowValueHelp(true);

	},

	onRoutePatternMatched: function(oEvent) {
		var sProductDraftID = oEvent.getParameter("arguments").productDraftID;
		if (!sProductDraftID) {
			return;
		}
		// Unbind element to remove old values from UI
		this._oView.unbindElement();

		this._sContextPath = "/ProductDrafts('" + sProductDraftID + "')";
		// Binds the (newly generated) product draft to the view and expands the Images part for the subview
		// ProductDraftUploadImages
		this._oView.bindElement(this._sContextPath, {
			expand: "Images"
		});

		// Checks if the binding context is already available locally. If so, refreshes the binding and retrieves the
		// data from backend again.
		var oBindingContext = this._oView.getBindingContext();
		if (oBindingContext && oBindingContext.getPath() === this._sContextPath) {
			this._oView.getElementBinding().refresh();
		}
		// Removes any existing filters on Subcategories first
		// this.byId("subcategory").getBinding("items").filter([]);

		// Updates header and footer after the product draft is retrieved
		this._oView.getElementBinding().attachEventOnce(
			"dataReceived",
			jQuery.proxy(function() {
				oBindingContext = this._oView.getBindingContext();
				if (oBindingContext) {
					// Sets the draft dirty flag based on the backend information
					this._bIsDraftDirty = oBindingContext.getObject() && oBindingContext.getObject().IsDirty;
					// Sets page header/footer
					this._oProduct = oBindingContext.getObject();
					this.setHeaderFooterOptions(this._buildHFOptions());

					// Sets Main Category as a filter on subcategory so that only relevant subcategories are shown
					// in ComboBox
					this._setCategoryFilter(oBindingContext);
				} else {
					// Handle the case if the product draft cannot be retrieved remotely (e.g. it's deleted already)
					// show the corresponding product detail page, since in this app the draft id is supposed to be
					// same as the product id
					this._oComponent.showProductDetailPage(sProductDraftID);
				}
			}, this));

	},

	onSavePressed: function() {

		var fnOnSuccess = function(oProductData) {
			this._resetValueStates();
			// Reuses the function in the master controller because the list there needs to be updated
			this._oEventBus.publish(this._sIdentity, "navToUpdatedProduct", {
				Id: oProductData.Id,
				Name: oProductData.Name
			});
		};

		// this.byId("subcategory").getBinding().filter([]);
		// If the user chooses SAVE and there was no focus change out of a field that had
		// been changed, the system must check again for missing mandatory fields
		if (!this._checkAndMarkEmptyMandatoryFields(true) && !this._fieldWithErrorState()) {
			this._oHelper.activateProduct(this._oView.getBindingContext().getProperty("Id"), jQuery.proxy(
				this._fnSubmitDraftSuccess, this), jQuery.proxy(fnOnSuccess, this));

		}
	},

	// The system must distinguish between CANCEL chosen in EDIT mode and CANCEL chosen in ADD mode
	// because Cancel Edit navigates to display of that product and Cancel Add to the previously
	// selected product

	// Cancels editing of a product
	onCancelPressed: function() {
		var sProductId = this._oView.getBindingContext().getObject().ProductId;
		var fnNavToProductDetail = function() {
			this._resetValueStates();
			this._oComponent.showProductDetailPage(sProductId);
		};

		this.deleteProductDraft(jQuery.proxy(fnNavToProductDetail, this));
	},

	// Cancels adding or copying of a product
	onCancelAddPressed: function() {
		var fnNavToProductDetail = function() {
			this._resetValueStates();
			this._oEventBus.publish(this._sIdentity, "resetSelectedProduct");
		};

		this.deleteProductDraft(jQuery.proxy(fnNavToProductDetail, this));
	},

	_buildHFOptions: function() {
		var oBindingContext = this._oView.getBindingContext();
		var bIsNewProduct = oBindingContext && oBindingContext.getObject() && oBindingContext.getObject().IsNewProduct;
		return {
			// Page title depends on whether the product draft is for a new product or for an existing product
			sI18NDetailTitle: bIsNewProduct ? "xtit.productNew" : "xtit.productEdit",
			buttonList: [
				{
					// Cancel button action for Edit and Add is different
					sId: "savebutton",
					sI18nBtnTxt: "xbut.save",
					onBtnPressed: jQuery.proxy(this.onSavePressed, this),
					bDisabled: false
                    },
				{
					sI18nBtnTxt: "xbut.cancel",
					onBtnPressed: bIsNewProduct ? jQuery.proxy(this.onCancelAddPressed, this) : jQuery.proxy(
						this.onCancelPressed, this)
                    }],

			oEmailSettings: {
				sSubject: this._getEmailSubject(),
				sRecepient: "",
				fGetMailBody: jQuery.proxy(this._getEmailContent, this)
			}

		};
	},

	// Ensure that buttons are rendered onInit and thus always visible, even when the EDIT screen is awaiting data
	_buildButtons: function() {
		return {
			buttonList: [{
				sId: "savebutton",
				sI18nBtnTxt: "xbut.save",
				onBtnPressed: jQuery.proxy(this.onSavePressed, this),
				bDisabled: false
            }, {
				sI18nBtnTxt: "xbut.cancel"
            }],

			// Makes the navBack button invisible
			onBack: null
		};

	},

	// deleteProductDraft is used in this controller to cancel editing and when
	// the active product has been updated or created.
	// Note that this method is also used in the S2_ProductMaster controller when the
	// user navigates away from the edit screen, for example by clicking another item in the
	// master list.
	deleteProductDraft: function(fnAfterDeleted, fnDeleteCanceled) {
		this._oHelper.deleteProductDraft(this._sContextPath, this._bIsDraftDirty, fnAfterDeleted, fnDeleteCanceled);
	},

	// Handle call to deleteProductDraft from S2_ProductMaster.controller and get function parameters from
	// the object passed by the Event Bus
	deleteProductDraftFromMaster: function(sChannel, sEvent, oParm) {

		var fnAfterLeave = oParm.fnAfterLeave,
			fnCancelLeave = oParm.fnCancelLeave;
		this.deleteProductDraft(fnAfterLeave, fnCancelLeave);
		this._resetValueStates();
	},

	// This method has been defined in the XML view and is required by UI5 to call
	// the Suggestions "type ahead" function
	suggestMethod: function(oEvent) {
		sap.m.InputODataSuggestProvider.suggest(oEvent);
	},

	// This method is currently not used, but remains until the use of the generated value help from
	// Annotations outside the Smart Filter Bar is clarified
	_setSearchHelpValues: function(oEvent, sValueName, sValueIdName) {
		var oSelectedItem = oEvent.getParameters().selectedItem;
		this.byId(sValueName).setValue(oSelectedItem.getTitle());
		this.byId(sValueIdName).setValue(oSelectedItem.getDescription());
	},

	_getMandatoryFields: function() {
		return [this.byId("productNameInput"), this.byId("price"), this.byId("currency"),
		    this.byId("category"), this.byId("subcategory"), this.byId("description"),
            this.byId("supplier"), this.byId("unitOfMeasure")];
	},

	_getInputFields: function() {
		return [this.byId("productNameInput"), this.byId("price"), this.byId("currency"),
		this.byId("category"), this.byId("subcategory"), this.byId("description"),
		this.byId("supplier"), this.byId("unitOfMeasure"), this.byId("length"), this.byId("width"),
        this.byId("height"), this.byId("weight")];
	},

	// Values states if set are not automatically removed from the view.  For example, if there 
	// are missing mandatory fields and the user presses "save", these fields are set to value state
	// error.  If the user then presses "cancel" and selects another product to edit, the values states
	// must be removed, otherwise the value states appear on the next product edit.
	_resetValueStates: function() {

		jQuery.each(this._aInputFields, function(i, input) {
			input.setValueState(sap.ui.core.ValueState.None);
		});
	},

	_fieldWithErrorState: function() {
		var bErrorFound = false;
		jQuery.each(this._aInputFields, function(i, input) {
			if (input.getValueState() === sap.ui.core.ValueState.Error) {
				bErrorFound = true;
				return bErrorFound;
			}

		});
		return bErrorFound;
	},

	onNumberChange: function(oEvent) {
		// If a number field is empty, an error occurs in the backend.
		// So this sets a missing number to "0".
		var oField = oEvent.getSource();
		var sNumber = oField.getValue();
		if (sNumber === "") {
			oField.setValue("0");
		}

		this._fieldChange(oField);
	},

	onCategoryChange: function() {
		// Do not use submitChanges because the subcategory determines the category and both
		// end up being blank. Only use submitChanges after the subcategory has been changed.
		this._setCategoryFilter(this._oView.getBindingContext());
		this.byId("subcategory").setValue(" ");

	},

	onInputChange: function(oEvent) {
		// Whenever the value of an input field is changed, the system must
		// update the product draft. For most of the fields, no specific
		// processing is required on the update of the product draft. onInputChange is the
		// change event defined in the XML view for such fields.
		var oField = oEvent.getSource();
		this._fieldChange(oField);
	},

	// Handler for a changed field that needs to be written to the draft.  This allows
	// specific processing for the "Change" event on the input fields, such as for numbers
	// to set empty to "0".
	_fieldChange: function(oControl) {

		var oFilter;
		var oSubCategory = this.byId("subcategory");
		this._setSaveButton();
		// If the category is changed and no new subcategory is selected, after
		// the next submitChanges, the backend sets the category to empty.
		// If this happens, the filter on the subcategory is removed.
		if (oSubCategory) {
			if (oSubCategory.getValue() === " " || oSubCategory.getValue() === "") {
				oFilter = [];
				oFilter.length = 0;
				oSubCategory.getBinding("items").filter([], sap.ui.model.FilterType.Application);
			}
		}
		// Removes previous error state
		oControl.setValueState(sap.ui.core.ValueState.None);

		// Callback function in the event that saving draft is unsuccessful
		var fnSubmitDraftError = function(oError) {
			// Note that with oData V2 requests are bundled into batches. Errors at the
			// batch level are picked up by the function defined in the mParameters.error
			// of the submitChanges call. These errors are at the batch level only.
			nw.epm.refapps.lib.reuse.util.messages.getErrorContent(oError);
			// Sets the Save button to disabled
			// this.setBtnEnabled("savebutton", false);
		};
		var fnSubmitDraftSuccess = function(sMessage) {
			if (sMessage && oControl) {
				oControl.setValueState("Error");
				oControl.setValueStateText(sMessage);
			}
		};
		this._oHelper.saveProductDraft(jQuery.proxy(fnSubmitDraftError, this), fnSubmitDraftSuccess);
	},

	_fnSubmitDraftSuccess: function(oControl, oData) {
		// When the batch of requests in oData V2 is successfully sent to the backend,
		// the mParameters.success in submitChanges is called. Errors relating to the
		// requests within the batch are not indicated separately and therefore the system must
		// check the requests contained in the batch for errors based on the request response.
		// Makes the assumption that the error returned relates to the field that has been
		// changed. This is not always the case and errors are shown in valueStateText
		// for the field that triggered the save of the draft.
		var i;
		for (i = 0; i < oData.__batchResponses.length; i++) {
			// jQuery.each(oData.__batchResponses, function(i, request) {
			if (oData.__batchResponses[i].response) {
				if (jQuery.sap.startsWith(oData.__batchResponses[i].response.body, "{\"error\":")) {
					var oErrModel = new sap.ui.model.json.JSONModel();
					oErrModel.setJSON(oData.__batchResponses[i].response.body);
					var sMessage = oErrModel.getProperty("/error/message/value");
					if (oControl) {
						oControl.setValueState("Error");
						oControl.setValueStateText(sMessage);
					}
					// this.setBtnEnabled("savebutton", false);
					// Just take the first error message found
					return false;

				}
			}
		}
		return true;

	},

	onSelectChange: function() {

		// Collect input controls.
		// Additional method for change event on SelectChanges because there is currently
		// no value status for a select field.
		this._setSaveButton();
		this._oHelper.saveSelectProductDraft();
	},

	// Save button is deactivated if one or more mandatory fields are not filled
	_setSaveButton: function() {
		// Sets the draft dirty flag to true
		this._bIsDraftDirty = true;

		// if (this._checkAndMarkEmptyMandatoryFields(false)) {
		// this.setBtnEnabled("savebutton", false);
		//
		// } else {
		// this.setBtnEnabled("savebutton", true);
		// }

	},
	// Set the empty mandatory fields to value state Error
	_checkAndMarkEmptyMandatoryFields: function() {
		var bErrors = false;

		// Check that inputs are not empty or space.
		// This does not happen during data binding because this is only triggered by changes.
		jQuery.each(this._aMandatoryFields, function(i, input) {
			if (!input.getValue() || input.getValue().trim() === "") {
				bErrors = true;
				input.setValueState(sap.ui.core.ValueState.Error);
			}
		});

		return bErrors;
	},

	// helper method to set image upload control
	_initSubViewImageUpload: function() {
		this._oEventBus.publish(this._sIdentity, "initViewData", {
			oResourceBundle: this._oResourceBundle,
			oDataHelper: this._oHelper,
			fnDirty: jQuery.proxy(this._setSaveButton, this)
		});
	},

	_getEmailSubject: function() {
		return this._oResourceBundle.getText("xtit.emailSubject", [this._oProduct.Name]);
	},

	_getEmailContent: function() {
		return this._oResourceBundle.getText("xtit.emailContent", [this._oProduct.Id, this._oProduct.Description,
                this._oProduct.SupplierName]);
	},

	_setCategoryFilter: function(oBindingContext) {

		var oSubCategory = this.byId("subcategory");
		var sMainCatgId = oBindingContext.getProperty("MainCategoryId");

		var oFilter = new sap.ui.model.Filter("MainCategoryName",
			sap.ui.model.FilterOperator.StartsWith, sMainCatgId);
		oSubCategory.getBinding("items").filter([oFilter], sap.ui.model.FilterType.Application);
	}

});