(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CloseIconWrapper");

    /**
     * @class This control adds a close icon in the top right corner of the controls contained in the content aggregation.
     * 
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>content : sap.ui.core.Control[] The controls to display.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>closeClicked : Raised when the close icon is clicked</li>
     * </ul>
     * </li>
     * </ul>
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.CloseIconWrapper
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.CloseIconWrapper",
    /** @lends jd.ui.eid.control.CloseIconWrapper */
    {
        metadata : {
            aggregations : {
                content : {
                    type : "sap.ui.core.Control",
                    multiple : true
                }
            },
            events : {
                closeClicked : {}
            }
        },

        /**
         * Add style class to control for branding.
         */
        init : function() {
            this.addStyleClass("jdUiEidCloseIconWrapper");
        },

        /**
         * Handle clicks on the close icon.
         * 
         * @param {sap.ui.core.Event}
         *            oEvent
         */
        onclick : function(oEvent) {
            if (oEvent.target.id == this.getId() + "-close") {
                this.fireCloseClicked(oEvent);
            }
        },

        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.writeClasses(oControl);
            oRm.write(">");

            // close icon
            oRm.write("<div id='" + oControl.getId() + "-close' class='jdUiEidCloseIconWrapperIcon'></div>");

            // render contents
            oRm.write("<div class='jdUiEidCloseIconWrapperContent'>");
            var aContent = oControl.getContent();
            for ( var i = 0; i < aContent.length; ++i) {
                oRm.renderControl(aContent[i]);
            }
            oRm.write("</div>");

            oRm.write("</div>");
        }
    });
})();