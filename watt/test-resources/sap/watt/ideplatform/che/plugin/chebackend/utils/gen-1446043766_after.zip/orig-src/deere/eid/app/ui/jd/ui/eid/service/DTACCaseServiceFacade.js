(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.DTACCaseServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    /**
     * @class The DTAC case service facade provides functionality to retrieve a list of DTAC cases or an individual DTAC case.
     * @name jd.ui.eid.service.DTACCaseServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.DTACCaseServiceFacade", /** @lends DTACCaseServiceFacade */
    {

        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleListBindingChanged : function(oListBinding) {
            // This is invoked if the filtering/sorting on the UI table changes.
            // If the list binding is relevant, then get the updated DTAC list based on new
            // filtering/sorting etc. This information is available inside oListBinding.
            if (oListBinding.sPath == '/DTACCaseList') {
                this.getDTACCaseList(oListBinding);
            }
        },

        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleDataRequested : function(oListBinding) {
            // This is invoked when there is paging on the UI table
            // If the list binding is relevant, then get the updated DTAC list based on the new
            // binding information (oListBinding)
            if (oListBinding.sPath == '/DTACCaseList') {
                this.getDTACCaseList(oListBinding);
            }
        },

        /**
         * Get the list of DTAC cases.
         * 
         * @memberOf jd.ui.eid.service.DTACCaseServiceFacade
         * 
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control.
         * @param {object}
         *            oCustomFilter contains the DTAC case custom control filter values.
         * @param {string}
         *            oEvidencePackage contains the filter values of the evidence package and the list of selected DTC codes.
         * @param {string}
         *            sSearchTerm the search string above of the DTAC case table. If there is no search term, this can be an empty string or null.
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getDTACCaseList : function(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "/xs/dtac/GetDTACCaseList.xsjs";

            // Set test data file name
            var sModelDataFileName = "getDTACCaseList_Response.json";

            // Prepare the custom payload for this service call
            var oArgs = {};
            oArgs.CustomFilter = oCustomFilter;
            oArgs.SearchTerm = sSearchTerm;
            oArgs.EvidencePackage = oEvidencePackage;

            // Prepare the fnGetListData callback. It accepts an object (JSON object of the server
            // response)
            // and returns an result object for DTAC cases containing the records count and an array
            // of the records.
            var fnGetDTACCaseListData = function(oData) {

                // Iterate over the list to mark those which are already in the evidence package
                var iDTACCount = that.oModel.getProperty("/EvidencePackageDetails/Header/DTACCaseList").length;
                if (iDTACCount > 0) {
                    var mDTACs = jd.ui.eid.model.EidModel.TransformationHelper.getDTACCaseMapFromEvidencePackageDetails();
                    var iMatches = 0;
                    $.each(oData.Result.DTACCaseList.Records, function(iIdx, mDTAC) {
                        if (mDTACs[mDTAC.DTACCaseNumber]) {
                            mDTAC._canBeAddedToEvidencePackage = false;
                            iMatches++;
                            if (iMatches == iDTACCount) {
                                return false; // break, we marked everything
                            }
                        }
                    });
                }

                return oData.Result.DTACCaseList;
            };

            var that = this;

            // Prepare the fnSuccess callback. It set's the values for the tagcloud filter
            var _fnSuccess = function(oData) {
                var oModel = that.oModel;
                var aTagCloud = oData.Result.TagCloud;

                // Set model properties
                oModel.setProperty("/DTACCaseFilters/DomainValues/TagCloud", aTagCloud);

                // call nested function
                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };

            // Invoke records retrieval
            this._retrieveList(sServicePath, _fnSuccess, fnError, fnGetDTACCaseListData, oBinding, oArgs, sModelDataFileName);
        },

        /**
         * Retrieve further details about a specific DTAC case.
         * 
         * @memberOf jd.ui.eid.service.DTACCaseServiceFacade
         * 
         * @param {int}
         *            iDTACCaseNumber the selected DTAC case number
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getDTACCaseDetails : function(iDTACCaseNumber, fnSuccess, fnError) {
            var sServicePath = "/xs/dtac/GetDTACCaseDetails.xsjs";
            var sModelPath = "/DTACCaseDetails";
            var oData = {
                DTACCaseNumbers : [iDTACCaseNumber]
            };

            var fnGetData = function(oData) {
                return oData.Result.DTACCaseDetails.Records[0];
            };

            var sModelFileName = "getDTACCaseDetails_Response.json";

            // Invoke record retrieval
            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName);
        }

    });

})();
