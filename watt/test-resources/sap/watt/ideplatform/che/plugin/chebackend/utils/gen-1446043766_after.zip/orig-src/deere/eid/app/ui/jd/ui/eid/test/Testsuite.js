(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.test.Testsuite");

    // Utility function to load qunit tests
    // This will require 'jd.ui.eid.test.<sName>.<sTypePrefix>.qunit.js'
    function _addTest(sName, sTypePrefix) {
        jd.ui.eid.require({
            modName : "jd.ui.eid.test." + sName,
            type : (sTypePrefix ? (sTypePrefix + ".qunit") : "qunit")
        });
    }

    // NB: add alphabetically and group by folder

    _addTest("jd-ui-eid-core");

    _addTest("application.Application");

    _addTest("common.formatter.DateTimeFormatter");
    _addTest("common.formatter.NumberFormatter");
    _addTest("common.validator.DateValidator");
    _addTest("common.DataLossManager");
    _addTest("common.DateHelper");
    _addTest("common.I18NHelper");
    _addTest("common.URLHandler");

    _addTest("control.CheckBoxFilterItem");
    _addTest("control.DateDistanceFilterItem");
    _addTest("control.DateRangeFilterItem");
    _addTest("control.FilterArea");
    _addTest("control.FilterItem");
    _addTest("control.HierarchyFilterItem");
    _addTest("control.InteractiveListBoxFilterItem");
    _addTest("control.ListBoxFilterItem");
    _addTest("control.TagCloudFilterItem");
    _addTest("control.TextAnalysisFilterItem");
    _addTest("control.ValueListItem");

    _addTest("model.EidModel");
    _addTest("model.EidModelListBinding");

    _addTest("service.BaseServiceFacade");
    _addTest("service.CustomizingServiceFacade");
    _addTest("service.DTACCaseServiceFacade");
    _addTest("service.DTCBlacklistServiceFacade");
    _addTest("service.DTCServiceFacade");
    _addTest("service.EvidencePackageServiceFacade");
    _addTest("service.FilterDomainValueServiceFacade");
    _addTest("service.PersonalizationFiltersServiceFacade");
    _addTest("service.WarrantyClaimServiceFacade");

    _addTest("view.main.worksheet.Evidence", "view");
    _addTest("view.main.Dashboard", "view");
    _addTest("view.main.Shell", "view");
})();