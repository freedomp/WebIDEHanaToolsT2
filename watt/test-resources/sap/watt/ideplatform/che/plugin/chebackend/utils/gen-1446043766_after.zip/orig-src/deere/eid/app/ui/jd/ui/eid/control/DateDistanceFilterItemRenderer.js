(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.DateDistanceFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer of control jd.ui.eid.control.DateDistanceFilterItemRenderer
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     * @name jd.ui.eid.control.DateDistanceFilterItemRenderer
     */
    jd.ui.eid.control.DateDistanceFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.DateDistanceFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     */
    jd.ui.eid.control.DateDistanceFilterItemRenderer._renderContent = function(oRm, oControl) {

        oRm.write("<div");
        oRm.addClass("jdUiEidListBoxFilterItemContent");
        oRm.writeClasses();
        oRm.write(">");

        oRm.write("<div");
        oRm.addClass("sapUiLbx");
        oRm.addClass("sapUiLbxFlexWidth");
        oRm.addClass("sapUiLbxStd");
        oRm.writeClasses();
        oRm.write(">");

        oRm.write("<ul");
        oRm.addClass("jdUiEidDateDistanceFilterItems");
        oRm.writeClasses();
        oRm.write(">");

        // Render custom items
        oRm.renderControl(oControl.getAggregation("customDateRangeItem"));
        oRm.renderControl(oControl.getAggregation("customDistanceItem"));

        // Render static items
        var aItems = oControl.getAggregation("items");
        if (aItems) {
            for ( var i = 0; i < aItems.length; i++) {
                oRm.renderControl(aItems[i]);
            }
        }

        oRm.write("</ul>");

        oRm.write("</div>");
        oRm.write("</div>");
    };

})();