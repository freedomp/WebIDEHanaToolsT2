(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");

    /**
     * Constructor for a new BaseDateDistanceToolPopupDelegate.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>allowEmpty : boolean (default: false) true if an empty date range is allowed, false otherwise.</li>
     * <li>fragmentId : string (default: undefined) The ID of the toolpopup fragement.</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>opener : jd.ui.eid.control.ValueListItem The valueListItem that opens the toolPopup.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>canceled : fired if the tool popup is canceled.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The BaseDateDistanceToolPopupDelegate contains all necessary handlers of the date distance toolpopup with a valueListItem as an opener.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate", /** @lends jd.ui.eid.common.delegate.BaseDateDistanceToolPopupDelegate */
    {

        metadata : {
            properties : {
                allowEmpty : {
                    type : "boolean",
                    defaultValue : false
                },
                fragmentId : "string"
            },
            associations : {
                opener : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                }
            },
            events : {
                canceled : {}
            }
        },

        /**
         * Get the valueListItem that opens the toolPopup
         * 
         * @return {jd.ui.eid.control.ValueListItem} the opener object.
         */
        _getOpener : function() {
            return sap.ui.getCore().byId(this.getAssociation("opener"));
        },

        /**
         * Gets the TextField where the user can enter a value
         * 
         * @returns {sap.ui.commons.TextField}
         */
        _getValueTextField : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "value");
        },

        /**
         * Gets the dropdown for unit of time
         * 
         * @returns {sap.ui.commons.DatePicker}
         */
        _getUnitDropdown : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "dropbox");
        },

        /**
         * Gets the tool popup.
         * 
         * @returns {sap.ui.ux3.ToolPopup}
         */
        _getToolPopup : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "DateDistanceToolPopup");
        },

        /**
         * Handles the change event of the custom date distance toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupChanged : function(oEvent) {
            // Trigger a validation
            this._validateDateDistanceToolPopupDistance();
        },

        /**
         * Validates the date distance toolpopup
         * 
         * @returns {boolean} True if valid, False otherwise.
         */
        _validateDateDistanceToolPopupDistance : function() {
            var bValid = false;
            var oInputField = this._getValueTextField();
            var sValue = oInputField.getValue();

            /* Check if the input field value is invalid: */
            if (sValue) {
                oInputField.setValueState(sap.ui.core.ValueState.None); // Set input field as valid
                oInputField.setTooltip(null); // Remove error callout
                bValid = true;
            } else {
                // Create a callout to indicate a invalid value
                var oCalloutText = new sap.ui.commons.TextView({
                    text : "{i18n>FILTER_ITEM_ERROR_INVALID_VALUE}"
                }).addStyleClass("jdUiTv");
                var oCallout = new sap.ui.commons.Callout({
                    content : oCalloutText
                }).addStyleClass("jdUiClt");

                oInputField.setValueState(sap.ui.core.ValueState.Error); // Set input field as
                // invalid
                // invalid
                oInputField.setTooltip(oCallout); // Set error callout to field
                bValid = false;
            }

            return bValid;
        },

        /**
         * Validate the keypress event on the date distance input field: Only numbers should be allowed
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        _validateDateDistanceToolPopupDistanceLiveInput : function(oEvent) {
            // Check whether typed key is not "Enter" and typed key does not refer to a number
            if (oEvent.keyCode != 13 && oEvent.keyCode < 48 || oEvent.keyCode > 57) {
                // Prevent the user input from being show in the input field
                oEvent.stopPropagation();
                oEvent.preventDefault();
                return;
            }
        },

        /**
         * Checks whether the user's input is empty
         * 
         * @returns {boolean} true if the fields in the toolpopup are empty, false otherwise.
         */
        _isUserInputEmpty : function() {
            if (!this._getValueTextField().getValue()) {
                return true;
            }
            return false;
        },

        /**
         * Checks whether the source of the date range is empty.
         * 
         * @returns {boolean} true if the source is empty, false otherwise.
         */
        _isSourceEmpty : function() {
            if (!(this._getOpener().getValue().duration || this._getOpener().getValue().unit)) {
                return true;
            }
            return false;
        },

        /**
         * Populates the values from the source to the controls in the tool popup.
         */
        _populateToolPopupValues : function() {
            if (this._getOpener().getValue().duration) {
                this._getValueTextField().setValue(this._getOpener().getValue().duration);
            }
            if (this._getOpener().getValue().unit) {
                this._getUnitDropdown().setSelectedKey(this._getOpener().getValue().unit);
            }
        },

        /**
         * Create the open event handler of the custom date range item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupOpen : function(oEvent) {
            if (!(this._isSourceEmpty() && this.getAllowEmpty())) {
                this._populateToolPopupValues();
                this._validateDateDistanceToolPopupDistance();
            } else {
                // If we don't validate it, the fields might still be flagged as invalid from the last time.
                var oValueTextField = this._getValueTextField();
                // Set the datepickers as valid
                oValueTextField.setValueState(sap.ui.core.ValueState.None);
                // Remove the error callouts
                oValueTextField.setTooltip(null);
            }

            // Attach keypress event handler to avoid non numeric values at oInputField
            this._getValueTextField().attachBrowserEvent("keypress", $.proxy(this._validateDateDistanceToolPopupDistanceLiveInput, this));
        },

        /**
         * Updates the source based on the values from the tool popup.
         */
        _updateSource : function() {
            this._getOpener().changeValue({
                duration : this._getValueTextField().getValue(),
                unit : this._getUnitDropdown().getSelectedKey()
            });
        },

        /**
         * Handles the event of the "submit button pressed" / "enter pressed"-event at the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupSubmit : function(oEvent) {
            if (!(this._isUserInputEmpty() && this.getAllowEmpty())) {
                if (this._validateDateDistanceToolPopupDistance()) {
                    this._updateSource();
                    this._getToolPopup().close(0);
                }
            } else if (this._isUserInputEmpty()) {
                this._updateSource();
                this._getToolPopup().close(0);
            }
        },

        /**
         * Handles the cancel event of the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateDistanceToolPopupCancel : function(oEvent) {
            var oDateRangeToolPopup = this._getToolPopup();
            oDateRangeToolPopup.close(0);
            this.fireCanceled();
        }
    });
})();