(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.DateRangeFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer for control jd.ui.eid.control.DateRangeFilterItem.
     * 
     * @class
     * @name jd.ui.eid.control.DateRangeFilterItemRenderer
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     */
    jd.ui.eid.control.DateRangeFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.DateRangeFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer
     * @param {jd.ui.eid.control.DateRangeFilterItem}
     *            oControl The control to be rendered
     * 
     * @memberOf jd.ui.eid.control.DateRangeFilterItemRenderer
     */
    jd.ui.eid.control.DateRangeFilterItemRenderer._renderContent = function(oRm, oControl) {
        oRm.write("<div>");
        oRm.renderControl(oControl.getAggregation("_fromLabel"));
        oRm.renderControl(oControl.getAggregation("_startDatePicker"));
        oRm.write("</div><div>");
        oRm.renderControl(oControl.getAggregation("_toLabel"));
        oRm.renderControl(oControl.getAggregation("_endDatePicker"));
        oRm.write("</div>");
    };

})();