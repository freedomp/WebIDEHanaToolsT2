(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.DataFetchPrintStep");
    jQuery.sap.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new DataFetchPrintStep.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>chartRenderAreaId : string (default: '') the id of the chart area element (should be hidden, the chart control will be rendered there).</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>chartPrintContainer : jd.ui.eid.control.ChartPrintContainer the chart print container to be managed by the step.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The DataFetchPrintStep manages a single {@link jd.ui.eid.control.ChartPrintContainer} control and triggers the rendering and
     *        manipulation of a chart for printing (in {@link #._process}). The step is notified via the <code>chartRendered</code> event of the
     *        chart print container when the chart is rendered. This event also indicates that the print step is complete and triggers the
     *        <code>processed</code event.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.DataFetchPrintStep
     */
    jd.ui.eid.common.print.PrintStep.extend("jd.ui.eid.common.print.DataFetchPrintStep", /** @lends jd.ui.eid.common.print.DataFetchPrintStep */
    {
        metadata : {
            properties : {
                facade : {
                    type : "string",
                    defaultValue : ""
                },
                method : {
                    type : "string",
                    defaultValue : ""
                },
                parameters : {
                    type : "object",
                    defaultValue : []
                }
            }
        },

        /**
         * Triggers the rendering of the chart association with the chart print container.
         */
        _process : function() {
            $.sap.log.debug("Fetching data from facade " + this.getFacade() + " and method " + this.getMethod());
            var that = this;
            var oFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade(this.getFacade());
            var fnMethod = oFacade[this.getMethod()];
            if (!(typeof fnMethod === 'function')) {

            }
            var aParameters = this.getParameters();
            var aArguments = $.extend([], aParameters);
            // Success callback
            aArguments.push(function() {
                $.sap.log.debug("Successfully fetched data from facade " + that.getFacade() + " and method " + that.getMethod());
                that.fireProcessed();
            });
            // Success callback
            aArguments.push(function() {
                $.sap.log.debug("Failed fetching data from facade " + that.getFacade() + " and method " + that.getMethod());
                that.fireProcessed();
            });
            // var oChartPrintContainer = this._getChartPrintContainer();
            // oChartPrintContainer.attachEventOnce("chartRendered", this._handleChartRendered, this);
            // this._getChartRenderArea().html("");
            // oChartPrintContainer.renderChart(this._getChartRenderArea());
            // this.fireProcessed();

            // Invoke facade
            fnMethod.apply(oFacade, aArguments);
        }
    });
})();