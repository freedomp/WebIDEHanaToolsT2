(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.main.shared.EPSummaryChartController");
    jQuery.sap.require("jd.ui.eid.common.chart.ChartHelper");

    /**
     * @class
     * <p>
     * The EPSummaryChartController provides reusable functionality for the detail charts of a Evidence Package Summary.
     * </p>
     * <p
     * </p>
     * <p>
     * The view has the following hook methods which need to be called from the consuming controller in the life cycle:
     * <ul>
     * <li>{@link #.initEPSummaryChartsInFragment} has to be called from <code>onInit</code></li>
     * <li>{@link #.onEPSummaryChartControllerAfterRendering} has to be called from <code>onAfterRendering</code>.</li>
     * <li>{@link #.exitEPSummaryChartController} has to be called from <code>onExit</code></li>
     * </ul>
     * </p>
     * <p>
     * Used in:
     * <ul>
     * <li>{@link jd.ui.eid.view.main.evidencepackage.EvidencePackageSummaryChart.controller}</li>
     * <li>{@link jd.ui.eid.view.print.EvidencePackage}</li>
     * </ul>
     * 
     * @static
     * @name jd.ui.eid.view.main.shared.DTCChartController
     */
    jd.ui.eid.view.main.shared.EPSummaryChartController = {

        /**
         * Initializes the charts in the given fragment.
         * 
         * 
         * 
         */
        initEPSummaryChartsInFragment : function() {
            // Store references to all the charts
            var sViewId = this.getView().getId();
            this._oRunningSumbyDate = sap.ui.core.Fragment.byId(sViewId, "RunningSumbyDate");
            this._oAccTotalCostDistPins = sap.ui.core.Fragment.byId(sViewId, "AccTotalCostDistPins");
            this._oAccTotalCost = sap.ui.core.Fragment.byId(sViewId, "AccTotalCost");
            this._AggregatedDTCCountbyEngineHours = sap.ui.core.Fragment.byId(sViewId, "AggregatedDTCCountbyEngineHours");
            this._oWarrantyClaimCostsByBuildDate = sap.ui.core.Fragment.byId(sViewId, "WarrantyClaimCostsByBuildDate");
            this._oWarrantyClaimCountByBuildDate = sap.ui.core.Fragment.byId(sViewId, "WarrantyClaimCountByBuildDate");
            this._oWarrantyClaimCostsByPrimePart = sap.ui.core.Fragment.byId(sViewId, "WarrantyClaimCostsByPrimePart");

            this._aAllDTCCharts = [this._oRunningSumbyDate, this._oAccTotalCostDistPins, this._oAccTotalCost, this._AggregatedDTCCountbyEngineHours,
                    this._oWarrantyClaimCostsByBuildDate, this._oWarrantyClaimCountByBuildDate, this._oWarrantyClaimCostsByPrimePart];

            this.turnOffEPSummaryChartAnimations();
            this.setEPSummaryChartHeight();

        },

        /**
         * Hook to be called in onAfterRendering.
         */
        onEPSummaryChartControllerAfterRendering : function() {
            jd.ui.eid.common.chart.ChartHelper.rerenderCharts('jdVizChart', this._aAllDTCCharts);
        },

        /**
         * Cleans up the merge controller. Should be called from <code>onExit</code>.
         */
        exitEPSummaryChartController : function() {
            this._oRunningSumbyDate = null;
            this._oAccTotalCostDistPins = null;
            this._oAccTotalCost = null;
            this._AggregatedDTCCountbyEngineHours = null;
            this._oWarrantyClaimCostsByBuildDate = null;
            this._oWarrantyClaimCountByBuildDate = null;
            this._oWarrantyClaimCostsByPrimePart = null;
        },

        /**
         * Turns the chart animations off.
         */
        turnOffEPSummaryChartAnimations : function() {
            var bUseColorPalette = true;

            jd.ui.eid.common.chart.ChartHelper.prepareLineChart(this._oRunningSumbyDate);

            jd.ui.eid.common.chart.ChartHelper.prepareDualCombinationChart(this._oAccTotalCostDistPins);

            jd.ui.eid.common.chart.ChartHelper.prepareStackedVerticalBarChart(this._oAccTotalCost, bUseColorPalette);

            jd.ui.eid.common.chart.ChartHelper.prepareLineChart(this._AggregatedDTCCountbyEngineHours);

            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oWarrantyClaimCostsByBuildDate, "INTEGER", bUseColorPalette);

            jd.ui.eid.common.chart.ChartHelper.prepareVerticalBarChart(this._oWarrantyClaimCountByBuildDate, "INTEGER", bUseColorPalette);

            jd.ui.eid.common.chart.ChartHelper.preparePieChart(this._oWarrantyClaimCostsByPrimePart);

        },

        /**
         * setup the width and height of the charts
         */
        setEPSummaryChartHeight : function() {
            this._aAllDTCCharts.forEach(function(oChart) {
                oChart.setHeight("300px");
            });

        }

    };
})();