(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.FilterArea");

    /**
     * The FilterArea control provides a labeled container for filter items and a tool popup which can be used to plug in any control (preferably
     * {@link sap.ui.commons.Link}). It provides logic to clear or reset all filter items of the item aggregation. This calls the _clear(),
     * respectively _reset() and shouldn't trigger the cleared or reset event of the filter items.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>caption : string (default: '') The caption of the filter area.</li>
     * <li>enabled : boolean (default: true) True if the control should be enabled, false otherwise.</li>
     * <li>matches : string (default: '') The number of matches for the filter criteria.</li>
     * <li>matchLabel : string (default: '') The label displayed along with the number of matches.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>items : jd.ui.eid.control.FilterItem[] The filter items to display.</li>
     * <li>actionItems : sap.ui.commons.ToolbarItem[] The items that that are displayed in the toolbar.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.FilterArea
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.FilterArea", /** @lends jd.ui.eid.control.FilterArea */
    {
        metadata : {
            properties : {
                caption : {
                    type : "string",
                    defaultValue : ""
                },
                enabled : {
                    type : "boolean",
                    defaultValue : true
                },
                matches : {
                    type : "string",
                    defaultValue : '0'
                },
                matchLabel : {
                    type : "string",
                    defaultValue : ""
                }
            },

            aggregations : {
                action : {
                    type : "sap.ui.core.Control",
                    multiple : false
                },
                items : {
                    type : "jd.ui.eid.control.FilterItem",
                    multiple : true,
                    singularName : "item"
                }
            }
        },

        /**
         * Initialize the control and its internal aggregations.
         */
        init : function() {
            // this.setAggregation("_actionBar", new sap.ui.commons.Toolbar().addStyleClass("jdUiEidFilterAreaActionBar"));
        },

        /* Control Logic */

        /**
         * Clear the filter area by calling _clear on all items.
         */
        clear : function() {
            var aItems = this.getItems();
            for ( var i = 0; i < aItems.length; i++) {
                var oItem = aItems[i];
                if (oItem._clear) {
                    oItem._clear();
                }
            }
        },

        /**
         * Resets the filter area by calling _reset in all items.
         */
        reset : function() {
            var aItems = this.getItems();
            for ( var i = 0; i < aItems.length; i++) {
                var oItem = aItems[i];
                if (oItem._reset) {
                    oItem._reset();
                }
            }
        },

        /* Control Rendering */

        /**
         * Renders the control.
         * 
         * @param {sap.ui.core.RenderManager}
         *            oRm The RenderManager that can be used for writing to the render output buffer.
         * @param {jd.ui.eid.control.FilterArea}
         *            oControl The control that should be rendered.
         */
        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addClass("jdUiEidFilterArea");
            if (!oControl.getEnabled()) {
                oRm.addClass("jdUiEidFilterAreaDisabled");
            }
            oRm.writeClasses();
            oRm.write(">");

            oRm.write("<div");
            oRm.addClass("jdUiEidFilterAreaDisabledLayer");
            oRm.writeClasses();
            oRm.write(">");
            oRm.write("</div>");

            // Header Start
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterAreaHeader");
            oRm.writeClasses();
            oRm.write(">");

            oRm.write("<div");
            oRm.addClass("jdUiEidFilterAreaCaption");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getCaption());
            oRm.write("</div>");

            if (oControl.getMatches() && oControl.getMatchLabel()) {
                // If neither of the properties is set, we can spare the entire element.
                oRm.write("<div");
                oRm.addClass("jdUiEidFilterAreaMatches");
                oRm.writeClasses();
                oRm.write(">");
                oRm.write("<span");
                oRm.addClass("jdUiEidFilterAreaMatchCount");
                oRm.writeClasses();
                oRm.write(">");
                oRm.write(oControl.getMatches());
                oRm.write("</span>");
                oRm.write("<span");
                oRm.addClass("jdUiEidFilterAreaMatchLabel");
                oRm.writeClasses();
                oRm.write(">");
                oRm.writeEscaped(oControl.getMatchLabel());
                oRm.write("</span>");
                oRm.write("</div>");
            }

            oRm.renderControl(oControl.getAggregation("action").addStyleClass("jdUiEidFilterAreaActionBar"));

            oRm.write("</div>");
            // Header End

            // Content Start
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterAreaContent");
            oRm.writeClasses();
            oRm.write(">");

            var aItems = oControl.getItems();
            if (aItems) {
                for ( var i = 0; i < aItems.length; ++i) {
                    var oItem = aItems[i];
                    oRm.renderControl(oItem);
                }
            }

            oRm.write("</div>");
            // Content End

            oRm.write("</div>");
        }
    });

})();