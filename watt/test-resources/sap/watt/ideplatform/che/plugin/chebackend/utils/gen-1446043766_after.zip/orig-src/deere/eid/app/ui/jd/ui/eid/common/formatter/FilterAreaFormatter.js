(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.formatter.FilterAreaFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");

    /**
     * @class Static class providing formatters for filter areas.
     * @static
     * @name jd.ui.eid.common.formatter.FilterAreaFormatter
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter = {};

    /**
     * Formats engine hours to a proper range
     * 
     * @memberOf jd.ui.eid.common.FilterAreaFormatter
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatEngineHourSegment = function(fLowerBound, fUpperBound) {
        if (!fUpperBound) {
            return jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_RANGE_OPEN", [fLowerBound]);
        } else {
            return jd.ui.eid.common.I18NHelper.getText("ENGINE_HOURS_FORMAT_TXT_RANGE", [fLowerBound, fUpperBound]);
        }
    };

    /**
     * Formats the build date into a string for the read only filter area.
     * 
     * @param {object}
     *            mDate the build date.
     * @param {string}
     *            mDate.Start the start date in format YYYY-MM-DD
     * @param {string}
     *            mDate.End the end date in format YYYY-MM-DD
     * @returns {string} Formatted date range.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyBuildDate = function(mDate) {
        if (mDate && mDate.Start && mDate.End) {
            var sFrom = jd.ui.eid.common.DateHelper.hyphenizedDateToFormattedDate(mDate.Start), sTo = jd.ui.eid.common.DateHelper
                    .hyphenizedDateToFormattedDate(mDate.End);
            return jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FORMAT_TXT_RANGE", [sFrom, sTo]);
        } else {
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_NO_BUILD_DATE_SELECTED");
        }
    };

    /**
     * Formats the selection from a list (item id) into the display text from the domain values for the read only filter area.
     * 
     * @param {string}
     *            sID the id of the item.
     * @param {array}
     *            aDomainValues an array of domain values, consisting of objects with a <code>ID</code> property and a <code>Name</code> property.
     * @returns {string} The corresponding name from the domain values.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyListSelection = function(sID, aDomainValues) {
        if (aDomainValues) {
            for ( var i = 0, l = aDomainValues.length; i < l; ++i) {
                if (sID == aDomainValues[i].ID) {
                    return aDomainValues[i].Name;
                }
            }
        } else {
            jQuery.sap.log.warning("DomainValue.ID not found for key " + sID, null,
                    "jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyListSelection");
            return sID;
        }
    };

    /**
     * Formats the DTC capture time into a string for the read only filter area.
     * 
     * @param {object}
     *            mDate the DTC capture time date
     * @param {string}
     *            mDate.Start the start date in JSON format
     * @param {string}
     *            mDate.End the end date in JSON format
     * @returns {string} Formatted date range.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyDTCCaptureTime = function(mDate) {
        if (mDate && mDate.Start && mDate.End) {
            var sFrom = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(mDate.Start), sTo = jd.ui.eid.common.DateHelper
                    .JSONDateToFormattedDate(mDate.End);
            return jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FORMAT_TXT_RANGE", [sFrom, sTo]);
        } else {
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_NO_DTC_CAPTURE_TIME_SELECTED");
        }
    };

    /**
     * Returns the text to show on a read only Noise Reduction filter selection display.
     * 
     * @param {boolean}
     *            bValue selected value
     * @returns {string} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyNoiseReduction = function(bValue) {
        if (bValue) {
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_NOISE_REDUCTION_ON");
        } else {
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_NOISE_REDUCTION_OFF");
        }
    };

    /**
     * Returns the text to show for trend range for read only filters.
     * 
     * @param {object}
     *            mDate
     * @param {string}
     *            mDate.Start JSON date for start.
     * @param {string}
     *            mDate.End JSON date for end.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyTrendRange = function(mDate) {
        if (mDate && mDate.Start && mDate.End) {
            var sFrom = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(mDate.Start), sTo = jd.ui.eid.common.DateHelper
                    .JSONDateToFormattedDate(mDate.End);
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_TREND_RANGE_FORMAT", [sFrom, sTo]);
        } else {
            return jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_RO_TXT_NO_TREND_RANGE_SELECTED");
        }
    };

    /**
     * Returns the text to show on a read only Test Machine filter selection display.
     * 
     * @param {string}
     *            sKey selected key
     * @returns {string} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyTestMachine = function(sKey) {
        var sTextKey;
        if (sKey == "E") {
            sTextKey = "DTC_FILTERS_RO_TXT_EXCLUDE_TEST_MACHINES";
        } else if (sKey == "I") {
            sTextKey = "DTC_FILTERS_RO_TXT_ONLY_TEST_MACHINES";
        } else {
            sTextKey = "DTC_FILTERS_RO_TXT_ALL_MACHINES";
        }
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Returns the text to show on a read only Date Distance filter selection display.
     * 
     * @param {object}
     *            oSelection selection object
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyDateDistanceFilterItem = function(oSelection) {
        var oDayDistance = {
            Duration : 1,
            Unit : 'day'
        };
        var oWeekDistance = {
            Duration : 1,
            Unit : 'week'
        };
        var oWeeksDistance = {
            Duration : 2,
            Unit : 'week'
        };
        var oMonthDistance = {
            Duration : 1,
            Unit : 'month'
        };

        // Check the selection object
        if (oSelection) {

            // Check if a custom distance was set
            if (oSelection.Type == "Absolute" && oSelection.CustomStartDate && oSelection.CustomEndDate) {
                // Get from/to datepicker formatted values if type is Absolute
                var dFrom = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.CustomStartDate);
                var dTo = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.CustomEndDate);

                // Return the Date Range value
                return jd.ui.eid.common.formatter.DateTimeFormatter.formatDateRangeValueListItemText(dFrom, dTo);
            }

            // Check if a custom date range was set
            else if (oSelection.Type == "Relative" && oSelection.CustomDuration && oSelection.CustomDuration >= 0 && oSelection.Duration == null) {
                // Get the unit and duration in days
                var sUnit = oSelection.CustomUnit;
                var iDuration = oSelection.CustomDuration;

                // Set the text of the date distance list item
                return jd.ui.eid.common.formatter.DateTimeFormatter.formatDateDistanceValueListItemText(iDuration, sUnit);
            }

            // Check if the date range is 1 day from DTC
            else if (oSelection.Type == "Relative" && oSelection.Duration == oDayDistance.Duration && oSelection.Unit == oDayDistance.Unit) {
                return jd.ui.eid.common.I18NHelper.getText('DATE_DISTANCE_FILTER_ITEM_FLD_ONE_DAY_DISTANCE');
            }

            // Check if the date range is 1 week from DTC
            else if (oSelection.Type == "Relative" && oSelection.Duration == oWeekDistance.Duration && oSelection.Unit == oWeekDistance.Unit) {
                return jd.ui.eid.common.I18NHelper.getText('DATE_DISTANCE_FILTER_ITEM_FLD_ONE_WEEK_DISTANCE');
            }

            // Check if the date range is 2 weeks from DTC
            else if (oSelection.Type == "Relative" && oSelection.Duration == oWeeksDistance.Duration && oSelection.Unit == oWeeksDistance.Unit) {
                return jd.ui.eid.common.I18NHelper.getText('DATE_DISTANCE_FILTER_ITEM_FLD_TWO_WEEKS_DISTANCE');
            }

            // Check if the date range is 1 month from DTC
            else if (oSelection.Type == "Relative" && oSelection.Duration == oMonthDistance.Duration && oSelection.Unit == oMonthDistance.Unit) {
                return jd.ui.eid.common.I18NHelper.getText('DATE_DISTANCE_FILTER_ITEM_FLD_ONE_MONTH_DISTANCE');
            }

            else {
                return null;
            }
        }

        return null;
    };

    /**
     * Returns the text to show on a read only Creation Date filter selection display.
     * 
     * @param {object}
     *            oSelection selection object
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyCreationDateFilterItem = function(oSelection) {
        var sText = jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyDateDistanceFilterItem(oSelection);
        return (sText != null ? sText : jd.ui.eid.common.I18NHelper.getText('DTAC_CASE_FILTERS_RO_TXT_NO_CREATION_DATE'));
    };

    /**
     * Returns the text to show on a read only Failure Date filter selection display.
     * 
     * @param {object}
     *            oSelection selection object
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyFailureDateFilterItem = function(oSelection) {
        var sText = jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyDateDistanceFilterItem(oSelection);
        return (sText != null ? sText : jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_FILTERS_RO_TXT_NO_FAILURE_DATE'));
    };

    /**
     * Returns the text to show for the search mode on a read only Text Analysis filter.
     * 
     * @param {string}
     *            sSearchMode selected search mode
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyTextAnalysisSearchMode = function(sSearchMode) {
        // Set search mode constants
        var sCompareSearchMode = "Similarity";
        var sExactSearchMode = "Exact";
        var sNearSearchMode = "Fuzzy";

        if (sSearchMode == sCompareSearchMode) {
            return jd.ui.eid.common.I18NHelper.getText('TEXT_ANALYSIS_FILTER_ITEM_FLD_DTAC_CASE_COMPARE_SEARCH');
        } else if (sSearchMode == sExactSearchMode) {
            return jd.ui.eid.common.I18NHelper.getText('TEXT_ANALYSIS_FILTER_ITEM_FLD_EXACT_SEARCH');
        } else if (sSearchMode == sNearSearchMode) {
            return jd.ui.eid.common.I18NHelper.getText('TEXT_ANALYSIS_FILTER_ITEM_FLD_NEAR_SEARCH');
        }
    };

    /**
     * Returns the text to show for the search mode on a read only DTAC Case Text Analysis filter.
     * 
     * @param {string}
     *            sSearchMode selected search mode
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyAutomaticCaseTextAnalysisSearchMode = function(sSearchMode) {
        var sText = jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyTextAnalysisSearchMode(sSearchMode);
        return (sText != null ? sText : jd.ui.eid.common.I18NHelper.getText('DTAC_CASE_FILTERS_RO_TXT_NO_TEXT_ANALYSIS'));
    };

    /**
     * Returns the text to show for the search mode on a read only Warranty Claim Text Analysis filter.
     * 
     * @param {string}
     *            sSearchMode selected search mode
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatReadOnlyAutomaticClaimTextAnalysisSearchMode = function(sSearchMode) {
        var sText = jd.ui.eid.common.formatter.FilterAreaFormatter._formatReadOnlyTextAnalysisSearchMode(sSearchMode);
        return (sText != null ? sText : jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_FILTERS_RO_TXT_NO_TEXT_ANALYSIS'));
    };

    /**
     * Returns the text to show for the search mode on a read only Text Analysis filter.
     * 
     * @param {boolean}
     *            bJDLinkActive JDLink Machines flag
     * @return {strings} text to show
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatJDLinkMachinesFlag = function(bJDLinkActive) {
        if (bJDLinkActive) {
            return jd.ui.eid.common.I18NHelper.getText('DTAC_CASE_FILTERS_LST_JDLINK_ACTIVE');
        } else {
            return jd.ui.eid.common.I18NHelper.getText('DTAC_CASE_FILTERS_LST_JDLINK_INACTIVE');
        }
    };

    /**
     * Formats factory code and name into a concatenated string (e.g. for build factory and design factory filters).
     * 
     * @param {string}
     *            sFactoryCode the factory code.
     * @param {string}
     *            sFactoryName the factory name.
     * @returns {string} concatenated string representing a factory.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatFactory = function(sFactoryCode, sFactoryName) {
        var sStr = "";
        if (sFactoryCode && sFactoryName) {
            // If factory code is available
            sStr = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_FACTORY_CODE_NAME_FORMATTER", [sFactoryCode, sFactoryName]);
        } else if (sFactoryCode) {
            sStr = sFactoryCode;
        } else if (sFactoryName) {
            sStr = sFactoryName;
        }
        return sStr;
    };

    /**
     * Formats branch code into a concatenated string.
     * 
     * @param {string}
     *            sBranchCodeID the branch code id.
     * @param {string}
     *            sBranchCodeName the branch code name.
     * @returns {string} concatenated string representing a branch code.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatBranchCode = function(sBranchCodeID, sBranchCodeName) {
        var sStr = "";
        if (sBranchCodeID && sBranchCodeName) {
            // If factory code is available
            sStr = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_BRANCH_CODE_NAME_FORMATTER", [sBranchCodeID, sBranchCodeName]);
        } else if (sBranchCodeID) {
            sStr = sBranchCodeID;
        } else if (sBranchCodeName) {
            sStr = sBranchCodeName;
        }
        return sStr;
    };

    /**
     * Formats a id-name pair.
     * 
     * @param {string}
     *            sID the id.
     * @param {string}
     *            sName the name.
     * @returns {string} concatenated string.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatIDAndNamePair = function(sID, sName) {
        var sStr = "";
        if (!sID && !sName) {
            sStr = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_DOMAIN_VALUE_UNAVAILABLE");
        } else if (sID == sName) {
            // If ID and Name are the same, we only display one of them
            sStr = sName;
        } else if (sID && sName) {
            // If both are available and different
            sStr = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_ID_NAME_FORMATTER", [sID, sName]);
        } else if (sID) {
            sStr = sID;
        } else if (sName) {
            sStr = sName;
        }
        return sStr;
    };

    /**
     * Formats the visibility of the control displaying the DTCs for text analysis.
     * 
     * @param {string}
     *            sSearchMode the search mode of the text analysis
     * @returns {boolean} true if the search mode is provided, false otherwise.
     */
    jd.ui.eid.common.formatter.FilterAreaFormatter.formatTextAnalysisDTCVisibility = function(sSearchMode) {
        return !!sSearchMode;
    };

})();