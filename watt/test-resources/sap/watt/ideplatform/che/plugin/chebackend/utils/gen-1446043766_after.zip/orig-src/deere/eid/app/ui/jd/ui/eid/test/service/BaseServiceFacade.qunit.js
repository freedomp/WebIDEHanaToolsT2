(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oServiceFacade = new jd.ui.eid.service.BaseServiceFacade("http://sap.com", "jd/ui/eid/asset/data/", oModel, false);
    var oDataGetResponse = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/template.json").data;

    // Module for BaseServiceFacade Testing
    module("jd.ui.eid.service.BaseServiceFacade", {
        setup : function() {

            // Start spying on AJAX requests
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };

            // Start spying on methods
            sinon.spy(oServiceFacade, "_executeAjax");

        },
        teardown : function() {
            // Stop spying on AJAX requests
            this.xhr.restore();

            // Stop spying on methods
            oServiceFacade._executeAjax.restore();
        }
    });

    // *** TEST CASE #1 ***
    test("_executeAjax() should make an AJAX call", function() {

        equal(0, this.requests.length);

        oServiceFacade._executeAjax("");

        equal(1, this.requests.length);

    });

    // *** TEST CASE #2 ***
    test("_executeAjax() should call the passed success function after receiving status code HTTP 2xx", function() {

        // Define success spy
        var fnSuccess = sinon.spy();

        // Call test function
        oServiceFacade._executeAjax("", fnSuccess);

        // Send fake response
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));

        // Check if fnSuccess was called
        ok(fnSuccess.called);

    });

    // *** TEST CASE #3 ***
    test("_executeAjax() should call the passed error function after receiving status code HTTP 5xx", function() {
        // Define error spy
        var fnError = sinon.spy();

        // Call test function
        oServiceFacade._executeAjax("", null, fnError);

        // Send fake response
        this.requests[0].respond(500, {
            "Content-Type" : "application/json"
        }, "Internal Server Error");

        // Check if fnError was called
        ok(fnError.called);

    });

    // *** TEST CASE #4 ***
    test("_retrieveList() should make an AJAX call", function() {

        equal(0, this.requests.length);

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
        oServiceFacade._retrieveList("", null, null, null, oListBinding);

        equal(1, this.requests.length);

    });

    // *** TEST CASE #5 ***
    test("_retrieveList() should call the function fnGetData() after receiving status code HTTP 2xx", function() {

        var fnGetData = sinon.spy();

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");

        oServiceFacade._retrieveList("", null, null, fnGetData, oListBinding);

        // Send fake response
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));

        // Check if fnGetData was called
        ok(fnGetData.called);

    });

    // *** TEST CASE #6 ***
    test("_retrieveList() should call the passed success function after receiving status code HTTP 2xx", function() {

        // Define success spy
        var fnSuccess = sinon.spy();

        var fnGetData = function(oData) {
            return oData.Result.DTCList;
        };

        oModel.setProperty("/test6", fnGetData(oDataGetResponse));

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/test6");
        oListBinding.iTop = 5;
        oListBinding.iSkip = 0;

        oServiceFacade._retrieveList("", fnSuccess, null, fnGetData, oListBinding);

        // Send fake response
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));

        // Check if fnSuccess was called
        ok(fnSuccess.called);

    });

    // *** TEST CASE #7 ***
    test("_retrieveList() should call the passed error function after receiving status code HTTP 5xx", function() {

        // Define error spy
        var fnError = sinon.spy();

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
        oServiceFacade._retrieveList("", null, fnError, null, oListBinding);

        // Send fake response
        this.requests[0].respond(500, {
            "Content-Type" : "application/json"
        }, "Internal Server Error");

        // Check if error was called
        ok(fnError.called);

    });

    // *** TEST CASE #8 ***
    test("_retrieveList() should raise the event 'requestFailed' if flag bCalledFromBinding was set and server returns status code HTTP 5xx",
            function() {

                // Set flags
                oServiceFacade.bCalledFromBinding = true;

                var fnCallback = sinon.spy();

                oServiceFacade.attachRequestFailed(fnCallback);

                var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
                oServiceFacade._retrieveList("", null, null, null, oListBinding);

                // Send fake response
                this.requests[0].respond(500, {
                    "Content-Type" : "application/json"
                }, "Internal Server Error");

                // Check if event was raised and callback function was called
                ok(fnCallback.called);

                // Reset flags
                oServiceFacade.bCalledFromBinding = false;

            });

    // *** TEST CASE #9 ***
    test("_retrieveList() should call the method 'reset' on EidModelListBinding (which resets Top/Skip values) if the parameter oData was set",
            function() {

                var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
                oListBinding.iTop = -1;
                oListBinding.iSkip = -1;

                var oData = {
                    "Filters" : []
                };

                oServiceFacade._retrieveList("", null, null, null, oListBinding, oData);

                equal(oListBinding.iDefaultTop, oListBinding.iTop);
                equal(0, oListBinding.iSkip);

            });

    // *** TEST CASE #10 ***
    test("_retrieveList() should add the new 'oData' value to the payload of the server request.", function() {

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
        var oData = {
            "Filters" : []
        };

        oServiceFacade.bCalledFromBinding = false;
        oServiceFacade._retrieveList("", null, null, null, oListBinding, oData);

        var oPayload = oServiceFacade._executeAjax.getCall(0).args[3];

        equal(oPayload.Data.Filters.length, oData.Filters.length);

    });

    // *** TEST CASE #11 ***
    test("_retrieveList() should add the old 'oData' value to the payload of the server request.", function() {

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "");
        var oData = {
            "Filters" : []
        };

        oServiceFacade._retrieveList("", null, null, null, oListBinding, oData);

        oServiceFacade._retrieveList("", null, null, null, oListBinding);

        var oPayload = oServiceFacade._executeAjax.getCall(1).args[3];

        equal(oPayload.Data.Filters.length, oData.Filters.length);

        oServiceFacade.bCalledFromBinding = true;
        oServiceFacade._retrieveList("", null, null, null, oListBinding, {});

        var oPayload = oServiceFacade._executeAjax.getCall(2).args[3];

        equal(oPayload.Data.Filters.length, oData.Filters.length);

    });

    // *** TEST CASE #12 ***
    test("_retrieveList() should reset after receiving data (on HTTP 2xx), if Skip is 0.", function() {

        var fnGetData = function(oData) {
            return oData;
        };

        oModel.setProperty("/test12", oDataGetResponse.Result.DTCList.Records);

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/test12");
        oListBinding.iTop = 10;
        oListBinding.iSkip = 0;

        oServiceFacade._retrieveList("", null, null, fnGetData, oListBinding);

        // Send fake response
        var json_response = {};
        json_response.Count = 1;
        json_response.Records = [{
            "id" : 1
        }];

        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(json_response));

        equal(json_response.Count, oModel.getData().test12.length);

    });

    // *** TEST CASE #13 ***
    test(
            "_retrieveList() should set the Count value of the response (on HTTP 2xx) on the oListBinding.iLength (used to calculate the total amout of pages) property. ",
            function() {

                var fnGetData = function(oData) {
                    return oData;
                };

                oModel.setProperty("/test13", oDataGetResponse.Result.DTCList.Records);

                var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/test13");
                oListBinding.iTop = 10;
                oListBinding.iSkip = 0;

                oServiceFacade._retrieveList("", null, null, fnGetData, oListBinding);

                // Send fake response
                var json_response = {};
                json_response.Count = 1;
                json_response.Records = {
                    "id" : 1
                };

                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(json_response));

                equal(json_response.Count, oListBinding.getLength());

            });

    // *** TEST CASE #14 ***
    test("_retrieveList() should not reset after receiving data (on HTTP 2xx), if Skip > 0.", function() {

        var fnGetData = function(oData) {
            return oData;
        };

        oModel.setProperty("/test14", oDataGetResponse.Result.DTCList.Records);

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/test14");
        oListBinding.iTop = 10;
        oListBinding.iSkip = oDataGetResponse.Result.DTCList.Records.length;

        oServiceFacade._retrieveList("", null, null, fnGetData, oListBinding);

        // Send fake response
        var json_response = {};
        json_response.Count = 200;
        json_response.Records = {
            "id" : 1
        };

        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(json_response));

        equal(oDataGetResponse.Result.DTCList.Records.length + 1, oModel.oData.test14.length);
    });

    // *** TEST CASE #15 ***
    test("_retrieveList() should call the passed success function after successfully receiving data from local files", function() {

        // Define success spy
        var fnSuccess = sinon.spy();

        var fnGetData = function(oData) {
            return oData.Result.DTCList;
        };

        oModel.setProperty("/test15", fnGetData(oDataGetResponse));

        var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/test15");
        oListBinding.iTop = 5;
        oListBinding.iSkip = 0;

        oServiceFacade.bUseTestData = true;
        oServiceFacade._retrieveList("", fnSuccess, null, fnGetData, oListBinding, {}, "myLocalFile.json");

        // Send fake response
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));

        // Check if fnSuccess was called
        ok(fnSuccess.called);

        oServiceFacade.bUseTestData = false;

    });

    // *** TEST CASE #16 ***
    test("_retrieveRecord() should call the passed success function after receiving status code HTTP 2xx", function() {

        // Define success spy
        var fnSuccess = sinon.spy();

        var fnGetData = function(oData) {
            return oData.Result.DTCList;
        };

        oModel.setProperty("/test16", fnGetData(oDataGetResponse));

        oServiceFacade._retrieveRecord("", "/test16", {}, fnSuccess, null, fnGetData, "", false);

        // Send fake response
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));

        // Check if fnSuccess was called
        ok(fnSuccess.called);

    });

    // *** TEST CASE #17 ***
    test("_retrieveRecord() should merge data after (if merge = true) receiving status code HTTP 2xx", function() {

        var fnGetData = function(oData) {
            return oData;
        };

        oModel.setProperty("/test17", fnGetData(oDataGetResponse));

        oServiceFacade._retrieveRecord("", "/test17/newData", {}, null, null, fnGetData, "", true); // merge
        // is
        // true

        // Send fake response
        var json_response = {};
        json_response.Count = 200;
        json_response.Records = {
            "id" : 1
        };

        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(json_response));

        // Check if merge was done
        ok(oModel.getProperty("/test17/newData"));
        ok(oModel.getProperty("/test17/Result"));

    });

    // *** TEST CASE #18 ***
    test("_retrieveRecord() should not merge data (if merge = false) after receiving status code HTTP 2xx", function() {

        var fnGetData = function(oData) {
            return oData;
        };

        oModel.setProperty("/test18", fnGetData(oDataGetResponse));

        oServiceFacade._retrieveRecord("", "/test18", {}, null, null, fnGetData, "", false); // merge
        // is
        // false

        // Send fake response
        var json_response = {};
        json_response.Count = 200;
        json_response.Records = {
            "id" : 1
        };

        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(json_response));

        // Check if merge was done
        equal(oModel.getProperty("/test18").Count, json_response.Count);

    });

    // *** TEST CASE #19 ***
    test("_executeAjax() should reset the flag bCalledFromBinding to false after receiving HTTP 2xx.", function() {
        // Execute request
        oServiceFacade.bCalledFromBinding = true;
        oServiceFacade._executeAjax("");

        // Check if flag is reset after receiving HTTP 200
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));
        equal(oServiceFacade.bCalledFromBinding, false);
    });

    // ** TEST CASE #20 ***
    test("_executeAjax() should reset the flag bCalledFromBinding to false after receiving HTTP 5xx.", function() {
        // Execute request
        oServiceFacade.bCalledFromBinding = true;
        oServiceFacade._executeAjax("");

        // Check if flag is reset after receiving HTTP 500
        this.requests[0].respond(500, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetResponse));
        equal(oServiceFacade.bCalledFromBinding, false);
    });

    // ** TEST CASE #21 ***
    test("_send() should push data to the backend within the payload property 'Data'", function() {
        // Execute request
        var oData = {
            "DTCID" : "1202"
        };
        oServiceFacade._send("", null, null, oData, "");

        // Check payload object
        var oPayload = oServiceFacade._executeAjax.getCall(0).args[3];
        equal(oPayload.Data, oData);

    });
})();
