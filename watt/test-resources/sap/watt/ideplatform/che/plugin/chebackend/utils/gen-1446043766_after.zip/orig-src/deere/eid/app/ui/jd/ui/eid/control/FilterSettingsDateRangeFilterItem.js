(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.FilterSettingsDateRangeFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");

    /**
     * This custom control inherits from the jd.ui.eid.controls.FilterItem control. The functionality and design of this control is similar to the
     * DateRangeFilterItem custom control. A new control was created, as the properties that need to be updated in the model are different.
     * 
     * @see jd.ui.eid.control.DateRangeFilterItem
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.FilterSettingsDateRangeFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.FilterSettingsDateRangeFilterItem", /** @lends jd.ui.eid.control.FilterSettingsDateRangeFilterItem */
    {
        metadata : {
            properties : {
                defaultCustomDateRangeLabel : {
                    type : "string"
                },
                defaultCustomDistanceLabel : {
                    type : "string"
                },
                enabledCustomDateRangeOnly : {
                    type : "boolean",
                    defaultValue : false
                }
            },
            aggregations : {
                customDateRangeItem : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                },
                customDistanceItem : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                },
                items : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : true,
                    singularName : "item"
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the listbox style class here so that we don't have to do any unnecessary
            // overwrites in
            // the renderer
            this.addStyleClass("jdUiEidListBoxFilterItem");
            this.addStyleClass("jdUiEidDateDistanceFilterItem");

            // Set constants
            this.DurationType = "duration";
            this.AbsoluteType = "absolute";
            this.SinceDateType = "sinceDate";
            this.CustomDurationType = "customDuration";
        },

        /*
         * Internal Event Handlers
         */

        /**
         * 
         * Handler of CustomDateRange-valueChanged event: Update the internal state and fire valueChanged event
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeValueChanged : function(oEvent) {
            var oSelection = {};
            jQuery.extend(oSelection, this.getProperty("selection"));
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");

            // Get new dates from custom date range item
            var sFromDate = oCustomDateRangeItem.getValue().from;
            var sToDate = oCustomDateRangeItem.getValue().to;
            var sType = oCustomDateRangeItem.getValue().type;

            // Format new date to JSON string. If the type is "sinceDate", we don't have a 'To'
            // date. ('To' is 'Current Date')
            var sFromJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sFromDate);
            var sToJSONDate;
            if (sType === this.SinceDateType) {
                sToJSONDate = null;
            } else {
                sToJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sToDate);
            }

            // If the type is sinceDate, clear AbsoluteStartDate and AbsoluteEndDate. If the type is absolute, clear sinceDate
            if (sType == this.SinceDateType) {
                oSelection.AbsoluteStartDate = "";
            } else if (sType == this.AbsoluteType) {
                oSelection.SinceDate = "";
            }

            // Check whether the values changed
            var bChanged = false;
            if (sFromJSONDate != oSelection.AbsoluteStartDate || sToJSONDate != oSelection.AbsoluteEndDate) {
                // Value has changed
                bChanged = true;
            }

            // Do this block even if value hasn't changed
            oSelection.Type = sType;
            if (sType == this.SinceDateType) {
                oSelection.SinceDate = sFromJSONDate;
            } else {
                oSelection.AbsoluteStartDate = sFromJSONDate;
            }
            oSelection.AbsoluteEndDate = sToJSONDate;
            this.setSelection(oSelection);
            bChanged = true;

            // Fire valueChanged only if value has actually changed
            if (bChanged) {
                this.fireValueChanged();
            }
        },

        /**
         * 
         * Handler of CustomDateRange-select event: Unmark all items & mark custom date range item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeSelected : function(oEvent) {
            this._clearAllItemSelection();
            this.getAggregation("customDateRangeItem").setSelected(true);
        },

        /**
         * Handler for the CustomDateRange-canceled event : Refresh the binding to force a re-render so that the display matches the selection state
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event
         */
        _handleCustomDateRangeToolPopupCanceled : function(oEvent) {
            this.getBinding("selection").refresh(true);
        },

        /**
         * 
         * Handler of CustomDistance-valueChange event: Change the label of the custom distance item and fire valueChanged event
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDistanceValueChanged : function(oEvent) {
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Get values of tool pop-up
            var iDuration = parseInt(oCustomDistanceItem.getValue().duration); // Get the numeric distance
            var sUnit = oCustomDistanceItem.getValue().unit;

            // Check if values have actually changed
            var bChanged = true;
            if ((this.getProperty("selection").Type == this.CustomDurationType) && (this.getProperty("selection").Duration == iDuration)
                    && (this.getProperty("selection").Unit == sUnit)) {
                bChanged = false;
            }

            // Update datamodel
            var oSelection = {};
            jQuery.extend(oSelection, this.getProperty("selection"));
            if (isNaN(iDuration)) {
                oSelection.Type = "";
                oSelection.Duration = null;
                oSelection.Unit = "";
            } else {
                oSelection.Type = this.CustomDurationType;
                oSelection.Duration = iDuration;
                oSelection.Unit = sUnit;
            }

            this.setSelection(oSelection);

            if (bChanged) {
                this.fireValueChanged();
            }
        },

        /**
         * 
         * Handler of CustomDistance-select event: Unmark all items & mark custom distance item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDistanceSelected : function(oEvent) {
            this._clearAllItemSelection();
            this.getAggregation("customDistanceItem").setSelected(true);
        },

        /**
         * Handler of the CustomDistance-canceled event : Refresh the FilterItem to render according to the current selection state
         * 
         * @param oEvent
         *            {sap.ui.base.Event} oEvent the event
         */
        _handleCustomDistanceToolPopupCanceled : function(oEvent) {
            // Force an update
            this.getBinding("selection").refresh(true);
        },

        /**
         * 
         * Select event handler of static ValueListItem: Fire valueChanged event if a static date distance item has been selected
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleItemSelected : function(oEvent) {
            var bSelected = oEvent.getSource().getSelected(); // Get the last selection state of
            // the clicked item
            this._clearAllItemSelection(); // Unmark all items
            oEvent.getSource().setSelected(!bSelected); // Revert the selection of clicked item

            // Check selection state
            var oSelection = {};
            jQuery.extend(oSelection, this.getProperty("selection"));
            if (oEvent.getSource().getSelected()) {
                // Update datamodel if selected
                oSelection.Type = this.DurationType;
                oSelection.Duration = oEvent.getSource().getValue().duration;
                oSelection.Unit = oEvent.getSource().getValue().unit;
            } else {
                // Reset the selection property
                oSelection.Type = "";
            }
            this.setProperty("selection", oSelection);

            this.fireValueChanged();
        },

        /**
         * This function sets the custom date range list item.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oCustomDateRangeItem The custom date range list item.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining
         */
        setCustomDateRangeItem : function(oCustomDateRangeItem) {
            this.setAggregation("customDateRangeItem", oCustomDateRangeItem);
            oCustomDateRangeItem.attachValueChanged($.proxy(this._handleCustomDateRangeValueChanged, this));
            oCustomDateRangeItem.attachSelect($.proxy(this._handleCustomDateRangeSelected, this));
            oCustomDateRangeItem.attachToolPopupCanceled($.proxy(this._handleCustomDateRangeToolPopupCanceled, this));
            return this;
        },

        /**
         * This function sets the custom distance list item.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oCustomDistanceItem The custom distance list item.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        setCustomDistanceItem : function(oCustomDistanceItem) {
            this.setAggregation("customDistanceItem", oCustomDistanceItem);
            oCustomDistanceItem.attachValueChanged($.proxy(this._handleCustomDistanceValueChanged, this));
            oCustomDistanceItem.attachSelect($.proxy(this._handleCustomDistanceSelected, this));
            oCustomDistanceItem.attachToolPopupCanceled($.proxy(this._handleCustomDistanceToolPopupCanceled, this));
            return this;
        },

        /**
         * This function adds the static date distance list item to the items aggregation.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        addItem : function(oItem) {
            // Set the selection event handler
            oItem.attachSelect($.proxy(this._handleItemSelected, this));

            // Add item to the list
            this.addAggregation("items", oItem);

            return this;
        },

        /**
         * This function inserts another static date distance list item to the items aggregation at a fix position.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @param {int}
         *            iIndex The position in the aggregation.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        insertItem : function(oItem, iIndex) {
            // Set the selection event handler
            oItem.attachSelect($.proxy(this._handleItemSelected, this));

            // Add item to the list
            this.insertAggregation("items", oItem, iIndex);

            return this;
        },

        /**
         * Deselect all items
         */
        _clearAllItemSelection : function() {
            // Clear selection of custom date range item
            this.getAggregation("customDateRangeItem").setSelected(false);

            // Clear selection of custom distance item
            this.getAggregation("customDistanceItem").setSelected(false);

            // Clear selection of all static items
            var aItems = this.getAggregation("items");
            if (aItems) {
                for ( var i = 0; i < aItems.length; i++) {
                    aItems[i].setSelected(false);
                }
            }
        },

        /*
         * Overridden methods of FilterItem class
         */

        /**
         * @see jd.ui.eid.control.FilterItem#_clear
         */
        _clear : function() {
            this._clearAllItemSelection();

            // If filter item is already clear, return false.
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Check whether the date range popup is open
            if (oCustomDateRangeItem.getToolPopup().isOpen()) {
                oCustomDateRangeItem.getToolPopup().close(0);
            }

            // Reset the date range item text
            oCustomDateRangeItem.setText(this.getDefaultCustomDateRangeLabel());

            // Reset the custom date range value
            oCustomDateRangeItem.setValue({
                from : "",
                to : ""
            });

            // Check whether the distance popup is open
            if (oCustomDistanceItem.getToolPopup().isOpen()) {
                oCustomDistanceItem.getToolPopup().close(0);
            }

            // Reset the label of the custom distance
            oCustomDistanceItem.setText(this.getDefaultCustomDistanceLabel());

            // Reset the input & unit field
            oCustomDistanceItem.setValue({
                duration : null,
                unit : ""
            });

            // Reset the internal state
            var oSelection = {};
            oSelection.Type = "";
            oSelection.AbsoluteStartDate = null;
            oSelection.AbsoluteEndDate = null;
            oSelection.SinceDate = null;
            oSelection.Duration = null;
            oSelection.Unit = "";
            this.setProperty("selection", oSelection);

            // Since _clear actually did something, return true.
            return true;
        },

        /**
         * Set the default selection
         */
        setSelection : function(oSelection) {
            // Set 'active' to false by default. In this method, if any ValueListItem's 'selected' is set to true, we set this FilterItem's 'active'
            // to true.
            var _bActive = false;

            // Get the custom list items
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Default values of custom items
            var oCustomDateRangeValue = {
                from : "",
                to : ""
            };
            var oCustomDistanceValue = {
                duration : null,
                unit : ""
            };

            // Check whether the "BuildWeek"/"DTCCaptureTime" property has been set in the model.
            // The 'selection' property is bound to the model. This is done in the FilterSettings
            // view's controller.
            if (oSelection) {
                // Set 'custom distance' item's value & text if needed
                if (oSelection.Duration && oSelection.Duration >= 0 && (oSelection.Type == this.CustomDurationType)) {
                    // Update the custom distance item's value
                    var iDuration = oSelection.Duration;
                    var sUnit = oSelection.Unit;
                    oCustomDistanceValue.duration = iDuration;
                    oCustomDistanceValue.unit = sUnit;

                    // Update the custom distance item's text
                    var sItemText = "";
                    switch (sUnit) {
                        case "day" :
                            sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_DAY_MULTIPLE",
                                    "DATE_DISTANCE_CUSTOM_LST_DAY_SINGLE");
                            break;
                        case "week" :
                            sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_WEEK_MULTIPLE",
                                    "DATE_DISTANCE_CUSTOM_LST_WEEK_SINGLE");
                            break;
                        case "month" :
                            sItemText = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iDuration, "DATE_DISTANCE_CUSTOM_LST_MONTH_MULTIPLE",
                                    "DATE_DISTANCE_CUSTOM_LST_MONTH_SINGLE");
                            break;
                    }

                    oCustomDistanceItem.setText(sItemText);
                } else if (!oCustomDistanceItem.getText()
                        || (!oSelection.Duration && ((oSelection.Type == this.CustomDurationType) || !oSelection.Type))) {
                    // 'Distance' is not available. This could be because the user cleared it (e.g by clicking OK with the distance TextField empty).
                    // So we now need to reset the ValueListItem text
                    var sText = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_CUSTOM_DISTANCE");
                    oCustomDistanceItem.setText(sText);
                }

                // Set 'date range' item's value & text if needed
                if (oSelection.AbsoluteStartDate && oSelection.AbsoluteEndDate) {
                    // Update the date range item's value. Dates need to be stored in YYYYMMDD
                    // format.
                    oCustomDateRangeValue.from = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.AbsoluteStartDate);
                    oCustomDateRangeValue.to = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.AbsoluteEndDate);
                    oCustomDateRangeValue.type = "absolute";

                    // Get UI-ready strings for 'from' and 'to'
                    var sStartDate = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(oSelection.AbsoluteStartDate);

                    // Update the date range item's text. If type is 'sinceDate', the end date needs
                    // to be displayed as 'Current Date' in the value list item
                    var sEndDate = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(oSelection.AbsoluteEndDate);

                    var sText = jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FORMAT_TXT_RANGE", [sStartDate, sEndDate]);
                    oCustomDateRangeItem.setText(sText);
                } else if (oSelection.SinceDate) {
                    // Handle sinceDate (do this if sinceDate is the currently selected type)
                    oCustomDateRangeValue.from = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.SinceDate);
                    oCustomDateRangeValue.type = "sinceDate";

                    // Get UI-ready strings for 'from' and 'to'
                    var sStartDate = jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(oSelection.SinceDate);
                    var sCurrentDate = jd.ui.eid.common.I18NHelper.getText("DATE_DISTANCE_CUSTOM_FLD_CURRENT_DATE");
                    var sText = jd.ui.eid.common.I18NHelper.getText("DATE_RANGE_FORMAT_TXT_RANGE", [sStartDate, sCurrentDate]);
                    oCustomDateRangeItem.setText(sText);
                } else {
                    // Dates are not available. This could be because the user cleared it . So we now need to reset the ValueListItem text
                    var sText = jd.ui.eid.common.I18NHelper.getText("DTC_FILTERS_TXT_CUSTOM_DATE_RANGE");
                    oCustomDateRangeItem.setText(sText);
                }

                // Check which value item needs to be shown as 'selected'. 'duration', if there is a static ValueListItem with the same value, it
                // should be selected.
                this._clearAllItemSelection();
                if (oSelection.Type == this.DurationType) {
                    var aItems = this.getItems();
                    for ( var i = 0; i < aItems.length; i++) {
                        var oItem = aItems[i];
                        if (oSelection.Duration == oItem.getValue().duration && oSelection.Unit == oItem.getValue().unit
                                && (oSelection.Type == "duration")) {
                            oItem.setSelected(true);
                            _bActive = true;
                        }
                    }
                } else if (oSelection.Type == "customDuration" && oSelection.Duration) {
                    oCustomDistanceItem.setSelected(true);
                    _bActive = true;
                } else if (((oSelection.Type == this.AbsoluteType) && oSelection.AbsoluteStartDate && oSelection.AbsoluteEndDate)
                        || ((oSelection.Type == this.SinceDateType) && oSelection.SinceDate)) {
                    oCustomDateRangeItem.setSelected(true);
                    _bActive = true;
                }
            }

            // Initialize the value attributes of all custom list items
            oCustomDateRangeItem.setValue(oCustomDateRangeValue);
            oCustomDistanceItem.setValue(oCustomDistanceValue);
            this.setActive(_bActive);
            this.setProperty("selection", oSelection);
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.DateDistanceFilterItemRenderer"

    });

})();