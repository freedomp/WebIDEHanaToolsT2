(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.BusinessProcessHelper");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");
    jd.ui.eid.require({
        modName : "jd.ui.eid.view.main.Worksheet",
        type : "controller"
    });

    /**
     * @class Helper Class for the business process.
     * @static
     * @name jd.ui.eid.common.BusinessProcessHelper
     */
    jd.ui.eid.common.BusinessProcessHelper = {};

    /**
     * @name jd.ui.eid.common.BusinessProcessHelper.EvidencePackage
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage = {};

    /**
     * Starts a new evidence package. First initializes the EvidencePackageDetails model, then opens the worksheet overlay and adds the DTC (if
     * provided) to the evidence package.
     * 
     * @param {object}
     *            [mDTC=null] the DTC to add to the new evidence package.
     * @param {int}
     *            [mDTC.DTCID] the DTC ID.
     * @param {string}
     *            [mDTC.DTCCode] the DTC code.
     * @param {string}
     *            [mDTC.DTCDescription] the DTC description.
     * @param {string}
     *            sSelectedKPIID1 the first selected KPI ID.
     * @param {string}
     *            sSelectedKPIID2 the second selected KPIID.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.startNewPackageInOverlay = function(mDTC, sSelectedKPIID1, sSelectedKPIID2) {
        var oEventBus = sap.ui.getCore().getEventBus();
        var oModel = sap.ui.getCore().getModel();
        oEventBus.publish("EvidencePackage", "startingNew");

        // (1) Initialize model
        this.initializeModel();

        // (2) Copy DTC filter domain values into a separate location and other relevant data
        jd.ui.eid.model.EidModel.TransformationHelper.copyDTCFilterDomainValuesForEvidencePackage();
        oModel.setProperty("/SearchTerms/DTCListSearchTerm", oModel.getProperty("/SearchTerms/DashboardDTCListSearchTerm"));
        oModel.setProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation", oModel.getProperty("/DTCFilters/PINPopulation"));

        // (4) Add DTC if provided
        if (mDTC) {
            this.addDTC(mDTC, sSelectedKPIID1, sSelectedKPIID2);
        }

        // (3) Open overlay
        oEventBus.publish("EvidencePackage", "newStarted");

        // (3) Open overlay
        oEventBus.publish("Worksheet", "open");
    };

    /**
     * Initialize the model path <code>EvidencePackageDetails</code>.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.initializeModel = function() {
        var oModel = sap.ui.getCore().getModel();

        // Clear Evidence Package Details
        oModel.setProperty("/EvidencePackageDetails", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails));

        var oEvidencePackageServiceFacade = this._getEvidencePackageServiceFacade();

        oEvidencePackageServiceFacade.initializeEvidencePackageDetails();

        // Set defaults
        var mEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");
        oModel.setProperty("/EvidencePackageDetails/Header", mEvidencePackageDetails);

        // Copy filters
        var oFilterSelection = jQuery.extend(true, {}, oModel.getProperty("/DTCFilters/FilterSelection"));
        var oFilterState = jQuery.extend(true, {}, oModel.getProperty("/DTCFilters/FilterState"));
        oModel.setProperty("/EvidencePackageDetails/Header/DTCFilterSelection", oFilterSelection);
        oModel.setProperty("/EvidencePackageDetails/Header/DTCFilterState", oFilterState);

        // Clear DTAC Case filters
        oModel.setProperty("/DTACCaseFilters", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter));

        // Clear DTAC Case list
        oModel.setProperty("/DTACCaseList", []);

        // Clear Warranty Claim filters
        oModel.setProperty("/WarrantyClaimFilters", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter));

        // Clear Warranty Claim list
        oModel.setProperty("/WarrantyClaimsByPrimePartList", []);

        // Clear Evidence Package related SearchTerms
        oModel.setProperty("/SearchTerms/DTCListSearchTerm", "");
        oModel.setProperty("/SearchTerms/DTACCaseListSearchTerm", "");
        oModel.setProperty("/SearchTerms/WarrantyClaimsByPrimePartListSearchTerm", "");
    };

    /**
     * Initialize the state management of an Evidence Package
     * 
     * @returns {boolean} true, if owned by current user
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.IsPackageOwnedByCurrentUser = function() {
        var oModel = sap.ui.getCore().getModel();
        var oHeader = oModel.getProperty("/EvidencePackageDetails/Header");

        if (oHeader) {
            // we call the formatter which is bound to path /EvidencePackageDetails/Header/PackageOwnedByCurrentUser as
            // we get from the backend 0 or 1 as boolean
            return jd.ui.eid.common.formatter.DTCFormatter.formatButtonEnabled(oHeader.PackageOwnedByCurrentUser);
        } else {
            false;
        }
    };

    /**
     * Calculates machine option codes which have not been calculated yet
     * 
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.calculateMissingMachineOptionCodes = function() {

        var oModel = sap.ui.getCore().getModel();
        var aDTCIDList = [];
        var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");
        var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");

        for ( var i = 0; i < oEvidencePackageDetailsHeader.MachineOptionCodes.length; i++) {

            // check if DTC is not yet calculated
            if (oEvidencePackageServiceFacade.MachineOptionCalculation
                    .hasCalculationNotYetStarted(oEvidencePackageDetailsHeader.MachineOptionCodes[i].MachineOption[0])) {
                // not yet calculated
                aDTCIDList.push(oEvidencePackageDetailsHeader.MachineOptionCodes.DTCID);
            };
        };

        if (aDTCIDList.length > 0) {
            oEvidencePackageServiceFacade.calculateMachineOptionCodesForDTC(aDTCIDList, oEvidencePackageDetailsHeader.DTCFilterSelection);
        }

    };

    /**
     * Adds a DTC to the evidence package and calculates machine option codes for it
     * 
     * @param {object}
     *            mDTC the DTC to add to the new evidence package.
     * @param {int}
     *            mDTC.DTCID the DTC ID.
     * @param {string}
     *            mDTC.DTCCode the DTC code.
     * @param {string}
     *            mDTC.DTCDescription the DTC description.
     * @param {string}
     *            mDTC.Level1Text Level 1 Text.
     * @param {string}
     *            mDTC.Level2Text Level 2 Text.
     * @param {string}
     *            sSelectedKPIID1 the first selected KPI ID.
     * @param {string}
     *            sSelectedKPIID2 the second selected KPIID.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTC = function(mDTC, sSelectedKPIID1, sSelectedKPIID2) {
        var oModel = sap.ui.getCore().getModel();
        var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");
        var oEvidencePackageServiceFacade = this._getEvidencePackageServiceFacade();

        // Concatenate Level1 and Level2 Text to Description if not delivered
        if (mDTC.DTCDescription == null) {
            mDTC.DTCDescription = mDTC.Level1Text + " " + mDTC.Level2Text;
        };

        if (!sSelectedKPIID1) {
            sSelectedKPIID1 = "";
        }
        if (!sSelectedKPIID2) {
            sSelectedKPIID2 = "";
        }

        var oAddedDTC = {
            DTCID : parseInt(mDTC.DTCID),
            DTCCode : mDTC.DTCCode,
            DTCDescription : mDTC.DTCDescription,
            AddedOn : new Date(),
            SelectedKPIID1 : sSelectedKPIID1,
            SelectedKPIID2 : sSelectedKPIID2,
            // Also temporarily store expensive properties
            _KPIs : mDTC.KPIs,
            _AffectedPINs : mDTC.AffectedPINs
        };

        // Update all required model paths
        // (1) DTC list and top ten chart
        $.each(["/DTCList", "/Top10DTCs/Records"], function(iIdx, sPath) {
            var aDTCList = oModel.getProperty(sPath);
            $.each(aDTCList, function(iIdx, _mDTC) {
                if (_mDTC.DTCID == mDTC.DTCID) {
                    oModel.setProperty(sPath + "/" + iIdx + "/_canBeAddedToEvidencePackage", false);
                    return false;
                }
            });
        });

        // (2) Evidence Package Header - DTCCode List and Machine Option Codes
        oEvidencePackageDetails.DTCCodeList.push(oAddedDTC);

        // needed to differ between DTCs which have no machine option
        // codes after calculating (which would be an empty array)
        var oMachineCodesNotYetCalculated = oEvidencePackageServiceFacade.MachineOptionCalculation.getCalculationNotYetStarted(mDTC);

        oEvidencePackageDetails.MachineOptionCodes.push(oMachineCodesNotYetCalculated);
        oModel.setProperty("/EvidencePackageDetails/Header", oEvidencePackageDetails);

        // Calculate machine option codes
        oEvidencePackageServiceFacade.calculateMachineOptionCodesForDTC([oAddedDTC.DTCID], oEvidencePackageDetails.DTCFilterSelection, null, null);

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
    };

    /**
     * Helper method for remove DTC from Evidence Package
     * 
     * @param{string} sDTCID the id of DTC The item corresponding to the given DTCID needs to be removed from -
     *                EvidencePackageDetails/Header/DTCCodeList - EvidencePackageDetails/DTCDetailsList -
     *                EvidencePackageDetails/Header/MachineOptionCodes
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTC = function(sDTCIDToRemove) {
        var oModel = sap.ui.getCore().getModel();

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);

        // remove the DTC from the DTCCode List, the DTC Detail List and the Machine Option Codes
        var aPaths = ["/EvidencePackageDetails/Header/DTCCodeList", "/EvidencePackageDetails/DTCDetailsList",
                "/EvidencePackageDetails/Header/MachineOptionCodes"];
        $.each(aPaths, function(iIdx, sPath) {
            var aList = oModel.getProperty(sPath);
            var sDTCID = "";
            if (aList) {
                for ( var i = 0; i < aList.length; i++) {
                    if (aList[i].DTCMasterData) {
                        sDTCID = aList[i].DTCMasterData.DTCID;
                    } else {
                        sDTCID = aList[i].DTCID;
                    }

                    if (sDTCID == sDTCIDToRemove) {
                        aList.splice(i, 1);
                        oModel.setProperty(sPath, aList);
                        break;
                    }
                }

            }
        });

        $.each(["/DTCList", "/Top10DTCs/Records"], function(iIdx, sPath) {
            var aList = oModel.getProperty(sPath);
            $.each(aList, function(iIdx, _mDTC) {
                if (_mDTC.DTCID == sDTCIDToRemove) {
                    oModel.setProperty(sPath + "/" + iIdx + "/_canBeAddedToEvidencePackage", true);
                    return false;
                }
            });
            oModel.setProperty(sPath, aList);
        });

        // Notify listeners about this
        sap.ui.getCore().getEventBus().publish("EvidencePackage", "DTCRemoved", sDTCIDToRemove);
    };

    /**
     * Adds a DTAC Case to the evidence package.
     * 
     * @param {object}
     *            mDTACCase the DTAC case to add to the new evidence package.
     * @param {int}
     *            mDTACCase.DTACCaseNumber the DTAC case number.
     * @param {string}
     *            mDTACCase.Description the DTAC case description.
     * @param {string}
     *            mDTACCase.CreatedOnDate the DTAC case created on date.
     * @param {object}
     *            mFilterSelection the DTAC case filter selection.
     * @param {object}
     *            mFilterState the DTAC case filter state.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addDTACCase = function(mDTACCase, mFilterSelection, mFilterState) {
        var oModel = sap.ui.getCore().getModel();
        var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");

        var oAddedDTACCase = {
            DTACCaseNumber : mDTACCase.DTACCaseNumber,
            DTACCaseDescription : mDTACCase.Description,
            CreatedOnDate : mDTACCase.CreatedOnDate,
            AddedOn : new Date(),
            DTACCaseFilterSelection : mFilterSelection,
            DTACCaseFilterState : mFilterState
        };

        // Update model path /DTACCaseList
        var aDTACCaseList = oModel.getProperty("/DTACCaseList");
        $.each(aDTACCaseList, function(iIdx, _mDTACCase) {
            if (_mDTACCase.DTACCaseNumber == mDTACCase.DTACCaseNumber) {
                oModel.setProperty("/DTACCaseList/" + iIdx + "/_canBeAddedToEvidencePackage", false);
                return false;
            }
        });
        // Update model path //EvidencePackageDetails/Header
        oEvidencePackageDetails.DTACCaseList.push(oAddedDTACCase);
        oModel.setProperty("/EvidencePackageDetails/Header", oEvidencePackageDetails);

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
    };

    /**
     * Remove a DTAC Case from the evidence package.
     * 
     * @param {object}
     *            mDTACCase the DTAC case to be removed.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTACCase = function(mDTACCase) {

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);

        // Remove DTAC Case from the Evidence Package Details
        var oModel = sap.ui.getCore().getModel();
        var aDTACCaseDetailsList = oModel.getProperty("/EvidencePackageDetails/DTACCaseDetailsList");
        if (aDTACCaseDetailsList && aDTACCaseDetailsList.indexOf(mDTACCase) != -1) {
            aDTACCaseDetailsList.splice(aDTACCaseDetailsList.indexOf(mDTACCase), 1);
            oModel.setProperty("/EvidencePackageDetails/DTACCaseDetailsList", aDTACCaseDetailsList);
        }

        // Remove DTAC Case from the Evidence Package Details Header
        var aDTACCaseList = oModel.getProperty("/EvidencePackageDetails/Header/DTACCaseList");
        for ( var i = 0; i < aDTACCaseList.length; i++) {
            if (aDTACCaseList[i].DTACCaseNumber == mDTACCase.DTACCaseNumber) {
                aDTACCaseList.splice(i, 1);
                break;
            }
        }
        // Setting back data to the model
        oModel.setProperty("/EvidencePackageDetails/Header/DTACCaseList", aDTACCaseList);

        // Update model path /DTACCaseList
        var aDTACCaseList = oModel.getProperty("/DTACCaseList");
        $.each(aDTACCaseList, function(iIdx, _mDTACCase) {
            if (_mDTACCase.DTACCaseNumber == mDTACCase.DTACCaseNumber) {
                oModel.setProperty("/DTACCaseList/" + iIdx + "/_canBeAddedToEvidencePackage", true);
                return false;
            }
        });
        oModel.setProperty("/DTACCaseList", aDTACCaseList);

        // Inform listeners that a DTAC Case was removed
        sap.ui.getCore().getEventBus().publish("EvidencePackage", "DTACCaseRemoved", mDTACCase);

    };

    /**
     * Add new Warranty Claim to path "EvidencePackageDetails" with Time stamp
     * 
     * @param {object}
     *            mPrimePart The Prime Part which relates to the Warranty Claim
     * @param {string}
     *            mPrimePart.PrimePartNumber the Prime Part Number
     * @param {string}
     *            mPrimePart.PrimePartDescription the Prime Part Description
     * @param {object}
     *            mWarrantyClaim The Warranty Claim to add to the evidence package
     * @param {integer}
     *            mWarrantyClaim.WarrantyClaimSequenceNumber the WarrantyClaimSequenceNumber
     * @param {string}
     *            mWarrantyClaim.WarrantyClaimNumber the new Warranty Claim number added to the evidence package
     * @param {string}
     *            mWarrantyClaim.TotalClaimCost the total claim cost of the Warranty Claim
     * @param {object}
     *            mWarrantyClaimFilterSelection the corresponding Warranty Claim filter selection of the to be added Warranty Claim
     * @param {object}
     *            mWarrantyClaimFilterState the corresponding Warranty Claim filter state of the to be added Warranty Claim
     * @param {boolean}
     *            bJDLinkActive the JDLinkActive flag
     * 
     * 
     * @public
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addWarrantyClaim = function(mPrimePart, mWarrantyClaim, mWarrantyClaimFilterSelection,
            mWarrantyClaimFilterState, bJDLinkActive) {

        var oModel = sap.ui.getCore().getModel();
        var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");
        var oAddedWarrantyClaim = {
            WarrantyClaimSequenceNumber : mWarrantyClaim.WarrantyClaimSequenceNumber,
            WarrantyClaimNumber : mWarrantyClaim.WarrantyClaimNumber,
            PrimePartNumber : mPrimePart.PrimePartNumber,
            PrimePartDescription : mPrimePart.PrimePartDescription,
            WarrantyClaimCosts : mWarrantyClaim.TotalClaimCost,
            AddedOn : new Date(),
            WarrantyClaimFilterSelection : mWarrantyClaimFilterSelection,
            WarrantyClaimFilterState : mWarrantyClaimFilterState,
            JDLinkActive : bJDLinkActive
        };
        oEvidencePackageDetails.WarrantyClaimList.push(oAddedWarrantyClaim);
        oModel.setProperty("/EvidencePackageDetails/Header", oEvidencePackageDetails);

        // Mark Warranty Claim item in Warranty Claim list of the Prime Part as already added to Evidence Package
        var iSelectedWarrantyClaimNumber = mWarrantyClaim.WarrantyClaimSequenceNumber;
        var aWarrantyClaimList = oModel.getProperty("/WarrantyClaimPrimePartHeader/WarrantyClaimList");
        $.each(aWarrantyClaimList, function(iIndex, mWarrantyClaim) {
            if (iSelectedWarrantyClaimNumber == mWarrantyClaim.WarrantyClaimSequenceNumber) {
                oModel.setProperty("/WarrantyClaimPrimePartHeader/WarrantyClaimList/" + iIndex + "/_canBeAddedToEvidencePackage", false);
                return false;
            }
        });

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
    };

    /**
     * Called to add all WarrantyClaims of the Prime Part Header to the Evidence Package with Time stamp
     * 
     * @param {boolean}
     *            bOverwrite indicates whether the process should overwrite existing Warranty Claims of the Evidence Package by the new ones
     * @param {boolean}
     *            bJDLinkActive the JDLinkActive flag
     * 
     * @public
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.addAllWarrantyClaimsToPackage = function(bOverwrite, bJDLinkActive) {
        var oData = sap.ui.getCore().getModel().getData();
        var mPrimePartSummary = oData.WarrantyClaimPrimePartHeader.PrimePartSummary;
        var mWarrantyClaimFilterSelection = oData.WarrantyClaimFilters.FilterSelection;
        var mWarrantyClaimFilterState = oData.WarrantyClaimFilters.FilterState;
        var aEvidencePackageWarrantyClaimList = oData.EvidencePackageDetails.Header.WarrantyClaimList;
        var mEvidencePackageWarrantyClaims = {};
        var aPrimePartHeaderWarrantyClaimList = oData.WarrantyClaimPrimePartHeader.WarrantyClaimList;

        // Create a map out of the current warranty claim array in the evidence package
        // This will make it easier and faster to modify the warranty claims
        $.each(aEvidencePackageWarrantyClaimList, function(iIdx, mWarrantyClaim) {
            var sPrimePartNumber = mWarrantyClaim.PrimePartNumber;
            var sWarrantyClaimNumber = mWarrantyClaim.WarrantyClaimSequenceNumber;

            if (mEvidencePackageWarrantyClaims[sPrimePartNumber] === undefined) {
                mEvidencePackageWarrantyClaims[sPrimePartNumber] = {};
            }

            var mPrimePartWarrantyClaims = mEvidencePackageWarrantyClaims[sPrimePartNumber];
            mPrimePartWarrantyClaims[sWarrantyClaimNumber] = mWarrantyClaim;
        });

        // Add all Warranty Claims from the Prime Part Header to the evidence package.
        // Also check whether existing warranty claims of the evidence package should be overwritten.
        $.each(aPrimePartHeaderWarrantyClaimList, function(iIdx, mWarrantyClaim) {
            var bAddToEvidencePackage = true;

            // Check whether the required map exists otherwise initialize it
            if (!mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber]) {
                mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber] = {};
            }

            // Check whether overwriting of Evidence Package Warranty Claims is disabled and whether the current Warranty Claim has already been added
            // to the Evidence Package
            if (!bOverwrite && mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber][mWarrantyClaim.WarrantyClaimSequenceNumber]) {
                bAddToEvidencePackage = false;
            }

            // Check whether the Warranty Claim should be added to Evidence Package
            if (bAddToEvidencePackage) {

                // Prepare the Warranty Claim for Evidence Package
                var oAddedWarrantyClaim = {
                    WarrantyClaimSequenceNumber : mWarrantyClaim.WarrantyClaimSequenceNumber,
                    WarrantyClaimNumber : mWarrantyClaim.WarrantyClaimNumber,
                    PrimePartNumber : mPrimePartSummary.PrimePartNumber,
                    PrimePartDescription : mPrimePartSummary.PrimePartDescription,
                    WarrantyClaimCosts : mWarrantyClaim.TotalClaimCost,
                    AddedOn : new Date(),
                    WarrantyClaimFilterSelection : mWarrantyClaimFilterSelection,
                    WarrantyClaimFilterState : mWarrantyClaimFilterState,
                    JDLinkActive : bJDLinkActive
                };

                // Add Warranty Claim to Evidence Package map
                if (!mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber]) {
                    mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber] = {};
                }
                mEvidencePackageWarrantyClaims[mPrimePartSummary.PrimePartNumber][mWarrantyClaim.WarrantyClaimSequenceNumber] = oAddedWarrantyClaim;
            }
        });

        // Reset the Evidence Package Warranty Claim list
        aEvidencePackageWarrantyClaimList = [];

        // Transform the map back to an array
        $.each(mEvidencePackageWarrantyClaims, function(iIdx, mEvidencePackageWarrantyClaim) {
            $.each(mEvidencePackageWarrantyClaim, function(iIdx, mWarrantyClaim) {
                aEvidencePackageWarrantyClaimList.push(mWarrantyClaim);
            });
        });

        sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails/Header/WarrantyClaimList", aEvidencePackageWarrantyClaimList);
    },

    /**
     * Remove a Warranty Claim from the evidence package. *
     * 
     * @param {object}
     *            mWarrantyClaim the Warranty Claim to be removed.
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeWarrantyClaim = function(mWarrantyClaim) {
        // Remove Warranty Claim from the Evidence Package Details
        var oModel = sap.ui.getCore().getModel();
        var aWarrantyClaimDetailsList = oModel.getProperty("/EvidencePackageDetails/WarrantyClaimDetailsList");

        // if user was not at the summary page, we might have to warranty list
        if (aWarrantyClaimDetailsList) {
            var index = aWarrantyClaimDetailsList.indexOf(mWarrantyClaim);
            if (index != -1) {
                aWarrantyClaimDetailsList.splice(index, 1);
                oModel.setProperty("/EvidencePackageDetails/WarrantyClaimDetailsList", aWarrantyClaimDetailsList);
            }
        }
        // Remove Warranty Claim from the Evidence Package Details Header
        var aWarrantyClaimList = oModel.getProperty("/EvidencePackageDetails/Header/WarrantyClaimList");
        for ( var i = 0; i < aWarrantyClaimList.length; i++) {
            if (aWarrantyClaimList[i].WarrantyClaimSequenceNumber == mWarrantyClaim.WarrantyClaimSequenceNumber) {
                aWarrantyClaimList.splice(i, 1);
                break;
            }
        }

        // Setting back data to the model
        oModel.setProperty("/EvidencePackageDetails/Header/WarrantyClaimList", aWarrantyClaimList);

        // Inform DLM about data change in
        jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);

        // Inform other listeners about this deletion
        sap.ui.getCore().getEventBus().publish("EvidencePackage", "warrantyClaimRemoved", mWarrantyClaim);
    };

    /**
     * Helper method for a reference to the evidence package service facade.
     * 
     * @returns {jd.ui.eid.service.EvidencePackageServiceFacade}
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage._getEvidencePackageServiceFacade = function() {
        return jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");
    };

    /**
     * DataLoss Manager Instance for the evidence package
     * 
     * @name jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM = {};

    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM._instance = null;

    /**
     * Returns DLM (Data Loss Manager) for Evidence Package *
     * 
     * @returns {jd.ui.eid.common.DataLossManager} the DLM reference
     */
    jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance = function() {

        if (jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM._instance == null) {

            // create data loss manager for business process helper
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM._instance = new jd.ui.eid.common.DataLossManager({});

            // register for root DLM
            var oRootDLM = jd.ui.eid.common.DataLossManager.getRootInstance();
            oRootDLM.addChild(jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM._instance);
        }

        return jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM._instance;
    };

    /**
     * @name jd.ui.eid.common.BusinessProcessHelper.EvidencePackage
     */
    jd.ui.eid.common.BusinessProcessHelper.DTCBlacklist = {};

    /**
     * Adds a DTC to the users blacklist
     * 
     * @param {object}
     *            mDTC the DTC to add to the new evidence package.
     * @param {int}
     *            mDTC.DTCID the DTC ID.
     * @param {string}
     *            mDTC.DTCCode the DTC code.
     */
    jd.ui.eid.common.BusinessProcessHelper.DTCBlacklist.addDTC = function(mDTC) {
        var oNotificationCenter = jd.ui.eid.application.Application.getInstance().getNotificationCenter();

        var fnSuccess = function() {
            var sText = jd.ui.eid.common.I18NHelper.getText("DTC_BLACKLIST_MSG_ADD_SUCCESS", [mDTC.DTCCode]);
            oNotificationCenter.success(sText);

            // Update all required model paths
            var oModel = sap.ui.getCore().getModel();
            // (1) DTC list
            var aDTCList = oModel.getProperty("/DTCList");
            $.each(aDTCList, function(iIdx, _mDTC) {
                if (_mDTC.DTCID == mDTC.DTCID) {
                    oModel.setProperty("/DTCList/" + iIdx + "/_isNotOnBlacklist", false);
                    return false;
                }
            });
            // (2) Top 10 Chart
            var aTop10DTCs = oModel.getProperty("/Top10DTCs/Records");
            var iIndexInTop10 = -1;
            $.each(aDTCList, function(iIdx, _mDTC) {
                if (_mDTC.DTCID == mDTC.DTCID) {
                    oModel.setProperty("/Top10DTCs/Records/" + iIdx + "/_isNotOnBlacklist", false);
                    iIndexInTop10 = iIdx;
                    return false;
                }
            });
            // (3) DTC Details
            var _mDTC = oModel.getProperty("/DTCDetails/DTCMasterData");
            if (_mDTC && _mDTC.DTCID == mDTC.DTCID) {
                oModel.setProperty("/DTCDetails/DTCMasterData/_isNotOnBlacklist", false);
            }

            // And finally, we fire an event (which could for example be handled by the controller of the top 10 dtc chart so see whether any column
            // needs to be highlighted).
            sap.ui.getCore().getEventBus().publish("BusinessProcess", "addedDTCToBlacklist", {
                'mDTC' : mDTC,
                'iIndexInTop10' : iIndexInTop10
            });
        };

        var fnError = function() {
            var sText = jd.ui.eid.common.I18NHelper.getText("DTC_BLACKLIST_MSG_DELETE_ERROR", [mDTC.DTCCode]);
            oNotificationCenter.alert(sText);
        };

        this._getServiceFacade().addDTCToBlacklist(mDTC.DTCID, fnSuccess, fnError);
    };

    /**
     * Helper method for a reference to the evidence package service facade.
     * 
     * @returns {jd.ui.eid.service.DTCBlacklist}
     */
    jd.ui.eid.common.BusinessProcessHelper.DTCBlacklist._getServiceFacade = function() {
        return jd.ui.eid.application.Application.getInstance().getServiceFacade("DTCBlacklist");
    };

})();