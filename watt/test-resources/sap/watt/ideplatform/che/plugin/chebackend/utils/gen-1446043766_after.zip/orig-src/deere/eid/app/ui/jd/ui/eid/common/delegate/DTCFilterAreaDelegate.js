(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DTCFilterAreaDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DateRangeToolPopupValueListItemDelegate");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.FilterAreaFormatter");

    /**
     * Constructor for a new DTCFilterAreaDelegate.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>fragmentId : string (default: undefined) The ID of the DTC Filter fragment </li>
     * <li>domainValuePath : string (default: undefined) The relative path to the Domain Filter Values </li>
     * <li>selectionPath : string (default: undefined) The relative path of the DTC Filter selection, like '/DTCFilters/FilterSelection'</li>
     * <li>filterStatePath: string (default: undefined) The relative path of the DTC Filter state, like '/DTCFilters/FilterState'</li>
     * </ul>
     * </li>
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>_delegator : internal delegates for filter area</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>filterAreaCleared : thrown after filter area is cleared</li>
     * <li>filterAreaReset : thrown after filter area is set to default values</li>
     * <li>filterItemValueChanged : thrown if a filter item value has changed</li>
     * <li>filterItemCleared : thrown if a filter item value is cleared</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The DTCFilterAreaDelegate contains all necessary handlers to handle a DTC Filter Area as a Fragment. Therefore it can be used from any
     *        view. Additional events are provided to handle DTC Filter events controller specific. All events contain the fragments which fired
     *        originally the event as a parameter ("FilerFragment"), so that the event handlers of the controllers can work with it. The DTC Filter
     *        Area Delegate works inside with other delegates objects which are hold in an internal aggregation.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.delegate.DTCFilterAreaDelegate
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.delegate.DTCFilterAreaDelegate", /** @lends jd.ui.eid.common.delegate.DTCFilterAreaDelegate */
    {

        metadata : {
            properties : {
                fragmentId : "string",
                domainValuePath : "string",
                selectionPath : "string",
                filterStatePath : "string"
            },
            aggregations : {
                _delegator : {
                    type : "sap.ui.base.ManagedObject",
                    multiple : true
                }
            },

            association : {
                filterArea : {
                    type : "jd.ui.eid.control.FilterArea"
                }
            },
            events : {
                filterAreaCleared : {},
                filterAreaReset : {},
                filterItemValueChanged : {},
                filterItemCleared : {}
            }
        },

        _oDTCCaptureTimeDateRangeDelegate : null,
        _oDTCCaptureTimeDateRangeToolPopup : null,
        _oMenu : null,

        /**
         * Returns the filter area object
         * 
         * @return {jd.ui.eid.control.FilterArea} the filter area object.
         */
        _getFilterArea : function() {
            return sap.ui.getCore().byId(this.getAssociation("filterArea"));
        },

        /**
         * Initializing the property binding of the filter area and adding additional fragments with own delegates for editing filter area data (like
         * Dates or manual PINs)
         * 
         * @return {jd.ui.eid.control.FilterArea} the filter area object.
         */
        _init : function() {
            var sFilterAreaId = this.getFragmentId();

            // Binding of clements that cannot be done in the view
            // cannot be done in XML Fragment
            // DTCFilterArea.fragment.xml, has to be done here as a
            // workaround (properties of type "object" do not work
            // in XML Views & Fragments
            //
            // problem cause:
            // XMLTemplateProcessor-dbg.js:396 (converts {mypath} to
            // {path:'mypath'})
            // sap-ui-core-dbg.js:27675 (ignores bindings in format
            // {path:'mypath'} if the property
            // type
            // is "object")

            // The binding of these filter area controls are also valid for the read only mode
            sap.ui.core.Fragment.byId(sFilterAreaId, "Platforms").bindProperty("selection", this.getSelectionPath() + "/PlatformAndProductLine");
            sap.ui.core.Fragment.byId(sFilterAreaId, "Models").bindProperty("selection", this.getSelectionPath() + "/Model");

            // We call a separate method to be overwritten by the read only delegate ('DTCFilterAreaReadOnlyDelegate') as these
            // controls are not part of the read only DTC filter area fragment
            this.initEditModeControls();

            // now call the methods for editing the filter area
            this.initNoiseReductionDateRangeToolPopup();
            this.initDTCCaptureTimeToolPopup();
        },

        /**
         * Checks whether the 'platform and product line' filter item has been provided and returns true then, false otherwise.
         * 
         * @returns {boolean} true if the requirements for fetching the DTC list are fulfilled, false otherwise.
         */
        isReadyToFetchDependentData : function() {
            var sFilterAreaId = this.getFragmentId();
            var oFilterItem = sap.ui.core.Fragment.byId(sFilterAreaId, "Platforms");
            var oSelection = oFilterItem.getSelection();
            return oSelection[0] && oSelection[0].PlatformID && oSelection[0].ProductLine[0];
        },

        /**
         * Initialize the binding for controls of the dtc filter area in edit mode In Read Only Mode other controls are used, so the method is
         * overwritten in delegate 'DTCFilterAreaReadOnlyDelegate'
         */
        initEditModeControls : function() {
            var sFilterAreaId = this.getFragmentId();

            // Set the path for the domain values
            sap.ui.core.Fragment.byId(sFilterAreaId, "FilterArea").bindElement(this.getDomainValuePath());

            // bind selection
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").bindProperty("selection", this.getSelectionPath() + "/BuildWeek");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildFactories").bindProperty("selection", this.getSelectionPath() + "/BuildFactory");
            sap.ui.core.Fragment.byId(sFilterAreaId, "DesignFactories").bindProperty("selection", this.getSelectionPath() + "/DesignFactory");
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").bindProperty("selection", this.getSelectionPath() + "/DTCCaptureTime");
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHours").bindProperty("selection", this.getSelectionPath() + "/EngineHour");
            sap.ui.core.Fragment.byId(sFilterAreaId, "MachineLocations").bindProperty("selection", this.getSelectionPath() + "/MachineLocation");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BranchCodes").bindProperty("selection", this.getSelectionPath() + "/BranchCode");
            sap.ui.core.Fragment.byId(sFilterAreaId, "FunctionalAreas").bindProperty("selection", this.getSelectionPath() + "/FunctionalArea");
            sap.ui.core.Fragment.byId(sFilterAreaId, "ManualPINList").bindProperty("selection", this.getSelectionPath() + "/ManualPinList");
            sap.ui.core.Fragment.byId(sFilterAreaId, "EmissionLevels").bindProperty("selection", this.getSelectionPath() + "/EmissionLevel");
            sap.ui.core.Fragment.byId(sFilterAreaId, "NoiseReduction").bindProperty("checked", this.getSelectionPath() + "/NoiseReduction");
            sap.ui.core.Fragment.byId(sFilterAreaId, "TestMachines").bindProperty("selectedKey", this.getSelectionPath() + "/TestMachine");
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").setDateFormatter(jd.ui.eid.common.DateHelper.yyyymmddToFormattedDate);
            // bind state
            sap.ui.core.Fragment.byId(sFilterAreaId, "Platforms").bindProperty("collapsed",
                    this.getFilterStatePath() + "/PlatformAndProductLine/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "Models").bindProperty("collapsed", this.getFilterStatePath() + "/Model/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").bindProperty("collapsed", this.getFilterStatePath() + "/BuildWeek/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildFactories").bindProperty("collapsed",
                    this.getFilterStatePath() + "/BuildFactory/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "DesignFactories").bindProperty("collapsed",
                    this.getFilterStatePath() + "/DesignFactory/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").bindProperty("collapsed",
                    this.getFilterStatePath() + "/DTCCaptureTime/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHours").bindProperty("collapsed", this.getFilterStatePath() + "/EngineHour/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "MachineLocations").bindProperty("collapsed",
                    this.getFilterStatePath() + "/MachineLocation/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "BranchCodes").bindProperty("collapsed", this.getFilterStatePath() + "/BranchCode/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "FunctionalAreas").bindProperty("collapsed",
                    this.getFilterStatePath() + "/FunctionalArea/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "ManualPINList").bindProperty("collapsed",
                    this.getFilterStatePath() + "/ManualPinList/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "EmissionLevels").bindProperty("collapsed",
                    this.getFilterStatePath() + "/EmissionLevel/Collapsed");
            sap.ui.core.Fragment.byId(sFilterAreaId, "TestMachines").bindProperty("collapsed", this.getFilterStatePath() + "/TestMachine/Collapsed");

        },

        /**
         * Destroys the delegate and all related managed objects.
         */
        destroy : function() {
            // Destroy controls
            this._oDTCCaptureTimeDateRangeDelegate.destroy();
            this._oDTCCaptureTimeDateRangeToolPopup.destroy();
            if (this._oMenu) {
                this._oMenu.destroy();
            }

            // Set properties to null
            this._oDTCCaptureTimeDateRangeDelegate = null;
            this._oDTCCaptureTimeDateRangeToolPopup = null;
            this._oMenu = null;

            sap.ui.base.ManagedObject.prototype.destroy(this, arguments);
        },

        /**
         * Sets the filter area from caller into the delegate. This is a required step. Otherwise the delegate does not work
         * 
         * @param {jd.ui.eid.control.FilterArea}
         *            oFilterArea the filter area control.
         */
        setFilterArea : function(oFilterArea) {
            this.setAssociation("filterArea", oFilterArea);
            this._init();
        },

        /**
         * Clearing the filter area and propagates event. The parameter "filterFragment" contains the fragment object where which event was originally
         * raised
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleClearFilterArea : function(oEvent) {
            sap.ui.core.Fragment.byId(this.getFragmentId(), "FilterArea").clear();
            this.fireFilterAreaCleared({
                filterFragment : oEvent.getSource()
            });
        },

        /**
         * Handles the reset action from the filter area's tool popup and resets the filter area. The parameter "filterFragment" contains the fragment
         * object where which event was originally raised
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleResetFilterArea : function(oEvent) {
            sap.ui.core.Fragment.byId(this.getFragmentId(), "FilterArea").reset();
            this.fireFilterAreaReset({
                filterFragment : oEvent.getSource()
            });
        },

        /**
         * Handles Filter Item Value Change by propagating event The parameter "filterFragment" contains the fragment object where which event was
         * originally raised
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleFilterItemValueChanged : function(oEvent) {
            this.fireFilterItemValueChanged({
                filterFragment : oEvent.getSource()
            });
        },
        /**
         * Handles Filter Item Value Clear by propagating event The parameter "filterFragment" contains the fragment object where which event was
         * originally raised
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleFilterItemCleared : function(oEvent) {
            // If this is the manual pin list, than we also need to clear the domain values.
            if (oEvent.getSource() == sap.ui.core.Fragment.byId(this.getFragmentId(), "ManualPINList")) {
                var oModel = sap.ui.getCore().getModel();
                oModel.setProperty("/DTCFilters/DomainValues/ManualPINListItems", []);
            }

            this.fireFilterItemCleared({
                filterFragment : oEvent.getSource()
            });
        },

        /**
         * Handles the <code>duplicateIgnored</code> event of the manual PIN list filter item. Notifies the user about the number of duplicates
         * which have automatically been removed.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the manual PIN list filter item.
         */
        handleManualPINListDuplicatesIgnored : function(oEvent) {
            jd.ui.eid.application.Application.getInstance().getNotificationCenter().success(
                    jd.ui.eid.common.I18NHelper.getText("INTERACTIVE_LIST_BOX_FILTER_ITEM_MSG_BATCH_INSERT_TOOL_POPUP_DUPLICATES_IGNORED", [oEvent
                            .getParameter("numberOfDuplicates")]));
        },

        /**
         * Handle the <code>press</code> event to trigger the Popup menu allowing clear and reset the filter setting
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by click on the clear/reset icon
         */
        handleOpenMenu : function(oEvent) {
            var sFilterAreaToolPopupFragmentId = sap.ui.core.Fragment.createId(this.getFragmentId(), "FilterAreaToolPopup");
            if (!this._oMenu) {
                this._oMenu = jd.ui.eid.xmlfragment(sFilterAreaToolPopupFragmentId, "jd.ui.eid.fragment.filter.DTCFilterAreaMenu", this);
            }
            var oOpener = sap.ui.core.Fragment.byId(this.getFragmentId(), "PopupOpener");
            var eDock = sap.ui.core.Popup.Dock;
            this._oMenu.open(false, oOpener.getFocusDomRef(), eDock.BeginTop, eDock.BeginBottom, oOpener.getDomRef());

        },

        /**
         * Initialize up the DTC Capture Time ToolPopup
         * 
         */
        initDTCCaptureTimeToolPopup : function() {
            var sFilterAreaFragmentId = this.getFragmentId();

            // setting value objects of DTC Capture Time Filter Item
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimeCustomRange").setValue({
                from : null,
                to : null,
            });
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimePreDefinedValueToday").setValue({
                Type : 'today'
            });
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimePreDefinedValueLastMonth").setValue({
                Type : 'duration',
                Duration : 1,
                Unit : 'month'
            });
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimePreDefinedValueLast3Months").setValue({
                Type : 'duration',
                Duration : 3,
                Unit : 'month'
            });
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimePreDefinedValueLast6Months").setValue({
                Type : 'duration',
                Duration : 6,
                Unit : 'month'
            });
            sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimePreDefinedValueLast12Months").setValue({
                Type : 'duration',
                Duration : 12,
                Unit : 'month'
            });

            var sDateRangeToolPopupFragmentId = sap.ui.core.Fragment.createId(sFilterAreaFragmentId, "DTCCaptureTimeCustomRangeToolPopup");
            // Create the data range toolPopup delegate object
            this._oDTCCaptureTimeDateRangeDelegate = new jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate({
                fragmentId : sDateRangeToolPopupFragmentId,
                allowEmpty : true
            });

            // Handle the delegate's 'canceled' event. The opener (ValueListItem) should be notified.. which in turn will raise an event to notify
            // the FilterItem
            this._oDTCCaptureTimeDateRangeDelegate.attachCanceled(function() {
                var oOpener = sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimeCustomRange");
                oOpener.onToolPopupCanceled();
            });

            // Create a date range toolPopup object and assign the delegate
            // object to it
            this._oDTCCaptureTimeDateRangeToolPopup = jd.ui.eid.xmlfragment(sDateRangeToolPopupFragmentId,
                    "jd.ui.eid.fragment.filter.DateRangeToolPopup", this._oDTCCaptureTimeDateRangeDelegate);

            // Get the date range item object and assign it to the toolPopup as
            // an opener
            var oCustomDateRangeItem = sap.ui.core.Fragment.byId(sFilterAreaFragmentId, "DTCCaptureTimeCustomRange");
            this._oDTCCaptureTimeDateRangeDelegate.setOpener(oCustomDateRangeItem);

            // Assign date range toolPopup to the opener
            oCustomDateRangeItem.setToolPopup(this._oDTCCaptureTimeDateRangeToolPopup);
        },

        /**
         * Initialize up the Date Range Tool Popup for Noise Reduction Filter Item
         * 
         */
        initNoiseReductionDateRangeToolPopup : function() {
            var sNoiseReductionDateRangeToolPopupFragmentId = sap.ui.core.Fragment.createId(this.getFragmentId(),
                    "NoiseReductionFilterItemTrendDateToolPopup");
            var oDelegate = new jd.ui.eid.common.delegate.DateRangeToolPopupModelDelegate({
                allowEmptyWhenOpening : true,
                fragmentId : sNoiseReductionDateRangeToolPopupFragmentId,
                modelPathFrom : this.getSelectionPath() + "/TrendRange/Start",
                modelPathTo : this.getSelectionPath() + "/TrendRange/End",
                modelUpdated : [this.handleFilterItemValueChanged, this]
            }).setModel(sap.ui.getCore().getModel());
            this.addAggregation("_delegator", oDelegate);
            var oPopup = jd.ui.eid
                    .xmlfragment(sNoiseReductionDateRangeToolPopupFragmentId, "jd.ui.eid.fragment.filter.DateRangeToolPopup", oDelegate);
            oPopup.bindProperty("title", "i18n>TREND_RANGE_TOOL_POPUP_HED_TITLE");
            var oOpener = sap.ui.core.Fragment.byId(this.getFragmentId(), "NoiseReductionTrendRange");
            oPopup.setPosition(sap.ui.core.Popup.Dock.BeginTop, sap.ui.core.Popup.Dock.EndTop, oOpener, "0 -5");
            oPopup.setOpener(oOpener);
            oOpener.attachPress(function() {
                if (oPopup.isOpen()) {
                    oPopup.close();
                } else {
                    oPopup.open();
                }
            });
        },

        /**
         * Checks if platform and product line is selected.
         * 
         * @returns {boolean} true, if platform and productline is selected
         */
        isPlatformAndProductlineSelected : function() {

            var oModel = sap.ui.getCore().getModel();
            var sPlatformAndProductLinePath = this.getSelectionPath() + "/PlatformAndProductLine";
            var oSelection = oModel.getProperty(sPlatformAndProductLinePath);
            if (!oSelection.length || (oSelection[0] && (!oSelection[0].ProductLine.length))) {

                return false;
            } else {
                return true;
            }
        },

        /**
         * Sets the visibility of all filter items except for 'platform and product line'.
         * 
         * @param {boolean}
         *            bVisible true to make the filter items visible, false otherwise.
         */
        setVisibilityOfDependentFilterItems : function(bVisible) {
            var sFilterAreaId = this.getFragmentId();
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildWeek").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "Models").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "DTCCaptureTime").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "BuildFactories").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "DesignFactories").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "EngineHours").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "MachineLocations").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "BranchCodes").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "FunctionalAreas").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "ManualPINList").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "EmissionLevels").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "NoiseReduction").setVisible(bVisible);
            sap.ui.core.Fragment.byId(sFilterAreaId, "TestMachines").setVisible(bVisible);

            // Also, toggle group
            var oDTCFiltersGroup = sap.ui.core.Fragment.byId(sFilterAreaId, "DTCFiltersGroup");
            if (oDTCFiltersGroup) {
                oDTCFiltersGroup.setVisible(bVisible);
            }
        },
        /**
         * Sets filter area to busy state (white color) or back to normal state.
         * 
         * @param {boolean}
         *            bBusy true to set the filter area to busy, false otherwise.
         */
        setBusy : function(bBusy) {
            var oFilterArea = sap.ui.core.Fragment.byId(this.getFragmentId(), "FilterArea");
            oFilterArea.setBusy(bBusy);
        }
    });
})();