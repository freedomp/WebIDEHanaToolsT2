(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.NotificationCenter");

    /**
     * Constructor for a new NotificationCenter.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>alertTitle : string (default: '') The default title of alert notifications.</li>
     * <li>confirmationTitle : string (default: '') The default title of confirmation notifications.</li>
     * <li>successTitle : string (default: '') The default title of success notifications.</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>notificationBar : sap.ui.ux3.NotificationBar The notification bar control to display notifications.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The notification center provides means to display different kinds of notifications to the user. Ideally, there is one central instance
     *        to the consuming application.<br>
     *        The following notifications are available:
     *        <ul>
     *        <li>alert
     *        <ul>
     *        <li>display: displayed via {@link sap.ui.commons.MessageBox}.</li>
     *        </ul>
     *        </li>
     *        <li>confirmation
     *        <ul>
     *        <li>display: displayed via {@link sap.ui.commons.MessageBox}.</li>
     *        </ul>
     *        </li>
     *        <li>success
     *        <ul>
     *        <li>display: displayed in the notification bar in a separate notifier.</li>
     *        <li>behavior: once a success notification is available and the user has moved the mouse, a timeout is created which will hide the
     *        notification bar after the amount if milliseconds as specified in <code>_iFadeOutTimeout</code>. If a new success notification is
     *        published in the meantime, the previous timeout is cleared and a new one is started.</li>
     *        </ul>
     *        </li>
     *        </ul>
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.NotificationCenter
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.NotificationCenter", /** @lends jd.ui.eid.common.NotificationCenter */
    {
        metadata : {
            properties : {
                alertTitle : {
                    type : "string",
                    defaultValue : ""
                },
                confirmationTitle : {
                    type : "string",
                    defaultValue : ""
                },
                successTitle : {
                    type : "string",
                    defaultValue : ""
                }
            },
            associations : {
                notificationBar : {
                    type : "sap.ui.ux3.NotificationBar",
                    multiple : false
                }
            }
        },

        /**
         * Show alert to the user. The callback doesn't receive any parameters.
         * 
         * @param {string}
         *            sMessage the message text to be displayed.
         * @param {function}
         *            [fnCallback] callback function to be called when the user closes the alert dialog.
         */
        alert : function(sMessage, fnCallback, sTitle) {
            // Workaround to assign custom style class
            var sId = $.sap.uid();
            sap.ui.commons.MessageBox.alert(sMessage, fnCallback, this.getAlertTitle(), sId);
            sap.ui.getCore().byId(sId).addStyleClass("jdUiDlg");
        },

        /**
         * Show confirmation to the user. The callback receives <code>bConfirmed</code> as parameter.
         * 
         * @param {string}
         *            sMessage the message text to be displayed.
         * @param {function}
         *            [fnCallback] callback function to be called when the user closes the confirmation dialog.
         */
        confirm : function(sMessage, fnCallback) {
            // Workaround to assign style class
            var sId = $.sap.uid();
            sap.ui.commons.MessageBox.confirm(sMessage, fnCallback, this.getConfirmationTitle(), sId);
            sap.ui.getCore().byId(sId).addStyleClass("jdUiDlg");
        },

        /**
         * Show confirmation to the user about pending data loss. The callback receives <code>iButtonIndex</code> as parameter.
         * 
         * @param {string}
         *            sMessage the message text to be displayed.
         * @param {function}
         *            [fnCallback] callback function to be called when the user closes the confirmation dialog.
         */
        confirmDataLoss : function(sMessage, fnCallback) {
            var iResult = 2, oDialog = null;

            oDialog = sap.ui.core.Fragment.byId("DataLossPopup", "Dialog");

            if (!oDialog) {

                oDialog = jd.ui.eid.xmlfragment("DataLossPopup", "jd.ui.eid.fragment.dialog.DataLossDialog", {
                    handleButtonPress : function(oEvent) {
                        iResult = oDialog.indexOfButton(oEvent.getSource());
                        oDialog.close();
                    },
                    handleClosed : function(oEvent) {
                        if (fnCallback) {
                            fnCallback(iResult);
                        }
                        oEvent.getSource().detachClosed(this.handleClosed);
                        oEvent.getSource().destroy();
                    }
                });
                if (sMessage) {
                    sap.ui.core.Fragment.byId("DataLossPopup", "Message").setText(sMessage);
                }
            }
            oDialog.open();
        },

        /**
         * Show success message to the user.
         * 
         * @param {string}
         *            sMessage the message text to be displayed.
         */
        success : function(sMessage) {
            var oMessage = new sap.ui.core.Message({
                text : sMessage,
                level : sap.ui.core.MessageType.Success
            });
            this._getSuccessNotifier().addMessage(oMessage);
            this._getNotificationBar().setVisibleStatus(sap.ui.ux3.NotificationBarStatus.Default);

            // Adjust the Z-Index of the notification center, to make sure it's always visible
            this._adjustNotificationBarZIndex();

            this._registerFadeOutNotificationBar();
        },

        /*
         * Reference to the notifier for success notifications.
         */
        _successNotifier : null,

        /**
         * Get the notifier for success notifications.
         * 
         * @returns {sap.ui.ux3.Notifier}
         */
        _getSuccessNotifier : function() {
            if (!this._successNotifier) {
                this._successNotifier = new sap.ui.ux3.Notifier({
                    title : this.getSuccessTitle(),
                    icon : ""
                });
                this._getNotificationBar().setMessageNotifier(this._successNotifier);
            }
            return this._successNotifier;
        },

        /**
         * Get the notification bar of the notification center.
         * 
         * @returns {sap.ui.ux3.NavigationBar}
         */
        _getNotificationBar : function() {
            return sap.ui.getCore().byId(this.getNotificationBar());
        },

        /**
         * Register for fading out the navigation bar after the mouse has been moved by the user.
         */
        _registerFadeOutNotificationBar : function() {
            clearTimeout(this._oFadeOutTimeout);
            var that = this;

            $("html").one('mousemove', function() {
                clearTimeout(that._oFadeOutTimeout);
                that._delayNotificationBarFadeOut();
            });
        },

        /**
         * Adjusts the Z-Index for the notification bar, to ensure that it is always on top and is visible. This method should be invoked everytime
         * the notification center is being shown.
         */
        _adjustNotificationBarZIndex : function() {
            // Get a reference to the notification bar
            var oNotificationBar = this._getNotificationBar();

            // Get the Z-Index from the framework that will be the highest z-index (the next unallotted z-index)
            var iNextZIndex = sap.ui.core.Popup.getNextZIndex();

            // Apply this to Z-index to the notification bar. Cannot use jQuery (.css method), because we need the '!important' tag.
            var sCurrentStyle = oNotificationBar.$().parent().attr("style");
            var sNewStyle = sCurrentStyle + " z-index: " + iNextZIndex + " !important;";
            oNotificationBar.$().parent().attr("style", sNewStyle);
        },

        /*
         * The timeout for fading out the notification bar after the mouse has been moved.
         */
        _iFadeOutTimeout : 5000,

        /*
         * Reference to the timout object that's currently active.
         */
        _oFadeOutTimeout : null,

        /**
         * Fade out the notification bar after the configured timeout. The timeout starts once the mouse has been moved.
         */
        _delayNotificationBarFadeOut : function() {
            var that = this;
            $("html").one("mousemove", function() {
                that._oFadeOutTimeout = setTimeout(function() {
                    that._getNotificationBar().setVisibleStatus(sap.ui.ux3.NotificationBarStatus.Min);
                }, that._iFadeOutTimeout);
            });
        }
    });

})();