(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.FilterDomainValueServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oServiceFacade = new jd.ui.eid.service.FilterDomainValueServiceFacade("http://sap.com", "/folder/to/test/data", oModel, true);

    // Prepare static test data
    var oDataGetPlatformAndProductLine = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getPlatformAndProductLine_Response.json").data;
    var oDataGetDTCFilterDomainValues = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getDTCFilterDomainValues_Response.json").data;

    module("jd.ui.eid.service.FilterDomainValueServiceFacade", {
        setup : function() {
            // Reset model
            oModel.setProperty("/DTCFilters", {
                "DomainValues" : undefined
            });

            // Prepare fake ajax requests
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };
        },
        teardown : function() {
            this.xhr.restore();
        }
    });

    test("getPlatformAndProductLine() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        oServiceFacade.getPlatformAndProductLine(function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    test("getPlatformAndProductLine() should call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();

        // Trigger the ajax request
        oServiceFacade.getPlatformAndProductLine(fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetPlatformAndProductLine));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataGetPlatformAndProductLine));
    });

    test("getPlatformAndProductLine() should call the error callback upon HTTP 500.", function() {
        // Define callback spy
        var fnError = sinon.spy();

        // Trigger the ajax request
        oServiceFacade.getPlatformAndProductLine(function() {
        }, fnError);

        // That's how we respond to the ajax request
        this.requests[0].respond(500, {
            "Content-Type" : "application/json"
        });

        // Assertion
        ok(fnError.called);
    });

    test("getPlatformAndProductLine() should update the model at path /DTCFilters/DomainValues/Platforms", function() {
        var oValue;

        // Assertion
        oValue = oModel.getProperty("/DTCFilter/DomainValues/Platforms");
        ok(!oValue);

        // Trigger the ajax request
        oServiceFacade.getPlatformAndProductLine(function() {
        }, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetPlatformAndProductLine));

        // Assertion
        oValue = oModel.getProperty("/DTCFilters/DomainValues/Platforms");
        deepEqual(oValue, oDataGetPlatformAndProductLine.Result.Platforms);
    });

    test("getDTCFilterDomainValues() should make an AJAX request.", function() {
        equal(0, this.requests.length);

        oServiceFacade.getDTCFilterDomainValues('Platform', 'ProductLine', null, null);

        equal(1, this.requests.length);
    });

    test("getDTCFilterDomainValues() should update the model at path /DTCFilters/DomainValues/*.", function() {

        // Trigger the ajax request
        oServiceFacade.getDTCFilterDomainValues('Platform', 'ProductLine', null, null);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCFilterDomainValues));

        // Manually move the empty domain values of the expected result to the end of the array.
        var mDomainValues = oDataGetDTCFilterDomainValues.Result;
        $.each([mDomainValues.BuildFactories, mDomainValues.DesignFactories, mDomainValues.MachineLocations, mDomainValues.BranchCodes,
                mDomainValues.FunctionalAreas, mDomainValues.EmissionLevels], function(iIdx, aArray) {
            if (aArray[0] && aArray[0].ID === "") {
                var mUnknownItem = aArray.shift(); // Take it from position 1...
                aArray.push(mUnknownItem); // ... and move it to the end.
            }
        });

        var oValue;
        // Assertion
        ok(oModel.getProperty("/DTCFilters/DomainValues"));
        // Spot Check 1
        oValue = oModel.getProperty("/DTCFilters/DomainValues/Models");
        deepEqual(oValue, mDomainValues.Models);
        // Spot Check 2
        oValue = oModel.getProperty("/DTCFilters/DomainValues/BuildFactories");
        deepEqual(oValue, mDomainValues.BuildFactories);
    });

    test("getDTCFilterDomainValues() should leave the model at path /DTCFilters/DomainValues/Platforms untouched.", function() {
        // Pre-populate the platforms path
        var oPlatforms = {
            Platforms : ['Platform 1', 'Platform 2']
        };
        oModel.setProperty("/DTCFilters/DomainValues", oPlatforms);

        // Trigger the ajax request
        oServiceFacade.getDTCFilterDomainValues('Platform', 'ProductLine', null, null);

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataGetDTCFilterDomainValues));

        // Assertion
        var oValue = oModel.getProperty("/DTCFilters/DomainValues/Platforms");
        deepEqual(oValue, oPlatforms.Platforms);
    });

    test("getDTCFilterDomainValues() should update the model at path /DTCFilters/DomainValues/* if the path has already been pre-populated.",
            function() {
                // Pre-populate the model
                oModel.setProperty("/DTCFilters/DomainValues", jQuery.extend(true, {}, oDataGetDTCFilterDomainValues.Result));

                // Trigger the ajax request
                oServiceFacade.getDTCFilterDomainValues('Platform', 'ProductLine', null, null);

                // Prepare different reponse data
                var oData = jQuery.extend(true, {}, oDataGetDTCFilterDomainValues);
                oData.Result.Models[0].Name = "a new model name";

                // That's how we respond to the ajax request
                this.requests[0].respond(200, {
                    "Content-Type" : "application/json"
                }, JSON.stringify(oData));

                var oValue;
                // Assertion
                ok(oModel.getProperty("/DTCFilters/DomainValues"));
                // Spot Check 1
                oValue = oModel.getProperty("/DTCFilters/DomainValues/Models");
                deepEqual(oValue, oData.Result.Models);
                // Spot Check 2
                oValue = oModel.getProperty("/DTCFilters/DomainValues/BuildFactories");
                deepEqual(oValue, oData.Result.BuildFactories);
            });
})();
