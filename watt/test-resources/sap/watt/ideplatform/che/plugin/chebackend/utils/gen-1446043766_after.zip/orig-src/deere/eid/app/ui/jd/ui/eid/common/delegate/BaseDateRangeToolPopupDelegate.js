(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate");
    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");

    /**
     * Constructor for a new BaseDateRangeToolPopupDelegate.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>allowEmpty : boolean (default: false) true if an empty date range is allowed, false otherwise.</li>
     * <li>fragmentId : string (default: "") The ID of the toolpopup fragement </li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>opener : jd.ui.eid.control.ValueListItem The valueListItem that opens the toolPopup.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>canceled : fired if the tool popup is canceled.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The BaseDateRangeToolPopupDelegate contains all necessary handlers of the date range toolpopup with a valueListItem as an opener.
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate", /** @lends jd.ui.eid.common.delegate.BaseDateRangeToolPopupDelegate */
    {

        metadata : {
            properties : {
                allowEmpty : {
                    type : "boolean",
                    defaultValue : false
                },
                fragmentId : "string"
            },
            associations : {
                opener : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                }
            },
            events : {
                canceled : {}
            }
        },

        /**
         * Map that stores whether the last value entered into each DatePicker by the user was valid.
         */
        _mDatePickerValidity : {
            from : true,
            to : true
        },

        /**
         * Get the valueListItem that opens the toolPopup
         * 
         * @return {jd.ui.eid.control.ValueListItem} the opener object.
         */
        _getOpener : function() {
            return sap.ui.getCore().byId(this.getAssociation("opener"));
        },

        /**
         * Gets the from date picker control.
         * 
         * @returns {sap.ui.commons.DatePicker}
         */
        _getFromDatePicker : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "from");
        },

        /**
         * Gets the to date picker control.
         * 
         * @returns {sap.ui.commons.DatePicker}
         */
        _getToDatePicker : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "to");
        },

        /**
         * Gets the tool popup.
         * 
         * @returns {sap.ui.ux3.ToolPopup}
         */
        _getToolPopup : function() {
            return sap.ui.core.Fragment.byId(this.getFragmentId(), "DateRangeToolPopup");
        },

        /**
         * Handles the change event of the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupRangeChanged : function(oEvent) {
            // Store whether this event indicates that an invalid value was entered. This will later be used for validation.
            var bValidValue = !oEvent.getParameter("invalidValue");
            if (oEvent.getSource() == this._getFromDatePicker()) {
                this._mDatePickerValidity.from = bValidValue;
            } else if (oEvent.getSource() == this._getToDatePicker()) {
                this._mDatePickerValidity.to = bValidValue;
            }

            // Trigger a validation
            this._validateDateRangeToolPopupRange(this._getFromDatePicker(), this._getToDatePicker());
        },

        /**
         * Validates the date range toolpopup
         * 
         * @param {sap.ui.commons.Datepicker}
         *            oFromDatePicker the datepicker for the from date
         * @param {sap.ui.commons.Datepicker}
         *            oToDatePicker the datepicker for the to date
         * @returns {boolean} True if valid, False otherwise.
         */
        _validateDateRangeToolPopupRange : function(oFromDatePicker, oToDatePicker) {
            var bValid;

            // If the last 'changed' event from the 'from' and/or 'to' DatePickers indicated an invalid value entered by the user, then no need to
            // validate the date range.
            bValid = this._mDatePickerValidity.from && this._mDatePickerValidity.to;
            if (bValid) {
                bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange(oFromDatePicker.getYyyymmdd(), oToDatePicker.getYyyymmdd());
            }

            if (!bValid) {
                // Create a callout to indicate an error with the
                // from-datepicker
                var oFromDatePickerText = new sap.ui.commons.TextView({
                    text : "{i18n>DATE_RANGE_FILTER_ITEM_ERROR_START}"
                }).addStyleClass("jdUiTv");
                var oFromCallout = new sap.ui.commons.Callout({
                    content : oFromDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the from-datepicker
                oFromDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oFromDatePicker.setTooltip(oFromCallout);

                // Create a callout to indicate an error with the
                // to-datepicker
                var oToDatePickerText = new sap.ui.commons.TextView({
                    text : "{i18n>DATE_RANGE_FILTER_ITEM_ERROR_END}"
                }).addStyleClass("jdUiTv");
                var oToCallout = new sap.ui.commons.Callout({
                    content : oToDatePickerText
                }).addStyleClass("jdUiClt");

                // Set callout as a tooltip of the to-datepicker
                oToDatePicker.setValueState(sap.ui.core.ValueState.Error);
                oToDatePicker.setTooltip(oToCallout);
            } else {
                // Set the datepickers as valid
                oFromDatePicker.setValueState(sap.ui.core.ValueState.None);
                oToDatePicker.setValueState(sap.ui.core.ValueState.None);

                // Remove the error callouts
                oFromDatePicker.setTooltip(null);
                oToDatePicker.setTooltip(null);
            }
            return bValid;
        },

        /**
         * Checks whether the user's input is empty
         * 
         * @returns {boolean} true if the fields in the toolpopup are empty, false otherwise.
         */
        _isUserInputEmpty : function() {
            if (!this._getFromDatePicker().getValue() && !this._getToDatePicker().getValue()) {
                return true;
            }
            return false;
        },

        /**
         * Checks whether the source of the date range is empty.
         * 
         * @returns {boolean} true if the source is empty, false otherwise.
         */
        _isSourceEmpty : function() {
            if (!(this._getOpener().getValue().from || this._getOpener().getValue().to)) {
                return true;
            }
            return false;
        },

        /**
         * Populates the values from the source to the controls in the tool popup.
         */
        _populateToolPopupValues : function() {
            this._getFromDatePicker().setYyyymmdd(this._getOpener().getValue().from);
            this._getToDatePicker().setYyyymmdd(this._getOpener().getValue().to);
        },

        /**
         * Create the open event handler of the custom date range item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupOpen : function(oEvent) {
            if (!(this._isSourceEmpty() && this.getAllowEmpty())) {
                this._populateToolPopupValues();
                this._validateDateRangeToolPopupRange(this._getFromDatePicker(), this._getToDatePicker());
            } else {
                // If we don't validate it, the fields might still be flagged as invalid from the last time.
                var oFromDatePicker = this._getFromDatePicker();
                var oToDatePicker = this._getToDatePicker();
                // Set the datepickers as valid
                oFromDatePicker.setValueState(sap.ui.core.ValueState.None);
                oToDatePicker.setValueState(sap.ui.core.ValueState.None);
                // Remove the error callouts
                oFromDatePicker.setTooltip(null);
                oToDatePicker.setTooltip(null);
            }
        },

        /**
         * Updates the source based on the values from the tool popup.
         */
        _updateSource : function() {
            this._getOpener().changeValue({
                from : this._getFromDatePicker().getYyyymmdd(),
                to : this._getToDatePicker().getYyyymmdd()
            });
        },

        /**
         * Handles the event of the "submit button pressed" / "enter pressed"-event at the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupSubmit : function(oEvent) {
            if (!(this._isUserInputEmpty() && this.getAllowEmpty())) {
                if (this._validateDateRangeToolPopupRange(this._getFromDatePicker(), this._getToDatePicker())) {
                    this._updateSource();
                    this._getToolPopup().close(0);
                }
            } else if (this._isUserInputEmpty()) {
                this._updateSource();
                this._getToolPopup().close(0);
            }
        },

        /**
         * Handles the cancel event of the custom date range toolpopup
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleDateRangeToolPopupCancel : function(oEvent) {
            var oDateRangeToolPopup = this._getToolPopup();
            oDateRangeToolPopup.close(0);
            this.fireCanceled();
        }
    });
})();