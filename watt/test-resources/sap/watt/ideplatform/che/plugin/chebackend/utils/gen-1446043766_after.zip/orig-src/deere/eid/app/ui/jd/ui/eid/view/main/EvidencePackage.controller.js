(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.EvidencePackageFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EvidencePackageSaveController");

    /**
     * @class
     * <p>
     * The Evidence Package Details provides a Thing Viewer to display the details of Evidence Package
     * </p>
     * <p>
     * The view raises the following <strong>event bus</strong> events:
     * <ul>
     * <li>{@link jd.ui.eid.Events#EvidencePackageView::contextChanged} : Raised after the context changed</li>
     * <li>{@link jd.ui.eid.Events#EvidencePackageView::close} : Notifies the overlay to close the view</li>
     * <li>{@link jd.ui.eid.Events#PrintEvidencePackage::inputShared} : Raised after parameters are sent to the print application</li>
     * </ul>
     * </p>
     * 
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @augments jd.ui.eid.view.main.shared.EvidencePackageSaveController
     * @name jd.ui.eid.view.main.EvidencePackage
     */
    sap.ui.controller("jd.ui.eid.view.main.EvidencePackage", jQuery
            .extend(true, {}, jd.ui.eid.view.BaseController, jd.ui.eid.view.main.shared.EvidencePackageSaveController,
                    /** @lends jd.ui.eid.view.main.EvidencePackage */
                    {

                        _oEditButton : null,
                        _oEPChartFacetContent : null,
                        _oEPDTACFacetContent : null,
                        _oEPDTCSFacetContent : null,
                        _oEPMachineOptionCodeFacetContent : null,
                        _oEPPINPopulationFacetContent : null,
                        _oEPWarrantyClaimFacetContent : null,
                        _oSaveButton : null,
                        _oSaveSendLinkButton : null,
                        _oSendLinkButton : null,
                        _oSendLinkDialog : null,
                        _oSetClosedButton : null,
                        _oPrintFilterDialog : null,
                        _oPrintPreviewDialog : null,
                        _oDLM : null,
                        _oView : null,
                        _sEventBusPrintChannelId : "PrintEvidencePackage",
                        _sEvidencePackageID : null,

                        /**
                         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify
                         * the View before it is displayed, to bind event handlers and do other one-time initialization.
                         * 
                         * @memberOf jd.ui.eid.view.main.EvidencePackage
                         */
                        onInit : function() {
                            this._oView = this.getView();
                            this._oView.addStyleClass("jdUiEidViewEvidencePackage");
                            this._oEditButton = this.byId("Edit");
                            this._oSaveButton = this.byId("Save")
                            this._oSaveSendLinkButton = this.byId("SaveSendLink");
                            this._oSendLinkButton = this.byId("SendLink");
                            this._oSetClosedButton = this.byId("SetClosed");

                            // Config
                            this.mEvidencePackageSaveControllerConfig.aBusyControls = [this._oView.getContent()[0]];
                            this.mEvidencePackageSaveControllerConfig.aDisabledControlsWhileSave = [this._oSaveSendLinkButton, this._oSaveButton];

                            // Subcribe to event bus
                            var oEventBus = sap.ui.getCore().getEventBus();
                            oEventBus.subscribe('EvidencePackage', 'DTCRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.subscribe('EvidencePackage', 'DTACCaseRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.subscribe('EvidencePackage', 'warrantyClaimRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.subscribe('Navigation', 'navigating', this.handleNavigation, this);
                            oEventBus.subscribe(this._sEventBusPrintChannelId, "requestInput", this.handlePrintApplicationRequestInput, this);
                            oEventBus.subscribe(this._sEventBusPrintChannelId, "ready", this.handlePrintApplicationReady, this);

                            // Initialize merge controllers
                            this.initEvidencePackageSaveController();

                            // Attach data loss manager so that we can check whether there's unsaved data on this
                            // view.
                            var that = this;
                            this._oDLM = jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance();
                            this._oDLM.setSaveHandler(function(fnNavigationHandler) {
                                var tmp = jd.ui.eid.view.main.shared.EvidencePackageSaveController;
                                var iAction = tmp.EvidencePackageSaveDialogButton.Save;
                                that.saveEvidencePackage(iAction, $.proxy(that._close, that));
                            });
                        },

                        /**
                         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                         * 
                         * @memberOf jd.ui.eid.view.main.EvidencePackage
                         */
                        onExit : function() {
                            // Unsubcribe to event bus
                            var oEventBus = sap.ui.getCore().getEventBus();
                            oEventBus.unsubscribe('EvidencePackage', 'DTCRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.unsubscribe('EvidencePackage', 'DTACCaseRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.unsubscribe('EvidencePackage', 'warrantyClaimRemoved', this.handleAnalysisDataRefreshNeeded, this);
                            oEventBus.unsubscribe('Navigation', 'navigating', this.handleNavigation, this);
                            oEventBus.unsubscribe(this._sEventBusPrintChannelId, "requestInput", this.handlePrintApplicationRequestInput, this);
                            oEventBus.unsubscribe(this._sEventBusPrintChannelId, "ready", this.handlePrintApplicationReady, this);

                            // Destroy merge controllers
                            this.exitEvidencePackageSaveController();

                            $.each([this._oEPChartFacetContent, this._oEPDTACFacetContent, this._oEPDTCSFacetContent,
                                    this._oEPMachineOptionCodeFacetContent, this._oEPPINPopulationFacetContent, this._oEPWarrantyClaimFacetContent,
                                    this._oPrintFilterDialog, this._oPrintPreviewDialog], function(iIdx, oManagedObject) {
                                if (oManagedObject) {
                                    oManagedObject.destroy();
                                }
                                oManagedObject = null;
                            });

                            this._oEditButton = null;
                            this._oSaveButton = null;
                            this._oSaveSendLinkButton = null;
                            this._oSendLinkButton = null;
                            this._oSetClosedButton = null;
                        },

                        /**
                         * Called when user selects a Navigation Item
                         * 
                         * @param {sap.ui.base.Event}
                         *            oEvent the fired event.
                         * 
                         * @memberOf jd.ui.eid.view.main.EvidencePackage
                         */
                        onFacetSelected : function(oEvent) {
                            this._showFacet(oEvent.getParameter("key"));
                        },

                        /**
                         * Set the Evidence Package ID
                         * 
                         * @param {string}
                         *            sEvidencePackageID the Evidence Package ID
                         * @memberOf jd.ui.eid.view.main.EvidencePackage
                         */
                        setContext : function(sEvidencePackageID) {
                            this._sEvidencePackageID = sEvidencePackageID;
                        },

                        /**
                         * Handles the navigating event.
                         * 
                         * @param {string}
                         *            sChannelId the channel id
                         * @param {string}
                         *            sEventId the event name
                         * @param {object}
                         *            oData the data passed along with the event.
                         * @see jd.ui.eid.Events#Navigation::navigating
                         */
                        handleNavigation : function(sChannelId, sEventId, oData) {
                            if (oData.target == 'jd.ui.eid.view.main.EvidencePackage') {

                                var oModel = sap.ui.getCore().getModel();

                                var sCurrentEvidencePackageId = oModel.getProperty("/EvidencePackageDetails/Header/PackageID");

                                if (this._sEvidencePackageID === sCurrentEvidencePackageId) {
                                    // New package
                                    // Either we have already the current loaded evidence package in the memory or
                                    // we have a new, never saved, evidence package in the memory.
                                    // In both cases we just have to load the summary details from db
                                    this._handleButtonStatesBasedOnEvidencePackageHeader();
                                    this._showFacet("SUMMARY");
                                    sap.ui.getCore().getEventBus().publish('EvidencePackageView', 'contextChanged');
                                } else {
                                    this.loadEvidencePackageDetailsHeader(this._sEvidencePackageID);
                                }
                            }
                        },

                        /**
                         * enable thing actions depending if user owns the package or not
                         * 
                         */
                        _handleButtonStatesBasedOnEvidencePackageHeader : function() {
                            var mEvidencePackageHeader = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");
                            var eClosed = jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Close;
                            var bIsClosed = mEvidencePackageHeader.PackageStatusID === eClosed;

                            this.byId("Print").setVisible(true);
                            if (jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.IsPackageOwnedByCurrentUser() && !bIsClosed) {
                                this._oSendLinkButton.setVisible(false);
                                this._oSaveSendLinkButton.setVisible(true);
                                this._oSaveButton.setVisible(true);
                                this._oEditButton.setVisible(true);
                                this._oSetClosedButton.setVisible(true);
                            } else {
                                // User has read access only or package has already been closed, so it should not be modifiable
                                this._oSendLinkButton.setVisible(true);
                                this._oSaveSendLinkButton.setVisible(false);
                                this._oSaveButton.setVisible(false);
                                this._oEditButton.setVisible(false);
                                this._oSetClosedButton.setVisible(false);
                            }
                        },

                        /**
                         * load the header data of the evidence package
                         * 
                         * @param {string}
                         *            sEvidencePackageID evidence package id
                         */
                        loadEvidencePackageDetailsHeader : function(sEvidencePackageID) {
                            var that = this;
                            var oModel = sap.ui.getCore().getModel();

                            // Hide all buttons first
                            this._oSendLinkButton.setVisible(false);
                            this._oSaveSendLinkButton.setVisible(false);
                            this._oSaveButton.setVisible(false);
                            this._oEditButton.setVisible(false);
                            this._oSetClosedButton.setVisible(false);
                            this.byId("Print").setVisible(false);

                            this.getView().getContent()[0].setBusy(true);
                            this.getServiceFacade("EvidencePackage").getEvidencePackageDetails(
                                    sEvidencePackageID,
                                    // success
                                    function() {
                                        sap.ui.getCore().getEventBus().publish('EvidencePackageView', 'contextChanged');
                                        that._handleButtonStatesBasedOnEvidencePackageHeader();
                                        that._showFacet("SUMMARY");
                                        that.getView().getContent()[0].setBusy(false);
                                    },
                                    // failed
                                    function() {
                                        that.getView().getContent()[0].setBusy(false);
                                        oModel.setProperty("/EvidencePackageDetails/Header", $.extend(true, {},
                                                jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails.Header));
                                        that._onRequestFailed.apply(that, arguments);
                                    });
                        },

                        /**
                         * Show facet content for selected Navigation Item
                         * 
                         * @param {string}
                         *            sKey the key of the selected navigation item
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        _showFacet : function(sKey) {
                            var oThingViewer = this.byId("ThingViewer");
                            oThingViewer.removeAllFacetContent();

                            // Set Selected Facet in case of a clicked link
                            oThingViewer.setSelectedFacet(this.byId(sKey));

                            switch (sKey) {
                                case "SUMMARY" :
                                    if (this._oEPChartFacetContent == null) {
                                        this._oEPChartFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.Summary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPChartFacetContent);
                                    break;

                                case "DTACS" :
                                    if (this._oEPDTACFacetContent == null) {
                                        this._oEPDTACFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.DTACCaseSummary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPDTACFacetContent);
                                    break;

                                case "WARRANTY_CLAIMS" :
                                    if (this._oEPWarrantyClaimFacetContent == null) {
                                        this._oEPWarrantyClaimFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPWarrantyClaimFacetContent);
                                    break;

                                case "DTCS" :
                                    if (this._oEPDTCSFacetContent == null) {
                                        this._oEPDTCSFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.DTCSummary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPDTCSFacetContent);
                                    break;

                                case "MACHINE_OPTION_CODE" :

                                    if (this._oEPMachineOptionCodeFacetContent == null) {
                                        this._oEPMachineOptionCodeFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.MachineOptionSummary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPMachineOptionCodeFacetContent);
                                    break;

                                case "POPULATION" :
                                    if (this._oEPPINPopulationFacetContent == null) {
                                        this._oEPPINPopulationFacetContent = new sap.ui.ux3.ThingGroup({
                                            colspan : true,
                                            content : new jd.ui.eid.xmlview("jd.ui.eid.view.main.evidencepackage.PINPopulationSummary")
                                        });
                                    }
                                    oThingViewer.addFacetContent(this._oEPPINPopulationFacetContent);
                                    break;
                            }
                        },

                        /**
                         * Event handler for the 'Close package' button
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        onSetClosedSelected : function() {
                            var that = this;
                            var oModel = sap.ui.getCore().getModel();
                            var oEvidencePackageService = this.getServiceFacade("EvidencePackage");

                            // Get evidence package ID to be deleted
                            var sEvidencePackageID = oModel.getProperty("/EvidencePackageDetails/Header/PackageID");
                            var sEvidencePackageName = oModel.getProperty("/EvidencePackageDetails/Header/PackageName");

                            // Callback to be executed when close fails
                            var fnOnCloseError = function() {
                                var sErrorMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSE_CLOSE_PACKAGE_FAILED");
                                that.getNotificationCenter().alert(sErrorMessage);
                                that._oView.setBusy(false);
                            };

                            // Callback to be executed when close is successful
                            var fnOnCloseSuccess = function() {
                                // Update the evidence package header model, so that UI state will be updated properly.
                                oModel.setProperty("/EvidencePackageDetails/Header/PackageStatusID",
                                        jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Close);
                                var sSuccessMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSI_CLOSE_PACKAGE_SUCCESSFUL");
                                that.getNotificationCenter().success(sSuccessMessage);
                                that._handleButtonStatesBasedOnEvidencePackageHeader();
                                that._oView.setBusy(false);
                            };

                            // Callback to be executed if user confirms closing the
                            // package
                            var fnOnCloseConfirmation = function(bConfirmed) {
                                if (bConfirmed) {
                                    that._oView.setBusy(true);
                                    oEvidencePackageService.closeEvidencePackage(sEvidencePackageID, fnOnCloseSuccess, fnOnCloseError);
                                }
                            };

                            // Get confirmation from user before closing
                            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CLOSE_PACKAGE_CONFIRM", [
                                    sEvidencePackageID, sEvidencePackageName]);
                            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnCloseConfirmation);
                        },

                        /**
                         * event handler to go editing the work sheet
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        onEditSelected : function(oEvent) {
                            var oWorksheetOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
                            if (!oWorksheetOverlay.isOpen()) {
                                var oModel = sap.ui.getCore().getModel();
                                var oOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
                                oOverlay.setContext({
                                    EvidencePackageID : oModel.getProperty("/EvidencePackageDetails/Header/PackageID")
                                });
                                oOverlay.open();
                            }
                            this._close();
                        },

                        /**
                         * event handler to cancel evidence package summary
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        onCancel : function(oEvent) {
                            var oWorksheetOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
                            var that = this;

                            // Raise Data Loss Manager only if the worksheet is also closed
                            if (this._oDLM && !oWorksheetOverlay.isOpen()) {
                                // If data is clean, we will display the content view for the selected workset item.
                                this._oDLM.setNavigationHandler(function() {
                                    // When we continue to navigate, either the changes have been saved or they are deliberately
                                    // discarded, so reset the DLM.
                                    that._oDLM.reset();

                                    if (!oWorksheetOverlay.isOpen()) {
                                        var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade(
                                                "EvidencePackage");
                                        oEvidencePackageServiceFacade.MachineOptionCalculation.abortAllServices();
                                    }

                                    that._close();
                                });

                                // If data is dirty, we will reset the selected workset item on the shell.
                                this._oDLM.setCancelHandler(null);
                                this._oDLM.notifyOrNavigate();
                            } else {
                                that._close();
                            }
                        },

                        /**
                         * Close the view
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        _close : function() {
                            var oEvidencePackageServiceFacade = jd.ui.eid.application.Application.getInstance().getServiceFacade("EvidencePackage");
                            oEvidencePackageServiceFacade.abortPendingGetEvidencePackageDetailsRequests();
                            sap.ui.getCore().getEventBus().publish('EvidencePackageView', 'close');
                        },

                        /**
                         * event handler to save Summary
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        onSaveSelected : function() {
                            var tmp = jd.ui.eid.view.main.shared.EvidencePackageSaveController;
                            var iAction = tmp.EvidencePackageSaveDialogButton.Save;
                            this.saveEvidencePackage(iAction);
                        },

                        /**
                         * event handler to save Summary and send link
                         * 
                         * @memberOf jd.ui.eid.view.main.evidencepackage.EvidencePackageSummary
                         */
                        saveAndSendLink : function() {
                            var tmp = jd.ui.eid.view.main.shared.EvidencePackageSaveController;
                            var iAction = tmp.EvidencePackageSaveDialogButton.SaveAndSendLink;
                            this.saveEvidencePackage(iAction, $.proxy(this.openSendLinkDialog, this));
                        },

                        /**
                         * Opens the local mail program and creates a new mail which includes a link to the current evidence package.
                         */
                        openSendLinkDialog : function() {
                            var sFragmentId = this.createId("SendLinkDialog");
                            var sEvidencePackageID = sap.ui.getCore().getModel().oData.EvidencePackageDetails.Header.PackageID;
                            var sURL = jd.ui.eid.common.URLHandler.EvidencePackage.generateURL(sEvidencePackageID);

                            if (!this._oSendLinkDialog) {
                                var that = this;
                                this._oSendLinkDialog = jd.ui.eid.xmlfragment(sFragmentId,
                                        "jd.ui.eid.fragment.dialog.main.EvidencePackageSendLinkDialog", {
                                            handleOpenProgram : function(oEvent) {
                                                // Open the Mail program
                                                var sURLMailTo = "mailto:?subject=Evidence Package: " + sEvidencePackageID + "&body=" + sURL;
                                                window.location.href = sURLMailTo;
                                            },
                                            handleClosed : function(oEvent) {
                                                that._oSendLinkDialog.close();
                                            }
                                        });

                            }

                            if (!this._oSendLinkDialog.isOpen()) {
                                this._oSendLinkDialog.open();
                            }

                            // Generate the URL for the Evidence Package Link
                            sap.ui.core.Fragment.byId(sFragmentId, "Link").setValue(decodeURIComponent(sURL));
                        },

                        /**
                         * Opens the print filter dialog which allows the user to select what should be printed.
                         */
                        openPrintFilterDialog : function() {
                            if (!this._oPrintFilterDialog) {
                                this._oPrintFilterDialog = jd.ui.eid.xmlfragment(this.createId("PrintFilterDialog"),
                                        "jd.ui.eid.fragment.dialog.main.EvidencePackagePrintFilterDialog", this);
                            }

                            if (!this._oPrintFilterDialog.isOpen()) {
                                this._oPrintFilterDialog.open();
                            }
                        },

                        /**
                         * Opens the print preview dialog from where the user can trigger the browser's print functionality.
                         */
                        openPrintPreviewDialog : function() {
                            var sFragmentId = this.createId("PrintPreviewDialog");
                            if (!this._oPrintPreviewDialog) {
                                this._oPrintPreviewDialog = jd.ui.eid.xmlfragment(sFragmentId,
                                        "jd.ui.eid.fragment.dialog.main.EvidencePackagePrintPreviewDialog", this);
                                // Hook into on after rendering to set the url on the iframe
                                var that = this;
                                this._oPrintPreviewDialog.addEventDelegate({
                                    onAfterRendering : function() {
                                        setTimeout(function() {
                                            var sUrl = that._oPrintPreviewDialog.data("url");
                                            that._oPrintPreviewDialog.$().find("iframe").prop("src", sUrl);
                                        }, 400);
                                    }
                                });
                            }

                            sap.ui.core.Fragment.byId(sFragmentId, "AppContainer").setBusy(true);
                            sap.ui.core.Fragment.byId(sFragmentId, "BtnPrint").setEnabled(false);

                            // Create the url for the print view and attach it to the dialog so that it can be processed in
                            // onAfterRendering (see above).
                            var sUrl;
                            if (window.location.href.indexOf("_local") > -1) {
                                // local
                                sUrl = "./print/index_local.html?useTestData=true";
                            } else {
                                // server
                                sUrl = "./print/index.html";
                            }
                            this._oPrintPreviewDialog.data("url", sUrl);

                            if (!this._oPrintPreviewDialog.isOpen()) {
                                this._oPrintPreviewDialog.open();
                            }

                        },

                        /* SECTION - Print Filter Dialog Handling - START */

                        /**
                         * Handles the cancel button of the print filter dialog and closes the dialog.
                         * 
                         * @param {sap.ui.base.Event}
                         *            the event fired cancel button.
                         */
                        handleEvidencePackagePrintFilterDialogCancel : function(oEvent) {
                            if (this._oPrintFilterDialog.isOpen()) {
                                this._oPrintFilterDialog.close();
                            }
                        },

                        /**
                         * Handles the print preview button, closes the print filter dialog and opens the print preview dialog instead.
                         * 
                         * @param {sap.ui.base.Event}
                         *            the event fired by the print preview button.
                         */
                        handleEvidencePackagePrintFilterDialogContinue : function(oEvent) {
                            this.openPrintPreviewDialog();

                            if (this._oPrintFilterDialog.isOpen()) {
                                this._oPrintFilterDialog.close();
                            }
                        },

                        /* SECTION - Print Filter Dialog Handling - END */

                        /* SECTION - Print Preview Dialog Handling - START */

                        /**
                         * Handles the print button of the print preview dialog and triggers the browser's print functionality.
                         * 
                         * @param {sap.ui.base.Event}
                         *            the event fired by the print button.
                         */
                        handleEvidencePackagePrintPreviewDialogPrint : function(oEvent) {
                            // Get the iframe element from the dialog
                            var elIFrame = this._oPrintPreviewDialog.$().find("iframe")[0];
                            // Trigger the browser's print mechanism for that iframe
                            elIFrame.contentWindow.focus();
                            elIFrame.contentWindow.print();
                        },

                        /**
                         * Handles the cancel button of the print preview dialog and closes the dialog.
                         * 
                         * @param {sap.ui.base.Event}
                         *            the event fired cancel button.
                         */
                        handleEvidencePackagePrintPreviewDialogCancel : function(oEvent) {
                            // Destroy print application
                            var elIframe = this._oPrintPreviewDialog.$().find("iframe")[0];
                            if (elIframe) {
                                elIframe.contentWindow.jd.ui.eid.application.Application.getInstance().destroy();
                            }
                            if (this._oPrintPreviewDialog.isOpen()) {
                                this._oPrintPreviewDialog.close();
                            }
                        },

                        /* SECTION - Print Preview Dialog Handling - START */

                        /* SECTION - Communication with Print View - START */

                        /**
                         * Handles the <code>requestInput</code> event from the print application. Sends the evidence package header back to the
                         * print application via the <code>inputShared</code> event.
                         * 
                         * @param {string}
                         *            sChannelId the channel id.
                         * @param {string}
                         *            sEvent the event name.
                         * @param {object}
                         *            mData the parameter map.
                         */
                        handlePrintApplicationRequestInput : function(sChannelId, sEvent, mData) {
                            $.sap.log.debug("Preparing input for print application.");
                            var elIframe = this._oPrintPreviewDialog.$().find("iframe")[0];

                            // Get the evidence package header
                            var mEvidencePackageHeader = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");
                            var aKPIValues = sap.ui.getCore().getModel().getProperty("/KPIValues");

                            // Get the print filter options
                            var mPrintFilterOptions = this._getPrintFilterOptions();

                            $.sap.log.debug("Sending data to print application....");
                            // Pass the data back to the print application
                            sap.ui.getCore().getEventBus().publish(this._sEventBusPrintChannelId, "inputShared", {
                                EvidencePackageHeader : mEvidencePackageHeader,
                                PrintFilterOptions : mPrintFilterOptions,
                                KPIValues : aKPIValues
                            });
                        },

                        /**
                         * Handles the <code>ready</code> event from the print application.
                         * 
                         * @param {string}
                         *            sChannelId the channel id.
                         * @param {string}
                         *            sEvent the event name.
                         * @param {object}
                         *            mData the parameter map.
                         */
                        handlePrintApplicationReady : function(sChannelId, sEvent, mData) {
                            var sFragmentId = this.createId("PrintPreviewDialog");
                            sap.ui.core.Fragment.byId(sFragmentId, "AppContainer").setBusy(false);
                            sap.ui.core.Fragment.byId(sFragmentId, "BtnPrint").setEnabled(true);
                        },

                        /**
                         * Prepares and returns a map of the print filter options that the user has selected.
                         * 
                         * @returns {object} map with print filter options selected by the user
                         * @private
                         */
                        _getPrintFilterOptions : function() {
                            // The checkboxes within the 'printFilterOptions' layout represent print options that need to be mapped
                            // against their custom
                            // attribute
                            // 'printFilterOptionName'
                            var mPrintOptions = {};
                            var aPrintFilterOptions = sap.ui.core.Fragment.byId(this.createId("PrintFilterDialog"), "printFilterOptions")
                                    .getContent();
                            $.each(aPrintFilterOptions, function(i, oCheckbox) {
                                var sKey = oCheckbox.data("printFilterOptionName");
                                var bValue = !oCheckbox.getChecked(); // Adding a NOT, because 'checked' = 'hide', 'unchecked' =
                                // 'show' and this property
                                // will later
                                // be bound to the 'visible' property of panels
                                mPrintOptions[sKey] = bValue;
                            });

                            return mPrintOptions;
                        },

                        /* SECTION - Communication with Print View - END */

                        /* SECTION - Event Bus Handling - START */

                        /**
                         * Handles the event fired when a DTC/DTAC Case/Warranty Claim has been removed from the Evidence Package. This means that the
                         * 'Analysis Data' could have changed, and now needs to be re-fetched from the server.
                         * 
                         * @param {string}
                         *            sChannelId the channel id.
                         * @param {string}
                         *            sEvent the event name.
                         * @param {object}
                         *            oData data passed along with the event.
                         */
                        handleAnalysisDataRefreshNeeded : function(sChannelId, sEvent, oData) {
                            // Set the busy indicator on the 'Analysis Data' ThingGroup
                            var oAnalysisDataThingGroup = this.byId("analysisDataThingGroup");
                            oAnalysisDataThingGroup.getContent()[0].setBusy(true);

                            // Get the Evidence package header. We need to pass this to the backend to get the Analysis Data
                            var oEvidencePackageHeader = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");

                            // Prepare the service request's success handler.
                            var fnSuccess = function() {
                                oAnalysisDataThingGroup.getContent()[0].setBusy(false);
                            };

                            // Trigger the backend request
                            this.getServiceFacade("EvidencePackage").getEvidencePackageAnalysisData(oEvidencePackageHeader, fnSuccess,
                                    this._onRequestFailed);

                        }

                    /* SECTION - Event Bus Handling - END */
                    }));
})();
