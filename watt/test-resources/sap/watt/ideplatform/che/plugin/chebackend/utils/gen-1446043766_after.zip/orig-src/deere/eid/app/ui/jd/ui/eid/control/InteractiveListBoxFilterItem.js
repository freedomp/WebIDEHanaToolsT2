(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.InteractiveListBoxFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBoxFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.InteractiveListBox");

    /**
     * Constructor for a new InteractiveListBoxFilterItem.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>deselectAllTooltip : string (default: '') the tooltip displayed for the toogle icon if it would deselect all items.</li>
     * <li>maxItems : int (default: -1) the maximum number of items that can be added to the list box. If -1, it has no effect..</li>
     * <li>selectAllTooltip : string (default: '') the tooltip displayed for the toggle icon if it would select all items.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>addIcon : sap.ui.commons.Image The image displayed for adding a new item</li>
     * <li>batchAddIcon : sap.ui.commons.Image|sap.ui.commons.Link The control that should serve as the opener for the tool popup. Needs to have a
     * press event.</li>
     * <li>toggleSelectionIcon : sap.ui.commons.Image The image displayed for toggling the selection.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>duplicatesIgnored : fired upon batch-inserting at least once string twice. It provides parameters <code>numberOfDuplicates</code>.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The InteractiveListBoxFilterItem control provides list of items which can be modified by the user (add single item, add multiple items,
     *        edit item, remove item).
     *        <p>
     *        <strong>Batch Insert</strong> is enabled via a text area in a tool popup (internal aggregation), which can be opened/closed through a
     *        control on the right item area of the control (internal aggregation, see renderer). The tool popup can be canceled, which will clear
     *        the content or the content can be added to the list via ok. When pressing ok, the user input will be parsed by
     *        {@link jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser#parse} and split at the maintained separators. Each item will
     *        then be added to the list.
     *        </p>
     *        <p>
     *        <strong>Model Interaction</strong> for this scenario is special, because UI5 doesn't have good support for dynamically adding new items
     *        to an aggregation. Usually, one would have to call getData() on the model, do the changes, and call setData() afterwards, which would
     *        refresh all bindings. In order to avoid this, whenever the item aggregation is changed (e.g. add, edit, delete), the control updates the
     *        model directly and refreshes the affected binding objects. The paths for the model updates are dynamically determined based on the
     *        binding objects. This applies for both the domain values (item aggregation) and the current selection (selection property). The relevant
     *        methods are {@link #._addDomainValue}, {@link #._removeDomainValue}, {@link #._updateDomainvalue}, {@link #._clearDomainValues}, and
     *        {@link #._updateSelection}.
     *        </p>
     *        <p>
     *        <strong>I18n keys</strong> that are used within this control:
     *        <ul>
     *        <li>INTERACTIVE_LIST_BOX_FILTER_ITEM_BTN_BATCH_INSERT_TOOL_POPUP_CANCEL : Text for the cancel button of the batch insert tool popup.</li>
     *        <li>INTERACTIVE_LIST_BOX_FILTER_ITEM_BTN_BATCH_INSERT_TOOL_POPUP_OK : Text for the ok button of the batch insert tool popup.</li>
     *        <li>INTERACTIVE_LIST_BOX_FILTER_ITEM_MSE_BATCH_INSERT_TOOL_POPUP_TOO_MANY_ITEMS : Text displayed as an error message if the user tries
     *        to insert more items than allows (cf. maxItems). First parameter is the number of distinct items that the user tried to enter. Second
     *        parameter is the number of remaining items. Third parameter is the maximum number of items.</li>
     *        </ul>
     *        </p>
     * @extends jd.ui.eid.control.ListBoxFilterItem
     * @name jd.ui.eid.control.InteractiveListBoxFilterItem
     */
    jd.ui.eid.control.ListBoxFilterItem.extend("jd.ui.eid.control.InteractiveListBoxFilterItem", /** @lends jd.ui.eid.control.InteractiveListBoxFilterItem */
    {
        metadata : {
            properties : {
                deselectAllTooltip : {
                    type : "string",
                    defaultValue : ""
                },
                maxItems : {
                    type : "int",
                    defaultValue : 4
                },
                selectAllTooltip : {
                    type : "string",
                    defaultValue : ""
                }
            },
            aggregations : {
                _batchInsertToolPopup : {
                    type : "sap.ui.ux3.ToolPopup",
                    multiple : false,
                    visibility : "hidden"
                },
                addIcon : {
                    type : "sap.ui.core.Control",
                    multiple : false
                },
                batchAddIcon : {
                    type : "sap.ui.core.Control",
                    multiple : false
                },
                toggleSelectionIcon : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            },
            events : {
                duplicatesIgnored : {}
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.ListBoxFilterItem.prototype.init.apply(this, arguments);

            // Add the style class here so that we don't have to do any unnecessary overwrites in
            // the renderer
            this.addStyleClass("jdUiEidInteractiveListBoxFilterItem");

            this.setAggregation("_listBox", new jd.ui.eid.control.InteractiveListBox({
                enableSimpleSelect : true,
                itemRemoved : [this._handleItemRemoved, this],
                itemUpdated : [this._handleItemUpdated, this],
                itemsChanged : [this._handleItemsChanged, this],
                select : [this._handleSelect, this]
            }));

            this._oBatchInsertToolPopupButtonOk = new sap.ui.commons.Button({
                text : "{i18n>INTERACTIVE_LIST_BOX_FILTER_ITEM_BTN_BATCH_INSERT_TOOL_POPUP_OK}",
                style : sap.ui.commons.ButtonStyle.Emph,
                press : [this._handleBatchInsertToolPopupOk, this]
            }).addStyleClass("jdUiBtn");
            this._oBatchInsertToolPopupButtonCancel = new sap.ui.commons.Button({
                text : "{i18n>INTERACTIVE_LIST_BOX_FILTER_ITEM_BTN_BATCH_INSERT_TOOL_POPUP_CANCEL}",
                press : [this._handleBatchInsertToolPopupCancel, this]
            }).addStyleClass("jdUiBtn");
            this._oBatchInsertToolPopupTextArea = new sap.ui.commons.TextArea({
                width : "100%",
                height : "150px"
            }).addStyleClass("jdUiTxtA");
            this._oBatchInsertToolPopupMessageBox = new sap.ui.commons.TextView({
                semanticColor : sap.ui.commons.TextViewColor.Negative
            }).addStyleClass("jdUiTv");
            this._oBatchInsertToolPopup = new sap.ui.ux3.ToolPopup({
                content : new sap.ui.commons.layout.VerticalLayout({
                    content : [this._oBatchInsertToolPopupTextArea, this._oBatchInsertToolPopupMessageBox],
                    width : "160px"
                }),
                buttons : [this._oBatchInsertToolPopupButtonOk, this._oBatchInsertToolPopupButtonCancel]
            }).addStyleClass("jdUiUx3TP ");
            this.setAggregation("_batchInsertToolPopup", this._oBatchInsertToolPopup);
        },

        /* Custom Getters & Setters */

        /**
         * Setter for the aggregated addIcon.
         * 
         * @param {sap.ui.commons.Image}
         *            oControl the control for the aggregation.
         * @return {jd.ui.eid.control.InteractiveListBoxFilterItem} this for method chaining.
         */
        setAddIcon : function(oControl) {
            this.setAggregation("addIcon", oControl);
            oControl.addStyleClass("jdUiEidFilterItemHeaderItemAdd");
            oControl.attachPress(null, this._handleAdd, this);
            return this;
        },

        /**
         * Setter for the aggregated batchAddIcon.
         * 
         * @param {sap.ui.commons.Image}
         *            oControl the control for the aggregation.
         * @return {jd.ui.eid.control.InteractiveListBoxFilterItem} this for method chaining.
         */
        setBatchAddIcon : function(oControl) {
            this.setAggregation("batchAddIcon", oControl);
            oControl.addStyleClass("jdUiEidInteractiveListBoxFilterItemBatchInsertOpener");
            oControl.attachPress(null, this._handleOpenBatchInsertToolPopup, this);

            // Adjust the tool popup properties based on opener
            this._oBatchInsertToolPopup.setOpener(oControl);
            this._oBatchInsertToolPopup.setPosition(sap.ui.core.Popup.Dock.BeginTop, sap.ui.core.Popup.Dock.EndTop, oControl, "10 -5");

            return this;
        },

        /**
         * Setter for the aggregated toggleSelectionIcon.
         * 
         * @param {sap.ui.commons.Image}
         *            oControl the control for the aggregation.
         * @return {jd.ui.eid.control.InteractiveListBoxFilterItem} this for method chaining.
         */
        setToggleSelectionIcon : function(oControl) {
            this.setAggregation("toggleSelectionIcon", oControl);
            oControl.addStyleClass("jdUiEidFilterItemHeaderItemToggleSelection");
            oControl.attachPress(null, this._handleToggleSelection, this);
            return this;
        },

        /* Internal Event Handlers */

        /**
         * Handles the event of the tool popup opener to either open or close the batch insert tool popup.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        _handleOpenBatchInsertToolPopup : function(oEvent) {
            if (this._oBatchInsertToolPopup.isOpen()) {
                this._oBatchInsertToolPopup.close();
            } else if (!this._isMaxItemsReached()) {
                this._oBatchInsertToolPopup.open();
            }
        },

        /**
         * Handles the ok button of the batch insert tool popup and processes the input.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        _handleBatchInsertToolPopupOk : function(oEvent) {
            var sInput = this._oBatchInsertToolPopupTextArea.getValue();

            // Process input
            var iNumberOfDuplicates = 0;
            var mParseParameters = {};
            var aItems = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sInput, mParseParameters);
            iNumberOfDuplicates += mParseParameters.iNumberOfDuplicates;

            // Now compare the parse items with the ones which are already in the list box to check for duplicates.
            var aCurrentItems = this.getItems();
            $.each(aCurrentItems, function(iIdx, oItem) {
                var iPos = $.inArray(oItem.getKey(), aItems);
                if (iPos > -1) {
                    iNumberOfDuplicates++;
                    // ... and remove the duplicate
                    aItems.splice(iPos, 1);
                }
            });

            // Check whether the number of distinct items that we're about to add still fits into the filter item if the maxItems property is set.
            if (this.getMaxItems() > -1) {
                if ((aCurrentItems.length + aItems.length) > this.getMaxItems()) {
                    // This would be too many items
                    this._oBatchInsertToolPopupTextArea.setValueState(sap.ui.core.ValueState.Error);
                    this._oBatchInsertToolPopupMessageBox.setText(jd.ui.eid.common.I18NHelper.getText(
                            "INTERACTIVE_LIST_BOX_FILTER_ITEM_MSE_BATCH_INSERT_TOOL_POPUP_TOO_MANY_ITEMS", [aItems.length,
                                    (this.getMaxItems() - aCurrentItems.length), this.getMaxItems()]));
                    this._oBatchInsertToolPopupMessageBox.setVisible(true);
                    return;
                }
            }

            // If we have duplicates, let's fire the event
            if (iNumberOfDuplicates > 0) {
                this.fireDuplicatesIgnored({
                    numberOfDuplicates : iNumberOfDuplicates
                });
            }

            var aSelection = this.getSelection();
            var that = this;
            $.each(aItems, function(iIdx, sItem) {
                // Add as domain value...
                that._addDomainValue(sItem);
                // ... but also add to selection
                aSelection.push(sItem);
            });
            this._updateSelection(aSelection);
            this.setSelection(aSelection);

            // Reset popup and close it
            this._oBatchInsertToolPopup.close();
            this._oBatchInsertToolPopupTextArea.setValue("");
            this._oBatchInsertToolPopupMessageBox.setVisible(false);
            this._oBatchInsertToolPopupTextArea.setValueState(sap.ui.core.ValueState.None);

            // Update control
            this.getBinding("items").refresh(true);
            var that = this;
            setTimeout(function() {
                // Add it to the queue.
                that.getBinding("selection").refresh(true);
            }, 0);

            this.fireValueChanged();
        },

        /**
         * Handles the cancel button of the batch insert tool popup and closes it.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        _handleBatchInsertToolPopupCancel : function(oEvent) {
            // Reset popup and close it
            this._oBatchInsertToolPopup.close();
            this._oBatchInsertToolPopupTextArea.setValue("");
            this._oBatchInsertToolPopupMessageBox.setVisible(false);
            this._oBatchInsertToolPopupTextArea.setValueState(sap.ui.core.ValueState.None);
        },

        /*
         * Internal flag to remember whether a new item has just been added.
         */
        _bAddingItem : false,

        /**
         * Event handler for the add icon.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleAdd : function(oEvent) {
            if (!this._bAddingItem) {
                this._bAddingItem = true;
                // Add empty domain value which can then be edited.
                this._addDomainValue("");

                // Refresh the control
                this.getBinding("items").refresh(true);
                var that = this;
                setTimeout(function() {
                    // Add to queue and continue refreshing the control..
                    $.sap.log.debug("refreshing selection binding", null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
                    that.getBinding("selection").refresh(true);
                    setTimeout(function() {
                        // And eventually enable editing of the newly added empty domain value.
                        that.getAggregation("_listBox").enableEditModeForItem(0);
                    }, 0);
                }, 0);
                this._updateSelectionIndicator();
            } else {
                this.getAggregation("_listBox").enableEditModeForItem(0);
            }
        },

        /**
         * Event handler for the toggle selection icon. Selects all items if not all items are already selected, deselects all items if all items are
         * selected.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleToggleSelection : function(oEvent) {
            if (this.getSelection().length == this.getItems().length) {
                // All items are selected, deselect everything.
                this._clearSelection();
            } else {
                this._selectAll();
            }
            if (this.getItems().length != 0) {
                // only fire the event if there are PINs available
                this.fireValueChanged();
            }
        },

        /**
         * Handles the itemRemoved event of the internal list box aggregation, removes the domain value that is to be deleted and updates the
         * selection in the model.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        _handleItemRemoved : function(oEvent) {
            var oItem = oEvent.getParameter("item");
            var iIndex = oEvent.getParameter("index");
            this._removeDomainValue(iIndex);
            if (iIndex == 0 && this._bAddingItem) {
                this._bAddingItem = false;
            }
            oItem.destroy();

            this._updateSelection(this.getAggregation("_listBox").getSelectedKeys());

            // Update control
            this.getBinding("items").refresh(true);
            var that = this;
            setTimeout(function() {
                // Add it to the queue.
                that.getBinding("selection").refresh(true);
            }, 0);

            this.fireValueChanged();
        },

        /**
         * Handles the itemUpdated event of the internal list box aggregation, updates the domain value that is to be updated and updates the
         * selection in the model.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the control.
         */
        _handleItemUpdated : function(oEvent) {
            var oItem = oEvent.getParameter("item");
            var iIndex = oEvent.getParameter("index");

            if (oItem.getText() == oEvent.getParameter("oldText")) {
                return;
            }

            // Update model
            this._updateDomainValue(iIndex, oItem.getText());

            if (iIndex == 0 && this._bAddingItem) {
                // Reset internal state
                this._bAddingItem = false;
                // Add newly created item to selection
                var aSelection = this.getSelection();
                aSelection.push(oItem.getText());
                this.setSelection(aSelection);
            }

            this._updateSelection(this.getAggregation("_listBox").getSelectedKeys());
            this.fireValueChanged();
        },

        /**
         * Handles the itemsChanged event of the list box aggregation and updates the selection indicator.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        _handleItemsChanged : function(oEvent) {
            this._updateSelectionIndicator();
        },

        /* Internal Helper Methods */

        /**
         * Additionally to maintaining the selection indicator, it swaps the tooltip on the toggle icon.
         */
        _updateSelectionIndicator : function() {
            jd.ui.eid.control.ListBoxFilterItem.prototype._updateSelectionIndicator.apply(this, arguments);

            // Check what toggle selection would do
            var iTotal = this.getItems().length || 0;
            var iSelected = 0;
            if (this.getAggregation("_listBox").getSelectedIndices()) {
                iSelected = this.getAggregation("_listBox").getSelectedIndices().length;
            }

            var oToggleSelectionIcon = this.getAggregation("toggleSelectionIcon");
            if (oToggleSelectionIcon && iTotal != 0 && iTotal == iSelected) {
                // All items are selected, so toggle what deselect all items
                oToggleSelectionIcon.setTooltip(this.getDeselectAllTooltip());
            } else if (oToggleSelectionIcon) {
                // and of course, the other way around.
                oToggleSelectionIcon.setTooltip(this.getSelectAllTooltip());
            }

            if (iTotal == 0) {
                this.addStyleClass("jdUiEidInteractiveFilterItemNoItems");
            } else {
                this.removeStyleClass("jdUiEidInteractiveFilterItemNoItems");
            }

            // Also, check whether maxItems is provided and whether we've reached this already
            if (this._isMaxItemsReached()) {
                this.addStyleClass("jdUiEidInteractiveFilterItemMaxItemsReached");
            } else {
                this.removeStyleClass("jdUiEidInteractiveFilterItemMaxItemsReached");
            }
        },

        /**
         * Checks whether maxItems is reached.
         * 
         * @returns {boolean} true of number of items equals maxItem property, false otherwise.
         */
        _isMaxItemsReached : function() {
            var iTotal = this.getItems().length || 0;
            return this.getMaxItems() > -1 && this.getMaxItems() == iTotal;
        },

        /**
         * Internal hook method for clearing both the domain values and the selection.
         */
        _clear : function() {
            $.sap.log.debug("_clear", null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            if (this.getItems().length == 0) {
                return false;
            }
            this.destroyItems();
            this._clearDomainValues();
            this._clearSelection();
            return true;
        },

        /**
         * Clears the selection.
         */
        _clearSelection : function() {
            this.setSelection([]);
        },

        /**
         * Selects all items.
         */
        _selectAll : function() {
            var aSelectedKeys = [];
            var aItems = this.getItems();
            $.each(aItems, function(iIdx, oItem) {
                aSelectedKeys.push(oItem.getKey());
            });
            this.setSelection(aSelectedKeys);
        },

        /* Public API */

        /**
         * Fire event valueChanged to attached listeners.
         */
        fireValueChanged : function(mArguments) {
            $.sap.log.debug("fireValueChanged", null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            this.fireEvent('valueChanged', mArguments);
        },

        /* Model Interaction */

        /**
         * Internal helper method to get the array of domain values from the model, based on the binding of the item aggregation.
         * 
         * @returns {array} an array of objects.
         */
        _getDomainValues : function() {
            var oBinding = this.getBinding("items");
            var oContext = oBinding.getContext();
            var sPath = oBinding.getPath();
            if (!$.sap.startsWith(sPath, "/") /* absolute binding */&& oContext) {
                sPath = oContext.getPath() + "/" + sPath;
            }
            return this.getModel().getProperty(sPath);
        },

        /**
         * Internal helper method to add a new domain value to the model.
         * 
         * @param {string}
         *            sItem the new domain value.
         */
        _addDomainValue : function(sItem) {
            $.sap.log.debug("adding domain value '" + sItem + "'", null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            var mNewItem = {
                ID : sItem,
                Name : sItem
            };

            var aDomainValues = this._getDomainValues();
            aDomainValues.splice(0, 0, mNewItem);
        },

        /**
         * Internal helper method to remove a domain value from the model.
         * 
         * @param {int}
         *            iIndex the index of the item.
         */
        _removeDomainValue : function(iIndex) {
            $.sap.log.debug("removing domain value at index " + iIndex, null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            var aDomainValues = this._getDomainValues();
            aDomainValues.splice(iIndex, 1);
        },

        /**
         * Internal helper method to update a domain value in the model at the given index.
         * 
         * @param {int}
         *            iIndex the index of the item.
         * @param {string}
         *            sValue the new value.
         */
        _updateDomainValue : function(iIndex, sValue) {
            var aDomainValues = this._getDomainValues();
            var mDomainValue = aDomainValues[iIndex];
            mDomainValue.ID = sValue;
            mDomainValue.Name = sValue;
        },

        /**
         * Internal helper method to clear the domain values in the model.
         */
        _clearDomainValues : function() {
            var aDomainValues = this._getDomainValues();
            aDomainValues.length = 0;
        },

        /**
         * Internal helper method to get the array of selected keys from the model, based on the binding of the selection property.
         * 
         * @returns {array} an array of selected keys.
         */
        _getSelection : function() {
            var oBinding = this.getBinding("selection");
            var oContext = oBinding.getContext();
            var sPath = oBinding.getPath();
            if (!$.sap.startsWith(sPath, "/") /* absolute binding */&& oContext) {
                sPath = oContext.getPath() + "/" + sPath;
            }
            return this.getModel().getProperty(sPath);
        },

        /**
         * Internal helper method to update the selection in the model.
         * 
         * @param {array}
         *            aKeys an array of selected keys.
         */
        _updateSelection : function(aKeys) {
            $.sap.log.debug("updating selection:", null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            $.sap.log.debug(aKeys, null, "jd.ui.eid.control.InteractiveListBoxFilterItem");
            var aCurrentSelection = this._getSelection();

            if (aCurrentSelection !== aKeys) {
                aCurrentSelection.length = 0;
                $.merge(aCurrentSelection, aKeys);
            }
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.InteractiveListBoxFilterItemRenderer"

    });

    /**
     * @namespace The BatchInsertParser takes care of parsing the user input of the {@link jd.ui.eid.control.InteractiveListBoxFilterItem}'s batch
     *            insert tool popup. Based on the maintained separators, it first harmonizes the separators by taking the first separator as the
     *            leading one and replacing all other separators by that one. Subsequently, it trims the separator so that there are no more than one
     *            consecutive separator in the input. Afterwards, the input is split at the separators. Only elements that are not empty are returned
     *            in an array by {@link #.parse}.
     */
    jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser = {

        Separators : ["\n", ",", " ", ";"],

        /**
         * Maps the separator to a valid regular expression operand.
         * 
         * @param {string}
         *            sSeparator the plain separator.
         * @returns {string} a valid regular expression operand.
         */
        _getRegExpCompatibleSeparator : function(sSeparator) {
            if (sSeparator == " ") {
                sSeparator = "\\s";
            }
            return sSeparator;
        },

        /**
         * Harmonizes the separators in the given string by replacing all occurrences of other separators by the leading separator.
         * 
         * @param {string}
         *            sString the input string.
         * @param {string}
         *            sLeadingSeparator the leading separator.
         * @param {array}
         *            aOtherSeparators array of separators that are to be replaced by the leading separator.
         * @returns {string} the input string with only one type of separator.
         */
        _harmonizeSeparators : function(sString, sLeadingSeparator, aOtherSeparators) {
            var that = this;
            $.each(aOtherSeparators, function(iIdx, sSeparator) {
                sString = sString.replace(new RegExp(that._getRegExpCompatibleSeparator(sSeparator), "g"), sLeadingSeparator);
            });
            return sString;
        },

        /**
         * Trims the occurrences of separators in the given string so that there never two or more consecutive occurrences.
         * 
         * @param {string}
         *            sString the input string.
         * @param {string}
         *            sLeadingSeparator the leading separator.
         * @returns {string} the input string with only no more than one consecutive occurrence of the leading separator.
         * @protected
         */
        _trimSeparators : function(sString, sLeadingSeparator) {
            var sLeadingSeparatorRegExp = this._getRegExpCompatibleSeparator(sLeadingSeparator);
            sString = sString.replace(new RegExp(sLeadingSeparatorRegExp + "\\s*" + sLeadingSeparatorRegExp, "g"), sLeadingSeparator);
            return sString;
        },

        /**
         * Parses the input string and splits it up based on the separators maintained. It only returns those chunks from the input that are no empty
         * strings.
         * 
         * @param {string}
         *            sString the input string.
         * @returns {array} an array of strings extracted from the input string.
         */
        parse : function(sString, mParameters) {
            if (!mParameters) {
                mParameters = {};
            }

            var aSeparators = jQuery.extend([], this.Separators);
            var sLeadingSeparator = aSeparators.shift();
            // Align separators so that the leading separator is the only one in the text
            sString = this._harmonizeSeparators(sString, sLeadingSeparator, aSeparators);
            // Reduce separators to single consecutive occurrences instead of multiple ones
            sString = this._trimSeparators(sString, sLeadingSeparator);

            var aChunks = sString.split(sLeadingSeparator);
            var aItems = [];
            var mItems = {}; // Also maintain a map to easily avoid duplicates
            mParameters.iNumberOfDuplicates = 0;
            // Trim chunks and only return non-empty ones.
            $.each(aChunks, function(iIdx, sStr) {
                sStr = $.trim(sStr);
                if (sStr.length > 0 && !mItems[sStr]) {
                    aItems.push(sStr);
                    mItems[sStr] = true;
                } else if (mItems[sStr]) {
                    mParameters.iNumberOfDuplicates++;
                }
            });
            return aItems;
        }
    };

})();