jQuery.sap.declare("nw.epm.refapps.shop.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.messages");

sap.ca.scfld.md.ConfigurationBase.extend("nw.epm.refapps.shop.Configuration", {

    oServiceParams : {
        serviceList : [ {
            name : nw.epm.refapps.shop.Component.getMetadata().getConfig().serviceConfig.name,
            masterCollection : "Products",
            // cloud enabling for service URL
            serviceUrl : nw.epm.refapps.shop.Component.getMetadata().getConfig().serviceConfig.serviceUrl,
            isDefault : true,
            //mockedDataSource : "/nw.epm.refapps.shop/src/main/webapp/model/metadata.xml",
         mockedDataSource : jQuery.sap.getModulePath("nw.epm.refapps.shop") + "/model/metadata.xml",
            useBatch : true,
            useV2ODataModel : true,
            // loadMetadataAsync : true,
            sDefaultBindingMode : sap.ui.model.BindingMode.TwoWay,
            fRequestFailed : nw.epm.refapps.lib.reuse.util.messages.showErrorMessage
        } ]
    },

    getServiceParams : function() {
        return this.oServiceParams;
    },

    getAppConfig : function() {
        return this.oAppConfig;
    },

    getServiceList : function() {
        return this.oServiceParams.serviceList;
    },

    getMasterKeyAttributes : function() {
        return [ "Id" ];
    }
});
