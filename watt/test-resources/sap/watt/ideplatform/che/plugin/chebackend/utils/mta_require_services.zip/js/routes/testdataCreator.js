var async = require('async');
var cds = require('cds');
var winston = require('winston');

var BOOK;
var ADDRESS;

winston.level = process.env.winston_level || 'error';

function init(appCallback) {
    if (BOOK && ADDRESS) {
        appCallback();
    } else {
        async.waterfall([
            function (callback) {
                cds.importEntities([ {
                        $entity: "com.sap.xs2.samples::AddressBook.Book",
                        $fields: { // for convenience we add an association from books to addresses
                            addresses: {
                                $association: {
                                    $entity: "com.sap.xs2.samples::AddressBook.Address",
                                    $viaBacklink: "book"
                                }
                            }
                        }
                    },
                    {$entity: "com.sap.xs2.samples::AddressBook.Address"}
                ], callback);
            },
            function (entities, callback) {
                BOOK = entities["com.sap.xs2.samples::AddressBook.Book"];
                ADDRESS = entities["com.sap.xs2.samples::AddressBook.Address"];
                callback(null);
            }
        ], function (error) {
            appCallback(error);
        });
    }
}

function testdataCreator(dbConnection, userid, appCallback) {
    //use database connection from hanacf pool
    cds.setConnection(dbConnection);
    async.waterfall([
        init,
        function createBook(callback) {
            var bookId = Math.floor(Math.random() * 1000000);
            BOOK.$save({
                id: bookId,
                name: 'My Book #' + bookId + ' created by ' + userid
            }, callback);
        },
        function createAddresses(book, callback) {
            cds.$save([
                ADDRESS.$prepare({
                    id: Math.floor(Math.random() * 1000000),
                    book: book,
                    first_name: 'John',
                    last_name: 'Doe',
                    address: 'Dietmar-Hopp-Allee 16',
                    city: 'Walldorf',
                    country: 'Germany',
                    zip: '69169',
                    phone: '+49 6227 7 12345',
                    email: 'john.doe@sap.com',
                    web: 'https://sap.de'
                }),
                ADDRESS.$prepare({
                    id: Math.floor(Math.random() * 1000000),
                    book: book,
                    first_name: 'Max',
                    last_name: 'Mustermann',
                    address: 'Dietmar-Hopp-Allee 16',
                    city: 'Walldorf',
                    country: 'Germany',
                    zip: '69169',
                    phone: '+49 6227 7 54321',
                    email: 'john.doe@sap.com',
                    web: 'https://sap.de'
                })
            ], callback);
        }
    ], function (error) {
        if (error) {
            appCallback(error);
        } else {
            appCallback(null);
        }
    });
}

module.exports = testdataCreator;
