(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.CustomizingServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel();
    sap.ui.getCore().setModel(oModel);
    var oCustomizingServiceFacade = new jd.ui.eid.service.CustomizingServiceFacade("http://sap.com", "/folder/to/test/data", oModel, true);

    var oDataKeyValueParameters = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getKeyValueParameters_Response.json").data;
    var oDataKPIs = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getKPIs_Response.json").data;
    var oDataSeverity = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getSeverity_Response.json").data;
    var oDataEngineHours = jQuery.sap.syncGetJSON("jd/ui/eid/asset/data/getEngineHourSegments_Response.json").data;

    // Module for getKeyValueParamters()
    module("jd.ui.eid.service.CustomizingServiceFacade", {
        setup : function() {
            // Start spying request
            this.xhr = sinon.useFakeXMLHttpRequest();
            var requests = this.requests = [];

            this.xhr.onCreate = function(xhr) {
                requests.push(xhr);
            };
        },
        teardown : function() {

            this.xhr.restore();
        }
    });

    test("getKeyValueParamters() should make an ajax call", function() {
        equal(0, this.requests.length);

        oCustomizingServiceFacade.getKeyValueParamters(function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    test("getKeyValueParamters() should call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();

        var oBinding = {};

        oBinding.sPath = "/KeyValParameters";

        // Trigger the ajax request
        oCustomizingServiceFacade.getKeyValueParamters(fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataKeyValueParameters));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataKeyValueParameters));

    });

    test("getKPIs() should make an ajax call", function() {
        equal(0, this.requests.length);

        oCustomizingServiceFacade.getKPIs(function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    test("getKPIs() should call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();

        var oBinding = {};

        oBinding.sPath = "/KPIValues";

        // Trigger the ajax request
        oCustomizingServiceFacade.getKPIs(fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataKPIs));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataKPIs));

    });

    test("getSeverity() should make an ajax call", function() {
        equal(0, this.requests.length);

        oCustomizingServiceFacade.getSeverity(function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    test("getSeverity() should call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();

        var oBinding = {};

        oBinding.sPath = "/SeverityValues";

        // Trigger the ajax request
        oCustomizingServiceFacade.getSeverity(fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataSeverity));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataSeverity));

    });

    test("getEngineHoursSegments() should make an ajax call", function() {
        equal(0, this.requests.length);

        oCustomizingServiceFacade.getEngineHoursSegments(function() {
        }, function() {
        });

        equal(1, this.requests.length);
    });

    test("getEngineHoursSegments() sshould call the success callback upon HTTP 200 and pass the response.", function() {
        // Define callback spy
        var fnSuccess = sinon.spy();

        var oBinding = {};

        oBinding.sPath = "/EngineHourSegments";

        // Trigger the ajax request
        oCustomizingServiceFacade.getEngineHoursSegments(fnSuccess, function() {
        });

        // That's how we respond to the ajax request
        this.requests[0].respond(200, {
            "Content-Type" : "application/json"
        }, JSON.stringify(oDataEngineHours));

        // Assertion
        ok(fnSuccess.called);
        ok(fnSuccess.calledWith(oDataEngineHours));

    });

})();