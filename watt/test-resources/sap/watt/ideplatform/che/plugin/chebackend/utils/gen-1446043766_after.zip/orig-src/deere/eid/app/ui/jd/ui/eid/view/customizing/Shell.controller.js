(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * @class The shell view provides the outer frame of the application. It has a custom look and feel and consists of a custom shell ({@link jd.ui.eid.control.Shell}).
     *        The controller handles the navigation between the different tabs via the data loss manager ({@link jd.ui.eid.common.DataLossManager})
     *        of the current view.
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.customizing.Shell
     */
    sap.ui.controller("jd.ui.eid.view.customizing.Shell", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.customizing.Shell */
    {
        _oView : null,

        /**
         * The method registers the shell's notification bar to the {@link jd.ui.eid.common.NotificationCenter} available on the
         * {@link jd.ui.eid.application.Application} singleton and displays the initial view inside the shell's content.
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiView");

            // Load customizing
            this.getServiceFacade("Customizing").getKPIs(null, this._onRequestFailed);

            this.getNotificationCenter().setNotificationBar(this.byId("shell").getNotificationBar());
            this.displayContentView();
        },

        /**
         * Event handler for the workItemSelected event of the shell control. The handler delegates the navigation to the next view to the data loss
         * manager of the current view in its content if a data loss manager has been assigned or otherwise directly navigates to the next view.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        onWorksetItemSelected : function(oEvent) {
            var that = this;
            var sKey = oEvent.getParameter("key");
            var sPreviousKey = this._sCurrentWorksetItemKey;

            // First, let's get the DLM attached to the current view.
            var oDLM = jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl(this.byId("shell").getContent()[0]);
            // And if the DLM is not null, let's attach the handlers and let the DLM to the rest.
            if (oDLM) {
                // If data is clean, we will display the content view for the selected workset item.
                oDLM.setNavigationHandler(function() {
                    // When we continue to navigate, either the changes have been saved or they are deliberately discarded, so reset the DLM.
                    oDLM.reset();
                    that.displayContentView(sKey);
                });

                // If data is dirty, we will reset the selected workset item on the shell.
                oDLM.setCancelHandler(function() {
                    var aWorksetItems = that.byId("shell").getWorksetItems();
                    $.each(aWorksetItems, function(iIndex, oWorksetItem) {
                        if (oWorksetItem.getKey() == sPreviousKey) {
                            that.byId("shell").setSelectedWorksetItem(oWorksetItem);
                            return false;
                        }
                    });
                });

                oDLM.notifyOrNavigate();
            } else {
                this.displayContentView(sKey);
            }
        },

        /**
         * Configuration map for the views related to the shell's navigation items.
         */
        _mWorksetItemViews : {
            wi_kv : "jd.ui.eid.view.customizing.shell.KeyValueParameters",
            wi_kpis : "jd.ui.eid.view.customizing.shell.KPIs",
            wi_sev : "jd.ui.eid.view.customizing.shell.Severity",
            wi_eh : "jd.ui.eid.view.customizing.shell.EngineHours"
        },

        /**
         * Map holding the cached view instances related to the navigation items.
         */
        _mWorksetItemViewCache : {},

        /**
         * Internal helper to remember the current workset item key.
         */
        _sCurrentWorksetItemKey : null,

        /**
         * Get the content view related to the given key from the navigation item.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         * @returns {sap.ui.core.mvc.View} the related view.
         */
        _getContentView : function(sKey) {
            if (!sKey || !this._mWorksetItemViews[sKey]) {
                // Make sure that sKey is actually a valid
                // navigation item key.
                sKey = "wi_kv"; // Default value
            }
            this._sCurrentWorksetItemKey = sKey;
            var sViewName = this._mWorksetItemViews[sKey];

            if (!this._mWorksetItemViewCache[sViewName]) {
                // If the view hasn't been created and cached yet,
                // we will do that
                // now. Essentially,
                // this is lazy loading.
                this._mWorksetItemViewCache[sViewName] = jd.ui.eid.xmlview(sViewName);
            }

            return this._mWorksetItemViewCache[sViewName];
        },

        /**
         * Display the view related to the given key from the navigation item as the sole content of the shell.
         * 
         * @param {string}
         *            [sKey] the key of the related navigation item.
         */
        displayContentView : function(sKey) {
            var oView = this._getContentView(sKey);
            this.byId("shell").setContent(oView);
        }

    }));
})();