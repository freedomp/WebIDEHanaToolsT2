(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.validator.DateValidator");

    module("jd.ui.eid.common.validator.DateValidator", {});

    // *** TEST CASE #1 ***
    test("validateDateRange() should return true if FromDate < ToDate", function() {
        var bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange("20111010", "20141010");
        equal(true, bValid);
    });

    // *** TEST CASE #2 ***
    test("validateDateRange() should return false if FromDate > ToDate", function() {
        var bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange("20131010", "20111010");
        equal(false, bValid);
    });

    // *** TEST CASE #3 ***
    test("validateDateRange() should return false if FromDate is an empty string and ToDate is an empty string", function() {
        var bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange("", "");
        equal(false, bValid);
    });

    // *** TEST CASE #3 ***
    test("validateDateRange() should return false if FromDate is not defined and ToDate is not defined", function() {
        var bValid = jd.ui.eid.common.validator.DateValidator.validateDateRange(null, null);
        equal(false, bValid);
    });

})();