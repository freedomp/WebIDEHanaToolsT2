(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ListBoxFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer for control {@link jd.ui.eid.control.ListBoxFilterItem}.
     * 
     * @class Default renderer for control {@link jd.ui.eid.control.ListBoxFilterItem}.
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     * @name jd.ui.eid.control.ListBoxFilterItemRenderer
     */
    jd.ui.eid.control.ListBoxFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.ListBoxFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRm The RenderManager that can be used for writing to the render output buffer.
     * @param {jd.ui.eid.control.ListBoxFilterItem}
     *            oControl The control that should be rendered.
     */
    jd.ui.eid.control.ListBoxFilterItemRenderer._renderContent = function(oRm, oControl) {
        var oListBox = oControl.getAggregation("_listBox");
        if (oListBox.getItems().length == 0) {
            oRm.write("<div");
            oRm.addClass("jdUiEidFilterItemNoData");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getNoData());
            oRm.write("</div>");
        } else {
            oRm.renderControl(oListBox);
        }
    };

})();