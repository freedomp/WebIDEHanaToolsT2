(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.DateDistanceFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");

    var oFilterItem = null;
    var oModel = null;
    var oCustomDateDistanceListItem = null;
    var oCustomDateRangeListItem = null;
    var oItem = null;
    var oData = {
        FilterSelection : {
            CreationDate : {
                Type : "Relative",
                CustomStartDate : "2013-11-24T00:00:00.000Z",
                CustomEndDate : "2013-12-10T00:00:00.000Z",
                CustomDuration : 2,
                CustomUnit : "week",
                Duration : null,
                Unit : ""
            }
        }
    };

    module("jd.ui.eid.control.DateDistanceFilterItem", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(oData);
            oCustomDateDistanceListItem = new jd.ui.eid.control.ValueListItem({
                text : "Custom Date Distance from DTCs...",
                toolPopup : new sap.ui.ux3.ToolPopup()
            });
            oCustomDateRangeListItem = new jd.ui.eid.control.ValueListItem({
                text : "Custom Date Range...",
                toolPopup : new sap.ui.ux3.ToolPopup()
            });
            oItem = new jd.ui.eid.control.ValueListItem({
                text : "One Week from DTC",
                value : {
                    duration : 2,
                    unit : "month"
                }
            });
            oFilterItem = new jd.ui.eid.control.DateDistanceFilterItem({
                defaultCustomDateRangeLabel : "Custom Date Range...",
                defaultCustomDistanceLabel : "Custom Distance from DTCs...",
                customDateRangeItem : oCustomDateRangeListItem,
                customDistanceItem : oCustomDateDistanceListItem,
                items : [oItem]
            });

            // Set the value list item formatter
            oFilterItem.setDateRangeValueListItemTextFormatter(function() {
            });
            oFilterItem.setDateDistanceValueListItemTextFormatter(function() {
            });

            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    // *** TEST CASE #1 ***
    test("_clear() should set the selection property to an object with empty properties", function() {
        oFilterItem.bindProperty('selection', '/FilterSelection/CreationDate');
        // Initial assertions
        equal(oFilterItem.getSelection(), oData.FilterSelection.CreationDate);

        // Execute the business logic
        oFilterItem._clear();

        var oEmptyObject = {
            Type : "",
            CustomStartDate : "",
            CustomEndDate : "",
            CustomDuration : -1,
            CustomUnit : "",
            Duration : -1,
            Unit : ""
        };

        // Final assertions
        deepEqual(oEmptyObject, oFilterItem.getProperty("selection"));
    });

    // *** TEST CASE #2 ***
    test("_clear() should not call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertion
        ok(!spy.called);
    });

    // *** TEST CASE #3 ***
    test("_clear() should reset the text property of customDateRangeItem to default value", function() {
        oFilterItem.getAggregation("customDateRangeItem").setProperty("text", "test3text");
        var sDefaultCustomDateRangeLabel = oFilterItem.getProperty("defaultCustomDateRangeLabel");
        notEqual(sDefaultCustomDateRangeLabel, oFilterItem.getAggregation("customDateRangeItem").getProperty("text"));
        oFilterItem._clear();
        equal(sDefaultCustomDateRangeLabel, oFilterItem.getAggregation("customDateRangeItem").getProperty("text"));
    });

    // *** TEST CASE #4 ***
    test("_clear() should reset the value property of customDateRangeItem to default value", function() {
        var oDateRange = {
            from : "20131010",
            to : "20131110"
        };
        oFilterItem.getAggregation("customDateRangeItem").setProperty("value", oDateRange);
        deepEqual(oDateRange, oFilterItem.getAggregation("customDateRangeItem").getProperty("value"));
        oFilterItem._clear();
        notDeepEqual(oDateRange, oFilterItem.getAggregation("customDateRangeItem").getProperty("value"));
    });

    // *** TEST CASE #5 ***
    test("_clear() should reset the text property of customDistanceItem to default value", function() {
        oFilterItem.getAggregation("customDistanceItem").setProperty("text", "test5text");
        var sDefaultCustomDistanceLabel = oFilterItem.getProperty("defaultCustomDistanceLabel");
        notEqual(sDefaultCustomDistanceLabel, oFilterItem.getAggregation("customDistanceItem").getProperty("text"));
        oFilterItem._clear();
        equal(sDefaultCustomDistanceLabel, oFilterItem.getAggregation("customDistanceItem").getProperty("text"));
    });

    // *** TEST CASE #6 ***
    test("_clear() should reset the value property of customDistanceItem", function() {
        var oDateDistance = {
            duration : 12,
            unit : "week"
        };
        oFilterItem.getAggregation("customDistanceItem").setProperty("value", oDateDistance);
        deepEqual(oDateDistance, oFilterItem.getAggregation("customDistanceItem").getProperty("value"));
        oFilterItem._clear();
        notDeepEqual(oDateDistance, oFilterItem.getAggregation("customDistanceItem").getProperty("value"));
    });

    // *** TEST CASE #7 ***
    test("setSelection() should select the customDateRangeItem if type is Absolute", function() {
        var oSelection = {
            Type : "Absolute"
        };

        equal(false, oFilterItem.getAggregation("customDateRangeItem").getProperty("selected"));
        oFilterItem.setSelection(oSelection);
        equal(true, oFilterItem.getAggregation("customDateRangeItem").getProperty("selected"));

    });

    // *** TEST CASE #8 ***
    test("setSelection() should select the customDistanceItem if type is Relative and CustomDuration is not null", function() {
        var oSelection = {
            Type : "Relative",
            CustomDuration : 12
        };

        equal(false, oFilterItem.getAggregation("customDistanceItem").getProperty("selected"));
        oFilterItem.setSelection(oSelection);
        equal(true, oFilterItem.getAggregation("customDistanceItem").getProperty("selected"));

    });

    // *** TEST CASE #8a ***
    test("setSelection() should not select the customDistanceItem if type is Relative and CustomDuration is not null and Duration is not null",
            function() {
                var oSelection = {
                    Type : "Relative",
                    CustomDuration : 12,
                    Duration : 12
                };

                equal(false, oFilterItem.getAggregation("customDistanceItem").getProperty("selected"));
                oFilterItem.setSelection(oSelection);
                equal(false, oFilterItem.getAggregation("customDistanceItem").getProperty("selected"));

            });

    // *** TEST CASE #9 ***
    test("setSelection() should select the static valueListItem which equals to the given selection", function() {
        var oSelection = {
            Type : "Relative",
            Duration : oItem.getProperty("value").duration,
            Unit : oItem.getProperty("value").unit
        };

        equal(false, oFilterItem.getAggregation("items")[0].getProperty("selected"));
        oFilterItem.setSelection(oSelection);
        equal(true, oFilterItem.getAggregation("items")[0].getProperty("selected"));

    });

    // *** TEST CASE #10 ***
    test("setSelection() should update the text property of the customDateRangeItem if type is Absolute", function() {
        var oSelection = {
            Type : "Absolute",
            CustomStartDate : "2013-11-24T00:00:00.000Z",
            CustomEndDate : "2013-12-10T00:00:00.000Z"
        };

        var sText = oFilterItem.getAggregation("customDateRangeItem").getProperty("text");
        oFilterItem.setSelection(oSelection);
        notEqual(sText, oFilterItem.getAggregation("customDateRangeItem").getProperty("text"));
    });

    // *** TEST CASE #11 ***
    test("setSelection() should update the text property of the customDistanceItem if type is Relative and CustomDuration is not null", function() {
        var oSelection = {
            Type : "Relative",
            CustomDuration : 2,
            CustomUnit : "week"
        };

        var sText = oFilterItem.getAggregation("customDistanceItem").getProperty("text");
        oFilterItem.setSelection(oSelection);
        notEqual(sText, oFilterItem.getAggregation("customDistanceItem").getProperty("text"));
    });

    // *** TEST CASE #12 ***
    test("_clearAllItemSelection() should unselect all items", function() {
        oFilterItem.getAggregation("customDistanceItem").setProperty("selected", true);
        oFilterItem.getAggregation("customDateRangeItem").setProperty("selected", true);
        oFilterItem.getAggregation("items")[0].setProperty("selected", true);
        oFilterItem._clearAllItemSelection();
        notEqual(false, oFilterItem.getAggregation("customDistanceItem").setProperty("selected"));
        notEqual(false, oFilterItem.getAggregation("customDateRangeItem").setProperty("selected"));
        notEqual(false, oFilterItem.getAggregation("items")[0].setProperty("selected"));
    });

    // *** TEST CASE #13 ***
    test("setEnabledAllListItems() should disable all items except the customDateRangeItem if false is passed.", function() {
        oFilterItem.getAggregation("customDistanceItem").setProperty("enabled", true);
        oFilterItem.getAggregation("customDateRangeItem").setProperty("enabled", false);
        oFilterItem.getAggregation("items")[0].setProperty("enabled", true);
        oFilterItem.setEnabledAllListItems(false);
        notEqual(false, oFilterItem.getAggregation("customDistanceItem").setProperty("enabled"));
        notEqual(true, oFilterItem.getAggregation("customDateRangeItem").setProperty("enabled"));
        notEqual(false, oFilterItem.getAggregation("items")[0].setProperty("enabled"));
    });

    // *** TEST CASE #13 ***
    test("_handleItemSelected() should fire the valueChanged event", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oItem.setProperty("selected", true);
        var oEvent = new sap.ui.base.Event("DateDistanceTest13", oItem);
        oFilterItem._handleItemSelected(oEvent);

        // Final assertion
        ok(spy.called);
    });

    // *** TEST CASE #14 ***
    test("_handleItemSelected() should update the selection property", function() {
        var oEvent = new sap.ui.base.Event("DateDistanceTest14", oItem);
        oFilterItem._handleItemSelected(oEvent);
        var oSelection = oFilterItem.getProperty("selection");
        equal("Relative", oSelection.Type);
        equal(oItem.getProperty("value").duration, oSelection.Duration);
        equal(oItem.getProperty("value").unit, oSelection.Unit);
    });

    // *** TEST CASE #15 ***
    test("_handleCustomDistanceSelected() should call _clearAllItemSelection()", function() {
        var spy = sinon.spy(oFilterItem, '_clearAllItemSelection');
        ok(!spy.called);
        oFilterItem._handleCustomDistanceSelected();
        ok(spy.called);
    });

    // *** TEST CASE #16 ***
    test("_handleCustomDistanceSelected() should select the customDistanceItem", function() {
        oFilterItem.getAggregation("customDistanceItem").setProperty("selected", false);
        oFilterItem._handleCustomDistanceSelected();
        equal(true, oFilterItem.getAggregation("customDistanceItem").getProperty("selected"));
    });

    // *** TEST CASE #17 ***
    test("_handleCustomDistanceValueChanged() should update the selection property", function() {
        oCustomDateDistanceListItem.setProperty("value", {
            duration : 2,
            unit : "week"
        });
        var oEvent = new sap.ui.base.Event("DateDistanceTest17", oCustomDateDistanceListItem);
        oFilterItem._handleCustomDistanceValueChanged(oEvent);
        var oSelection = oFilterItem.getProperty("selection");
        equal("Relative", oSelection.Type);
        equal(oCustomDateDistanceListItem.getProperty("value").duration, oSelection.CustomDuration);
        equal(oCustomDateDistanceListItem.getProperty("value").unit, oSelection.CustomUnit);
        equal(null, oSelection.Duration);
        equal("", oSelection.Unit);
    });

    // *** TEST CASE #18 ***
    test("_handleCustomDistanceValueChanged() should fire the valueChanged event", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oItem.setProperty("selected", true);
        oCustomDateDistanceListItem.setProperty("value", {
            duration : 2,
            unit : "week"
        });
        var oEvent = new sap.ui.base.Event("DateDistanceTest18", oCustomDateDistanceListItem);
        oFilterItem._handleCustomDistanceValueChanged(oEvent);

        // Final assertion
        ok(spy.called);
    });

    // *** TEST CASE #19 ***
    test("_handleCustomDateRangeSelected() should call _clearAllItemSelection()", function() {
        var spy = sinon.spy(oFilterItem, '_clearAllItemSelection');
        ok(!spy.called);
        oFilterItem._handleCustomDateRangeSelected();
        ok(spy.called);
    });

    // *** TEST CASE #20 ***
    test("_handleCustomDateRangeSelected() should select the customDateRangeItem", function() {
        oFilterItem.getAggregation("customDateRangeItem").setProperty("selected", false);
        oFilterItem._handleCustomDateRangeSelected();
        equal(true, oFilterItem.getAggregation("customDateRangeItem").getProperty("selected"));
    });

    // *** TEST CASE #21 ***
    test("_handleCustomDateRangeValueChanged() should update the selection property", function() {
        oCustomDateRangeListItem.setProperty("value", {
            from : "20131124",
            to : "20131210"
        });
        var oEvent = new sap.ui.base.Event("DateDistanceTest21", oCustomDateRangeListItem);
        oFilterItem._handleCustomDateRangeValueChanged(oEvent);
        var oSelection = oFilterItem.getProperty("selection");
        equal("Absolute", oSelection.Type);
        var sFromDate = oCustomDateRangeListItem.getProperty("value").from;
        var sToDate = oCustomDateRangeListItem.getProperty("value").to;
        var sFromJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sFromDate);
        var sToJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sToDate);
        equal(sFromJSONDate, oSelection.CustomStartDate);
        equal(sToJSONDate, oSelection.CustomEndDate);
    });

    // *** TEST CASE #22 ***
    test("_handleCustomDateRangeValueChanged() should fire the valueChanged event", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oItem.setProperty("selected", true);
        oCustomDateRangeListItem.setProperty("value", {
            from : "20131124",
            to : "20131210"
        });
        var oEvent = new sap.ui.base.Event("DateDistanceTest22", oCustomDateRangeListItem);
        oFilterItem.getProperty("selection").Type = "Relative";
        oFilterItem._handleCustomDateRangeValueChanged(oEvent);

        // Final assertion
        ok(spy.called);
    });

})();