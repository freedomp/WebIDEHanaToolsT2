sap.ui.controller("nw.epm.refapps.products.manage.Main", {

    onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");
        if (sap.ui.Device.support.touch === false) {
            this.getView().addStyleClass("sapUiSizeCompact");
        }

        sap.ca.scfld.md.Startup.init("nw.epm.refapps.products.manage", this);
    }
});
