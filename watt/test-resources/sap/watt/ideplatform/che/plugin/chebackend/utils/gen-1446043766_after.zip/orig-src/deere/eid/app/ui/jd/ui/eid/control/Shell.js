(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.Shell");
    jd.ui.eid.require("sap.ui.core.Control");
    jd.ui.eid.require("jd.ui.eid.control.ShellRenderer");
    jd.ui.eid.require("jd.ui.eid.control.NavigationBar");

    /**
     * The custom shell control that is used in the application. It has been implemented to achieve the desired UI look & feel and behaviour, which is
     * different from the standard sap.ui.ux3.Shell in some ways.
     * 
     * **** This control's definition has been copied from sap.ui.ux3.Shell (from UI5 version 1.16.5) to ensure that changes to the Shell control in
     * future versions of the UI5 framework do not affect the Shell in this application. ****
     * 
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.Shell", {
        metadata : {

            // ---- object ----
            publicMethods : [
            // methods
            "setContent"],

            // ---- control specific ----
            properties : {
                "appTitle" : {
                    type : "string",
                    group : "Misc",
                    defaultValue : null
                },
                "appIcon" : {
                    type : "sap.ui.core.URI",
                    group : "Misc",
                    defaultValue : null
                },
                "appIconTooltip" : {
                    type : "string",
                    group : "Misc",
                    defaultValue : null
                },
                "showLogoutButton" : {
                    type : "boolean",
                    group : "Misc",
                    defaultValue : true
                },
                "logoutButtonTooltip" : {
                    type : "string",
                    group : "Accessibility",
                    defaultValue : null
                },
                "applyContentPadding" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                },
                "fullHeightContent" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : false
                }
            },
            defaultAggregation : "content",
            aggregations : {
                "worksetItems" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : true,
                    singularName : "worksetItem"
                },
                "content" : {
                    type : "sap.ui.core.Control",
                    multiple : true,
                    singularName : "content"
                },
                "headerItems" : {
                    type : "sap.ui.core.Control",
                    multiple : true,
                    singularName : "headerItem"
                },
                "notificationBar" : {
                    type : "sap.ui.ux3.NotificationBar",
                    multiple : false
                }
            },
            associations : {
                "selectedWorksetItem" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : false
                }
            },
            events : {
                "worksetItemSelected" : {
                    allowPreventDefault : true
                }
            }
        }
    });

    /**
     * Creates a new subclass of class jd.ui.eid.control.Shell with name <code>sClassName</code> and enriches it with the information contained in
     * <code>oClassInfo</code>.
     * 
     * <code>oClassInfo</code> might contain the same kind of informations as described in {@link sap.ui.core.Element.extend Element.extend}.
     * 
     * @param {string}
     *            sClassName name of the class to be created
     * @param {object}
     *            [oClassInfo] object literal with informations about the class
     * @param {function}
     *            [FNMetaImpl] constructor function for the metadata object. If not given, it defaults to sap.ui.core.ElementMetadata.
     * @return {function} the created class / constructor function
     * @public
     * @static
     * @name jd.ui.eid.control.Shell.extend
     * @function
     */

    jd.ui.eid.control.Shell.M_EVENTS = {
        'worksetItemSelected' : 'worksetItemSelected',
        'logout' : 'logout'
    };

    /**
     * Getter for property <code>appTitle</code>. The application title to appear in the left part of the header, usually a company and/or product
     * name. appIcon and appTitle are both optional and can both be set; in this case the icon appears first.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @return {string} the value of property <code>appTitle</code>
     * @public
     * @name jd.ui.eid.control.Shell#getAppTitle
     * @function
     */

    /**
     * Setter for property <code>appTitle</code>.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @param {string}
     *            sAppTitle new value for property <code>appTitle</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#setAppTitle
     * @function
     */

    /**
     * Getter for property <code>appIcon</code>. The URL of the image to appear in the left part of the header, usually a branding image containing
     * a logo and/or product name. appIcon and appTitle are both optional and can both be set; in this case the icon appears first. If the appIcon is
     * set, for accessibility reasons the appIconTooltip must also be set.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @return {sap.ui.core.URI} the value of property <code>appIcon</code>
     * @public
     * @name jd.ui.eid.control.Shell#getAppIcon
     * @function
     */

    /**
     * Setter for property <code>appIcon</code>.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @param {sap.ui.core.URI}
     *            sAppIcon new value for property <code>appIcon</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#setAppIcon
     * @function
     */

    /**
     * Getter for property <code>appIconTooltip</code>. The tooltip of the application icon in the header
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @return {string} the value of property <code>appIconTooltip</code>
     * @public
     * @name jd.ui.eid.control.Shell#getAppIconTooltip
     * @function
     */

    /**
     * Setter for property <code>appIconTooltip</code>.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @param {string}
     *            sAppIconTooltip new value for property <code>appIconTooltip</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#setAppIconTooltip
     * @function
     */

    /**
     * Getter for property <code>showLogoutButton</code>. Whether the Logoff button in the header should be displayed or not.
     * 
     * Default value is <code>true</code>
     * 
     * @return {boolean} the value of property <code>showLogoutButton</code>
     * @public
     * @name jd.ui.eid.control.Shell#getShowLogoutButton
     * @function
     */

    /**
     * Setter for property <code>showLogoutButton</code>.
     * 
     * Default value is <code>true</code>
     * 
     * @param {boolean}
     *            bShowLogoutButton new value for property <code>showLogoutButton</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#setShowLogoutButton
     * @function
     */

    /**
     * Getter for property <code>logoutButtonTooltip</code>. The tooltip to be displayed for the Logout Button of the Shell. If not set, a text
     * meaning "Logout" in the current language will be displayed.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @return {string} the value of property <code>logoutButtonTooltip</code>
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#getLogoutButtonTooltip
     * @function
     */

    /**
     * Setter for property <code>logoutButtonTooltip</code>.
     * 
     * Default value is empty/<code>undefined</code>
     * 
     * @param {string}
     *            sLogoutButtonTooltip new value for property <code>logoutButtonTooltip</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#setLogoutButtonTooltip
     * @function
     */

    /**
     * Getter for property <code>applyContentPadding</code>. Whether the Shell content area should have a theme-dependent padding or not.
     * 
     * Default value is <code>true</code>
     * 
     * @return {boolean} the value of property <code>applyContentPadding</code>
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#getApplyContentPadding
     * @function
     */

    /**
     * Setter for property <code>applyContentPadding</code>.
     * 
     * Default value is <code>true</code>
     * 
     * @param {boolean}
     *            bApplyContentPadding new value for property <code>applyContentPadding</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#setApplyContentPadding
     * @function
     */

    /**
     * Getter for property <code>fullHeightContent</code>. If set to true, the content area has a defined height. This means that any content put
     * inside can use "100%" height in CSS and will then consume all available space. However, if content is larger, scrollbars will appear at the
     * content area of the Shell and not on window level.
     * 
     * Default value is <code>false</code>
     * 
     * @return {boolean} the value of property <code>fullHeightContent</code>
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#getFullHeightContent
     * @function
     */

    /**
     * Setter for property <code>fullHeightContent</code>.
     * 
     * Default value is <code>false</code>
     * 
     * @param {boolean}
     *            bFullHeightContent new value for property <code>fullHeightContent</code>
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @since 1.9.0
     * @name jd.ui.eid.control.Shell#setFullHeightContent
     * @function
     */

    /**
     * Getter for aggregation <code>worksetItems</code>.<br/> The workset items.
     * 
     * @return {jd.ui.eid.control.NavigationItem[]}
     * @public
     * @name jd.ui.eid.control.Shell#getWorksetItems
     * @function
     */

    /**
     * Inserts a worksetItem into the aggregation named <code>worksetItems</code>.
     * 
     * @param {jd.ui.eid.control.NavigationItem}
     *            oWorksetItem the worksetItem to insert; if empty, nothing is inserted
     * @param {int}
     *            iIndex the <code>0</code>-based index the worksetItem should be inserted at; for a negative value of <code>iIndex</code>, the
     *            worksetItem is inserted at position 0; for a value greater than the current size of the aggregation, the worksetItem is inserted at
     *            the last position
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#insertWorksetItem
     * @function
     */

    /**
     * Adds some worksetItem <code>oWorksetItem</code> to the aggregation named <code>worksetItems</code>.
     * 
     * @param {jd.ui.eid.control.NavigationItem}
     *            oWorksetItem the worksetItem to add; if empty, nothing is inserted
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#addWorksetItem
     * @function
     */

    /**
     * Removes an worksetItem from the aggregation named <code>worksetItems</code>.
     * 
     * @param {int |
     *            string | jd.ui.eid.control.NavigationItem} vWorksetItem the worksetItem to remove or its index or id
     * @return {jd.ui.eid.control.NavigationItem} the removed worksetItem or null
     * @public
     * @name jd.ui.eid.control.Shell#removeWorksetItem
     * @function
     */

    /**
     * Removes all the controls in the aggregation named <code>worksetItems</code>.<br/> Additionally unregisters them from the hosting UIArea.
     * 
     * @return {jd.ui.eid.control.NavigationItem[]} an array of the removed elements (might be empty)
     * @public
     * @name jd.ui.eid.control.Shell#removeAllWorksetItems
     * @function
     */

    /**
     * Checks for the provided <code>jd.ui.eid.control.NavigationItem</code> in the aggregation named <code>worksetItems</code> and returns its
     * index if found or -1 otherwise.
     * 
     * @param {jd.ui.eid.control.NavigationItem}
     *            oWorksetItem the worksetItem whose index is looked for.
     * @return {int} the index of the provided control in the aggregation if found, or -1 otherwise
     * @public
     * @name jd.ui.eid.control.Shell#indexOfWorksetItem
     * @function
     */

    /**
     * Destroys all the worksetItems in the aggregation named <code>worksetItems</code>.
     * 
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#destroyWorksetItems
     * @function
     */

    /**
     * Getter for aggregation <code>content</code>.<br/> The content to appear in the main canvas. Each modification of this aggregation leads to
     * a re-rendering of the content area - but not to a re-rendering of the complete Shell.
     * 
     * @return {sap.ui.core.Control[]}
     * @public
     * @name jd.ui.eid.control.Shell#getContent
     * @function
     */

    /**
     * Inserts a content into the aggregation named <code>content</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oContent the content to insert; if empty, nothing is inserted
     * @param {int}
     *            iIndex the <code>0</code>-based index the content should be inserted at; for a negative value of <code>iIndex</code>, the
     *            content is inserted at position 0; for a value greater than the current size of the aggregation, the content is inserted at the last
     *            position
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#insertContent
     * @function
     */

    /**
     * Adds some content <code>oContent</code> to the aggregation named <code>content</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oContent the content to add; if empty, nothing is inserted
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#addContent
     * @function
     */

    /**
     * Removes an content from the aggregation named <code>content</code>.
     * 
     * @param {int |
     *            string | sap.ui.core.Control} vContent the content to remove or its index or id
     * @return {sap.ui.core.Control} the removed content or null
     * @public
     * @name jd.ui.eid.control.Shell#removeContent
     * @function
     */

    /**
     * Removes all the controls in the aggregation named <code>content</code>.<br/> Additionally unregisters them from the hosting UIArea.
     * 
     * @return {sap.ui.core.Control[]} an array of the removed elements (might be empty)
     * @public
     * @name jd.ui.eid.control.Shell#removeAllContent
     * @function
     */

    /**
     * Checks for the provided <code>sap.ui.core.Control</code> in the aggregation named <code>content</code> and returns its index if found or -1
     * otherwise.
     * 
     * @param {sap.ui.core.Control}
     *            oContent the content whose index is looked for.
     * @return {int} the index of the provided control in the aggregation if found, or -1 otherwise
     * @public
     * @name jd.ui.eid.control.Shell#indexOfContent
     * @function
     */

    /**
     * Destroys all the content in the aggregation named <code>content</code>.
     * 
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#destroyContent
     * @function
     */

    /**
     * Getter for aggregation <code>headerItems</code>.<br/> Controls to appear in the header next to the logout button. It is recommended to only
     * use controls of type Button, MenuButton and TextView. The respective UI guidelines need to be enforced on a higher level.
     * 
     * @return {sap.ui.core.Control[]}
     * @public
     * @name jd.ui.eid.control.Shell#getHeaderItems
     * @function
     */

    /**
     * Inserts a headerItem into the aggregation named <code>headerItems</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oHeaderItem the headerItem to insert; if empty, nothing is inserted
     * @param {int}
     *            iIndex the <code>0</code>-based index the headerItem should be inserted at; for a negative value of <code>iIndex</code>, the
     *            headerItem is inserted at position 0; for a value greater than the current size of the aggregation, the headerItem is inserted at
     *            the last position
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#insertHeaderItem
     * @function
     */

    /**
     * Adds some headerItem <code>oHeaderItem</code> to the aggregation named <code>headerItems</code>.
     * 
     * @param {sap.ui.core.Control}
     *            oHeaderItem the headerItem to add; if empty, nothing is inserted
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#addHeaderItem
     * @function
     */

    /**
     * Removes an headerItem from the aggregation named <code>headerItems</code>.
     * 
     * @param {int |
     *            string | sap.ui.core.Control} vHeaderItem the headerItem to remove or its index or id
     * @return {sap.ui.core.Control} the removed headerItem or null
     * @public
     * @name jd.ui.eid.control.Shell#removeHeaderItem
     * @function
     */

    /**
     * Removes all the controls in the aggregation named <code>headerItems</code>.<br/> Additionally unregisters them from the hosting UIArea.
     * 
     * @return {sap.ui.core.Control[]} an array of the removed elements (might be empty)
     * @public
     * @name jd.ui.eid.control.Shell#removeAllHeaderItems
     * @function
     */

    /**
     * Checks for the provided <code>sap.ui.core.Control</code> in the aggregation named <code>headerItems</code> and returns its index if found
     * or -1 otherwise.
     * 
     * @param {sap.ui.core.Control}
     *            oHeaderItem the headerItem whose index is looked for.
     * @return {int} the index of the provided control in the aggregation if found, or -1 otherwise
     * @public
     * @name jd.ui.eid.control.Shell#indexOfHeaderItem
     * @function
     */

    /**
     * Destroys all the headerItems in the aggregation named <code>headerItems</code>.
     * 
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#destroyHeaderItems
     * @function
     */

    /**
     * Getter for aggregation <code>notificationBar</code>.<br/> The NotificationBar which should be integrated into the Shell.
     * 
     * @return {sap.ui.ux3.NotificationBar}
     * @public
     * @since 1.7.0
     * @name jd.ui.eid.control.Shell#getNotificationBar
     * @function
     */

    /**
     * Setter for the aggregated <code>notificationBar</code>.
     * 
     * @param oNotificationBar
     *            {sap.ui.ux3.NotificationBar}
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @since 1.7.0
     * @name jd.ui.eid.control.Shell#setNotificationBar
     * @function
     */

    /**
     * Destroys the notificationBar in the aggregation named <code>notificationBar</code>.
     * 
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @since 1.7.0
     * @name jd.ui.eid.control.Shell#destroyNotificationBar
     * @function
     */

    /**
     * The ID of the Item that is currently selected. When setting, the NavigationItem itself can be given instead of its ID. There will not be a
     * worksetItemSelected event, the application is responsible to show the proper content according to the newly selected WorksetItem. If the set
     * WorksetItem does not exist in this Shell, the first item (and first sub-item) will be selected after the call. When getting, always the ID is
     * returned, by which the NavigationItem instance can be retrieved.
     * 
     * @return {string} Id of the element which is the current target of the <code>selectedWorksetItem</code> association, or null
     * @public
     * @name jd.ui.eid.control.Shell#getSelectedWorksetItem
     * @function
     */

    /**
     * The ID of the Item that is currently selected. When setting, the NavigationItem itself can be given instead of its ID. There will not be a
     * worksetItemSelected event, the application is responsible to show the proper content according to the newly selected WorksetItem. If the set
     * WorksetItem does not exist in this Shell, the first item (and first sub-item) will be selected after the call. When getting, always the ID is
     * returned, by which the NavigationItem instance can be retrieved.
     * 
     * @param {string |
     *            jd.ui.eid.control.NavigationItem} vSelectedWorksetItem Id of an element which becomes the new target of this
     *            <code>selectedWorksetItem</code> association. Alternatively, an element instance may be given.
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#setSelectedWorksetItem
     * @function
     */

    /**
     * Fired when a workset item was selected by the user. The application may populate the sub-items of the given workset item in the event handler,
     * but this must happen synchronously. If this is done, the application is responsible for displaying the correct content for the selected one of
     * the newly created sub-items. The Shell will currently always mark the first sub-item as selected.
     * 
     * @name jd.ui.eid.control.Shell#worksetItemSelected
     * @event
     * @param {sap.ui.base.Event}
     *            oControlEvent
     * @param {sap.ui.base.EventProvider}
     *            oControlEvent.getSource
     * @param {object}
     *            oControlEvent.getParameters
     * 
     * @param {string}
     *            oControlEvent.getParameters.id The id of the workset item that has been newly selected by the user. If a top-level item has been
     *            clicked which has sub-items, the ID of the currently active sub-item (/leaf) is given.
     * @param {jd.ui.eid.control.NavigationItem}
     *            oControlEvent.getParameters.item The selected NavigationItem
     * @param {string}
     *            oControlEvent.getParameters.key The key of the selected NavigationItem (or null if there is no key)
     * @public
     */

    /**
     * Attach event handler <code>fnFunction</code> to the 'worksetItemSelected' event of this <code>jd.ui.eid.control.Shell</code>.<br/>. When
     * called, the context of the event handler (its <code>this</code>) will be bound to <code>oListener<code> if specified
     * otherwise to this <code>jd.ui.eid.control.Shell</code>.<br/> itself. 
     *  
     * Fired when a workset item was selected by the user. The application may populate the sub-items of the given workset item in the event handler, but this must happen synchronously. If this is done, the application is responsible for displaying the correct content for the selected one of the newly created sub-items. The Shell will currently always mark the first sub-item as selected. 
     *
     * @param {object}
     *            [oData] An application specific payload object, that will be passed to the event handler along with the event object when firing the event.
     * @param {function}
     *            fnFunction The function to call, when the event occurs.  
     * @param {object}
     *            [oListener=this] Context object to call the event handler with. Defaults to this <code>jd.ui.eid.control.Shell</code>.<br/> itself.
     *
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#attachWorksetItemSelected
     * @function
     */

    /**
     * Detach event handler <code>fnFunction</code> from the 'worksetItemSelected' event of this <code>jd.ui.eid.control.Shell</code>.<br/>
     * 
     * The passed function and listener object must match the ones used for event registration.
     * 
     * @param {function}
     *            fnFunction The function to call, when the event occurs.
     * @param {object}
     *            oListener Context object on which the given function had to be called.
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#detachWorksetItemSelected
     * @function
     */

    /**
     * Fire event worksetItemSelected to attached listeners.
     * 
     * Listeners may prevent the default action of this event using the preventDefault-method on the event object. * Expects following event
     * parameters:
     * <ul>
     * <li>'id' of type <code>string</code> The id of the workset item that has been newly selected by the user. If a top-level item has been
     * clicked which has sub-items, the ID of the currently active sub-item (/leaf) is given.</li>
     * <li>'item' of type <code>jd.ui.eid.control.NavigationItem</code> The selected NavigationItem</li>
     * <li>'key' of type <code>string</code> The key of the selected NavigationItem (or null if there is no key)</li>
     * </ul>
     * 
     * @param {Map}
     *            [mArguments] the arguments to pass along with the event.
     * @return {boolean} whether to prevent the default action
     * @protected
     * @name jd.ui.eid.control.Shell#fireWorksetItemSelected
     * @function
     */

    /**
     * Fired when the user clicks the "Log-off" button
     * 
     * @name jd.ui.eid.control.Shell#logout
     * @event
     * @param {sap.ui.base.Event}
     *            oControlEvent
     * @param {sap.ui.base.EventProvider}
     *            oControlEvent.getSource
     * @param {object}
     *            oControlEvent.getParameters
     * 
     * @public
     */

    /**
     * Attach event handler <code>fnFunction</code> to the 'logout' event of this <code>jd.ui.eid.control.Shell</code>.<br/>. When called, the
     * context of the event handler (its <code>this</code>) will be bound to <code>oListener<code> if specified
     * otherwise to this <code>jd.ui.eid.control.Shell</code>.<br/> itself. 
     *  
     * Fired when the user clicks the "Log-off" button 
     *
     * @param {object}
     *            [oData] An application specific payload object, that will be passed to the event handler along with the event object when firing the event.
     * @param {function}
     *            fnFunction The function to call, when the event occurs.  
     * @param {object}
     *            [oListener=this] Context object to call the event handler with. Defaults to this <code>jd.ui.eid.control.Shell</code>.<br/> itself.
     *
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#attachLogout
     * @function
     */

    /**
     * Detach event handler <code>fnFunction</code> from the 'logout' event of this <code>jd.ui.eid.control.Shell</code>.<br/>
     * 
     * The passed function and listener object must match the ones used for event registration.
     * 
     * @param {function}
     *            fnFunction The function to call, when the event occurs.
     * @param {object}
     *            oListener Context object on which the given function had to be called.
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @public
     * @name jd.ui.eid.control.Shell#detachLogout
     * @function
     */

    /**
     * Fire event logout to attached listeners.
     * 
     * @param {Map}
     *            [mArguments] the arguments to pass along with the event.
     * @return {jd.ui.eid.control.Shell} <code>this</code> to allow method chaining
     * @protected
     * @name jd.ui.eid.control.Shell#fireLogout
     * @function
     */

    /**
     * Replaces the existing Shell content with the given Control(-Tree). Only leads to a re-rendering of the content area (not the complete Shell).
     * This method may be more convenient than a series of calls to "removeContent" and "addContent", which each lead to a re-rendering of the content
     * area (but again not of the complete Shell).
     * 
     * By default the old content is not destroyed and is returned by this method in an array for further usage. To avoid memory leaks, the old
     * content should be destroyed (if not needed later), by setting the "destroyOldContent" flag or by destroying it manually later on. If
     * "destroyOldContent" is set, an empty array is returned.
     * 
     * @name jd.ui.eid.control.Shell.prototype.setContent
     * @function
     * @param {sap.ui.core.Control}
     *            oContent The new Content. In this method it must be exactly one control (-tree). Use addContent() to add more control (-trees) to
     *            the main content area of the Shell.
     * @param {boolean}
     *            bDestroyOldContent If set, the controls previously contained in the Shell will be destroyed, to avoid memory leaks.
     * 
     * @type sap.ui.core.Control[]
     * @public
     */

    jd.ui.eid.control.Shell.WSI_MENU_DELAY = 200;
    jd.ui.eid.control.Shell.WSI_OVERFLOW_SCROLL_STEP = 250; // how many pixels to scroll with every overflow arrow click
    jd.ui.eid.control.Shell.TOOL_PREFIX = "-tool-";
    jd.ui.eid.control.Shell.FIRST_RENDERING = true; // used for detecting the single very first rendering of any Shell on the page
    /**
     * The basic width of the ToolPalette if all icons fit into one column. Multiplied if more than one column of items must be used.
     * 
     * This value might change after rendering from the LESS parameter "jdUiEidShellSideBarBaseWidth"
     * 
     * @see onBeforeRendering and onThemeChanged
     */
    jd.ui.eid.control.Shell.SIDE_BAR_BASE_WIDTH = null;

    /**
     * The basic height of the overflow button in the right pane. Shown when there are too many entries.
     * 
     * This value might change after rendering from the LESS parameter "jdUiEidShellPaneOverflowButtonHeight",
     * 
     * @see onBeforeRendering and onThemeChanged
     */
    jd.ui.eid.control.Shell.PANE_OVERFLOW_BUTTON_HEIGHT = null;

    /**
     * This method has custom changes to instantiate custom jd.ui.eid.control.NavigationBar instances instead of ux3.NavigationBar.
     */
    jd.ui.eid.control.Shell.prototype.init = function() {
        this._iOpenPaneIndex = -1;
        this._sOpenWsiId = null;

        this._bPreviousScrollRight = false; // remember the workset item overflow state
        this._bPreviousScrollLeft = false;

        this._sSelectedWorksetId = null;
        this._sSelectedFacetId = null;

        this._aSyncRefStack = [];
        this._mSyncRefs = {};

        this._oWorksetBar = new jd.ui.eid.control.NavigationBar(this.getId() + "-wsBar", {
            toplevelVariant : true,
            select : [this._handleWorksetBarSelect, this]
        }).setParent(this);
        this._oFacetBar = new jd.ui.eid.control.NavigationBar(this.getId() + "-facetBar", {
            select : [this._handleFacetBarSelect, this]
        }).setParent(this);

        // The following calue is updated when the ToolPalette is resized.
        // (It is used in methods like _closePane and setOffsetRight)
        this.currentToolPaletteWidth = 0;
    };

    jd.ui.eid.control.Shell.prototype.exit = function() {
        if (this._oWorksetBar) {
            this._oWorksetBar.destroy();
            delete this._oWorksetBar;
        }
        if (this._oFacetBar) {
            this._oFacetBar.destroy();
            delete this._oFacetBar;
        }
        this._oSearchField = null;
    };

    jd.ui.eid.control.Shell.prototype.onBeforeRendering = function() {
        var sId = this.getId();

        jQuery.sap.byId(this.getId() + "-focusDummyPane").unbind("focusin");

        // drag&drop for images with local file API
        if (window.FileReader) {
            var $hdr = jQuery.sap.byId(sId + "-hdr");
            $hdr.unbind('dragover', this._handleDragover).unbind('dragend', this._handleDragend).unbind('drop', this._handleDrop);
            var $bg = jQuery.sap.byId(sId + "-bgImg");
            $bg.unbind('dragover', jQuery.proxy(this._handleDragover)).unbind('dragend', this._handleDragend).unbind('drop', this._handleDrop);
        }

    };

    jd.ui.eid.control.Shell.prototype.onAfterRendering = function() {
        var sId = this.getId();

        if (this._topSyncRefId && this._mSyncRefs[this._topSyncRefId].focusLast) {
            jQuery.sap.byId(this.getId() + "-focusDummyPane").focusin(this._mSyncRefs[this._topSyncRefId].focusLast);
        }

        // drag&drop for images with local file API
        if (window.FileReader) {
            var $hdr = jQuery.sap.byId(sId + "-hdr");
            $hdr.bind('dragover', jQuery.proxy(this._handleDragover, this)).bind('dragend', jQuery.proxy(this._handleDragend, this)).bind('drop',
                    jQuery.proxy(this._handleDrop, this));
            var $bg = jQuery.sap.byId(sId + "-bgImg");
            $bg.bind('dragover', jQuery.proxy(this._handleDragover, this)).bind('dragend', jQuery.proxy(this._handleDragend, this)).bind('drop',
                    jQuery.proxy(this._handleDrop, this));
        }

        // hide or show the facet bar depending on whether the current workset item has sub-items
        var bShowFacetBar = (this._oFacetBar.getAssociatedItems().length > 0);
        var $FacetBar = jQuery.sap.byId(this.getId() + "-facetBar");
        $FacetBar.css("display", (bShowFacetBar ? "block" : "none"));
        this._adaptContentHeight();

        // remember RTL mode to avoid repeated checks
        this._bRtl = sap.ui.getCore().getConfiguration().getRTL();

        // ItemNavigation for PaneBar items
        if (!this._oPaneItemNavigation) {
            this._oPaneItemNavigation = new sap.ui.core.delegate.ItemNavigation().setCycling(false);
            this.addDelegate(this._oPaneItemNavigation);
        }

        this._setNotifyVisibility();

        jd.ui.eid.control.Shell.FIRST_RENDERING = false;

    };

    /**
     * @returns an object defining the current focus in the Shell
     */
    jd.ui.eid.control.Shell.prototype.getFocusInfo = function() {
        try {
            var oElement = document.activeElement;
            return oElement ? {
                'sFocusId' : oElement.id,
                'oFocusedElement' : oElement
            } : {};
        } catch (ex) {
            // IE9 throws an Unspecified Error when accessing document.activeElement inside a frame before body.onload. This is not an issue, as there
            // is just no focus yet to restore.
            return {};
        }
    };

    /**
     * Restores focus according to the given oFocusInfo which has been acquired by calling Shell.getFocusInfo
     * 
     * @param oFocusInfo
     */
    jd.ui.eid.control.Shell.prototype.applyFocusInfo = function(oFocusInfo) {
        var oElement = jQuery.sap.domById(oFocusInfo.sFocusId) || oFocusInfo.oFocusedElement; // if not even an ID was available when focus was lost
        // maybe the original DOM element is still there
        jQuery.sap.focus(oElement); // also works for oElement == null
    };

    jd.ui.eid.control.Shell.prototype.onclick = function(oEvent) {
        this.onUserActivation(oEvent);
    };
    jd.ui.eid.control.Shell.prototype.onsapspace = function(oEvent) {
        this.onUserActivation(oEvent);
    };
    jd.ui.eid.control.Shell.prototype.onsapenter = function(oEvent) {
        this.onUserActivation(oEvent);
    };

    jd.ui.eid.control.Shell.prototype.onUserActivation = function(oEvent) {
        var sTargetId = oEvent.target.id;
        var parent = oEvent.target.parentNode;
        var sId = this.getId();

        if (oEvent.target.className && oEvent.target.className.indexOf /* not available for SVG elements */
                && oEvent.target.className.indexOf("jdUiEidShellHeader-logout") > -1) { // logout button clicked
            this.fireLogout();

        } else if (parent && parent.parentNode && parent.parentNode.className && parent.parentNode.className.indexOf /*
                                                                                                                         * not available for SVG
                                                                                                                         * elements
                                                                                                                         */
                && parent.parentNode.className.indexOf("jdUiEidShellToolPaletteArea") > -1) { // tool item clicked
            this._handleToolItemClick(sTargetId);

        } else if (parent && parent.parentNode && parent.parentNode.parentNode && parent.parentNode.parentNode.className
                && parent.parentNode.parentNode.className.indexOf /* not available for SVG elements */
                && parent.parentNode.parentNode.className.indexOf("jdUiEidShellToolPaletteArea") > -1) { // image in tool item clicked
            this._handleToolItemClick(parent.id);

        } else if (sTargetId === sId + "-paneBarOverflowButtonIcon" || sTargetId === sId + "-paneBarOverflowButton") {
            // Show/Hide overflow menu
            var oTarget = jQuery.sap.byId(sId + "-paneBarOverflowButton")[0];
            this._getPaneOverflowMenu().open(true, oTarget, (this._bRtl ? "left" : "right") + " bottom", "center center", oTarget);

        } else if (sTargetId) {
            if (parent && parent.className && parent.className.indexOf /* not available for SVG elements */
                    && parent.className.indexOf("jdUiEidShellPaneEntries") > -1) { // pane bar item clicked
                this._handlePaneBarItemClick(sTargetId);
            }
        }
    };

    /* ====== WORKSET ITEMS ====== */

    jd.ui.eid.control.Shell.prototype._handleWorksetBarSelect = function(oEvent) {
        var bProcessSelection = this._handleWorksetItemClick(oEvent.getParameter("item"));
        if (!bProcessSelection) {
            oEvent.preventDefault();
        }
    };

    jd.ui.eid.control.Shell.prototype._handleFacetBarSelect = function(oEvent) {
        var bProcessSelection = this._handleWorksetItemClick(oEvent.getParameter("item"));
        if (!bProcessSelection) {
            oEvent.preventDefault();
        }
    };

    /**
     * This method has custom changes to set the correct custom CSS class on the ShellContent area, to achieve the desired non-standard scrolling
     * behaviour.
     * 
     * @param oElement
     * @returns {Boolean}
     */
    jd.ui.eid.control.Shell.prototype._handleWorksetItemClick = function(oElement) {
        var parent = oElement.getParent(), id = oElement.getId(), facetId = id, bProcessSelection = true;

        if (parent instanceof jd.ui.eid.control.Shell) { // 1st-level
            if (id != this._sSelectedWorksetId) { // it's actually a change

                var aSubItems = oElement.getSubItems();
                if (aSubItems.length > 0) {
                    facetId = aSubItems[0].getId();

                    // If there are subitems, additionally set a class on the jdUiEidShellContent
                    // shell.
                    // This lets us set its height accordingly, to achieve the required scrolling
                    // functionality.
                    jQuery(".jdUiEidShellContent").removeClass("jdUiEidShellContentNoFacetBar").addClass("jdUiEidShellContentAfterFacetBar");
                } else {
                    jQuery(".jdUiEidShellContent").removeClass("jdUiEidShellContentAfterFacetBar").addClass("jdUiEidShellContentNoFacetBar");
                }

                // tell the application what the user has done and give the chance to supply new/more/changed subitems
                bProcessSelection = this._fireWorksetItemSelected(facetId);
                if (bProcessSelection) {

                    this._sSelectedWorksetId = id;
                    if (aSubItems.length > 0) {
                        this._sSelectedFacetId = aSubItems[0].getId();
                        id = this._sSelectedFacetId; // the user clicked first-level, but if the first-level has children there must be one of them
                        // selected
                    } else {
                        this._sSelectedFacetId = null;
                    }

                    // if the application modifies/sets the selected subId, this should work, as long as this._sSelectedFacetId is updated

                    // application has received the event and potentially modified the subitems
                    var aSubItems = oElement.getSubItems();
                    this._oFacetBar.setAssociatedItems(aSubItems, true); // exchange the items in the second-level navigation; force an "arrow
                    // flies in" animation

                    var $FacetBar = jQuery.sap.byId(this.getId() + "-facetBar");
                    var iFacetBarHeight = this._calcFacetBarHeight($FacetBar);

                    // hide/show the second-level navigation
                    if (aSubItems.length > 0) {
                        if (!this._oFacetBar.isSelectedItemValid()) {
                            this._oFacetBar.setSelectedItem(aSubItems[0]);
                            this._sSelectedFacetId = aSubItems[0].getId();
                        }
                        $FacetBar.slideDown();
                        this._adaptContentHeight(null, true, iFacetBarHeight);
                    } else {
                        this._oFacetBar.setSelectedItem(null);
                        $FacetBar.slideUp();
                        this._adaptContentHeight(null, true, iFacetBarHeight);
                    }
                }
            }

        } else { // 2nd-level - it is a sub-item
            if (id != this._sSelectedFacetId) { // it's actually a change
                bProcessSelection = this._fireWorksetItemSelected(facetId);
                if (bProcessSelection) {
                    this._sSelectedFacetId = id;
                }
            }
        }
        return bProcessSelection;
    };

    jd.ui.eid.control.Shell.prototype._fireWorksetItemSelected = function(sId) {
        var item = sap.ui.getCore().byId(sId);
        var key = (item ? item.getKey() : null);
        var bProcessSelection = this.fireWorksetItemSelected({
            id : sId,
            item : item,
            key : key
        });
        if (bProcessSelection) {
            this.setAssociation("selectedWorksetItem", sId, true); // update the internal and publicly available knowledge about which item is
            // selected
        }
        return bProcessSelection;
    };

    (function() {

        jd.ui.eid.control.Shell._SHELL_OFFSET_RIGHT = 0; // can be changed during runtime

        jd.ui.eid.control.Shell.prototype._setNotifyVisibility = function(sVisibleStatus) {
            var oNotificationBar = this.getNotificationBar();
            if (!oNotificationBar) {
                return;
            }

            if (!sVisibleStatus) {
                sVisibleStatus = oNotificationBar.getVisibleStatus();
            }

            var $notify = jQuery.sap.byId(this.getId() + "-notify");
            var $syncRef = this._topSyncRefId ? jQuery.sap.byId(this._topSyncRefId) : jQuery(null);
            var bIsThingInspector = $syncRef.hasClass("jdUiEidTI");

            var iHeight = 0;
            var iBottom = 0;
            var iZIndex = 1;

            if (sVisibleStatus === sap.ui.ux3.NotificationBarStatus.Min) {
                iHeight = 10;
            } else if (sVisibleStatus === sap.ui.ux3.NotificationBarStatus.Max || sVisibleStatus === sap.ui.ux3.NotificationBarStatus.Default) {
                iHeight = 10;
                iBottom = iHeight;
            }

            $notify.removeClass("jdUiEidShellNotifyTI").removeClass("jdUiEidShellNotifyOverlay");

            if (this._topSyncRefId) {
                this._getSyncRefs().animate({
                    "bottom" : iBottom + "px"
                }, "fast");
                // $syncRef.css("bottom", iBottom+"px");
                iZIndex = parseInt($syncRef.css("z-index"));
                if (iBottom > 0) {
                    $notify.addClass(bIsThingInspector ? "jdUiEidShellNotifyTI" : "jdUiEidShellNotifyOverlay");
                }
            }

            $notify.css("height", iHeight + "px").css("z-index", iZIndex + 1);

            if (iHeight > 0 && !this.$().hasClass("jdUiEidShellNotifyVisible")) {
                this.$().addClass("jdUiEidShellNotifyVisible");
            } else if (iHeight == 0 && this.$().hasClass("jdUiEidShellNotifyVisible")) {
                this.$().removeClass("jdUiEidShellNotifyVisible");
            }

            this._adaptContentHeight(sVisibleStatus);
        };
    }());

    /**
     * Returns a jQuery object containing all registered "special cases" aka overlays (ThingInspector, etc.) that cover the canvas area, but not the
     * panes. Whenever the canvas size is changes, all these have to be updated as well.
     * 
     * @private
     * @return {jQuery} $Refs A jQuery-object referencing all "overlaying" elements
     */
    jd.ui.eid.control.Shell.prototype._getSyncRefs = function() {
        var aRefs = [];
        var oRef;
        for ( var i = 0; i < this._aSyncRefStack.length; i++) {
            oRef = jQuery.sap.domById(this._aSyncRefStack[i]);
            if (oRef) {
                aRefs.push(oRef);
            }
        }
        return jQuery(aRefs);
    };

    // invalidation avoiding code

    jd.ui.eid.control.Shell.prototype.setAppTitle = function(sAppTitle) {
        this.setProperty("appTitle", sAppTitle, true);
        this._rerenderHeader();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.setAppIcon = function(sAppIcon) {
        this.setProperty("appIcon", sAppIcon, true);
        this._rerenderHeader();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.setShowLogoutButton = function(bShowLogoutButton) {
        this.setProperty("showLogoutButton", bShowLogoutButton, true);
        this._rerenderHeader();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.setLogoutButtonTooltip = function(sTooltip) {
        this.setProperty("logoutButtonTooltip", sTooltip, true);
        this._rerenderHeader();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.insertHeaderItem = function(oHeaderItem, iIndex) {
        if (sap.ui.commons && sap.ui.commons.Button && (oHeaderItem instanceof sap.ui.commons.Button)) {
            oHeaderItem.setStyled(false);
        }
        this.insertAggregation("headerItems", oHeaderItem, iIndex, true);
        this._rerenderHeader();
        return this;
    };
    jd.ui.eid.control.Shell.prototype.addHeaderItem = function(oHeaderItem) {
        if (sap.ui.commons && sap.ui.commons.Button && (oHeaderItem instanceof sap.ui.commons.Button)) {
            oHeaderItem.setStyled(false);
        }
        this.addAggregation("headerItems", oHeaderItem, true);
        this._rerenderHeader();
        return this;
    };
    jd.ui.eid.control.Shell.prototype.removeHeaderItem = function(vIndex) {
        var result = this.removeAggregation("headerItems", vIndex, true);
        this._rerenderHeader();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.removeAllHeaderItems = function() {
        var result = this.removeAllAggregation("headerItems", true);
        this._rerenderHeader();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.destroyHeaderItems = function() {
        this.destroyAggregation("headerItems", true);
        this._rerenderHeader();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.insertContent = function(oContent, iIndex) {
        this.insertAggregation("content", oContent, iIndex, true);
        this._rerenderContent();
        return this;
    };
    jd.ui.eid.control.Shell.prototype.addContent = function(oContent) {
        this.addAggregation("content", oContent, true);
        this._rerenderContent();
        return this;
    };
    jd.ui.eid.control.Shell.prototype.removeContent = function(vIndex) {
        var result = this.removeAggregation("content", vIndex, true);
        this._rerenderContent();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.removeAllContent = function() {
        var result = this.removeAllAggregation("content", true);
        this._rerenderContent();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.destroyContent = function() {
        this.destroyAggregation("content", true);
        this._rerenderContent();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.addWorksetItem = function(oWorksetItem) {
        this.addAggregation("worksetItems", oWorksetItem, true);
        this._rerenderWorksetItems();
        return this;
    };

    jd.ui.eid.control.Shell.prototype.insertWorksetItem = function(oWorksetItem, iIndex) {
        this.insertAggregation("worksetItems", oWorksetItem, iIndex, true);
        this._rerenderWorksetItems();
        return this;
    };
    jd.ui.eid.control.Shell.prototype.removeWorksetItem = function(vWorksetItem) {
        var result = this.removeAggregation("worksetItems", vWorksetItem, true);
        this._rerenderWorksetItems();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.removeAllWorksetItems = function() {
        var result = this.removeAllAggregation("worksetItems", true);
        this._rerenderWorksetItems();
        return result;
    };
    jd.ui.eid.control.Shell.prototype.destroyWorksetItems = function() {
        this.destroyAggregation("worksetItems", true);
        this._rerenderWorksetItems();
        return this;
    };

    (function() {

        function clearNotificationBar(oShell) {
            var oOldNotificationBar = oShell.getNotificationBar();
            if (oOldNotificationBar) {
                oShell._setNotifyVisibility(sap.ui.ux3.NotificationBarStatus.None);
                oOldNotificationBar.setVisibleStatus = oOldNotificationBar.__orig_setVisibleStatus;
                oOldNotificationBar.detachDisplay(oOldNotificationBar.__fHandleNotifyDisplay);
                delete oOldNotificationBar.__orig_setVisibleStatus;
                delete oOldNotificationBar.__fHandleNotifyDisplay;
            }
        };

        jd.ui.eid.control.Shell.prototype.setNotificationBar = function(oNotificationBar) {
            clearNotificationBar(this);
            if (oNotificationBar) {
                var that = this;
                oNotificationBar.__orig_setVisibleStatus = oNotificationBar.setVisibleStatus;
                oNotificationBar.setVisibleStatus = function(sVisibleStatus) {
                    this.__orig_setVisibleStatus.apply(this, arguments);
                    that._setNotifyVisibility();
                };
            }
            this.setAggregation("notificationBar", oNotificationBar, true);
            this._rerenderNotificationArea();
            if (oNotificationBar) {
                oNotificationBar.__fHandleNotifyDisplay = function(oEvent) {
                    var bShow = oEvent ? oEvent.getParameter("show") : oNotificationBar.hasItems();
                    oNotificationBar.setVisibleStatus(bShow ? sap.ui.ux3.NotificationBarStatus.Default : sap.ui.ux3.NotificationBarStatus.None);
                };
                oNotificationBar.attachDisplay(oNotificationBar.__fHandleNotifyDisplay);
                oNotificationBar.__fHandleNotifyDisplay();
            }
            return this;
        };

        jd.ui.eid.control.Shell.prototype.destroyNotificationBar = function() {
            clearNotificationBar(this);
            this.destroyAggregation("notificationBar", true);
            this._rerenderNotificationArea();
            return this;
        };

    }());

    jd.ui.eid.control.Shell.prototype._rerenderNotificationArea = function() {
        var $notify = jQuery.sap.byId(this.getId() + "-notify");
        if ($notify.length > 0) {
            var rm = sap.ui.getCore().createRenderManager();
            jd.ui.eid.control.ShellRenderer.renderNotificationArea(rm, this);
            rm.flush($notify[0], true);
            rm.destroy();
        }
    };

    jd.ui.eid.control.Shell.prototype._rerenderHeader = function() {
        var $hdr = jQuery.sap.byId(this.getId() + "-hdr");
        if ($hdr.length > 0) {
            var rm = sap.ui.getCore().createRenderManager();
            jd.ui.eid.control.ShellRenderer.renderHeader(rm, this);
            rm.flush($hdr[0], true);
            rm.destroy();
        }
    };

    jd.ui.eid.control.Shell.prototype._rerenderContent = function(bPreventPreserve) {
        var $content = jQuery.sap.byId(this.getId() + "-content");
        if ($content.length > 0) {
            var aContent = this.getContent(), rm = sap.ui.getCore().createRenderManager();
            for ( var i = 0; i < aContent.length; i++) {
                rm.renderControl(aContent[i]);
            }
            rm.flush($content[0], bPreventPreserve);
            rm.destroy();
        }
    };

    jd.ui.eid.control.Shell.prototype._rerenderWorksetItems = function() {
        if (jQuery.sap.byId(this.getId() + "-wBar").length > 0) {
            jd.ui.eid.control.ShellRenderer.renderWorksetItems(null, this);
            jd.ui.eid.control.ShellRenderer.renderFacetBar(null, this);
            var items = this._oFacetBar.getAssociatedItems();
            this._oFacetBar.$().css("display", (items && items.length > 0 ? "block" : "none"));
            this._adaptContentHeight();
        }
    };

    /* DEBUG code for tracking invalidation */

    /**
     * Forces invalidation and rerendering (.invalidate() is disabled)
     * 
     * @private
     */
    jd.ui.eid.control.Shell.prototype.forceInvalidation = sap.ui.core.Control.prototype.invalidate;

    /**
     * Hack that prevents Shell invalidation by default. Later, invalidation should return to normal, but be prevented in all typical cases by
     * bSuppressRerendering with explicit change handling.
     * 
     * @private
     */
    jd.ui.eid.control.Shell.prototype.invalidate = function(oSource) {

        if (oSource == this) {
            // does not happen because the source is only given when propagating to a parent

        } else if (!oSource) {
            // direct invalidation of the Shell; this means a property has been modified
            this.forceInvalidation(); // let invalidation occur

        } else if (oSource instanceof jd.ui.eid.control.NavigationItem) {
            // a workset item was changed/renamed or, more likely, subitems were added/exchanged
            if (this._oWorksetBar && this._oFacetBar) { // if already destroyed no update
                this._oWorksetBar.setAssociatedItems(this.getWorksetItems());
                var wsi = this.getSelectedWorksetItem();
                if (wsi) {
                    var items;
                    var sel = sap.ui.getCore().byId(wsi);
                    if (sel && sel.getParent() instanceof jd.ui.eid.control.NavigationItem) { // second-level item is selected
                        this._oFacetBar.setAssociatedItems(sel.getParent().getSubItems()); // update the second-level NavigationBar as well
                    } else if (sel && (items = sel.getSubItems())) { // toplevel item is selected and has children
                        if (items && (items.length > 0)) {
                            this._oFacetBar.setAssociatedItems(items); // update the second-level NavigationBar as well
                        }
                    } else {
                        // toplevel item with no children, TODO: removing/adding the only child may be interesting to look at
                    }

                    items = this._oFacetBar.getAssociatedItems();
                    this._oFacetBar.$().css("display", (items && items.length > 0 ? "block" : "none"));
                    this._adaptContentHeight();
                }
            }

        } else if (this.indexOfHeaderItem(oSource) >= 0) {
            // a header item was invalidated - rerender the header
            this._rerenderHeader();

        } else {
            // a child was invalidated - TODO: check what kind of child and either handle directly or re-render
        }
    };

    jd.ui.eid.control.Shell.prototype._setParent = sap.ui.core.Control.prototype.setParent;
    jd.ui.eid.control.Shell.prototype.setParent = function(oParent, sAggregationName, bSuppressRerendering) {
        this._setParent(oParent, sAggregationName, bSuppressRerendering);
        this.forceInvalidation(); // TODO: temporary hack to force invalidation when the Shell is added to a UiArea
    };

    /* METHODS */

    jd.ui.eid.control.Shell.prototype.setContent = function(vContent, bDestruct) {
        jQuery.sap.assert(vContent === null || (vContent instanceof sap.ui.core.Control)
                || ((jQuery.isArray(vContent) && ((vContent.length > 0) ? (vContent[0] instanceof sap.ui.core.Control) : true))),
                "vContent must be a control or array of controls or null"); // only the first array element is checked
        jQuery.sap.assert((bDestruct === undefined || bDestruct === true || bDestruct === false), "bDestruct must be true, false, or undefined");

        var oldContent = [];
        var $content = jQuery.sap.byId(this.getId() + "-content");
        var bPreventPreserve = false;

        if (!bDestruct) {
            oldContent = this.removeAllAggregation("content", true);

            if ($content.length > 0) {
                sap.ui.core.RenderManager.preserveContent($content[0]);
                bPreventPreserve = true;
                $content.empty();
            }
        } else {
            this.destroyAggregation("content", true);
        }

        // add new control(s) to aggregation
        if (vContent instanceof sap.ui.core.Control) { // one single control
            this.addAggregation("content", vContent, true);
        } else if (vContent && typeof (vContent) == "object" && vContent.length) { // an array of (hopefully) controls
            for ( var i = 0; i < vContent.length; i++) {
                this.addAggregation("content", vContent[i], true);
            }
        }

        // if Shell is already rendered, update the UI
        this._rerenderContent(bPreventPreserve);

        return oldContent;
    };

    jd.ui.eid.control.Shell.prototype.getSelectedWorksetItem = function() {
        /*
         * Initially, this is null There is a value as soon as: 1. The application sets a value 2. The Shell is rendered without a value (the first
         * toplevel item will be used then (respectively its first child, if present))
         */
        return this.getAssociation("selectedWorksetItem");
    };

    jd.ui.eid.control.Shell.prototype.setSelectedWorksetItem = function(selectedWorksetItem) {
        var oldSelectedId = this.getSelectedWorksetItem();
        this.setAssociation("selectedWorksetItem", selectedWorksetItem, true);
        var newSelectedId = this.getSelectedWorksetItem();

        if (oldSelectedId != newSelectedId) { // only do something if selected item really changed
            var newSelectedItem = sap.ui.getCore().byId(newSelectedId);

            if (newSelectedItem) {

                this._sSelectedWorksetId = newSelectedId;
                this._sSelectedFacetId = null;

                var sub = newSelectedItem.getSubItems();
                if (sub.length > 0) { // app set a parent item that has children, so select automatically the first child
                    newSelectedItem = sub[0];
                }

                if (newSelectedItem && (newSelectedItem.getParent() instanceof jd.ui.eid.control.NavigationItem)) { // if selected item is sub-item
                    var newParentItem = newSelectedItem.getParent();
                    this._sSelectedWorksetId = newParentItem.getId();
                    this._sSelectedFacetId = newSelectedItem.getId();

                    this._oWorksetBar.setSelectedItem(newParentItem);
                    this._oFacetBar.setAssociatedItems(newParentItem.getSubItems());
                    this._oFacetBar.setSelectedItem(newSelectedItem);

                    if (this.getDomRef()) {
                        var $FacetBar = jQuery.sap.byId(this.getId() + "-facetBar");
                        var iFacetBarHeight = this._calcFacetBarHeight($FacetBar);
                        $FacetBar.slideDown();
                        this._adaptContentHeight(null, true, iFacetBarHeight);
                    }

                } else if (newSelectedItem) {
                    this._oWorksetBar.setSelectedItem(newSelectedItem);
                    this._oFacetBar.setAssociatedItems([]);
                    this._oFacetBar.setSelectedItem(null);

                    if (this.getDomRef()) {
                        var $FacetBar = jQuery.sap.byId(this.getId() + "-facetBar");
                        var iFacetBarHeight = this._calcFacetBarHeight($FacetBar);
                        $FacetBar.slideUp();
                        this._adaptContentHeight(null, true, iFacetBarHeight);
                    }

                } else {
                    // newSelectedItem == null after selecting the child
                }
            } else {
                // newSelectedItem == null
                throw new Error("WorksetItem with ID " + newSelectedId + " cannot be found.");
            }
        }

        return this;
    };

    /* FullHeight / ContentPadding */

    jd.ui.eid.control.Shell.prototype.setApplyContentPadding = function(bApplyContentPadding) {
        this.setProperty("applyContentPadding", bApplyContentPadding, true); // no re-rendering
        this.$().toggleClass("jdUiEidShellNoContentPadding", !bApplyContentPadding);
        this._adaptContentHeight();
    };

    jd.ui.eid.control.Shell.prototype.setFullHeightContent = function(bFullHeightContent) {
        this.setProperty("fullHeightContent", bFullHeightContent, true); // no re-rendering
        this.$().toggleClass("jdUiEidShellFullHeightContent", bFullHeightContent);
        this._adaptContentHeight();
    };

    jd.ui.eid.control.Shell.prototype._calcFacetBarHeight = function($FacetBar) {
        if (this._iFacetBarHeight === undefined) {
            this._iFacetBarHeight = 0;
        }

        if (!$FacetBar) {
            $FacetBar = jQuery.sap.byId(this.getId() + "-facetBar");
        }
        if ($FacetBar.length > 0) {
            var h = jQuery.sap.byId(this.getId() + "-facetBar").outerHeight(true);
            this._iFacetBarHeight = Math.max(this._iFacetBarHeight, h);
        }

        return this._iFacetBarHeight;
    };

    jd.ui.eid.control.Shell.prototype._adaptContentHeight = function(sNotificationBarVisibleStatus, bAnimate, iFacetBarHeight) {
        if (!this.getDomRef()) {
            return;
        }

        var $content = jQuery.sap.byId(this.getId() + "-content");
        var $canvas = jQuery.sap.byId(this.getId() + "-canvas");

        if (this.getFullHeightContent()) {
            var bPad = this.getApplyContentPadding();
            var iTop = !bPad ? 0 : parseInt($canvas.css("paddingTop"), 10);
            var iLeft = !bPad ? 0 : parseInt($canvas.css("paddingLeft"), 10);
            var iRight = !bPad ? 0 : parseInt($canvas.css("paddingRight"), 10);

            var _iFacetBarHeight = iFacetBarHeight ? iFacetBarHeight : this._calcFacetBarHeight();

            var sTop = (iTop + (this._oFacetBar.getAssociatedItems().length > 0 ? _iFacetBarHeight : 0)) + "px";

            if (bAnimate) {
                $content.stop().animate({
                    top : sTop
                });
            } else {
                $content.stop().css("top", sTop);
            }

            var oNotify = this.getNotificationBar();
            if (oNotify && !sNotificationBarVisibleStatus) {
                sNotificationBarVisibleStatus = oNotify.getVisibleStatus();
            }

            if (sNotificationBarVisibleStatus === sap.ui.ux3.NotificationBarStatus.Default
                    || sNotificationBarVisibleStatus === sap.ui.ux3.NotificationBarStatus.Max) {
                $content.css("bottom", oNotify.getHeightOfStatus(sap.ui.ux3.NotificationBarStatus.Default));
            } else {
                var iBottom = !bPad ? 0 : parseInt($canvas.css("paddingBottom"), 10);
                if (oNotify && sNotificationBarVisibleStatus === sap.ui.ux3.NotificationBarStatus.Min) {
                    iBottom += sap.ui.ux3.NotificationBar.HOVER_ITEM_HEIGHT;
                }
                $content.css("bottom", iBottom + "px");
            }

            $content.css(this._bRtl ? "right" : "left", iLeft + "px");
            $content.css(this._bRtl ? "left" : "right", iRight + "px");
        } else {
            $content.removeAttr("style");
        }

        if (!!sap.ui.Device.browser.webkit) {
            // Force Webkit Browsers to do a repaint
            sap.ui.core.RenderManager.forceRepaint(this.getId() + "-canvas");
        }
    };

})();