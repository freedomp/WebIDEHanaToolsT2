(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CollectionInspectorWithSummaryRenderer");

    /**
     * @class The renderer for the {@link jd.ui.eid.control.CollectionInspectorWithSummary} control.
     * 
     * @static
     * @name jd.ui.eid.control.CollectionInspectorWithSummaryRenderer
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer = {};

    /**
     * Renders the Collection
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.render = function(oRenderManager, oControl) {
        // convenience variable
        var rm = oRenderManager;

        rm.write("<div");
        rm.addClass("jdUiEidCI");
        if (oControl.getSidebarVisible()) {
            rm.addClass("jdUiEidCISidebarOpened");
        } else {
            rm.addClass("jdUiEidCISidebarClosed");
        }
        if (oControl.getFitParent()) {
            rm.addClass("jdUiEidCIFitParent");
        }
        rm.writeClasses();
        rm.writeControlData(oControl);
        rm.write(">");

        rm.write("<div");
        rm.addClass("jdUiEidCIToolBar");
        rm.writeClasses();
        rm.write(">");

        // Custom : The toggle button is a standard feature, but it is to be rendered only if needed (if the custom attribute allowSidebarCollapse is
        // true)
        if (oControl.getAllowSidebarCollapse()) {
            this.renderToggleButton(rm, oControl);
        }

        this.renderCollectionSelector(rm, oControl);

        rm.write("</div>");

        // Creating a new wrapper DIV for {custom summary + jdUiEidCISidebar divs}. This DIV will together float:left, so that the content stays on
        // the right.
        rm.write("<div");
        rm.writeAttribute("id", oControl.getId() + "-leftSection");
        rm.addClass("jdUiEidCollectionInspectorLeftSection");
        rm.writeClasses();
        rm.write(">");

        // Custom summary area (start)
        rm.write("<div");
        rm.addClass("jdUiEidCollectionInspectorSummary");
        rm.writeClasses();
        rm.write(">");
        this.renderSummary(rm, oControl);
        rm.write("</div>");
        // Custom summary area (end)

        // Sidebar containing collection items (start)
        rm.write('<div');
        rm.addClass("jdUiEidCISidebar");
        rm.writeClasses();
        rm.writeAttribute("id", oControl.getId() + "-sidebar");
        rm.write(">");
        this.renderSidebar(rm, oControl);
        rm.write("</div>");
        // Sidebar containing collection items (end)
        // Close wrapper for {summary + sidebar}
        rm.write("</div>");

        rm.write("<div");
        rm.addClass("jdUiEidCIContent");
        rm.writeAttribute("id", oControl.getId() + "-content");
        rm.writeClasses();
        rm.write(">");
        this.renderContent(rm, oControl);
        rm.write("</div>");
        rm.write("<div");
        rm.addClass("jdUiEidCIClear");
        rm.writeClasses();
        rm.write(">");
        rm.write("</div>");
        rm.write("</div>");
    };

    /**
     * Renders the ToggleButton to open and close the sidebar
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.renderToggleButton = function(rm, oControl) {
        // render Togglebutton
        if (oControl.getToggleButton()) {
            rm.write("<div");
            rm.writeAttribute("id", oControl.getId() + "-togglebutton");
            rm.addClass("jdUiEidCIToggleButton");
            rm.writeClasses();
            rm.write(">");
            rm.renderControl(oControl.getToggleButton());
            rm.write("</div>");
        }
    };

    /**
     * Renders the collection selector which selects the current collection
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.renderCollectionSelector = function(rm, oControl) {
        // render collection selector
        if (oControl.getCollectionSelector()) {
            rm.write("<div");
            rm.addClass("jdUiEidCICollectionSelector");
            rm.writeClasses();
            rm.write(">");
            rm.renderControl(oControl.getCollectionSelector());
            rm.write("</div>");
        }
    };

    /**
     * Renders the Sidebar which displays all collections
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.renderSidebar = function(rm, oControl) {
        rm.write("<div");
        rm.addClass("jdUiEidCICollectionListContainer");
        rm.writeClasses();
        rm.write(">");
        rm.write('<ul tabindex="-1"');
        rm.addClass("jdUiEidCICollectionList");
        rm.writeClasses();
        var oCollection = sap.ui.getCore().byId(oControl.getSelectedCollection());

        // ARIA
        if (oControl.getSelectedCollection()) {
            rm.writeAccessibilityState(oCollection, {
                role : "listbox",
                multiselectable : oCollection.getMultiSelection()
            });
        }
        rm.write(">");
        if (oControl.getSelectedCollection()) {
            var iItemCount = oCollection.getItems().length;
            jQuery.each(oCollection.getItems(), function(iIndex, oCollectionItem) {
                rm.write('<li tabindex="-1"');
                rm.writeElementData(oCollectionItem);
                rm.writeAttributeEscaped("title", oCollectionItem.getText());
                rm.addClass("jdUiEidCICollectionListItem");
                if (oCollectionItem.getHighlighted()) {
                    rm.addClass("jdUiEidCICollectionListItemHighlighted");
                }
                rm.writeClasses();

                // ARIA
                rm.writeAccessibilityState(oCollectionItem, {
                    role : "option",
                    selected : (jQuery.inArray(oCollectionItem.getId(), oCollection.getSelectedItems()) >= 0),
                    setsize : iItemCount,
                    posinset : iIndex
                });

                rm.write(">");

                // Custom : Each <li> needs two lines
                rm.write("<div>"); // DIV for each list item

                rm.write("<div"); // For line 1 (text)
                rm.addClass("jdUiEidCollectionInspectorCollectionItemText");
                rm.writeClasses();
                rm.write(">");
                rm.writeEscaped(oCollectionItem.getText());
                rm.write("</div>");

                rm.write("<div"); // For line 2 (Secondary text)
                rm.addClass("jdUiEidCollectionInspectorCollectionItemSecondaryText");
                rm.writeClasses();
                rm.write(">");
                rm.writeEscaped(oCollectionItem.getSecondaryText());
                rm.write("</div>");

                rm.write("</div></li>");
            });
        }
        rm.write("</ul></div>");
        rm.renderControl(oControl.getEditButton());
    };

    /**
     * Renders the Content that is displayed
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.renderContent = function(rm, oControl) {
        jQuery.each(oControl.getContent(), function(iIndex, oContent) {
            rm.renderControl(oContent);
        });
    };

    /**
     * Renders the custom summary
     * 
     * @param {sap.ui.core.RenderManager}
     *            oRenderManager the RenderManager that can be used for writing to the Render-Output-Buffer
     * @param {sap.ui.core.Control}
     *            oControl an object representation of the control that should be rendered
     */
    jd.ui.eid.control.CollectionInspectorWithSummaryRenderer.renderSummary = function(rm, oControl) {
        var headerContent = oControl.getSummary();

        if (headerContent.getTitle()) {
            rm.write("<div class='sapUiUx3TVHeaderGroupTitle jdUiEidCollectionInspectorSummaryHeaderTitle'");
            rm.writeAttributeEscaped("title", headerContent.getTooltip_AsString() ? headerContent.getTooltip_AsString() : headerContent.getTitle());
            rm.write("><span role='heading' aria-level='4'>");
            rm.writeEscaped(headerContent.getTitle());
            rm.write("</span>");
            rm.write("</div>");
        }
        rm.write("<div class='sapUiUx3TVHeaderGroupContent'>");
        var childContent = headerContent.getContent();
        for ( var j = 0; j < childContent.length; j++) {
            var childControl = childContent[j];
            rm.renderControl(childControl);
        }
        rm.write("</div>");
    };
})();