jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
//
sap.ca.scfld.md.controller.BaseFullscreenController.extend("nw.epm.refapps.shop.view.EmptyPage", {

    onBackPressed : function() {
        this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
		this._oRouter = this._oComponent.getRouter();
		this._oRouter.navTo("ProductList", {});
    }
});
