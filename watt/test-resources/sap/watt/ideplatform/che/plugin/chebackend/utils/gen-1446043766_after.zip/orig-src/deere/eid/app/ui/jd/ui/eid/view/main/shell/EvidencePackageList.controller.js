(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.EvidencePackageFormatter");

    /**
     * @class
     * <p>
     * The view displays a list of evidence packages.
     * </p>
     * <h2>Controls</h2>
     * <p>
     * The view mainly consists of a table control. The search field control and buttons on top are in the table's toolbar. The 'package name' column
     * uses the {@link jd.ui.eid.control.TableActionCell TableActionCell} control as its template, to provide actions on mouse hover.
     * </p>
     * <h2>Functionality</h2>
     * <p>
     * When the user selects a row, the 'Delete' and 'Close Package' buttons get enabled if the selected evidence package has the status 'Open' and
     * the user owns this evidence package (that is, this package was created by the current user, information provided by the backend as part of data
     * structure). On mouse hover, the 'Edit' and 'Copy' options are visible on each row depending on the evidence package.
     * </p>
     * <p>
     * A custom column menu exists for the 'Status' column with the three options 'Show open', 'Show closed' and 'Show all'. The currently selected
     * filter option is indicated with a 'check' icon. A QuickView with the evidence package description is shown on hovering over the package name.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.shell.EvidencePackageList
     */
    sap.ui.controller("jd.ui.eid.view.main.shell.EvidencePackageList", jQuery.extend(true, {}, jd.ui.eid.view.BaseController, /** @lends jd.ui.eid.view.main.shell.EvidencePackageList */
    {
        _oService : null,
        _oView : null,
        _sViewName : "jd.ui.eid.view.main.shell.EvidencePackageList",

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         */
        onInit : function() {
            this._oView = this.getView();
            this._oView.addStyleClass("jdUiView jdUiEidViewAutoScroll");

            // Subcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
            oEventBus.subscribe("WorksheetOverlay", "closed", this.handleWorksheetOverlayClosed, this);
            oEventBus.subscribe("EvidencePackageOverlay", "closed", this.handleEvidencePackageSummaryOverlayClosed, this);

            this._oService = this.getServiceFacade("EvidencePackage");
            this._oService.attachRequestFailed(this._onRequestFailed);
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         */
        onAfterRendering : function() {
            // UI is ready. Load the evidence package list
            this.fetchEvidencePackageList();
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         */
        onExit : function() {
            // Unsubcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
            oEventBus.unsubscribe("WorksheetOverlay", "closed", this.handleWorksheetOverlayClosed, this);
            oEventBus.unsubscribe("EvidencePackageOverlay", "closed", this.handleEvidencePackageSummaryOverlayClosed, this);

            // Detach event listeners
            this._oService.detachRequestFailed(this._onRequestFailed);

            // Set properties to null
            this._oService = null;
            this._oView = null;
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the DTAC case list is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageList") {
                this.byId("evidencePackageTable").setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the DTAC case list has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelDataFeteched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageList") {
                this.byId("evidencePackageTable").setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Triggers a service call to fetch the entire list of evidence packages and update the model.
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        fetchEvidencePackageList : function() {
            // Get binding and search term from UI
            var oBinding = this._oView.byId("evidencePackageTable").getBinding();
            var sSearchTerm = this._oView.byId("searchField").getValue();
            var oController = this;

            // Update the button states (enabled/disabled) after every refresh (for example, if a row has been deleted by the user and there
            // has been a refresh)
            function fnSuccess() {
                oController._updateButtonStates();
            }

            // Make the service call
            this._oService.getEvidencePackageList(oBinding, sSearchTerm, fnSuccess, this._onRequestFailed);
        },

        /**
         * Handler of the refresh list event. Triggers a service call to update the current list of Evidence Packages.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event fired by the button.
         */
        handleRefreshEvidencePackageList : function(oEvent) {
            var oBinding = this._oView.byId("evidencePackageTable").getBinding();
            oBinding.refreshData();
        },

        /**
         * Event handler for the 'Copy package' action
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        handleCopyEvidencePackage : function(oEvent) {
            var oModel = sap.ui.getCore().getModel();

            // Clear the evidence package model paths before continuing
            oModel.setProperty("/EvidencePackageDetails", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails));

            // Clear Evidence Package related SearchTerms
            oModel.setProperty("/SearchTerms/DTCListSearchTerm", "");
            oModel.setProperty("/SearchTerms/DTACCaseListSearchTerm", "");
            oModel.setProperty("/SearchTerms/WarrantyClaimsByPrimePartListSearchTerm", "");

            var iEvidencePackageID = oEvent.getSource().getBindingContext().getProperty('PackageID');
            var oOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
            oOverlay.setContext({
                EvidencePackageID : iEvidencePackageID,
                Copy : true
            });
            oOverlay.open();
        },

        /**
         * Event handler for the 'Edit package' action
         */
        handleEditEvidencePackage : function(oEvent) {
            var oModel = sap.ui.getCore().getModel();
            // Clear the evidence package model paths before continuing
            oModel.setProperty("/EvidencePackageDetails", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails));
            // Clear the DTAC and Warranty Claim filters as well
            oModel.setProperty("/DTACCaseFilters", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter));
            oModel.setProperty("/WarrantyClaimFilters", jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter));
            // Clear Evidence Package related SearchTerms
            oModel.setProperty("/SearchTerms/DTCListSearchTerm", "");
            oModel.setProperty("/SearchTerms/DTACCaseListSearchTerm", "");
            oModel.setProperty("/SearchTerms/WarrantyClaimsByPrimePartListSearchTerm", "");

            var iEvidencePackageID = oEvent.getSource().getBindingContext().getProperty('PackageID');
            var oOverlay = jd.ui.eid.common.OverlayHelper.getWorksheetOverlay();
            oOverlay.setContext({
                EvidencePackageID : iEvidencePackageID
            });
            oOverlay.open();
        },

        /**
         * Event handler for the 'Delete package' button
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        handleDeleteEvidencePackage : function() {
            var oController = this;

            // Get the selected row index
            var oTable = this._oView.byId("evidencePackageTable");
            var iRowIndex = oTable.getSelectedIndex();

            // Get the selected row's context
            var oRowContext = oTable.getContextByIndex(iRowIndex);

            // If context was not obtained (ie. no row was
            // selected), don't proceed.
            if (!oRowContext) {
                return;
            }

            // Disable the delete button to handle multiple quick clicks. This happens, e.g, if the Enter key is kept pressed for long.
            this.byId("deleteButton").setEnabled(false);

            // Get evidence package ID to be deleted
            var sEvidencePackageID = oRowContext.getProperty("PackageID");
            var sEvidencePackageName = oRowContext.getProperty("PackageName");

            // Callback to be executed when deletion fails
            var fnOnDeletionError = function() {
                var sErrorMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_LIST_MSG_DELETE_ERROR");
                oController.getNotificationCenter().alert(sErrorMessage);
            };

            // Callback to be executed when deletion is successful
            var fnOnDeletionSuccess = function() {
                // Delete was successful. Refresh the list
                oController.fetchEvidencePackageList();
            };

            // Callback to be executed if user confirms deletion
            var fnOnDeleteConfirmation = function(bConfirmed) {
                // No matter what the user chose, let's a control other than the delete button. Because when the user confirmed the deletion
                // with enter and accidentally hit it multiple times, he would land in the delete confirmation dialog again (cause after
                // close, focus is set to the delete button again and pressing enter would fire the press event).
                // oController.byId("tableHeader").focus();

                if (bConfirmed) {
                    oController._oService.deleteEvidencePackage(sEvidencePackageID, fnOnDeletionSuccess, fnOnDeletionError);
                } else {
                    // Reenable delete button if 'Cancel' was selected. For OK, button state will be updated after the list is refreshed.
                    oController.byId("deleteButton").setEnabled(true);
                }
            };

            // Get confirmation from user before proceeding
            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_LIST_MSW_DELETE_CONFIRMATION", [sEvidencePackageID,
                    sEvidencePackageName]);
            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);
        },

        /**
         * Event handler for the 'Close package' button
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        handleCloseEvidencePackage : function() {
            var oController = this;

            // Get the selected row index
            var oTable = this._oView.byId("evidencePackageTable");
            var iRowIndex = oTable.getSelectedIndex();

            // Get the selected row's context
            var oRowContext = oTable.getContextByIndex(iRowIndex);

            // If context was not obtained (ie. no row was
            // selected), don't proceed.
            if (!oRowContext) {
                return;
            }

            // Disable the button for as long as the popup is open. This is to prevent an issue that happens when the user keeps the Enter
            // button pressed for long JUST after closing the popup. The Close button, since it has focus, is pressed multiple times and
            // mulitple confirmation popups are opened.
            this.byId("closeButton").setEnabled(false);

            // Get evidence package ID to be deleted
            var sEvidencePackageID = oRowContext.getProperty("PackageID");
            var sEvidencePackageName = oRowContext.getProperty("PackageName");

            // Callback to be executed when close fails
            var fnOnCloseError = function() {
                var sErrorMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSE_CLOSE_PACKAGE_FAILED");
                oController.getNotificationCenter().alert(sErrorMessage);
            };

            // Callback to be executed when close is successful
            var fnOnCloseSuccess = function() {
                // Close was successful. Refresh the list
                oController.fetchEvidencePackageList();
            };

            // Callback to be executed if user confirms closing the
            // package
            var fnOnCloseConfirmation = function(bConfirmed) {
                if (bConfirmed) {
                    oController._oService.closeEvidencePackage(sEvidencePackageID, fnOnCloseSuccess, fnOnCloseError);
                } else {
                    // Re-enable the 'Close' button if user selected 'Cancel.' If OK was selected, button states will be updated after the
                    // list is refreshed
                    oController.byId("closeButton").setEnabled(true);
                }
            };

            // Get confirmation from user before closing
            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_MSW_CLOSE_PACKAGE_CONFIRM", [sEvidencePackageID,
                    sEvidencePackageName]);
            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnCloseConfirmation);
        },

        /**
         * Handler for click on the package name, to trigger 'Open package in Evidence Package Summary'
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        handleOpenEvidencePackage : function(oEvent) {
            // Clear the evidence package model paths before continuing
            sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails",
                    jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails));

            var iEvidencePackageID = oEvent.getSource().getBindingContext().getProperty('PackageID');
            var oEvidencePackageDetailsOverlay = jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay();
            oEvidencePackageDetailsOverlay.setContext(iEvidencePackageID);
            if (!oEvidencePackageDetailsOverlay.isOpen()) {
                oEvidencePackageDetailsOverlay.open();
            }
        },

        /**
         * Event handler for the UI table control's 'rowSelectionChange' event. Sets the 'enabled' property on 'Delete' and 'Close package' buttons
         * accordingly.
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        handleRowSelectionChange : function(oEvent) {
            // Update the delete and close button states based on the row that is currently selected
            this._updateButtonStates();
        },

        /**
         * Updates the enabled/disabled states of the buttons on the UI (Close, Delete) based on the row in the evidence package table that is
         * currently selected.
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         */
        _updateButtonStates : function() {
            // Get selected index (to check if a row was selected or
            // deselected)
            var oTable = this._oView.byId("evidencePackageTable");
            var iSelectedIndex = oTable.getSelectedIndex();
            var oContext = oTable.getContextByIndex(iSelectedIndex);

            // 'Delete' and 'Close' allowed only if one row is
            // selected AND user is owner of package
            // AND status is open
            // (0).
            if ((iSelectedIndex != -1) && (oContext.getProperty("PackageOwnedByCurrentUser") == true)
                    && (oContext.getProperty("PackageStatusID") == 0)) {
                this._oView.byId("deleteButton").setEnabled(true);
                this._oView.byId("closeButton").setEnabled(true);
            } else {
                // In other cases, disable both buttons
                this._oView.byId("closeButton").setEnabled(false);
                this._oView.byId("deleteButton").setEnabled(false);
            }
        },

        /**
         * Formatter for visibility of the 'Edit' action
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         * @param iEvidencePackageStatusID
         *            The status of an evidence package
         * @param bPackageOwnedByCurrentUser
         *            Indicates whether evidence package is owned by the current user
         * @returns {Boolean}
         */
        _formatEditVisibility : function(iEvidencePackageStatusID, bPackageOwnedByCurrentUser) {
            // If status is 'Open (0)' and package is owned by
            // current user, then
            // allow edit.
            if ((iEvidencePackageStatusID == 0) && bPackageOwnedByCurrentUser) {
                return true;
            } else {
                return false;
            }
        },

        /**
         * Formatter for the 'Status' column
         * 
         * @param sEvidencePackageStatusID
         *            The 'Status ID' which needs to be formatted to readable text like 'Open' and 'Closed'.
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         * @private
         */
        _formatPackageStatus : function(iEvidencePackageStatusID) {
            if (iEvidencePackageStatusID == jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Open) {
                return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_TABLE_CEL_STATUS_OPEN");
            } else if (iEvidencePackageStatusID == jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus.Close) {
                return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_TABLE_CEL_STATUS_CLOSED");
            }
        },

        /**
         * Formatter for the evidence package list count
         * 
         * @param aEvidencePackageList
         */
        formatEPListCCount : function(aEvidencePackageList) {
            var sLength = 0;
            var oListBinding = this.byId("evidencePackageTable").getBinding("rows");
            if (oListBinding) {
                sLength = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oListBinding.getLength());
            }
            return jd.ui.eid.common.I18NHelper.getNumberChoiceText(sLength, "EVIDENCE_PACKAGE_TABLE_CAP_COUNT_MULTIPLE",
                    "EVIDENCE_PACKAGE_TABLE_CAP_COUNT_SINGLE");
        },

        /**
         * Event handler for the 'Show open' menu item for the Status column
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         * @private
         */
        _onStatusFilterOpen : function() {
            var oTable = this._oView.byId("evidencePackageTable");
            var oStatusColumn = this._oView.byId("statusColumn");
            oTable.getBinding().filter([new sap.ui.model.Filter("PackageStatusID", "EQ", "0")]);
            oStatusColumn.setFiltered(true);

            // Set icon
            this._oView.byId("menuItemAll").setIcon(null);
            this._oView.byId("menuItemClosed").setIcon(null);
            this._oView.byId("menuItemOpen").setIcon("jd/ui/eid/asset/img/accept_16.png");
        },

        /**
         * Event handler for the 'Show closed' menu item for the Status column
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         * @private
         */
        _onStatusFilterClosed : function() {
            var oTable = this._oView.byId("evidencePackageTable");
            var oStatusColumn = this._oView.byId("statusColumn");
            oTable.getBinding().filter([new sap.ui.model.Filter("PackageStatusID", "EQ", "1")]);
            oStatusColumn.setFiltered(true);

            // Set icon
            this._oView.byId("menuItemAll").setIcon(null);
            this._oView.byId("menuItemClosed").setIcon("jd/ui/eid/asset/img/accept_16.png");
            this._oView.byId("menuItemOpen").setIcon(null);
        },

        /**
         * Event handler for the 'Show all' menu item for the Status column
         * 
         * @memberOf jd.ui.eid.view.main.shell.EvidencePackageList
         * @private
         */
        _onStatusFilterAll : function() {
            var oTable = this._oView.byId("evidencePackageTable");
            var oStatusColumn = this._oView.byId("statusColumn");
            oTable.getBinding().filter([]);
            oStatusColumn.setFiltered(false);

            // Set icon
            this._oView.byId("menuItemAll").setIcon("jd/ui/eid/asset/img/accept_16.png");
            this._oView.byId("menuItemClosed").setIcon(null);
            this._oView.byId("menuItemOpen").setIcon(null);
        },

        /**
         * Hook method called after the evidence package overlay has been closed. Refreshes the evidence package list if the view is visible.
         * 
         * @see #handleEvidencePackageSummaryOverlayHookAfter
         */
        handleEvidencePackageSummaryOverlayClosed : function() {
            $.sap.log.debug("Handling EvidencePackageOverlay::closed event", null, this._sViewName);
            if (this.isVisible()) {
                this.fetchEvidencePackageList();
            }
        },

        /**
         * Hook method called after the worksheet overlay has been closed. Refreshes the evidence package list if the view is visible.
         * 
         * @see #handleWorksheetOverlayClosedHookAfter
         */
        handleWorksheetOverlayClosed : function() {
            $.sap.log.debug("Handling WorksheetOverlay::closed event", null, this._sViewName);
            if (this.isVisible()) {
                this.fetchEvidencePackageList();
            }
        }

    }));
})();