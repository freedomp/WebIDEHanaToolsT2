(function() {
    "use strict";
    
    // mock time due to static data in the database
    window.FAKE_TODAY = function() {
    	return new Date(1410739200000); // Sep 2014
    };

    var $bootstrap = $("#jd-ui-eid-bootstrap");
    var sApp = $bootstrap.data("jdUiEidApp");
    var sEnv = $bootstrap.data("jdUiEidEnv");
    var bOpt = $bootstrap.data("jdUiEidOpt") == true;

    // Check app parameter against whitelist
    if ($.inArray(sApp, ["customizing", "main", "print", "test"]) == -1) {
        throw new Error("Application with name '" + sApp + "' is not valid.");
    }

    // Check env parameter against whitelist
    if ($.inArray(sEnv, ["dev", "test", "prod"]) == -1) {
        throw new Error("Environment of type '" + sEnv + "' is not valid.");
    }

    // Check for clickjacking attacks.
    // If we're not running in an iframe or if the app is the print app (which always runs in an iframe), we dislay the content.
    // Displaying the print application shouldn't be a security issue because there are no buttons or other actions which could be clicked by the
    // user.
    if (window.top === self || sApp === "print") {
        // We're good, so let's make the content visible
        document.documentElement.style.display = 'block';
    }
    // Otherwise, the document remains hidden (display: none in CSS)

    var bLess, bRequireAggregate, sModulePath;
    if (sEnv == "prod") {
        bLess = true;
        bRequireAggregate = false;
        sModulePath = "jd";
    } else {
        bLess = true;
        bRequireAggregate = false;
        sModulePath = "jd";
    }

    if (bOpt) {
        sModulePath = "target/jd";
        bLess = false;
    }

    jQuery.sap.registerModulePath("jd", sModulePath);
    $.sap.require("jd.ui.eid.jd-ui-eid-core");

    if (bOpt) {
        $.sap.require("jd.ui.eid.all");
    }

    if (bLess) {
        jd.ui.eid.require("sap.ui.core.plugin.LessSupport");
    }

    // Initialize runtime based on environment
    if (sApp == 'test') {
        $.sap.require("jd.ui.eid.test.Testsuite");
    } else {
        var elStylesheet;
        elStylesheet = document.createElement("link");
        elStylesheet.setAttribute("type", "text/css");
        elStylesheet.setAttribute("rel", (bLess ? "stylesheet/less" : "stylesheet"));
        elStylesheet.setAttribute("href", (bLess ? "jd/ui/eid/asset/less/application/" + sApp + ".less" : "target/jd/ui/eid/asset/css/application/"
                + sApp + ".css"));
        $("head")[0].appendChild(elStylesheet);

        // Start the application
        jd.ui.eid.require("jd.ui.eid.application.Application");
        jd.ui.eid.require("jd.ui.eid.application." + sApp + ".ApplicationParameters");
        var oApp = jd.ui.eid.application.Application.getInstance();
        oApp.launch(jd.ui.eid.application[sApp].ApplicationParameters);
    }

})();