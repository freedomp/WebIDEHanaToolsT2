jQuery.sap.declare("nw.epm.refapps.shop.util.formatter");

nw.epm.refapps.shop.util.formatter = {};

/**
 * Formatter for Reviewer Name - Returns Me for own review or user name for other reviews
 * 
 * @param {boolean}
 *            bIsReviewOfCurrentUser Indicates whether the review was created by the current user or not
 * @param {string}
 *            sUserName Name of the current user
 * @returns {string} Me if the review was created by the current user otherwise the user name
 * @public
 */
nw.epm.refapps.shop.util.formatter.formatMyReview = function(bIsReviewOfCurrentUser, sUserName) {
    return (bIsReviewOfCurrentUser) ? this.getModel("i18n").getResourceBundle().getText("xfld.me") : sUserName;
};

/**
 * Formatter for Helpful link - Returns concatenated string with Text and Helpful Count
 * 
 * @param {int}
 *            iHelpfulCount The number of helpful ratings
 * @returns {string} Helpful text and count
 * @public
 */
nw.epm.refapps.shop.util.formatter.formatHelpfulCount = function(iHelpfulCount) {
    return this.getModel().getProperty("/#Review/HelpfulForCurrentUser/@sap:label") + " (" + iHelpfulCount + ")";
};

/**
 * Formatter that negates a boolean value
 * 
 * @param {boolean}
 *            bValue A boolean value
 * @returns {boolean} The negation of the input parameter
 * @public
 */
nw.epm.refapps.shop.util.formatter.negateBoolean = function(bValue) {
    return !bValue;
};