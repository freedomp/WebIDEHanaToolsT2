(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.formatter.WarrantyClaimFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");

    /**
     * @class This formatter class provides methods for formatting Warranty Claims data
     * @static
     * @name jd.ui.eid.common.formatter.WarrantyClaimFormatter
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter = {};

    /**
     * Formatter of the Prime Part JDLinkActive Collection title
     * 
     * @param {string}
     *            sPrimePartDescription The Prime Part Description
     * @param {string}
     *            sPrimePartNumber The Prime Part Number
     * @returns {String} title of the Collection
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter.formatPrimePartCollectionJDLinkActiveTitle = function(sPrimePartDescription, sPrimePartNumber) {
        return jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_DETAILS_TBS_COLLECTION_JDLINK_ACTIVE', [sPrimePartDescription, sPrimePartNumber]);
    };

    /**
     * Formatter of the Prime Part Other Collection title
     * 
     * @param {string}
     *            sPrimePartDescription The Prime Part Description
     * @param {string}
     *            sPrimePartNumber The Prime Part Number
     * @returns {String} title of the Collection
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter.formatPrimePartCollectionOtherTitle = function(sPrimePartDescription, sPrimePartNumber) {
        return jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_DETAILS_TBS_COLLECTION_OTHER', [sPrimePartDescription, sPrimePartNumber]);
    };

    /**
     * Formatter of the Warranty Claim Summary-Panel title
     * 
     * @param {string}
     *            sWarrantyClaimNumber The Warranty Claim Number
     * @param {string}
     *            sPrimePartDescription The Prime Part Description
     * @param {string}
     *            sPrimePartNumber The Prime Part Number
     * @returns {String} title of the Panel
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter.formatWarrantyClaimSummaryPanelTitle = function(sWarrantyClaimNumber, sPrimePartDescription,
            sPrimePartNumber) {
        return jd.ui.eid.common.I18NHelper.getText('WARRANTY_CLAIM_DETAILS_GRP_PANEL_HEADER', [sWarrantyClaimNumber, sPrimePartDescription,
                sPrimePartNumber]);
    };

    /**
     * Formatter of the Prime Part Collection title
     * 
     * @param {int}
     *            iDTCID The DTC ID
     * @returns {String} DTC Code
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter.formatDTCIDToDTCCode = function(iDTCID) {
        var oDTC = jd.ui.eid.model.EidModel.TransformationHelper.getDTCHeaderForDTCIDFromEvidencePackageDetails(iDTCID);
        if (oDTC) {
            return oDTC.DTCCode;
        }
        return "";
    };

    /**
     * Formats the engine hour from failure for the vulcano chart.
     */
    jd.ui.eid.common.formatter.WarrantyClaimFormatter.formatEngineHourForVulcanoChart = function(sEngineHour) {
        return jd.ui.eid.common.I18NHelper.getNumberChoiceText(sEngineHour, "WARRANTY_CLAIM_VULCANO_CHART_TXT_FORMAT_ENGINE_HOUR_MULTIPLE",
                "WARRANTY_CLAIM_VULCANO_CHART_TXT_FORMAT_ENGINE_HOUR_SINGLE", "WARRANTY_CLAIM_VULCANO_CHART_TXT_FORMAT_ENGINE_HOUR_ZERO");
    };
})();