jQuery.sap.declare("nw.epm.refapps.products.manage.util.formatter");

nw.epm.refapps.products.manage.util.formatter = {
    _SERVICEURL : "/sap/opu/odata/sap/EPM_REF_APPS_PROD_MAN_SRV",

    // Forms the image URL for the image GUID specified.
    // sDraftId -- Product draft ID that the new image is uploaded to.
    // Returns the relative path of the image URL.
    formatImageURL : function(sId) {
        var sPath = "";
        if (sId && typeof sId === "string") {
            sPath = nw.epm.refapps.products.manage.util.formatter._SERVICEURL + "/ImageDrafts(guid'" + sId +
                    "')/$value";
        }
        return sPath;
    },

    // Gets the image upload URL for the product draft specified.
    // sDraftId -- Product draft ID that the new image is uploaded to.
    // Returns the relative path of the image upload path for the product draft specified.
    getImageUploadURL : function(sDraftId) {
        var sUploadPath = "";
        if (sDraftId && typeof sDraftId === "string") {
            sUploadPath = nw.epm.refapps.products.manage.util.formatter._SERVICEURL + "/ProductDrafts('" + sDraftId +
                    "')/Images";
        }
        return sUploadPath;
    }
};