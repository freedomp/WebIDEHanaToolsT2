(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.application.Application");

    var oApplication = null;

    // Module for DTC Blacklist
    module("jd.ui.eid.application.Application", {
        setup : function() {
            oApplication = new jd.ui.eid.application.Application();
        },
        teardown : function() {
            oApplication.destroy();
            oApplication = null;
        }
    });

    test("getInstance() should always return the same instance.", function() {
        var oApp1 = jd.ui.eid.application.Application.getInstance();
        var oApp2 = jd.ui.eid.application.Application.getInstance();
        equal(oApp1, oApp2);
    });

    test("_getUrlParameter() should return null if an invalid URL parameter name is provided.", function() {
        var sUrl = "http://eid.deere.com?myParam1=test&myParam2=test43";
        equal(oApplication._getUrlParameter("invalidParameter", sUrl), null);
    });

    test("_getUrlParameter() should return the value associated with the given parameter.", function() {
        var sUrl = "http://eid.deere.com?myParam1=test&myParam2=test43";
        equal(oApplication._getUrlParameter("myParam1", sUrl), "test");
        equal(oApplication._getUrlParameter("myParam2", sUrl), "test43");
    });

})();