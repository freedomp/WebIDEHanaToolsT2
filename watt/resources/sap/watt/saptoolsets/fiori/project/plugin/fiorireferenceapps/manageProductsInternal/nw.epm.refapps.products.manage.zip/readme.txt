SAP internal development: SAP Fiori Reference Application to create and maintain product entities for the EPM model (master-detail application, draft pattern, ...)

For documentation on Fiori Reference Apps, see
https://wiki.wdf.sap.corp/wiki/display/refapps/Fiori+Reference+Applications+Home