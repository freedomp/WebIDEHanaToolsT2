(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.FilterArea");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");

    var oFilterArea = null;

    module("jd.ui.eid.control.FilterArea", {
        setup : function() {
            oFilterArea = new jd.ui.eid.control.FilterArea();
        },
        teardown : function() {
            oFilterArea = null;
        }
    });

    test("clear() should call the _clear method of all items in the item aggregation.", function() {
        var oFilterItemA = new jd.ui.eid.control.FilterItem();
        var oFilterItemASpy = sinon.spy(oFilterItemA, "_clear");
        var oFilterItemB = new jd.ui.eid.control.FilterItem();
        var oFilterItemBSpy = sinon.spy(oFilterItemB, "_clear");

        // Assign filter items to filter area
        oFilterArea.addItem(oFilterItemA);
        oFilterArea.addItem(oFilterItemB);

        // Initial assertions
        ok(!oFilterItemASpy.called);
        ok(!oFilterItemBSpy.called);

        // Execute the business logic
        oFilterArea.clear();

        // Final assertions
        ok(oFilterItemASpy.calledOnce);
        ok(oFilterItemBSpy.calledOnce);
    });

    test(
            "clear() should not trigger a call of the fireCleared method of any item in the item aggregation.",
            function() {
                var oFilterItemA = new jd.ui.eid.control.FilterItem();
                var oFilterItemASpy = sinon.spy(oFilterItemA, "fireCleared");
                var oFilterItemB = new jd.ui.eid.control.FilterItem();
                var oFilterItemBSpy = sinon.spy(oFilterItemB, "fireCleared");

                // Assign filter items to filter area
                oFilterArea.addItem(oFilterItemA);
                oFilterArea.addItem(oFilterItemB);

                // Initial assertions
                ok(!oFilterItemASpy.called);
                ok(!oFilterItemBSpy.called);

                // Execute the business logic
                oFilterArea.clear();

                // Final assertions
                ok(!oFilterItemASpy.called);
                ok(!oFilterItemBSpy.called);
            });

})();