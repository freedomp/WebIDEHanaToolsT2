(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.application.main.ApplicationParameters");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    var oDashboardController = null;
    var oDashboardView = null;

    // Module for DTC Blacklist
    module("jd.ui.eid.view.main.shell.Dashboard.view", {
        setup : function() {
            var oApp = jd.ui.eid.application.Application.getInstance();
            oApp.setParameters(jd.ui.eid.application.main.ApplicationParameters);
            oApp._initModels();

            oDashboardView = new jd.ui.eid.xmlview("jd.ui.eid.view.main.shell.Dashboard");
            oDashboardController = oDashboardView.getController();
        },
        teardown : function() {
            // oShell.destroy();
            oDashboardView = null;
            oDashboardController = null;
            setTimeout(function() {
                $("#content").html("");
            }, 1000);

        }
    });

    test("check availability of UI elements", function() {
        ok(oDashboardView.byId('chartButton') != null);
        ok(oDashboardView.byId('tableButton') != null);
        ok(oDashboardView.byId('DTCKPISelection') != null);
        ok(oDashboardView.byId('dashboardSearchField') != null);
        ok(oDashboardView.byId('trendDateRangeButton') != null);
    });

    test("handleSwitchDTCListVisible() shall set the column chart invisible, search field becomes visible", function() {
        oDashboardController.handleSwitchDTCListVisible();
        equal(oDashboardView.byId('DTCListTableArea').getVisible(), true);
        equal(oDashboardView.byId('dashboardSearchField').getVisible(), true);
        equal(oDashboardView.byId('DTCTopChartArea').getVisible(), false);
    });

    test("handleSwitchColumnChartVisible() shall set Top 10 column chart Visible, the DTC List table and search field will be invisible", function() {
        oDashboardController.handleSwitchColumnChartVisible();
        equal(oDashboardView.byId('DTCListTableArea').getVisible(), false);
        equal(oDashboardView.byId('dashboardSearchField').getVisible(), false);
        equal(oDashboardView.byId('DTCTopChartArea').getVisible(), true);
    });

    test("handleKPISelectionChange() selects KPI form dropdow for KPI, label of KPI column in DTC List table updated", function() {
        var sKPIName = "Rate Per Engine Hours";
        oDashboardController.handleSwitchDTCListVisible();
        // Fire select even
        var oKPICombobox = oDashboardView.byId("DTCKPISelection");
        var oItem1 = new sap.ui.core.ListItem("item1", {
            key : "dummykey",
            text : "dummyName"
        });
        var oItem2 = new sap.ui.core.ListItem("item2", {
            key : "KPI245",
            text : sKPIName
        });

        oKPICombobox.addItem(oItem1);
        oKPICombobox.addItem(oItem2);
        oKPICombobox.setValue(sKPIName);
        oKPICombobox.setSelectedKey(oItem2.getKey());
        oKPICombobox.fireChange({
            newValue : sKPIName,
            selectedItem : oItem2
        });

        equal(oDashboardView.byId('columnLabelKPIName').getText(), sKPIName);
        equal(oDashboardView.byId('DTCListTable').getVisibleRowCount(), oDashboardController._iDTCListTableExpandedRowCount);
        equal(oDashboardView.byId('DTCColumnChart').getHeight(), oDashboardController._sCsColumnChartHeightExpanded);
    });

})();