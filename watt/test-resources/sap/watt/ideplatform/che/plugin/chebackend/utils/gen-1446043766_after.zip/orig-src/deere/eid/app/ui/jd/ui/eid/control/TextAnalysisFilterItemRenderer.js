(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TextAnalysisFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * @class Default renderer for control jd.ui.eid.control.TextAnalysisFilterItemRenderer
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     * @name jd.ui.eid.control.TextAnalysisFilterItemRenderer
     */
    jd.ui.eid.control.TextAnalysisFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.TextAnalysisFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     */
    jd.ui.eid.control.TextAnalysisFilterItemRenderer._renderContent = function(oRm, oControl) {

        //Render listbox
        oRm.renderControl(oControl.getAggregation("_listBox"));

        //Render sub listbox
        oRm.write("<div");
        oRm.addClass("jdUiEidTextAnalysisSubList");
        oRm.writeClasses();
        oRm.write(">");

        //Check whether a _listBox item was selected
        if (oControl.getAggregation("_listBox").getSelectedIndex() > -1) {
            //Sub listbox: Header Start
            oRm.write("<div");
            oRm.addClass("jdUiEidTextAnalysisSubListHeader");
            oRm.writeClasses();
            oRm.write(">");

            oRm.write("<div");
            oRm.addClass("jdUiEidTextAnalysisSubListCaption");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getSubListCaption());
            oRm.write("</div>");

            oRm.write("<div");
            oRm.addClass("jdUiEidTextAnalysisSubListCounter");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oControl.getSubListCounter());
            oRm.write("</div>");

            oRm.write("</div>");
            //Sub listbox: Header End

            //Content of Sub listbox        
            oRm.renderControl(oControl.getAggregation("_subListBox"));
        }

        oRm.write("</div>");
    };

})();