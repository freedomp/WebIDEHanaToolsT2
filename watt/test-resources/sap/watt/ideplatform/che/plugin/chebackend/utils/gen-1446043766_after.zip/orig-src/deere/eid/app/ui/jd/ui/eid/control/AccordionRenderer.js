(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.AccordionRenderer");

    /**
     * Renderer for the <i>jd.ui.eid.control.Accordion</i> control.
     */
    jd.ui.eid.control.AccordionRenderer = {};

    jd.ui.eid.control.AccordionRenderer.render = function(oRm, oControl) {
        oRm.write("<div");
        oRm.writeControlData(oControl);
        oRm.addClass("jdUiEidAccordion");
        oRm.writeClasses();
        oRm.write(">");
        this.renderSections(oRm, oControl);
        oRm.write("</div>");
    };

    /**
     * Renders all sections of the Accordion. The template control is inserted as the 'content' of the open section.
     */
    jd.ui.eid.control.AccordionRenderer.renderSections = function(oRm, oControl) {

        var aSections = oControl.getSections();

        // No sections? Show the 'no data text'
        if (aSections.length == 0) {
            var oNoDataLabel = new sap.ui.commons.Label({
                text : oControl.getNoDataText()
            });
            oRm.write("<div");
            oRm.addClass("jdUiEidAccordionNoData");
            oRm.writeClasses();
            oRm.write(">");
            oRm.renderControl(oNoDataLabel);
            oRm.write("</div>");
            return;
        }

        // If there are section, and _openSectionId is still undefined (ie, user hasn't opened/closed any sections), then set the
        // 'defaultOpenSectionIndex' section to open.
        var iDefaultOpenIndex = oControl.getDefaultOpenSectionIndex();
        if (aSections[iDefaultOpenIndex] && (oControl.get_openSectionId() == undefined)) {
            oControl.set_openSectionId(aSections[iDefaultOpenIndex].getSectionId());
        }

        // Render the sections
        $.each(aSections, function(i, oSection) {
            var sTitle = oSection.getTitle();

            // jdUiEidAccordionSection
            oRm.write("<div");
            oRm.writeElementData(oSection);
            oRm.addClass("jdUiEidAccordionSection");
            oRm.writeClasses();
            oRm.write(">");

            // jdUiEidAccordionSection -- jdUiEidAccordionSectionHeader
            oRm.write("<div");
            oRm.addClass("jdUiEidAccordionSectionHeader");
            oRm.writeClasses();
            if (oSection.getSectionId() == oControl.get_openSectionId()) {
                oRm.write(" title='" + oControl.getCollapseTooltip() + "'");
            } else {
                oRm.write(" title='" + oControl.getExpandTooltip() + "'");
            }
            oRm.write(">");

            oRm.write("<div");
            oRm.addClass("jdUiEidAccordionSectionHeaderTitle");
            oRm.writeClasses();
            oRm.write(">");
            oRm.write(sTitle);
            oRm.write("</div>");

            // Header buttons
            var aButtons = oSection.getActions();
            if (aButtons.length > 0) {
                oRm.write("<div");
                oRm.addClass("jdUiEidAccordionSectionHeaderActions");
                oRm.writeClasses();
                oRm.write(">");
                $.each(aButtons, function(x, oButton) {
                    oRm.renderControl(oButton);
                });
                oRm.write("</div>");
            }

            oRm.write("</div>");

            // jdUiEidAccordionSection -- jdUiEidAccordionSectionContent
            if (oSection.getSectionId() == oControl.get_openSectionId()) {
                oControl._setItemTemplateContext(oSection.getBindingContext());
                oControl.fireOnBeforeSectionOpening({
                    template : oControl.getItemTemplate()
                });
                oRm.write("<div");
                oRm.addClass("jdUiEidAccordionSectionContent");
                oRm.writeClasses();
                oRm.write(">");
                oRm.renderControl(oControl.getItemTemplate());
                oRm.write("</div>");
            }

            oRm.write("</div>"); // jdUiEidAccordionSection ends here

        });
    };

})();