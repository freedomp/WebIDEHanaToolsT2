(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.ListBoxFilterItem");

    var oFilterItem = null;
    var oModel = null;
    var oData = {
        emptySelectedKeys : [],
        selectedKeys : [1, 2],
        defaultKeys : [2],
        objectKeys : [{
            surrogateKey : "1",
            additional : "one"
        }, {
            surrogateKey : "2",
            additional : "two"
        }, {
            surrogateKey : "3",
            additional : "three"
        }],
        booleanKeyTrue : true,
        booleanKeyFalse : false
    };

    module("jd.ui.eid.control.ListBoxFilterItem", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(jQuery.extend(true, {}, oData));
            oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
                items : [new sap.ui.core.Item({
                    key : 1,
                    text : "Item 1"
                }), new sap.ui.core.Item({
                    key : 2,
                    text : "Item 2"
                }), new sap.ui.core.Item({
                    key : 3,
                    text : "Item 3"
                })]
            });
            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    test("_clear() should set the selection property to an empty array.", function() {
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Initial assertions
        deepEqual(oFilterItem.getSelection(), oData.selectedKeys);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertions
        deepEqual(oFilterItem.getSelection(), []);
    });

    test("_clear() should not call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertions
        ok(!spy.called);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertions
        ok(!spy.called);
    });

    test("_clear() should return true if the selection is not empty.", function() {
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Initial assertions
        deepEqual(oFilterItem.getSelection(), oData.selectedKeys);

        // Execute the business logic
        ok(oFilterItem._clear() === true);
    });

    test("_clear() should return false if the selection is empty.", function() {
        oFilterItem.bindProperty('selection', '/emptySelectedKeys');

        // Initial assertions
        deepEqual(oFilterItem.getSelection(), oData.emptySelectedKeys);

        // Execute the business logic
        ok(oFilterItem._clear() === false);
    });

    test("_clear() should update the booleanKey property to the value of the first item.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setEnableBooleanKey(true);
        oFilterItem.setBooleanKey(true);

        // pre-check
        ok(oFilterItem.getBooleanKey() === true);

        ok(oFilterItem._clear() === true); // Should return true of cleared

        ok(oFilterItem.getBooleanKey() === false);
    });

    test("_clear() should update the selectedKey property to empty string.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setSelectedKey("0");

        // pre-check
        ok(oFilterItem.getSelectedKey() === "0");

        ok(oFilterItem._clear() === true); // Should return true of cleared

        ok(oFilterItem.getSelectedKey() === "");
    });

    test("_reset() should set the selection property to the defaultSelection.", function() {
        oFilterItem.bindProperty('defaultSelection', '/defaultKeys');
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Initial assertions
        deepEqual(oFilterItem.getDefaultSelection(), oData.defaultKeys);
        deepEqual(oFilterItem.getSelection(), oData.selectedKeys);

        // Execute the business logic
        oFilterItem._reset();

        // Final assertions
        deepEqual(oFilterItem.getSelection(), oData.defaultKeys);
    });

    test("bindProperty() for the selection property should not call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertions
        ok(!spy.called);

        // Execute logic
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Final assertions
        ok(!spy.called);
    });

    test("_handleSelect() should call fireValueChanged().", function() {
        // When the list box changes its value, the select event is fired which is handled
        // by _handleSelect. We will call this method directly in this test to simulate
        // this.

        // Prepare control
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Prepare event
        var oEvent = new sap.ui.base.Event('select', null, {
            selectedIndices : [0]
        });

        // Simulate event
        oFilterItem._handleSelect(oEvent);

        // Final assertions
        ok(spy.calledOnce);
    });

    test("_getKeysFromIndices() should return an empty array when an empty array of indices is provided.", function() {
        var aKeys = oFilterItem._getKeysFromIndices([]);
        deepEqual(aKeys, []);
    });

    test("_getKeysFromIndices() should return an array on indices associated with the given keys.", function() {
        // Prepare data
        var aIndices = [1, 2];
        var aExpKeys = [];
        $.each(aIndices, function(i, iIndex) {
            aExpKeys.push(oFilterItem.getItems()[iIndex].getKey());
        });

        // Execute logic
        var aActKeys = oFilterItem._getKeysFromIndices(aIndices);

        // Assertions
        deepEqual(aActKeys, aExpKeys);
    });

    test("_getKeysFromIndices() should ignore indices that are out of bounds.", function() {
        // Prepare data
        var aIndices = [1, 9999];
        var aExpKeys = [oFilterItem.getItems()[1].getKey()];

        // Execute logic
        var aActKeys = oFilterItem._getKeysFromIndices(aIndices);

        // Assertions
        deepEqual(aActKeys, aExpKeys);
    });

    test("getSelectedKey() should return null if the useSelectedKey property is set to false.", function() {
        oFilterItem.setUseSelectedKey(false);
        equal(oFilterItem.getSelectedKey(), null);
    });

    test("getSelectedKey() should return the selected key if the useSelectedKey property is set to true.", function() {
        oFilterItem.setUseSelectedKey(true);
        var sExpKey = 1;
        oFilterItem.setSelectedKey(sExpKey);
        equal(oFilterItem.getSelectedKey(), sExpKey);
    });

    test("getSelection() should return the value of the selectedKey property in an array if the useSelectedKey property is set to true.", function() {
        oFilterItem.setUseSelectedKey(true);
        var sExpKey = 1;
        oFilterItem.setSelectedKey(sExpKey);
        deepEqual(oFilterItem.getSelection(), [sExpKey]);
    });

    test(
            "setSelection() should extract the keys from an array of objects based on the objectSelectionKey property when the enableObjectSelection property is set to true.",
            function() {
                oFilterItem.bindAggregation("items", "/objectKeys", new sap.ui.core.Item({
                    key : "{surrogateKey}",
                    text : "{surrogateKey}"
                }));
                oFilterItem.setEnableObjectSelection(true);
                oFilterItem.setObjectSelectionKey("surrogateKey");

                oFilterItem.setSelection([oData.objectKeys[1]]);
                deepEqual(oFilterItem.getAggregation("_listBox").getSelectedKeys(), [oData.objectKeys[1].surrogateKey]);
            });

    test("getBooleanKey() should return false if the booleanKey is false and boolean keys are enabled.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setEnableBooleanKey(true);
        oFilterItem.setBooleanKey(false);
        ok(oFilterItem.getBooleanKey() === false);
    });

    test("getBooleanKey() should return true if the booleanKey is true and boolean keys are enabled.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setEnableBooleanKey(true);
        oFilterItem.setBooleanKey(true);
        ok(oFilterItem.getBooleanKey() === true);
    });

    test("setBooleanKey() should select the item with string key '1' when passed boolean true and enabledBooleanKey is true.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setEnableBooleanKey(true);
        oFilterItem.setBooleanKey(true);

        // True maps to key '1'
        deepEqual(oFilterItem.getAggregation("_listBox").getSelectedKeys(), ['1']);
    });

    test("setBooleanKey() should select the item with string key '0' when passed boolean false and enabledBooleanKey is true.", function() {
        oFilterItem = null;
        oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
            items : [new sap.ui.core.Item({
                key : 0,
                text : "Item 1"
            }), new sap.ui.core.Item({
                key : 1,
                text : "Item 2"
            })]
        });
        oFilterItem.setUseSelectedKey(true);
        oFilterItem.setEnableBooleanKey(true);
        oFilterItem.setBooleanKey(false);

        // True maps to key '1'
        deepEqual(oFilterItem.getAggregation("_listBox").getSelectedKeys(), ['0']);
    });

    test(
            "_handleSelect() should set the booleanKey property to boolean false if enableBooleanKey is true and the selected list item has string key '0'",
            function() {
                oFilterItem = null;
                oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
                    items : [new sap.ui.core.Item({
                        key : 0,
                        text : "Item 1"
                    }), new sap.ui.core.Item({
                        key : 1,
                        text : "Item 2"
                    })]
                });
                oFilterItem.setUseSelectedKey(true);
                oFilterItem.setEnableBooleanKey(true);

                // Prepare event
                var oEvent = new sap.ui.base.Event('select', oFilterItem, {
                    selectedIndices : [0]
                });

                oFilterItem._handleSelect(oEvent);

                ok(oFilterItem.getProperty('booleanKey') === false);
            });

    test("_handleSelect() should set the boolean property to boolean true if enableBooleanKey is true and the selected list item has string key '1'",
            function() {
                oFilterItem = null;
                oFilterItem = new jd.ui.eid.control.ListBoxFilterItem({
                    items : [new sap.ui.core.Item({
                        key : 0,
                        text : "Item 1"
                    }), new sap.ui.core.Item({
                        key : 1,
                        text : "Item 2"
                    })]
                });
                oFilterItem.setUseSelectedKey(true);
                oFilterItem.setEnableBooleanKey(true);

                // Prepare event
                var oEvent = new sap.ui.base.Event('select', oFilterItem, {
                    selectedIndices : [1]
                });

                oFilterItem._handleSelect(oEvent);

                ok(oFilterItem.getProperty('booleanKey') === true);
            });

})();