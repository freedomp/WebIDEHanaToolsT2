(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");

    var oControl = null;
    var oDataLossManager = null;

    module("jd.ui.eid.common.DataLossManager.prototype", {
        setup : function() {
            oControl = new sap.ui.commons.layout.VerticalLayout();
            oControl.placeAt("content");
            oDataLossManager = new jd.ui.eid.common.DataLossManager();
        },
        teardown : function() {
            oControl.destroy();
            oControl = null;
            oDataLossManager.destroy();
            oDataLossManager = null;
            setTimeout(function() {
                $(sap.ui.getCore().getStaticAreaRef()).html("");
            }, 1000);
        }
    });

    test("_getControl() should return the control of the control association.", function() {
        oDataLossManager.setControl(oControl);
        equal(oDataLossManager._getControl(), oControl);
    });

    test("isDirty() should return true if the dirty property is set to true.", function() {
        oDataLossManager.setDirty(true);
        ok(oDataLossManager.isDirty());
    });

    test("isDirty() should return false if the dirty property is set to false.", function() {
        oDataLossManager.setDirty(false);
        ok(!oDataLossManager.isDirty());
    });

    test("isDirty() should return true if the dirty property is set to false but the property of a child DLM is set to true.", function() {
        oDataLossManager.setDirty(false);
        ok(!oDataLossManager.getDirty());

        var oChildDLM = new jd.ui.eid.common.DataLossManager({
            dirty : true
        });
        ok(oChildDLM.getDirty());

        oDataLossManager.addChild(oChildDLM);
        ok(oDataLossManager.isDirty());
    });

    test("setControl() should attach the DLM instance to the custom data of the control.", function() {
        oDataLossManager.setControl(oControl);
        equal(oControl.data(oDataLossManager._CTRL_CUSTOM_DATA_KEY), oDataLossManager);
    });

    test("getSaveHandler() should return the function passed to setSaveHandler().", function() {
        var spy = sinon.spy();
        oDataLossManager.setSaveHandler(spy);
        deepEqual(spy, oDataLossManager.getSaveHandler());
    });

    test("getNavigationHandler() should return the function passed to setNavigationHandler().", function() {
        var spy = sinon.spy();
        oDataLossManager.setNavigationHandler(spy);
        deepEqual(spy, oDataLossManager.getNavigationHandler());
    });

    test("getCancelHandler() should return the function passed to setCancelHandler().", function() {
        var spy = sinon.spy();
        oDataLossManager.setCancelHandler(spy);
        deepEqual(spy, oDataLossManager.getCancelHandler());
    });

    test("getBeforeNotificationHandler() should return the function passed to setBeforeNotificationHandler().", function() {
        var spy = sinon.spy();
        oDataLossManager.setBeforeNotificationHandler(spy);
        deepEqual(spy, oDataLossManager.getBeforeNotificationHandler());
    });

    test("reset() should set the dirty property to false.", function() {
        oDataLossManager.setDirty(true);

        oDataLossManager.reset();

        ok(!oDataLossManager.getDirty());
    });

    test("reset() should call reset() on child DLMs.", function() {
        var oChildDLM = new jd.ui.eid.common.DataLossManager();
        oDataLossManager.addChild(oChildDLM);
        var spy = sinon.spy(oChildDLM, "reset");

        ok(!spy.called);
        oDataLossManager.reset();
        ok(spy.called);
    });

    test("reset() should clear the messages aggregation.", function() {
        var sText = "Lorem Ipsum";
        var oMessage = new sap.ui.core.Message({
            text : sText
        });
        oDataLossManager.addMessage(oMessage);
        ok(oDataLossManager.getMessages().length > 0);

        oDataLossManager.reset();

        ok(oDataLossManager.getMessages().length == 0);
    });

    test("getConcatenatedMessages() should return null if no messages have been assigned.", function() {
        var sMessages = oDataLossManager.getConcatenatedMessages();
        equal(null, sMessages);
    });

    test("getConcatenatedMessages() should return a string containing the message if only one message has been assigned.", function() {
        var sText = "Lorem Ipsum";
        var oMessage = new sap.ui.core.Message({
            text : sText
        });
        oDataLossManager.addMessage(oMessage);

        var sMessages = oDataLossManager.getConcatenatedMessages();
        ok(sMessages.indexOf(sText) >= 0);
    });

    test("getConcatenatedMessages() should return a string containing all messages if more than one message has been assigned.", function() {
        var sText = "Lorem Ipsum";
        var oMessage = new sap.ui.core.Message({
            text : sText
        });
        oDataLossManager.addMessage(oMessage);
        var sText2 = "Dolor sit amet";
        var oMessage2 = new sap.ui.core.Message({
            text : sText2
        });
        oDataLossManager.addMessage(oMessage2);

        var sMessages = oDataLossManager.getConcatenatedMessages();
        ok(sMessages.indexOf(sText) >= 0);
        ok(sMessages.indexOf(sText2) >= 0);
    });

    test("addSoleMessage() should remove all previously assigned messages and make the message passed as a parameter the sole one.", function() {
        var sText = "Lorem Ipsum";
        var oMessage = new sap.ui.core.Message({
            text : sText
        });
        oDataLossManager.addMessage(oMessage);
        ok(oDataLossManager.getMessages().length == 1);

        var sSoleText = "Dolor sit amet";
        var oSoleMessage = new sap.ui.core.Message({
            text : sSoleText
        });
        oDataLossManager.addSoleMessage(oSoleMessage);

        ok(oDataLossManager.getMessages().length == 1);
        var oActSoleMessage = oDataLossManager.getMessages()[0];
        deepEqual(oActSoleMessage, oSoleMessage);
    });

    test("notifyOrNavigate() should fire the dataLossPending event via the event bus if the DLM is dirty.", function() {
        // Register handlers
        var spy = sinon.spy();
        var oEventBus = sap.ui.getCore().getEventBus();
        oEventBus.subscribe("DataLossManager", "dataLossPending", spy);

        // Prepare state
        oDataLossManager.setDirty(true);
        ok(oDataLossManager.isDirty());

        // Call logic
        oDataLossManager.notifyOrNavigate();

        // Assertions
        ok(spy.calledOnce);
    });

    test("notifyOrNavigate() should call the beforeNotification handler if the DLM is dirty.", function() {
        // Register handlers
        var spy = sinon.spy();

        // Prepare state
        oDataLossManager.setDirty(true);
        oDataLossManager.setBeforeNotificationHandler(spy);
        ok(oDataLossManager.isDirty());

        // Call logic
        oDataLossManager.notifyOrNavigate();

        // Assertions
        ok(spy.calledOnce);
    });

    test(
            "notifyOrNavigate() should call the beforeNotification handler before the dataLossPending event is fired via the event bus if the DLM is dirty.",
            function() {
                // Register handlers
                var spy = sinon.spy();
                var oEventBus = sap.ui.getCore().getEventBus();
                oEventBus.subscribe("DataLossManager", "dataLossPending", spy);
                var fnBeforeNofication = function() {
                    ok(!spy.called);
                };

                // Prepare state
                oDataLossManager.setDirty(true);
                oDataLossManager.setBeforeNotificationHandler(fnBeforeNofication);
                ok(oDataLossManager.isDirty());

                // Call logic
                oDataLossManager.notifyOrNavigate();

                // Assertions
                ok(spy.calledOnce);
            });

    test("notifyOrNavigate() should not call the navigation handler if the DLM is dirty.", function() {
        // Register handlers
        var spy = sinon.spy();
        oDataLossManager.setNavigationHandler(spy);

        // Prepare state
        oDataLossManager.setDirty(true);
        ok(oDataLossManager.isDirty());

        // Call logic
        oDataLossManager.notifyOrNavigate();

        // Assertions
        ok(!spy.called);
    });

    test("notifyOrNavigate() should note fire the dataLossPending event via the event bus if the DLM is clean.", function() {
        // Register handlers
        var spy = sinon.spy();
        var oEventBus = sap.ui.getCore().getEventBus();
        oEventBus.subscribe("DataLossManager", "dataLossPending", spy);

        // Prepare state
        oDataLossManager.setDirty(false);
        ok(!oDataLossManager.isDirty());

        // Call logic
        oDataLossManager.notifyOrNavigate();

        // Assertions
        ok(!spy.called);
    });

    test("notifyOrNavigate() should call the navigation handler if the DLM is clean.", function() {
        // Register handlers
        var spy = sinon.spy();
        oDataLossManager.setNavigationHandler(spy);

        // Prepare state
        oDataLossManager.setDirty(false);
        ok(!oDataLossManager.isDirty());

        // Call logic
        oDataLossManager.notifyOrNavigate();

        // Assertions
        ok(spy.calledOnce);
    });

    test("handleUserDecision() should invoke the save handler and subsequently the navigation handler if the choice is SaveAndContinue.", function() {
        // Register handlers
        var spy = sinon.spy();
        var fnSaveHandler = function(fnNavigationHandler) {
            spy();
            fnNavigationHandler();
        };
        oDataLossManager.setNavigationHandler(spy);
        oDataLossManager.setSaveHandler(fnSaveHandler);

        // Call logic
        oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.SaveAndContinue);

        // Assertions
        ok(spy.calledTwice);
    });

    test("handleUserDecision() should invoke the navigation handler if the choice is SaveAndContinue and no save handler is provided.", function() {
        // Register handlers
        var spy = sinon.spy();
        oDataLossManager.setNavigationHandler(spy);

        // Call logic
        oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.SaveAndContinue);

        // Assertions
        ok(spy.calledOnce);
    });

    test("handleUserDecision() should not invoke the save handler but the navigation handler if the choice is ContinueWithoutSaving.", function() {
        // Register handlers
        var spyNavigation = sinon.spy();
        oDataLossManager.setNavigationHandler(spyNavigation);
        var spySave = sinon.spy();
        oDataLossManager.setSaveHandler(spySave);

        // Call logic
        oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.ContinueWithoutSaving);

        // Assertions
        ok(spyNavigation.calledOnce);
        ok(!spySave.called);
    });

    test("handleUserDecision() should invoke the cancel handler if the choice is Cancel.", function() {
        // Register handlers
        var spy = sinon.spy();
        oDataLossManager.setCancelHandler(spy);

        // Call logic
        oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.Cancel);

        // Assertions
        ok(spy.called);
    });

    test("handleUserDecision() should not invoke the save handler nor the navigation handler if the choice is Cancel.", function() {
        // Register handlers
        var spyNavigation = sinon.spy();
        oDataLossManager.setNavigationHandler(spyNavigation);
        var spySave = sinon.spy();
        oDataLossManager.setSaveHandler(spySave);

        // Call logic
        oDataLossManager.handleUserDecision(jd.ui.eid.common.DataLossManager.UserDecision.Cancel);

        // Assertions
        ok(!spyNavigation.called);
        ok(!spySave.called);
    });

    /** Static Methods */

    module("jd.ui.eid.common.DataLossManager", {
        setup : function() {
            oControl = new sap.ui.commons.layout.VerticalLayout();
            oControl.placeAt("content");
            oDataLossManager = new jd.ui.eid.common.DataLossManager();
        },
        teardown : function() {
            oControl.destroy();
            oControl = null;
            oDataLossManager.destroy();
            oDataLossManager = null;
        }
    });

    test("getInstanceForControl() should return the DLM instance of the control passed as a parameter if it has a DLM attached to its custom data.",
            function() {
                oDataLossManager.setControl(oControl);
                var oDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oControl);
                equal(oDLM, oDataLossManager);
            });

    test("getInstanceForControl() should return the root instance if the control doesn't have a DLM attached to its custom data.", function() {
        var oDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oControl);
        equal(oDLM, jd.ui.eid.common.DataLossManager.getRootInstance());
    });

    test(
            "getInstanceForControl() should return the DLM instance of the immediate parent control of the control passed as a parameter if that control has a DLM attached to its custom data.",
            function() {
                var oChildControl = new sap.ui.commons.TextView();
                oControl.addContent(oChildControl);
                oDataLossManager.setControl(oControl);

                var oDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oChildControl);
                equal(oDLM, oDataLossManager);
            });

    test(
            "getInstanceForControl() should return the DLM instance of a distant parent control of the control passed as a parameter if that control has a DLM attached to its custom data.",
            function() {
                var oLeaf = new sap.ui.commons.TextView();
                var oChildControl = new sap.ui.commons.layout.VerticalLayout({
                    content : oLeaf
                });
                oControl.addContent(oChildControl);
                oDataLossManager.setControl(oControl);

                var oDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oLeaf);
                equal(oDLM, oDataLossManager);
            });

    test("getRootInstance() should return a DLM instance.", function() {
        ok(jd.ui.eid.common.DataLossManager.getRootInstance() instanceof jd.ui.eid.common.DataLossManager);
    });

    test("getRootInstance() should always return the same instance.", function() {
        equal(jd.ui.eid.common.DataLossManager.getRootInstance(), jd.ui.eid.common.DataLossManager.getRootInstance());
    });

    test("getImmediateInstanceForControl() should return null if the control passed as a parameter does not have a DLM atached to its custom data.",
            function() {
                equal(null, jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl(oControl));
            });

    test("getImmediateInstanceForControl() should return null if null is passed as a parameter.", function() {
        equal(null, jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl(null));
    });

    test("getImmediateInstanceForControl() should return the DLM instance attached to the control passed as a parameter.", function() {
        oDataLossManager.setControl(oControl);
        equal(oDataLossManager, jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl(oControl));
    });

    test("createDataLossContextForControl() should attach a DLM instance to the control's custom data.", function() {
        equal(oControl.data(oDataLossManager._CTRL_CUSTOM_DATA_KEY), null);
        jd.ui.eid.common.DataLossManager.createDataLossContextForControl(oControl);
        ok(oControl.data(oDataLossManager._CTRL_CUSTOM_DATA_KEY) instanceof jd.ui.eid.common.DataLossManager);
    });

    test("createDataLossContextForControl() should assign the new DLM instance as a child of the parent DLM instance.", function() {
        var oParentDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oControl);
        var iChildrenCount = oParentDLM.getChildren().length;

        jd.ui.eid.common.DataLossManager.createDataLossContextForControl(oControl);

        equal(iChildrenCount + 1, oParentDLM.getChildren().length);
    });

    test(
            "createDataLossContextForControl() should return a new DLM instance whose parent DLM is the one found for the control passed as a parameter.",
            function() {
                var oParentDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oControl);
                var oDLM = jd.ui.eid.common.DataLossManager.createDataLossContextForControl(oControl);

                equal(oDLM.getParent(), oParentDLM);
            });

})();