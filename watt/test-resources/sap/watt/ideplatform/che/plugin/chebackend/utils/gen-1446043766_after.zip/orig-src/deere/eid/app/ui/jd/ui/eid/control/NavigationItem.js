(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.NavigationItem");
    jd.ui.eid.require("sap.ui.core.Item");

    /**
     * Constructor for a new NavigationItem.
     * 
     * Accepts an object literal <code>mSettings</code> that defines initial property values, aggregated and associated objects as well as event
     * handlers.
     * 
     * If the name of a setting is ambiguous (e.g. a property has the same name as an event), then the framework assumes property, aggregation,
     * association, event in that order. To override this automatic resolution, one of the prefixes "aggregation:", "association:" or "event:" can be
     * added to the name of the setting (such a prefixed name must be enclosed in single or double quotes).
     * 
     * ========= This control has been copied from the standard definition for jd.ui.eid.control.NavigationItem (from UI5 version 1.16.5) to ensure
     * that future upgrades the installed UI5 version do not affect the behaviour of the custom navigation bar (jd.ui.eid.control.NavigationBar)
     * =========
     * 
     * The supported settings are:
     * <ul>
     * <li>Properties
     * <ul>
     * <li>{@link #getVisible visible} : boolean (default: true)</li>
     * <li>{@link #getHref href} : sap.ui.core.URI</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>{@link #getSubItems subItems} : jd.ui.eid.control.NavigationItem[]</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * </ul>
     * </li>
     * </ul>
     * 
     * 
     * In addition, all settings applicable to the base type {@link sap.ui.core.Item#constructor sap.ui.core.Item} can be used as well.
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class Is the item to be used within the NavigationBar
     * @extends sap.ui.core.Item
     * 
     * 
     * @version 1.16.5
     * 
     * @constructor
     * @public
     * @name jd.ui.eid.control.NavigationItem
     */
    sap.ui.core.Item.extend("jd.ui.eid.control.NavigationItem", {
        metadata : {

            // ---- object ----

            // ---- control specific ----
            library : "sap.ui.ux3",
            properties : {
                "visible" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                },
                "href" : {
                    type : "sap.ui.core.URI",
                    group : "Behavior",
                    defaultValue : null
                }
            },
            defaultAggregation : "subItems",
            aggregations : {
                "subItems" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : true,
                    singularName : "subItem"
                }
            }
        }
    });

})();