(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.view.customizing.shell.BaseController");

    /**
     * @class The controller handles a table of key-value parameters retrieved from the backend that can be updated by the user. Editing a table row
     *        is done via a dialog (see <code>jd.ui.eid.fragment.dialog.customizing.EditKeyValueParameterDialog.xml</code>), where only the value
     *        can be changed (mandatory and numeric). Validation is done in {@link #.handleDialogOk}.
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.customizing.shell.KeyValueParameters
     * @augments jd.ui.eid.view.customizing.shell.BaseController
     */
    sap.ui.controller("jd.ui.eid.view.customizing.shell.KeyValueParameters", jQuery.extend(true, {}, jd.ui.eid.view.customizing.shell.BaseController, /** @lends jd.ui.eid.view.customizing.shell.KeyValueParameters */
    {
        /* Configuration */

        _mConfig : {
            mFetchData : {
                sMethodName : "getKeyValueParamters"
            },
            mSendData : {
                sPath : "/KeyValParameters",
                sMethodName : "updateKeyValueParameters",
                sSuccessTextKey : "KEY_VALUE_PARAMETERS_TABLE_MSG_SAVE_SUCCESSFUL"
            },
            mDialog : {
                sId : "EditKeyValueParameterDialog",
                sFragment : "jd.ui.eid.fragment.dialog.customizing.EditKeyValueParameterDialog",
                sContextPath : "/KeyValueDialog"
            },
            mHelpDialog : {
                sLongTextKey : "KEY_VALUE_PARAMETERS_TABLE_EXP_HELP_TEXT",
                sTitleTextKey : "KEY_VALUE_PARAMETERS_TABLE_HED_HELP_DIALOG"
            },
            sTableId : "table"
        },

        /* Dialog Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleDialogBeforeOpenHook
         */
        handleDialogBeforeOpenHook : function() {
            // Detach all error tooltips from controls
            var oKey = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "KeyName");
            var oValue = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "KeyValue");
            this.detachErrorTooltipFromControl(oKey);
            this.detachErrorTooltipFromControl(oValue);
        },

        /**
         * Sets back values to the given row.
         */
        handleDialogOk : function() {
            if (this.validateDialogValueField()) {
                var oModel = sap.ui.getCore().getModel();

                // Compare the values of the dialog with the values of the table. Only if the values are not the same, we need to change the state of
                // the data loss manager
                if (!oModel.pathsEqual(this._sDialogPath, "/KeyValueDialog")) {
                    this._oDLM.setDirty(true);
                }

                // Now we can go ahead and copy back the values from the dialog to the table.
                oModel.setProperty(this._sDialogPath, oModel.getProperty("/KeyValueDialog"));
                this._oDialog.close();
            }
        },

        /* Validation */

        /**
         * Validates the value field of the edit dialog. The value is valid if it is not empty (after being trimmed) and numeric.
         * 
         * @return {boolean} True if the value is valid, false otherwise.
         */
        validateDialogValueField : function() {
            var oValueField = sap.ui.core.Fragment.byId("EditKeyValueParameterDialog", "KeyValue");
            return this.validateMandatoryNumericTextField(oValueField, "KEY_VALUE_PARAMETERS_DETAILS_MSE_VALUE_REQUIRED",
                    "KEY_VALUE_PARAMETERS_DETAILS_MSE_VALUE_NOT_NUMERIC");
        },

        /* Formatter */

        /**
         * Formats the parameter id into an explanation text for the rich tooltip. This is done by appending the id to the prefix and using that
         * string as the text key.
         * 
         * @param {string}
         *            sParameterID the parameter id.
         * @returns {string} the formatted explanation for the given parameter.
         */
        formatParameterToHelpText : function(sParameterID) {
            var sTextKey = "KEY_VALUE_PARAMETERS_HELP_EXP_" + sParameterID;
            return jd.ui.eid.common.I18NHelper.getText(sTextKey);
        }

    }));
})();