(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.Tag");

    /**
     * The Tag element stores the data of on tag cloud element.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>text : string (default: "") This property defines the text of the tag.</li>
     * <li>weight : float (default: 1) This property defines the weigth/score of the tag.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Element
     * @name jd.ui.eid.control.Tag
     */
    sap.ui.core.Element.extend("jd.ui.eid.control.Tag", /** @lends jd.ui.eid.control.Tag */
    {
        metadata : {
            properties : {
                text : {
                    type : "string",
                    defaultValue : ""
                },
                weight : {
                    type : "float",
                    defaultValue : 1
                }
            }
        }
    });

})();