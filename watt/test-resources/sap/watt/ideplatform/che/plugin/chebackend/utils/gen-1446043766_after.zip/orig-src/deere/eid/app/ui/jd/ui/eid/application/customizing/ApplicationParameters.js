(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.application.customizing.ApplicationParameters");
    jd.ui.eid.require("jd.ui.eid.common.DataLossManager");

    jd.ui.eid.application.customizing.ApplicationParameters = {

        // Root content
        root : "content", // The id of the element to assign the root content
        getRootContent : function() {
            return jd.ui.eid.xmlview("jd.ui.eid.view.customizing.Shell");
        },

        // Text key displayed when there is onsaved data
        dataLossTextKey : "DATA_LOSS_DIALOG_MSW_DEFAULT_MESSAGE_ON_CLOSE",

        // Service facades
        serviceFacades : {
            "Customizing" : "jd.ui.eid.service.CustomizingServiceFacade",
            "FilterDomainValue" : "jd.ui.eid.service.FilterDomainValueServiceFacade",
        },
        // Notification Center
        notificationCenter : {
            alertTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_ALERT_TITLE}",
            confirmationTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_CONFIRM_TITLE}",
            successTitle : "{i18n>COMMON_NOTIFICATION_CENTER_CAP_SUCCESS_TITLE}"
        },

        // Data source
        useTestData : false,

        serverUrl : "../",
        eidRootPath : "./jd/ui/eid/"

    };

})();