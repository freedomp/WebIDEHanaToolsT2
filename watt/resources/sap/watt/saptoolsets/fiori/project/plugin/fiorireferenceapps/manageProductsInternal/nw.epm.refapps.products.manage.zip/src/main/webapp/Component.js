// Defines a root UIComponent that exposes the main view
jQuery.sap.declare("nw.epm.refapps.products.manage.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
jQuery.sap.require("nw.epm.refapps.products.manage.util.Products");

// check for BSP environment and set reuse library path
(function() {
    var sPath = jQuery.sap.getModulePath("nw.epm.refapps.products.manage");
    if (sPath.indexOf("EPM_REF_PRODMAN") !== -1) {
        if (sPath.lastIndexOf("/") !== sPath.length - 1) {
            sPath += "/";
        }
        jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse", sPath + "../EPM_REF_LIB/nw/epm/refapps/lib/reuse/");
    }
}());

sap.ca.scfld.md.ComponentBase.extend("nw.epm.refapps.products.manage.Component", {
    _ROUTENAMES : {
        MASTER : "master",
        DETAIL : "detail",
        EDIT : "ProductEdit"
    },
    _oDataHelper : null, // Stores the application helper for handling oData operations

    metadata : sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
        "name" : "EMP Reference App - Manage Products",
        "version" : "1.1.0-SNAPSHOT",
        "library" : "nw.epm.refapps.products.manage",
        "includes" : [ "css/productStyles.css" ],
        "dependencies" : {
            "libs" : [ "sap.m", "sap.me", "nw.epm.refapps.lib.reuse", "sap.ui.table", "sap.ui.comp" ],
            "components" : []
        },
        "config" : {
            "resourceBundle" : "i18n/i18n.properties",
            "titleResource" : "shellTitle",
            "icon" : "sap-icon://Fiori6/F0865",
            "favIcon" : "icon/F0865_Manage_Products.ico",
            "phone" : "icon/launchicon/57_iPhone_Desktop_Launch.png",
            "phone@2" : "icon/launchicon/114_iPhone-Retina_Web_Clip.png",
            "tablet" : "icon/launchicon/72_iPad_Desktop_Launch.png",
            "tablet@2" : "icon/launchicon/144_iPad_Retina_Web_Clip.png",
			serviceConfig: {
				name: "EPM_REF_APPS_PROD_MAN",
				serviceUrl: "/sap/opu/odata/sap/EPM_REF_APPS_PROD_MAN_SRV/"
			}
        },

        viewPath : "nw.epm.refapps.products.manage.view",
        masterPageRoutes : {
            // Defines the master page routes:
            // The scaffolding/application starts by navigating to the route "master", which leads to a default master
            // view "S2"; the default view can be replaced here in the route "master" definition.
            "master" : {
                pattern : "",
                view : "S2_ProductMaster"
            }
        },
        detailPageRoutes : {
            // Defines the routes to detail pages here:
            // The scaffolding/application navigates from the master page to route "detail", which leads to a default
            // detail screen "S3"; the default view can be replaced here in the route "detail" definition.
            "detail" : {
                pattern : "product/{productID}",
                view : "S3_ProductDetail",
                viewLevel : 2
            },
            // Edit product draft
            "ProductEdit" : {
                pattern : "editProduct/{productDraftID}",
                view : "S3_ProductEdit",
                transition : "show",
                viewLevel : 3
            }
        }
    }),

    // Initializes the application
    createContent : function() {
        var oViewData = {
            component : this
        };
        return sap.ui.view({
            viewName : "nw.epm.refapps.products.manage.Main",
            type : sap.ui.core.mvc.ViewType.XML,
            viewData : oViewData
        });
    },

    // Gets the helper for handling oData operations in this application
    getODataHelper : function(oResourceBundle, oModel) {
        if (!this._oDataHelper) {
            this._oDataHelper = new nw.epm.refapps.products.manage.util.Products(oResourceBundle, oModel);
        }
        return this._oDataHelper;
    },

    // Navigates to the product edit page based on the product draft ID specified
    navToProductEditPage : function(sProductDraftID) {
        this.getRouter().navTo(this._ROUTENAMES.EDIT, {
            productDraftID : sProductDraftID
        }, !sap.ui.Device.system.phone); // On the phone, the current hash (such as product page) should be stored in
        // the window history; on the other hand, the current hash does not need to be stored on the desktop or tablets
    },

    // Navigates back to the master page on phone, return true for the phone case, return false for other cases
    navBackToMasterPageInPhone : function() {
        if (sap.ui.Device.system.phone) {
            this.getRouter().navTo(this._ROUTENAMES.MASTER, {}, true); // true: hash should not be stored
            return true;
        }
        return false;
    },

    // Shows the product detail in S3 via Router based on the product ID specified.
    // NOTE: the current hash before the navigation is not stored in the history.
    // The method is used currently in the following cases:
    // 1. After the product is edited and saved;
    // 2. In multiSelect mode, the selected product is to be shown on the detail page (on desktop or tablets)
    showProductDetailPage : function(sProductID) {
        this.getRouter().navTo(this._ROUTENAMES.DETAIL, {
            productID : sProductID
        }, true); // true: hash should not be stored in the history
    }
});