(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("sap.ui.model.json.JSONModel");

    /**
     * @class
     * <p>
     * Eid (emerging issues application) model class.
     * </p>
     * <p>
     * For the Eid the usage of the JSON model together with server side filtering/sorting/paging(lazy loading) is crucial. Currently the classes
     * sap.ui.model.json.JSONModel and sap.ui.model.json.JSONModelListBinding do not support this functionality. Therefore this classes got extended
     * by the custom classes jd.ui.eid.model.EidModel and jd.ui.eid.model.EidModelListBinding.
     * </p>
     * 
     * @extends sap.ui.model.json.JSONModel
     * @name jd.ui.eid.model.EidModel
     */
    sap.ui.model.json.JSONModel.extend("jd.ui.eid.model.EidModel", /** @lends jd.ui.eid.model.EidModel */
    {
        // Assign an almost-unique name to that property to avoid name clashed in future upgrades.
        _aJdUiEidPropertyBindings : [],
        _aJdUiEidListBindings : [],
        _aJdUiEidArrayCountBindings : [],
        _aJdUiEidObjectPropertyBindings : [],
        _mJdUiEidContexts : {},

        /**
         * @construtor
         */
        constructor : function() {
            // call super constructor
            sap.ui.model.json.JSONModel.apply(this, arguments);
            this.init();
        },

        /**
         * Initializes the model
         * 
         * @proteced
         */
        init : function() {
            // Init dynamic default values
            // (1) Trend range should cover the past 12 months
            var sEndDate = jd.ui.eid.common.DateHelper.DateToJSONDate(FAKE_TODAY());
            var sStartDate = jd.ui.eid.common.DateHelper.subtractMonths(sEndDate, 12);
            jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterSelection.TrendRange = {
                Start : sStartDate,
                End : sEndDate
            };

            this.initModelPaths();
            this.setSizeLimit(10000);
        },

        /**
         * Initialize all paths in the model.
         * 
         * @protected
         */
        initModelPaths : function() {
            var oData = {
                DTCList : [],
                DTCDetails : {},
                DTACCaseFilters : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter),
                DTACCaseList : [],
                DTACCaseDetails : {},
                WarrantyClaimDetails : {},
                WarrantyClaimFilters : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter),
                WarrantyClaimPrimePartHeader : {
                    PrimePartSummary : {
                        PrimePartNumber : "",
                        PrimePartDescription0 : "",
                        DistinctPINCount0 : 0,
                        WarrantyClaimCount : 0,
                        TotalClaimCost : 0,
                        LaborCost : 0,
                        PartCost : 0
                    },
                    WarrantyClaimList : []
                },
                WarrantyClaimsByPrimePartList : {},
                EvidencePackageList : [],
                EvidencePackageDetails : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails),
                DTCBlacklist : [],
                PersonalizedDTCFilters : {
                    DomainValues : {
                        ManualPinList : [],
                        Models : [],
                        BuildFactories : [],
                        DesignFactories : [],
                        EngineHours : [],
                        MachineLocations : [],
                        BranchCodes : [],
                        FunctionalAreas : []
                    },
                    FilterSelection : {
                        PlatformAndProductLine : [],
                        Model : [],
                        BuildWeek : {},
                        BuildFactory : [],
                        DesignFactory : [],
                        DTCCaptureTime : {},
                        EngineHour : [],
                        MachineLocation : [],
                        BranchCode : [],
                        FunctionalArea : [],
                        ManualPinList : [],
                        EmissionLevel : [],
                        NoiseReduction : false,
                        TestMachine : "E"
                    }, // FilterSelection
                    FilterState : {}
                }, // PersonalizedDTCFilters
                DTCKPIs : {},
                Top10DTCs : [],
                DTCFilters : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters),
                SimulatedEvidencePackageDetails : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.SimulatedEvidencePackageDetails),
                SearchTerms : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.SearchTerms)
            };
            this.setData(oData);
        },

        /**
         * Creates a property binding.
         * 
         * @see sap.ui.model.Model#bindProperty
         * @param {string}
         *            sPath the path pointing to the property that should be bound
         * @param {object}
         *            [oContext=null] the context object for this databinding (optional)
         * @param {object}
         *            [mParameters=null] additional model specific parameters {optional)
         * @returns {sap.ui.model.json.JSONListBinding}
         */
        bindProperty : function(sPath, oContext, mParameters) {
            var oBinding = sap.ui.model.json.JSONModel.prototype.bindProperty.apply(this, arguments);
            this._aJdUiEidPropertyBindings.push(oBinding);

            if (mParameters && mParameters.bIsArrayCountBinding === true) {
                this._aJdUiEidArrayCountBindings.push(oBinding);
            } else if (mParameters && mParameters.bIsObjectPropertyBinding) {
                this._aJdUiEidObjectPropertyBindings.push(oBinding);
            }

            return oBinding;
        },

        /**
         * Creates a list binding.
         * 
         * @see sap.ui.model.Model#bindList
         * @param {string}
         *            sPath the path pointing to the list / array that should be bound
         * @param {object}
         *            [oContext=null] the context object for the databinding (optional)
         * @param {array|sap.ui.model.Sorter}
         *            [aSorters=null] initial sort order (can be either a sorter or an array of sorters) (optional)
         * @param {array|sap.ui.model.Filter}
         *            [aFilters=null] predefined filter/s (can be either a filter or an array of filters) (optional)
         * @param {object}
         *            [mParameters=null] additional model specific parameters (optional)
         * @param {boolean}
         *            [mParameters.bIsLocal=false] True to create a local binding that does sorting and filtering locally, false otherwise (optional)
         * @returns {jd.ui.eid.model.EidModelListBinding}
         */
        bindList : function(sPath, oContext, aSorters, aFilters, mParameters) {
            var oBinding;
            if (mParameters && mParameters.bIsLocal === true) {
                oBinding = sap.ui.model.json.JSONModel.prototype.bindList.apply(this, arguments);
                if (!oBinding.getLength && typeof oBinding.getLength != 'function') {
                    // Make sure that this has a getLength method (which we might need to display
                    // the number of entries in an array)
                    oBinding.getLength = function() {
                        return oBinding.getContexts().length;
                    };
                }
            } else {
                // Get Binding
                oBinding = new jd.ui.eid.model.EidModelListBinding(this, sPath, oContext, aSorters, aFilters, mParameters);
            }
            this._aJdUiEidListBindings.push(oBinding);
            return oBinding;
        },

        /**
         * Override the tree binding function. Due to the fact that in the Eie TreeBinding will not be supported, it causes an error
         */
        bindTree : function() {
            $.sap.log.fatal("Error: TreeBinding is not supported in the Eid.");
            return null;
        },

        /**
         * Sets a new value for the given property <code>sPropertyName</code> in the model. If the model value changed all interested parties are
         * informed. The method has some additional logic to support object and array bindings for properties.
         * 
         * @param {string}
         *            sPath path of the property to set
         * @param {any}
         *            oValue value to set the property to
         * @param {object}
         *            [oContext=null] the context which will be used to set the property
         */
        setProperty : function(sPath, oValue, oContext) {
            var sUpdatedPath = oContext ? oContext.getPath() + "/" + sPath : sPath;
            $.sap.log.debug("Calling setProperty '" + sUpdatedPath + "' with object value, updating other bindings...");

            var bRefreshArrayCountBindings = false;
            if (typeof oValue === 'object') {
                bRefreshArrayCountBindings = true;
            } else if (sUpdatedPath.match(/\/[0-9]+/)) {
                // If the updated path is something like '/Array/11'
                bRefreshArrayCountBindings = true;
            }

            // Call the standard implementation of the parent model
            sap.ui.model.json.JSONModel.prototype.setProperty.apply(this, [sPath, oValue, oContext]);

            if (bRefreshArrayCountBindings) {
                // Let's explicitly refresh all bindings if required. There's a bug so that
                // object and array bindings are only refreshed every second time, even if you copy
                // the object / array before.
                for ( var i = 0, l = this._aJdUiEidArrayCountBindings.length; i < l; i++) {
                    var oBinding = this._aJdUiEidArrayCountBindings[i];
                    var sBindingPath = oBinding.getContext() ? oBinding.getContext().getPath() + "/" + oBinding.getPath() : oBinding.getPath();
                    if ($.sap.startsWith(sBindingPath, sUpdatedPath) || $.sap.startsWith(sUpdatedPath, sBindingPath)) {
                        $.sap.log.debug("Refreshing binding with path '" + sBindingPath + "'");
                        // Make sure that refresh exists. The documentation is not super clear here.
                        oBinding.refresh(true); // Force the binding to refresh
                    }
                }
            }

            // Reset the binding length if an empty array was given as the new binding value
            if (oValue instanceof Array && oValue.length == 0) {
                for ( var i = 0, l = this._aJdUiEidListBindings.length; i < l; i++) {
                    var oBinding = this._aJdUiEidListBindings[i];
                    if (oBinding instanceof jd.ui.eid.model.EidModelListBinding) {
                        var sBindingPath = oBinding.getContext() ? oBinding.getContext().getPath() + "/" + oBinding.getPath() : oBinding.getPath();
                        if (sUpdatedPath == sBindingPath) {
                            oBinding.setLength(0);
                        }
                    }
                }
            }

            for ( var i = 0, l = this._aJdUiEidObjectPropertyBindings.length; i < l; i++) {
                var oBinding = this._aJdUiEidObjectPropertyBindings[i];
                var sBindingPath = oBinding.getContext() ? oBinding.getContext().getPath() + "/" + oBinding.getPath() : oBinding.getPath();
                // This will refresh bindings to /Object if /Object/Property is updated
                if ($.sap.startsWith(sUpdatedPath, sBindingPath)) {
                    oBinding.refresh(true);
                }
            }
        },

        /**
         * Gets a binding context. If context already exists, return it from the map, otherwise create one using the context constructor.
         * 
         * @param {string}
         *            sPath the path
         * 
         */
        getContext : function(sPath) {
            if (!jQuery.sap.startsWith(sPath, "/")) {
                throw new Error("Path " + sPath + " must start with a / ");
            }
            var oContext = this._mJdUiEidContexts[sPath];
            if (!oContext) {
                oContext = new sap.ui.model.Context(this, sPath);
                this._mJdUiEidContexts[sPath] = oContext;
            }
            return oContext;
        },

        /**
         * Compares two paths for equality.
         * 
         * @param {string}
         *            sPathLeft path to compare
         * @param {string}
         *            sPathRight path to compare
         * @returns {boolean} True if the two paths are equal, false otherwise.
         */
        pathsEqual : function(sPathLeft, sPathRight) {
            var oLeft = this.getProperty(sPathLeft);
            var oRight = this.getProperty(sPathRight);
            return JSON.stringify(oLeft) === JSON.stringify(oRight);
        }

    });

    /* Static Methods */

    /**
     * @namespace Enumerations
     * @name jd.ui.eid.model.EidModel.Enum
     */
    jd.ui.eid.model.EidModel.Enum = {

        /**
         * @namespace Evidence Package Enumerations
         * @name jd.ui.eid.model.EidModel.Enum.EvidencePackage
         */
        EvidencePackage : {

            /**
             * @namespace Package Status Enumeration
             * @name jd.ui.eid.model.EidModel.Enum.EvidencePackage.PackageStatus
             */
            PackageStatus : {
                Open : 0,
                Close : 1
            }
        },

        /**
         * @namespace Machine Option Code Enumerations
         * @name jd.ui.eid.model.EidModel.Enum.MachineOptionCode
         */
        MachineOptionCode : {
            CalculationPending : 100,
            CalculationFailed : 200,
            CalculationSuccessfull : 500
        }
    };

    /**
     * @namespace Helper methods which transform data in the application model.
     * @static
     * @name jd.ui.eid.model.EidModel.TransformationHelper
     */
    jd.ui.eid.model.EidModel.TransformationHelper = {};

    /**
     * Gets an array of DTC IDs from the evidence package details.
     * 
     * @returns {array} array of integers.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getDTCIDListFromEvidencePackageDetails = function() {
        var oModel = sap.ui.getCore().getModel();
        var aDTCList = oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList");
        var aDTCIDs = [];
        $.each(aDTCList, function(iIdx, mDTC) {
            aDTCIDs.push(parseInt(mDTC.DTCID));
        });
        return aDTCIDs;
    };

    /**
     * Gets a map of DTCs by DTC ID from the evidence package details.
     * 
     * @returns {object} a map of DTCs.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getDTCMapFromEvidencePackageDetails = function() {
        var oModel = sap.ui.getCore().getModel();
        var aDTCList = oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList");
        var mDTCs = {};
        $.each(aDTCList, function(iIdx, mDTC) {
            mDTCs[mDTC.DTCID] = mDTC;
        });
        return mDTCs;
    };

    /**
     * Gets a map of DTAC cases by DTAC case number from the evidence package details.
     * 
     * @returns {object} a map of DTAC cases.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getDTACCaseMapFromEvidencePackageDetails = function() {
        var oModel = sap.ui.getCore().getModel();
        var aDTACCases = oModel.getProperty("/EvidencePackageDetails/Header/DTACCaseList");
        var mDTACCases = {};
        $.each(aDTACCases, function(iIdx, mDTACCase) {
            mDTACCases[mDTACCase.DTACCaseNumber] = mDTACCase;
        });
        return mDTACCases;
    };

    /**
     * Gets a map of warranty claims by warranty claim sequence number from the evidence package details.
     * 
     * @returns {object} a map of warranty claims.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getWarrantyClaimMapFromEvidencePackageDetails = function() {
        var oModel = sap.ui.getCore().getModel();
        var aWarrantyClaims = oModel.getProperty("/EvidencePackageDetails/Header/WarrantyClaimList");
        var mWarrantyClaims = {};
        $.each(aWarrantyClaims, function(iIdx, mWarrantyClaim) {
            mWarrantyClaims[mWarrantyClaim.WarrantyClaimSequenceNumber] = mWarrantyClaim;
        });
        return mWarrantyClaims;
    };

    /**
     * Gets the DTC object for an DTC ID from the evidence package details.
     * 
     * @param {integer}
     *            iDTCID the DTC ID
     * @returns {object} DTC object.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getDTCHeaderForDTCIDFromEvidencePackageDetails = function(iDTCID) {
        var oModel = sap.ui.getCore().getModel();
        var aDTCList = oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList");
        var oDTC = null;
        $.each(aDTCList, function(iIdx, mDTC) {
            if (mDTC.DTCID == iDTCID) {
                oDTC = mDTC;
            }
        });
        return oDTC;
    };

    /**
     * Gets the name of the KPI for the provided KPI ID from the /KPIValues node in the model
     * 
     * @param {string}
     *            sKPIID the KPI ID
     * @returns {object} the KPI object.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getKPIByKPIID = function(sKPIID) {
        var aKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
        var mKPI = null;
        $.each(aKPIs, function(i, _mKPI) {
            if (_mKPI.KPIID == sKPIID) {
                mKPI = _mKPI;
                return false;
            }
        });
        return mKPI;
    };

    /**
     * Copies the current domain values of the DTC filters to the evidence package header to be used during the creation of the evidence package (so
     * that it's independent from the filters on the dashboad, very important when opening an evidence package before having maintained the filters on
     * the dashboard).
     */
    jd.ui.eid.model.EidModel.TransformationHelper.copyDTCFilterDomainValuesForEvidencePackage = function() {
        var oModel = sap.ui.getCore().getModel();
        var mDomainValues = oModel.getProperty("/DTCFilters/DomainValues");
        oModel.setProperty("/EvidencePackageDetails/_DTCFilters/DomainValues", mDomainValues); // underscore = UI only, ignored by services
    };

    var mExpensiveDTCPropertiesBuffer = null;

    /**
     * Copies the DTC data such as KPIs and affected PINs to a buffer to be applied to the DTC details path later on. These properties would be
     * expensive to re-calculate.
     * 
     * @see #.applyExpensiveDTCDetailsFromBuffer
     * 
     * @param {object}
     *            mDTC the DTC
     * @param {array}
     *            mDTC.KPIs
     * @param {int}
     *            mDTC.AffectedPINs
     */
    jd.ui.eid.model.EidModel.TransformationHelper.bufferExpensiveDTCListItemDataToDTCDetails = function(mDTC) {
        mExpensiveDTCPropertiesBuffer = {
            KPIs : mDTC.KPIs,
            AffectedPINs : mDTC.AffectedPINs
        };
    };

    /**
     * Applies the backup of expensive DTC properties to the DTC details from the buffer.
     * 
     * @param {string}
     *            [sRootPath] the root path to write the data to.
     * 
     * @see #.bufferExpensiveDTCListItemDataToDTCDetails
     */
    jd.ui.eid.model.EidModel.TransformationHelper.applyExpensiveDTCDetailsFromBuffer = function(sRootPath) {
        if (!mExpensiveDTCPropertiesBuffer) {
            return;
        }
        if (!sRootPath) {
            sRootPath = "/DTCDetails";
        }

        var oModel = sap.ui.getCore().getModel();
        // First, make sure that the master data path exists
        if (!oModel.getProperty(sRootPath)) {
            oModel.setProperty(sRootPath, {});
        }
        if (!oModel.getProperty(sRootPath + "/DTCMasterData")) {
            oModel.setProperty(sRootPath + "/DTCMasterData", {});
        }

        oModel.setProperty(sRootPath + "/DTCMasterData/KPIs", mExpensiveDTCPropertiesBuffer.KPIs);
        oModel.setProperty(sRootPath + "/DTCMasterData/AffectedPINs", mExpensiveDTCPropertiesBuffer.AffectedPINs);
        mExpensiveDTCPropertiesBuffer = null;
    };

    /**
     * Initializes the model paths for the selection of those filter items which are dependent on the combination of platform and product line.
     * 
     * @param {string}
     *            sDTCFilterRootPath the Root Path for the DTC Filter like '/DTCFilters/FilterSelection'
     */
    jd.ui.eid.model.EidModel.TransformationHelper.initializeDepedentDTCFilterSelection = function(sDTCFilterRootPath) {
        var oModel = sap.ui.getCore().getModel();
        $.each(jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterSelection, function(sKey, oValue) {
            if (sKey == 'PlatformAndProductLine') {
                return true; // continue
            }
            if (oValue instanceof Array) {
                oModel.setProperty(sDTCFilterRootPath + '/' + sKey, []);
            } else if (oValue instanceof Object) {
                oModel.setProperty(sDTCFilterRootPath + '/' + sKey, jQuery.extend(true, {}, oValue));
            } else {
                oModel.setProperty(sDTCFilterRootPath + '/' + sKey, oValue);
            }
        });

        jd.ui.eid.require("jd.ui.eid.common.DateHelper");
        var sEnd = JSON.stringify(FAKE_TODAY()).replace(/\"/g, "");
        var oDate = jd.ui.eid.common.DateHelper.JSONDateToDate(jd.ui.eid.common.DateHelper.subtractMonths(jd.ui.eid.common.DateHelper
                .DateToJSONDate(FAKE_TODAY()), 6));
        var sStart = JSON.stringify(oDate).replace(/\"/g, "");

        oModel.setProperty(sDTCFilterRootPath + "/DTCCaptureTime", {
            Start : sStart,
            End : sEnd,
            _Type : "static"
        });
    };

    /**
     * Moves empty domain values (which will be displayed as 'Unknown' or 'Unavailable') to the end of the array.
     * 
     * @param {object}
     *            mDomainValues the DTC domain values which should be transformed.
     */
    jd.ui.eid.model.EidModel.TransformationHelper.moveEmptyDTCDomainValuesToEnd = function(mDomainValues) {
        // Ok, this is new. For a lot of filters (e.g. build factory, design factory, functional area, etc.), there's an empty value which is
        // displayed as 'Unavailable' or 'Unknown'. As the values are sorted lexicographically, that item (represented by an empty string as
        // id) will be first. But as this item sementailly represents the rest (aka left overs), we manually shift it to the end of the array.
        $.each([mDomainValues.BuildFactories, mDomainValues.DesignFactories, mDomainValues.MachineLocations, mDomainValues.BranchCodes,
                mDomainValues.FunctionalAreas, mDomainValues.EmissionLevels], function(iIdx, aArray) {
            if (aArray[0] && aArray[0].ID === "") {
                var mUnknownItem = aArray.shift(); // Take it from position 1...
                aArray.push(mUnknownItem); // ... and move it to the end.
            }
        });
    };

    /**
     * Applies the simulated DTC filter change result to the current evidence package
     * 
     * @param {string}
     *            sDTCFilterRootPath the Root Path for the DTC Filter like '/DTCFilters/FilterSelection'
     */
    jd.ui.eid.model.EidModel.TransformationHelper.applySimulatedEvidencePackage = function() {
        var oModel = sap.ui.getCore().getModel();
        var oRootSimulatedEvidencePackageDetails = oModel.getProperty("/SimulatedEvidencePackageDetails");
        oModel.setProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation", oRootSimulatedEvidencePackageDetails._DTCFilters.PINPopulation);
        oModel.setProperty("/EvidencePackageDetails/Header", jQuery.extend(true, {}, oRootSimulatedEvidencePackageDetails.Header));

        // take removed DTCs from various paths
        if (oRootSimulatedEvidencePackageDetails.RemovedDTCCodeList) {
            for ( var i = 0; i < oRootSimulatedEvidencePackageDetails.RemovedDTCCodeList.length; i++) {
                jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTC(oRootSimulatedEvidencePackageDetails.RemovedDTCCodeList[i].DTCID);
            }
        }

        // take removed DTACs from various paths
        if (oRootSimulatedEvidencePackageDetails.RemovedDTACCaseList) {
            for ( var i = 0; i < oRootSimulatedEvidencePackageDetails.RemovedDTACCaseList.length; i++) {
                jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeDTACCase(oRootSimulatedEvidencePackageDetails.RemovedDTACCaseList[i]);
            }
        }

        // take removed Warranty Claims from various paths
        if (oRootSimulatedEvidencePackageDetails.RemovedWarrantyClaimList) {
            for ( var i = 0; i < oRootSimulatedEvidencePackageDetails.RemovedWarrantyClaimList.length; i++) {
                jd.ui.eid.common.BusinessProcessHelper.EvidencePackage
                        .removeWarrantyClaim(oRootSimulatedEvidencePackageDetails.RemovedWarrantyClaimList[i]);
            }
        }
    };

    /**
     * Returns the ID of the first active KPI from the list of KPIs (/KPIValues)
     * 
     * @returns {object} the KPI
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getFirstActiveKPI = function() {
        var aKPIs = [], _aKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
        $.each(_aKPIs, function(iIdx, mKPI) {
            if (mKPI.Enabled == 1) {
                aKPIs.push(mKPI);
            }
        });
        return aKPIs[0];
    };

    /**
     * Returns the ID of the second active KPI from the list of KPIs (/KPIValues). If there is only one KPI available, it returns the same result as
     * getFirstActiveKPIID.
     * 
     * @returns {object} the KPI
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getSecondActiveKPI = function() {
        var aKPIs = [], _aKPIs = sap.ui.getCore().getModel().getProperty("/KPIValues");
        $.each(_aKPIs, function(iIdx, mKPI) {
            if (mKPI.Enabled == 1) {
                aKPIs.push(mKPI);
            }
        });
        return aKPIs[1] ? aKPIs[1] : aKPIs[0];
    };

    /**
     * Check whether the Warranty Claims of the evidence package collide with the Warranty Claims of the selected Prime Part
     * 
     * @returns {integer} the count of Warranty Claims that have a collision with the current Warranty Claims of the Evidence Package
     */
    jd.ui.eid.model.EidModel.TransformationHelper.getCollisionsOfEvidencePackageWarrantyClaims = function() {
        // Create a map out of the Warranty Claims which are currently assigned to the Evidence Package
        var aWarrantyClaimListOfEvidencePackage = sap.ui.getCore().getModel().getData().EvidencePackageDetails.Header.WarrantyClaimList;
        var mWarrantyClaim = {};

        $.each(aWarrantyClaimListOfEvidencePackage, function(iIndex, oValue) {
            mWarrantyClaim[oValue.WarrantyClaimSequenceNumber] = oValue;
        });

        // Get the Warranty Claims of the currently opened Prime Part
        var aWarrantyClaimListOfEvidencePackageOfPrimePart = sap.ui.getCore().getModel().getData().WarrantyClaimPrimePartHeader.WarrantyClaimList;

        // Initialize counter to identify the amout of Warranty Claims that have a collision with the current Warranty Claims of the Evidence Package
        var iCount = 0;

        // Execute the check
        $.each(aWarrantyClaimListOfEvidencePackageOfPrimePart, function(iIndex, oValue) {
            if (mWarrantyClaim[oValue.WarrantyClaimSequenceNumber]) {
                iCount++;
            }
        });

        return iCount;
    };

    /**
     * @namespace Define default values for the model
     * @name jd.ui.eid.model.EidModel.DefaultValues
     */
    jd.ui.eid.model.EidModel.DefaultValues = {};

    jd.ui.eid.model.EidModel.DefaultValues.DTCFilters = {
        PINPopulation : 0,
        DomainValues : {
            Platforms : [],
            Models : [],
            BuildFactories : [],
            DesignFactories : [],
            EngineHours : [],
            MachineLocations : [],
            BranchCodes : [],
            FunctionalAreas : [],
            EmissionLevels : [],
            ManualPinList : []
        }, // DomainValues
        FilterSelection : {
            PlatformAndProductLine : [],
            Model : [],
            BuildWeek : {
                Start : "",
                End : ""
            },
            BuildFactory : [],
            DesignFactory : [],
            DTCCaptureTime : {
                Start : "",
                End : ""
            },
            EngineHour : [],
            MachineLocation : [],
            BranchCode : [],
            FunctionalArea : [],
            ManualPinList : [],
            EmissionLevel : [],
            NoiseReduction : false,
            TestMachine : "E",
            TrendRange : {
                Start : "",
                End : ""
            }
        }, // FilterSelection
        FilterState : {
            PlatformAndProductLine : {
                Collapsed : false
            },
            Model : {
                Collapsed : false
            },
            BuildWeek : {
                Collapsed : false
            },
            BuildFactory : {
                Collapsed : false
            },
            DesignFactory : {
                Collapsed : true
            },
            DTCCaptureTime : {
                Collapsed : false
            },
            EngineHour : {
                Collapsed : false
            },
            MachineLocation : {
                Collapsed : false
            },
            BranchCode : {
                Collapsed : false
            },
            FunctionalArea : {
                Collapsed : false
            },
            ManualPinList : {
                Collapsed : false
            },
            EmissionLevel : {
                Collapsed : false
            },
            TestMachine : {
                Collapsed : false
            }
        }
    };

    jd.ui.eid.model.EidModel.DefaultValues.DTACCaseFilter = {
        DomainValues : {
            TagCloud : []
        },
        FilterSelection : {
            TagCloud : [],
            TextAnalysis : {
                SearchMode : "",
                SelectedValues : []
            },
            CreationDate : {
                Type : "",
                CustomStartDate : "",
                CustomEndDate : "",
                CustomDuration : -1,
                CustomUnit : "",
                Duration : -1,
                Unit : ""
            },
            EngineHour : [],
            JDLinkActive : true
        }, // FilterSelection
        FilterState : {
            TagCloud : {
                Collapsed : false
            },
            TextAnalysis : {
                Collapsed : false
            },
            CreationDate : {
                Collapsed : false
            },
            JDLinkActive : {
                Collapsed : false
            },
            EngineHour : {
                Collapsed : false
            }
        }
    };

    jd.ui.eid.model.EidModel.DefaultValues.WarrantyClaimFilter = {
        DomainValues : {},
        FilterSelection : {
            TextAnalysis : {
                SearchMode : "",
                SelectedValues : []
            },
            FailureDate : {
                Type : "",
                CustomStartDate : "",
                CustomEndDate : "",
                CustomDuration : -1,
                CustomUnit : "",
                Duration : -1,
                Unit : ""
            },
            EngineHour : []
        }, // FilterSelection
        FilterState : {
            TextAnalysis : {
                Collapsed : false
            },
            FailureDate : {
                Collapsed : false
            },
            EngineHour : {
                Collapsed : false
            }
        }
    };

    jd.ui.eid.model.EidModel.DefaultValues.EvidencePackageDetails = {
        Header : {
            PackageName : "",
            PackageID : null,
            PackageDescription : "",
            AnalystName : "",
            FactoryCode : "",
            DepartmentNumber : "",
            LastChangedDate : "",
            PackageStatusID : null,
            PackageOwnedByCurrentUser : null,
            DTCCodeList : [],
            DTCFilterSelection : $.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterSelection),
            DTCFilterState : {},
            DTACCaseList : [],
            WarrantyClaimList : [],
            LastView : "",
            MachineOptionCodes : []
        },
        PINPopulationList : [],
        _DTCFilters : {
            // We maintain a copy of the domain values locally on the evidence package so that we can e.g. open an evidence package and display it
            // properly without touching domain values on the dashboard.
            DomainValues : null
        }
    };

    jd.ui.eid.model.EidModel.DefaultValues.SearchTerms = {
        DashboardDTCListSearchTerm : "",
        DTCListSearchTerm : "",
        DTACCaseListSearchTerm : "",
        WarrantyClaimsByPrimePartListSearchTerm : ""
    };

    jd.ui.eid.model.EidModel.SimulatedEvidencePackageDetails = {
        Header : {
            DTCFilterSelection : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterSelection),
            DTCFilterState : jQuery.extend(true, {}, jd.ui.eid.model.EidModel.DefaultValues.DTCFilters.FilterState)
        },
        _DTCFilters : {
            PINPopulation : 0,
            DomainValues : {
                Platforms : [],
                Models : [],
                BuildFactories : [],
                DesignFactories : [],
                EngineHours : [],
                MachineLocations : [],
                BranchCodes : [],
                FunctionalAreas : [],
                EmissionLevels : [],
                ManualPinList : []
            }
        },
        RemovedDTCCodeList : [],
        RemovedDTACCaseList : [],
        RemovedWarrantyClaimList : []
    };

})();