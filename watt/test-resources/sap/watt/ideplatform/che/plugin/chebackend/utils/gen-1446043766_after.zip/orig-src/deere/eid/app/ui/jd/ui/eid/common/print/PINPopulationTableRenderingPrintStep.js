(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new PINPopulationTableRenderingPrintStep.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>PINTableRenderAreaId : string (default: "") the id of the table placeholder.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The class provides a mechanism for rendering the table of PINs for printing.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep
     */
    jd.ui.eid.common.print.PrintStep.extend("jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep",
    /** @lends jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep */
    {
        metadata : {
            properties : {
                PINTableRenderAreaId : {
                    type : "string",
                    defaultValue : ""
                }
            }
        },

        /**
         * Triggers a fetch for the PIN Population list, and once complete, prepares a 'table' HTML node and attaches it to the 'PINTableRenderAreaId'
         * div
         * 
         * @memberOf jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep
         */
        _process : function() {
            var aPINPopulationList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/PINPopulationList");
            if (aPINPopulationList && (aPINPopulationList.length > 0)) {
                // The _createAndAttachHTMLNode method fires the 'processed' event once it is done.
                this._createAndAttachHTMLNode(aPINPopulationList);
            } else {
                this.fireProcessed();
            }
        },

        /**
         * Create a new HTML node (table) and set it to the "PINTableRenderAreaId" DIV, based on the supplied list of PINs.
         * 
         * @param {array}
         *            aPINPopulationList The array of PINs to be rendered as a table
         * @memberOf jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep
         */
        _createAndAttachHTMLNode : function(aPINPopulationList) {
            var $root = $("<table/>").addClass("jdUiEidPrintTable");
            var oPrintStep = this;

            // Table headers
            var $headerRow = $("<thead><tr/></thead>");
            var aHeaders = [jd.ui.eid.common.I18NHelper.getText("MACHINE_TABLE_COL_PIN"),
                    jd.ui.eid.common.I18NHelper.getText("MACHINE_TABLE_COL_RELATED_DTCS"),
                    jd.ui.eid.common.I18NHelper.getText("MACHINE_TABLE_COL_RELATED_DTAC_CASES"),
                    jd.ui.eid.common.I18NHelper.getText("MACHINE_TABLE_COL_RELATED_WARRANTY_CLAIMS")];
            $.each(aHeaders, function(i, sHeader) {
                $headerRow.find("tr").append($("<th>" + sHeader + "</th>"));
            });
            $root.append($headerRow);

            // Table rows
            $root.append("<tbody/>");

            // Here we create a function that will create x rows at a time, and place it appropriately in $root. After rendering x rows, it
            // queues
            // itself for the next x rows, at the end of the browser's event processing queue (setTimeout with interval). This lets the
            // browser
            // have time for the UI rendering to catch up. Thus, the UI doesn't "freeze".
            var iNextRowIndex = 0;
            var iCurrentIndex;
            var sTableRowsHTML = "";
            var iChunk = 100; // Number of rows to render before taking a break.
            var _fnCreateRows = function() {
                while (true) {
                    // Get the next PIN to be rendered..
                    iCurrentIndex = iNextRowIndex++;
                    var oPIN = aPINPopulationList[iCurrentIndex];
                    // jQuery.sap.log.debug("PIN Population : Rendering row " + iCurrentIndex + "...");

                    // Translate JDLink Active from true/false to Active/Inactive
                    if (oPIN.JDLinkActive) {
                        oPIN.JDLinkActive = jd.ui.eid.common.I18NHelper.getText("MACHINE_DETAILS_TXT_JDLINK_ACTIVE");
                    } else {
                        oPIN.JDLinkActive = jd.ui.eid.common.I18NHelper.getText("MACHINE_DETAILS_TXT_JDLINK_INACTIVE");
                    }

                    // Create <td>s for the row
                    var sTdPINNumber = "<td>" + oPIN.PINNumber + "</td>";
                    var sTdRelatedDTCsIncluded = "<td class='jdUiEidPrintTableQtyCell'>"
                            + jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oPIN.RelatedDTCsIncluded) + "</td>";
                    var sTdRelatedDTACCasesIncluded = "<td class='jdUiEidPrintTableQtyCell'>"
                            + jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oPIN.RelatedDTACCasesIncluded) + "</td>";
                    var sTdRelatedWarrantyClaimsIncluded = "<td class='jdUiEidPrintTableQtyCell'>"
                            + jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oPIN.RelatedWarrantyClaimsIncluded) + "</td>";

                    // Append <td>s to <tr>
                    var sRowHTML = "<tr>" + sTdPINNumber + sTdJDLinkActive + sTdRelatedDTCsIncluded + sTdRelatedDTACCasesIncluded
                            + sTdRelatedWarrantyClaimsIncluded + "</tr>";

                    // Append this row to the <tbody>
                    sTableRowsHTML += sRowHTML;

                    // Did we just render the last row in the list? If so, we need to add $root to our DOM node, and indicate that this step
                    // has completed
                    if (iCurrentIndex == (aPINPopulationList.length - 1)) {
                        $root.find("tbody").append($(sTableRowsHTML));
                        $("#" + oPrintStep.getPINTableRenderAreaId()).append($root);
                        oPrintStep.fireProcessed();
                        return;
                    }

                    // Did the user cancel the Print view? If so, then stop.
                    if (oPrintStep.bIsDestroyed) {
                        return;
                    }

                    // Exit this infinite loop and proceed to setTimeout (which will give time for the UI rendering to catch up) if we'e
                    // rendered 'iChunk' rows
                    if ((iCurrentIndex % iChunk) == 0) {
                        // $root.find("tbody").append($(sTableRowsHTML));
                        // $("#" + oPrintStep.getPINTableRenderAreaId()).append($root);
                        // sTableRowsHTML = "";
                        break;
                    }
                }

                // Do we need to render more rows? If so, add it to the end of the event queue. This way, the browser gets some time for the
                // rendering
                // to catch up. This prevents the browser from freezing because of this long-running task, and results in the 'Cancel' button
                // being
                // clickable.
                window.setTimeout(_fnCreateRows, 0);
            };

            // Start rendering the PIN population table
            _fnCreateRows();
        }
    });
})();