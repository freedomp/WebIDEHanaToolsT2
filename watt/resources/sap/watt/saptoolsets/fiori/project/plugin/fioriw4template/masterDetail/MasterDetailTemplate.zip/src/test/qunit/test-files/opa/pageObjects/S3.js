sap.ui.define(["sap/ui/test/Opa5", "./Common"], function(Opa5,Common) {
	"use strict";

	return Opa5.createPageObjects({
		onPageS3 : {
			baseClass : Common,

			actions : {
				iClickOnFooterButton : function(sI18nKey){
					return this.waitFor({
						controlType: "sap.m.Button",
						matchers : new sap.ui.test.matchers.PropertyStrictEquals({
							name : "text", 
							value : this.getI18nText(sI18nKey)
						}),
						success: function(aButtons) {
							var oButton = aButtons[0];
							oButton.$().tap();
						},
						errorMessage: "Didn't find footer button with i18n key = " + sI18nKey

					});
				}
			},

			assertions : {
				iShouldSeeDetailsOfSelectedEntry : function () {
					this.waitFor({
						controlType: "sap.m.ObjectHeader",
						viewName: "S3",
						success: function(items) {
							var selItem = this.getContext().selectedItem;
							var item = items[0];
							equal( item.getTitle(), selItem.getTitle(), "Title of Object Header (S3) has same value as selected Object List Item (S2)" );
							equal( item.getNumber(), selItem.getNumber(), "Number of Object Header (S3) has same value as selected Object List Item (S2)" );
							equal( item.getNumberUnit(), selItem.getNumberUnit(), "Number Unit of Object Header (S3) has same value as selected Object List Item (S2)" );
						},
						errorMessage: "Object Header not found (S3)"
					});
					return this;
				},

				iShouldSeeDetailsOfTheFirstEntry : function() {
					//just to have better test description
					this.iShouldSeeDetailsOfSelectedEntry();
				}
			}
		}
	});
});
