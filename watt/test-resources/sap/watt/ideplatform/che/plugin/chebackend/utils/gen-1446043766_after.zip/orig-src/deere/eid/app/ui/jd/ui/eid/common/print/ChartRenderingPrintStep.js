(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.print.ChartRenderingPrintStep");
    jQuery.sap.require("jd.ui.eid.common.print.PrintStep");

    /**
     * Constructor for a new ChartRenderingPrintStep.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>chartRenderAreaId : string (default: '') the id of the chart area element (should be hidden, the chart control will be rendered there).</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>chartPrintContainer : jd.ui.eid.control.ChartPrintContainer the chart print container to be managed by the step.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class The ChartRenderingPrintStep manages a single {@link jd.ui.eid.control.ChartPrintContainer} control and triggers the rendering and
     *        manipulation of a chart for printing (in {@link #._process}). The step is notified via the <code>chartRendered</code> event of the
     *        chart print container when the chart is rendered. This event also indicates that the print step is complete and triggers the
     *        <code>processed</code event.
     * @extends jd.ui.eid.common.print.PrintStep
     * @name jd.ui.eid.common.print.ChartRenderingPrintStep
     */
    jd.ui.eid.common.print.PrintStep.extend("jd.ui.eid.common.print.ChartRenderingPrintStep", /** @lends jd.ui.eid.common.print.ChartRenderingPrintStep */
    {
        metadata : {
            properties : {
                chartRenderAreaId : {
                    type : "string",
                    defaultValur : ""
                }
            },
            associations : {
                chartPrintContainer : {
                    type : "jd.ui.eid.control.ChartPrintContainer"
                }
            }
        },

        /**
         * Gets the control of the chartPrintContainer association.
         * 
         * @returns {jd.ui.eid.control.ChartPrintContainer} the control of the chartPrintContainer association.
         */
        _getChartPrintContainer : function() {
            return sap.ui.getCore().byId(this.getChartPrintContainer());
        },

        /**
         * Handler for the <code>chartRendered</code> event of the chart print container. Fires the <code>processed</code> event to indicate that
         * the print step is complete.
         */
        _handleChartRendered : function() {
            $.sap.log.debug("Chart rendered ", null, this._sLogComponent);
            this.fireProcessed();
        },

        /**
         * Gets the jQuery object of the chart render area.
         * 
         * @returns {jQuery} jQUery object of the chart render area.
         */
        _getChartRenderArea : function() {
            return $("#" + this.getChartRenderAreaId());
        },

        /**
         * Triggers the rendering of the chart association with the chart print container.
         */
        _process : function() {
            $.sap.log.debug("Rendering chart");
            var oChartPrintContainer = this._getChartPrintContainer();
            oChartPrintContainer.attachEventOnce("chartRendered", this._handleChartRendered, this);
            this._getChartRenderArea().html("");
            oChartPrintContainer.renderChart(this._getChartRenderArea());

        }
    });
})();