(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.view.main.shared.EvidencePackageSaveController");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");

    /**
     * @class
     * <p>
     * The Evidence Package Save Controller can be merged into other sap.ui.mvc.Controller objects and provides the following function: - checks if
     * Package Name is maintained by user - If not a dialog pops up to maintain package name and description
     * </p>
     * 
     * Example for merging:
     * 
     * <pre>
     * jQuery.sap.require(&quot;jd.ui.eid.view.main.shared.EvidencePackageSaveController&quot;);
     * sap.ui.controller(&quot;view.ViewName&quot;, jQuery.extend(true, {}, jd.ui.eid.view.main.shared.EvidencePackageSaveController, {
     * // here goes the usual view methods like createContent(), etc.
     * }));
     * </pre>
     * 
     * @static
     */
    jd.ui.eid.view.main.shared.EvidencePackageSaveController = {

        mEvidencePackageSaveControllerConfig : {
            aBusyControls : [],
            aDisabledControlsWhileSave : []
        },

        _fnCallback : null,
        _oEvidencePackageSaveDialog : null,
        _oVisibleSaveButton : null,
        _sEvidencePackageSaveDialogFragmentId : null,

        /**
         * Initialize the controller.
         */
        initEvidencePackageSaveController : function() {
            this._sEvidencePackageSaveDialogFragmentId = this.createId("SaveDialogId");
        },

        /**
         * Exit the controller
         */
        exitEvidencePackageSaveController : function() {
            if (this._oEvidencePackageSaveDialog) {
                this._oEvidencePackageSaveDialog.destroy();
            }

            this.mEvidencePackageSaveControllerConfig.aBusyControls = null;
        },

        /**
         * Saves the evidence package.
         * 
         * @param {jd.ui.eid.view.main.shared.EvidencePackageSaveController.Mode}
         *            sMode mode which decides which additional buttons besides save and cancel should be displayed
         * @param {sap.ui.control}
         *            oBusyControl control which will be set to busy while saving action is performed
         * @param {function}
         *            fnSuccessFurtherAction the function which is executed in case of successfully saving
         */

        saveEvidencePackage : function(iSaveButton, fnSuccessFurtherAction) {
            this._fnCallback = fnSuccessFurtherAction;
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");

            if (oEvidencePackageDetails.DTCCodeList.length < 1) {
                this.getNotificationCenter().alert(jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_MSG_ERROR_NO_DTC"), function() {
                }, jd.ui.eid.common.I18NHelper.getText('EVIDENCE_PACKAGE_DETAILS_HED_ERROR_NO_DTC'));
                return;
            }

            this._setEnabledControlsDuringSave(false);

            var sPackageName = $.trim(oEvidencePackageDetails.PackageName);
            if (!sPackageName) {
                // Package name is empty, so let's dislay the dialog
                var oDialog = this._getEvidencePackageSaveDialog();
                this._maintainEvidencePackageSaveDialogButtonVisibility(iSaveButton);
                oDialog.open();
            } else {
                this._saveEvidencePackage(fnSuccessFurtherAction);
            }
        },

        /**
         * Returns the save dialog that prompts the user to enter a package name.
         * 
         * @returns {sap.ui.commons.Dialog}
         */
        _getEvidencePackageSaveDialog : function() {
            if (!this._oEvidencePackageSaveDialog) {
                this._oEvidencePackageSaveDialog = jd.ui.eid.xmlfragment(this._sEvidencePackageSaveDialogFragmentId,
                        "jd.ui.eid.fragment.dialog.main.EvidencePackageSaveDialog", this);
            }
            return this._oEvidencePackageSaveDialog;
        },

        /**
         * Sets the controls maintained in the configuration of this controller to either busy or not busy.
         */
        _setEvidencePackageSaveControllerBusy : function(bBusy) {
            $.each(this.mEvidencePackageSaveControllerConfig.aBusyControls, function(iIdx, oControl) {
                oControl.setBusy(bBusy);
            });
        },

        _maintainEvidencePackageSaveDialogButtonVisibility : function(iVisibleSaveButtonIndex) {
            this._oVisibleSaveButton = null;
            var oDialog = sap.ui.core.Fragment.byId(this._sEvidencePackageSaveDialogFragmentId, 'Dialog');
            // Let's go through the first three buttons of the dialog and maintain their visibility based on the method's parameter. The fourth/last
            // button
            // is the cancel button which should always be visible.
            var aButtons = oDialog.getButtons();
            for ( var i = 0, l = aButtons.length - 1; i < l; i++) {
                var oButton = aButtons[i];
                if (i == iVisibleSaveButtonIndex) {
                    oDialog.setDefaultButton(oButton);
                    this._oVisibleSaveButton = oButton;
                }
                oButton.setVisible(i == iVisibleSaveButtonIndex); // visible if the index match
                oButton.setEnabled(false);
            }
        },

        /* SECTION - Dialog Button Handler - START */

        /**
         * Handles any 'save' button.
         */
        handleEvidencePackageSaveDialogSave : function() {
            return this._saveEvidencePackage(this._fnCallback);
        },

        /**
         * Handles the 'cancel' button.
         */
        handleEvidencePackageSaveDialogCancel : function() {
            if (this._getEvidencePackageSaveDialog().isOpen()) {
                this._getEvidencePackageSaveDialog().close();
            }
            this._setEnabledControlsDuringSave(true);
        },

        /* SECTION - Dialog Button Handler - END */

        /**
         * Saves the evidence package and invokes the callback if provided
         * 
         * @param {function}
         *            [fnCallback] callback to be invoked once save is successful.
         */
        _saveEvidencePackage : function(fnCallback) {
            var that = this;
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageDetails = oModel.getProperty("/EvidencePackageDetails/Header");
            var sWorksheetMode = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/LastView");

            if (this._oEvidencePackageSaveDialog && this._oEvidencePackageSaveDialog.isOpen()) {
                this._oEvidencePackageSaveDialog.close();
            }
            this._setEvidencePackageSaveControllerBusy(true);

            var oServiceFacade = this.getServiceFacade("EvidencePackage");
            oServiceFacade.saveEvidencePackage(oEvidencePackageDetails, sWorksheetMode, function() {
                // Request successful
                that._setEvidencePackageSaveControllerBusy(false);
                var sText = jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_MSG_SAVE_SUCCESS");
                that.getNotificationCenter().success(sText);

                that._setEnabledControlsDuringSave(true);

                // Call callback for further action
                if (fnCallback) {
                    fnCallback();
                }
            }, function() {
                // Request failed
                that._setEnabledControlsDuringSave(true);

                that._setEvidencePackageSaveControllerBusy(false);
                that._onRequestFailed.apply(that, arguments);
            });

        },

        /**
         * Sets the enable properties of all controls assigned to the config parameter <code>aDisabledControlsWhileSave</code>
         * 
         * @param {boolean}
         *            bEnable true to enable the controls, false otherwise.
         */
        _setEnabledControlsDuringSave : function(bEnable) {
            $.each(this.mEvidencePackageSaveControllerConfig.aDisabledControlsWhileSave, function(iIdx, oElement) {
                if (oElement.setEnabled) {
                    oElement.setEnabled(bEnable);
                }
            });
        },

        /**
         * Event handler for typing a value into the form field "Package Name" for enabling the action button
         * 
         * @param {sap.ui.base.Event}
         *            liveChange event fired by the text field.
         */
        onLiveChangeTextFieldPackageName : function(oEvent) {
            if ($.trim(oEvent.getParameter("liveValue")) != "") {
                this._oVisibleSaveButton.setEnabled(true);
            } else {
                this._oVisibleSaveButton.setEnabled(false);
            }
        },

        /**
         * Handles the event if user changes the package name
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        onChangePackageName : function(oEvent) {

            // Inform DLM about data change in
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
        },

        /**
         * Handles the event if user changes the package description
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        onChangePackageDescription : function(oEvent) {

            // Inform DLM about data change in
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.DLM.getInstance().setDirty(true);
        },

        /**
         * @namespace Save Button Enumeration
         */
        EvidencePackageSaveDialogButton : {
            Save : 0,
            SaveAndReview : 1,
            SaveAndSendLink : 2
        }
    };

})();