(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.Accordion");
    jd.ui.eid.require("sap.ui.core.Control");

    /**
     * The Accordion control is a custom control (similar to the standard <i>commons.Accordion</i> control) that si used in the application to
     * display Evidence Paclage Summary DTCs, DTAC Cases and Warranty Claims. Irrespective of the number of sections in the Accordion, there is always
     * exactly 1 instance of the template (and this is how it differes from the standard Accordion). This is more memory-effecient and fast (because
     * less rendering is required).
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>noDataText : String The text that is rendered if there are no sections to render.</li>
     * <li>collapseTooltip : String The tooltip shown on the open section's header.</li>
     * <li>expandTooltip : String the tooltip shown on the closed sections' headers. </li>
     * <li>defaultOpenSectionIndex : Integer the index of the section that should be open by default. </li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>sections : jd.ui.eid.control.AccordionSection The sections that the Accordion contains.</li>
     * <li>itemTemplate : sap.ui.core.Control The control to be used as the template for each open Accordion section.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.Accordion", /** @lends jd.ui.eid.control.Accordion */
    {
        metadata : {
            properties : {
                "_openSectionId" : {
                    type : "string"
                },
                "noDataText" : {
                    type : "string"
                },
                "collapseTooltip" : {
                    type : "string"
                },
                "expandTooltip" : {
                    type : "string"
                },
                "defaultOpenSectionIndex" : {
                    type : "int",
                    defaultValue : 0
                }
            },
            aggregations : {
                "sections" : {
                    type : "jd.ui.eid.control.AccordionSection",
                    multiple : true,
                    singularName : "section"
                },

                "itemTemplate" : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            },
            events : {
                onBeforeSectionOpening : {}
            }
        },

        /**
         * Invoked by framework when there is a click within the Accordion. The method determines the AccordionSection that was clicked, sets it to
         * 'open' and triggers a rerender of the control.
         * 
         * @param {jQuery.Event}
         *            oEvent the event.
         */
        onclick : function(oEvent) {
            // If click event is from within the actions DIV, then the Accordion control doesn't need to react to it.
            if (this._isEventFromAction(oEvent)) {
                return;
            }

            var oClickedSection = this._getClickedSection(oEvent);
            if (!oClickedSection) {
                return;
            }

            if (oClickedSection.getSectionId() == this.get_openSectionId()) {
                this.set_openSectionId("-1");
            } else {
                this.set_openSectionId(oClickedSection.getSectionId());
            }
        },

        /**
         * Invoked when the user 'mousedown's in the control. The CSS style on the SectionHeader needs to be updated. This is not done with CSS (using
         * state selectors), because the style should NOT be applied if the mousedown event is on any of the actions.
         * 
         * @param {jQuery.Event}
         *            oEvent the event
         */
        onmousedown : function(oEvent) {
            if (!this._isEventFromAction(oEvent)) {
                var oClickedSection = this._getClickedSection(oEvent);
                if (oClickedSection) {
                    this._lastHandledMouseEvent = "mousedown";
                    oClickedSection.$().find(".jdUiEidAccordionSectionHeader").addClass("jdUiEidAccordionSectionHeaderPressed");
                }
            }
        },

        /**
         * Invoked when the user 'mouseup's in the control. CSS of the header is updated to adjust the background image sprite position.
         * 
         * @param {jQuery.Event}
         *            oEvent the event
         */
        onmouseup : function(oEvent) {
            this._lastHandledMouseEvent = "mouseup";
            this._removePressedStyle();
        },

        /**
         * Invoked when the user 'mouseout's out of the control. If the user is trying to do something like a drag on the Section (but not technically
         * a drag, since section headers don't allow dragging), then remove the 'pressed' CSS class from any section that has it.
         * 
         * @param {jQuery.Event}
         *            oEvent the event
         */
        onmouseout : function(oEvent) {
            if (this._lastHandledMouseEvent === "mousedown") {
                this._removePressedStyle();
            }
        },

        /**
         * Helper method. Removes the 'pressed' style class from any section within the accordion that has it.
         */
        _removePressedStyle : function() {
            this.$().find(".jdUiEidAccordionSectionHeaderPressed").removeClass("jdUiEidAccordionSectionHeaderPressed");
        },

        /**
         * Helper method. Accepts a jQuery click event and determines the AccordionSection that caused the event to occur.
         * 
         * @param {jQuery.Event}
         *            oEvent the event
         * @returns {jd.ui.eid.control.AccordionSection} the element that represents the accordion section on the UI that generated the click event (<i>oEvent</i>)
         */
        _getClickedSection : function(oEvent) {
            // Check if a closed section header was clicked. Otherwise, exit.
            var oSource = oEvent.srcControl;
            var $Source = oSource.$();
            while (!$Source.hasClass("jdUiEidAccordionSection")) {
                if ($Source.length == 0) {
                    return null;
                }
                // if not clicked on the Accordion Section Hearder, but within the template->do nothing
                if ($Source.hasClass("jdUiEidAccordionSectionContent")) {
                    return null;
                };
                $Source = $Source.parent();
            }

            // Get the UI5 representation of the 'jdUiEidAccordionSection' (the corresponding element)
            var sSourceId = $Source.attr("id");
            return sap.ui.getCore().byId(sSourceId);
        },

        /**
         * Helper method. Returns true if oEvent was generated by an element within the 'jdUiEidAccordionSectionHeaderActions' DIV
         * 
         * @param {jQuery.Event}
         *            oEvent the event
         */
        _isEventFromAction : function(oEvent) {
            var $Source = oEvent.srcControl.$();
            while (!$Source.hasClass("jdUiEidAccordionSectionHeaderActions")) {
                if ($Source.length == 0) {
                    return false;
                }

                // if parent.parent.par.. gets to SectionHeader before getting to SectionHeaderActions, that means the event isn't from any of the
                // actions
                if ($Source.hasClass("jdUiEidAccordionSectionHeader")) {
                    return false;
                }

                $Source = $Source.parent();
            }

            return true;
        },

        /**
         * Helper method. Sets the <i>collapsed</i> property of all <i>AccordionSection</i>s to <i>true</i>
         */
        _setAllSectionsClosed : function() {
            $.each(this.getSections(), function(i, oSection) {
                oSection.setCollapsed(true);
            });
        },

        /**
         * Helper method. Updates the bound context of the item template
         * 
         * @param {sap.ui.mode.Context}
         *            oContext the context that needs to be set as the item template's binding context
         */
        _setItemTemplateContext : function(oContext) {
            this.getItemTemplate().setBindingContext(oContext);
        },

        /**
         * Stores the name of the mouse event (mouseup, mousedown etc.) that was handled by the control
         */
        _lastHandledMouseEvent : "",

        renderer : "jd.ui.eid.control.AccordionRenderer"

    });
})();
