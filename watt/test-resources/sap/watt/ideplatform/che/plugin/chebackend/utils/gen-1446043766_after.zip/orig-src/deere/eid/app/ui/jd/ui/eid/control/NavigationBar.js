(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.NavigationBar");
    jd.ui.eid.require("sap.ui.core.delegate.ItemNavigation");
    jd.ui.eid.require("jd.ui.eid.control.NavigationItem");
    jd.ui.eid.require("jquery.sap.dom");
    jd.ui.eid.require("sap.ui.core.Control");

    /**
     * This custom navigation bar is implemented to achieve the 'resizing' effect of the NavigationBar pointer that indicates the currently selected
     * workset item.
     * 
     * @class
     * @name jd.ui.eid.control.NavigationBar
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.NavigationBar", /** @lends jd.ui.eid.control.NavigationBar */
    {
        metadata : {
            // ---- object ----
            publicMethods : [
            // methods
            "setAssociatedItems", "isSelectedItemValid"],

            // ---- control specific ----
            properties : {
                "toplevelVariant" : {
                    type : "boolean",
                    group : "Misc",
                    defaultValue : false
                },
                "visible" : {
                    type : "boolean",
                    group : "Appearance",
                    defaultValue : true
                }
            },
            defaultAggregation : "items",
            aggregations : {
                "items" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : true,
                    singularName : "item"
                },
                "overflowMenu" : {
                    type : "sap.ui.commons.Menu",
                    multiple : false,
                    visibility : "hidden"
                }
            },
            associations : {
                "selectedItem" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : false
                },
                "associatedItems" : {
                    type : "jd.ui.eid.control.NavigationItem",
                    multiple : true,
                    singularName : "associatedItem"
                }
            },
            events : {
                "select" : {
                    allowPreventDefault : true
                }
            }
        }
    });

    /**
     * Overriding the _updateSelection method to adjust the animation of the navigationBar pointer. As per our requirements, the pointer's width must
     * be resized according to the size of the selected workset item
     * 
     * @param {string}
     *            sItemId DOM ID of the selection
     */
    jd.ui.eid.control.NavigationBar.prototype._updateSelection = function(sItemId) {
        // update the css classes to make the selected item larger etc.
        var $newSel = jQuery.sap.byId(sItemId);
        $newSel.prop("tabindex", "0").prop("aria-checked", "true");
        $newSel.parent().addClass("jdUiEidNavBarItemSel");
        $newSel.parent().parent().children().each(function() {
            var a = this.firstChild;
            if (a && (a.id != sItemId) && (a.className.indexOf("Dummy") == -1)) {
                jQuery(a).prop("tabindex", "-1"); // includes arrow and dummy, but does not hurt
                // TODO?
                jQuery(a).parent().removeClass("jdUiEidNavBarItemSel");
                jQuery(a).prop("aria-checked", "false");
            }
        });

        // let the ItemNavigation know about the new selection
        var iSelectedDomIndex = $newSel.parent().index();
        if (iSelectedDomIndex > 0) {
            iSelectedDomIndex--; // if a selected element is found, its index in the
            // ItemNavigation is the DOM index minus the dummy element,
            // which is the first sibling
        }
        this._oItemNavigation.setSelectedIndex(iSelectedDomIndex);

        // make the arrow slide to the selected item
        var $Arrow = jQuery.sap.byId(this.getId() + "-arrow");

        // Custom part starts ------->
        // Find out the width that the pointer bar should have.
        // Do this ONLY for the top NavigationBar
        var arrowWidth;
        var targetPos;
        if ($newSel.parent().parent().parent().hasClass("jdUiEidNavBarToplevel")) {
            arrowWidth = this._getCustomArrowWidth($newSel);
            targetPos = this._getCustomArrowPos($newSel);
        } else {
            // Standard behaviour
            arrowWidth = $Arrow.width();
            targetPos = jd.ui.eid.control.NavigationBar._getArrowTargetPos(sItemId, arrowWidth, this._bRtl);
        }

        $Arrow.stop(); // stop any ongoing animation

        // Custom : Along with position, also change the width of the pointer bar
        var animation_1 = this._bRtl ? {
            right : targetPos + "px",
            width : arrowWidth
        } : {
            left : targetPos + "px",
            width : arrowWidth
        };
        $Arrow.animate(animation_1, 500, "linear");
        var that = this;
        window.setTimeout(function() { // because the items resize (for 300ms), interrupt and
            // adjust the animation in the middle
            if ($newSel.parent().parent().parent().hasClass("jdUiEidNavBarToplevel")) {
                arrowWidth = that._getCustomArrowWidth($newSel);
                targetPos = that._getCustomArrowPos($newSel);
            } else {
                // Standard behaviour
                arrowWidth = $Arrow.width();
                targetPos = jd.ui.eid.control.NavigationBar._getArrowTargetPos(sItemId, arrowWidth, that._bRtl);
            }

            $Arrow.stop();
            var animation_2 = that._bRtl ? {
                right : targetPos + "px",
                width : arrowWidth
            } : {
                left : targetPos + "px",
                width : arrowWidth
            };
            // <------- Custom part ends
            $Arrow.animate(animation_2, 200, "linear", function() {
                var item = jQuery.sap.domById(sItemId);
                that._scrollItemIntoView(item);
            });
        }, 300);
    };

    /**
     * Overriding this method as we need custom logic to determine the 'navigation item bar's initial width and position.
     * 
     * @see jd.ui.eid.control.NavigationBar
     */
    jd.ui.eid.control.NavigationBar.prototype._calculatePositions = function() {
        var sId = this.getId();
        var oDomRef = jQuery.sap.domById(sId);

        var oListDomRef = oDomRef.firstChild;
        var of_back = jQuery.sap.domById(sId + "-ofb");
        var of_fw = jQuery.sap.domById(sId + "-off");

        // re-initialize display of scroll arrows
        this._bPreviousScrollForward = false;
        this._bPreviousScrollBack = false;
        this._checkOverflow(this.getDomRef().firstChild, jQuery.sap.domById(sId + "-ofb"), jQuery.sap.domById(sId + "-off"));

        // paint selection arrow in the right place
        var selItem = sap.ui.getCore().byId(this.getSelectedItem());
        if (selItem) {
            // Custom part starts ------>
            var $selItem = jQuery.sap.byId(selItem.getId());
            this._checkOverflow(oListDomRef, of_back, of_fw);
            var $Arrow = jQuery.sap.byId(this.getId() + "-arrow");

            // Set initial width
            var arrowWidth, targetPos;
            if (this.getToplevelVariant()) {
                arrowWidth = this._getCustomArrowWidth($selItem);
                targetPos = this._getCustomArrowPos($selItem);
            } else {
                arrowWidth = 0;
                targetPos = jd.ui.eid.control.NavigationBar._getArrowTargetPos(selItem.getId(), arrowWidth, this._bRtl);
            }
            $Arrow.width(arrowWidth);
            // <------ Custom part ends

            if (!this._bRtl) {
                $Arrow[0].style.left = targetPos + "px";
            } else {
                $Arrow[0].style.right = targetPos + "px";
            }
        }
    };

    /**
     * Gets the position (left or right depending on RTL setting) for the custom navigation bar's 'pointer' bar.
     * 
     * @param {object}
     *            $selectedWSI jQuery object representing the selected workset item DOM element.
     * @returns {Integer} The target position (in px) of the 'pointer bar', based on the length of the text in the currently selected workset item
     */
    jd.ui.eid.control.NavigationBar.prototype._getCustomArrowPos = function($selectedWSI) {
        var iContainerScroll = $selectedWSI.parent().parent().scrollLeft();
        return this._bRtl ? $selectedWSI.parent().offset().right + 26 - iContainerScroll : $selectedWSI.parent().offset().left - 26
                + iContainerScroll;
    };

    /**
     * Gets the width of the top level NavigationBar's 'pointer bar' that indicates the selected workset item
     * 
     * @param {object}
     *            $selectedWSI
     * @returns {Integer} The target width (in px) of the 'pointer bar', based on the length of the text in currently the selected workset item.
     */
    jd.ui.eid.control.NavigationBar.prototype._getCustomArrowWidth = function($selectedWSI) {
        return $selectedWSI.parent().width() - 30;
    };

    // ================= Unmodified methods from jd.ui.eid.control.NavigationBar ================
    jd.ui.eid.control.NavigationBar.SCROLL_STEP = 250; // how many pixels to scroll with every overflow arrow click
    // jd.ui.eid.control.NavigationBar._MAX_ITEM_WIDTH = 300;

    jd.ui.eid.control.NavigationBar.prototype.init = function() {
        this._bPreviousScrollForward = false; // remember the item overflow state
        this._bPreviousScrollBack = false;
        this._iLastArrowPos = -100; // this property is always read and applied as "left"/"right" depending on RTL configuration
        this._bRtl = sap.ui.getCore().getConfiguration().getRTL();

        this.allowTextSelection(false);

        this.startScrollX = 0;
        this.startTouchX = 0;
        var that = this;

        // Initialize the ItemNavigation
        this._oItemNavigation = new sap.ui.core.delegate.ItemNavigation().setCycling(false);
        this.addDelegate(this._oItemNavigation);

        if (jQuery.sap.touchEventMode === "ON") {
            var fnTouchStart = function(evt) {
                evt.preventDefault();

                // stop any inertia scrolling
                if (that._iInertiaIntervalId) {
                    window.clearInterval(that._iInertiaIntervalId);
                }

                that.startScrollX = jQuery.sap.domById(that.getId() + "-list").scrollLeft;
                that.startTouchX = evt.touches[0].pageX;
                that._bTouchNotMoved = true;
                that._lastMoveTime = new Date().getTime();
            };

            var fnTouchMove = function(evt) {
                var dx = evt.touches[0].pageX - that.startTouchX;

                var oListRef = jQuery.sap.domById(that.getId() + "-list");
                var oldScrollLeft = oListRef.scrollLeft;
                var newScrollLeft = that.startScrollX - dx;
                oListRef.scrollLeft = newScrollLeft;
                that._bTouchNotMoved = false;

                // inertia scrolling: prepare continuation even after touchend by calculating the current velocity
                var dt = new Date().getTime() - that._lastMoveTime;
                that._lastMoveTime = new Date().getTime();
                if (dt > 0) {
                    that._velocity = (newScrollLeft - oldScrollLeft) / dt;
                }

                evt.preventDefault();
            };

            var fnTouchEnd = function(evt) {
                if (that._bTouchNotMoved === false) { // swiping ends now
                    evt.preventDefault();

                    // add some inertia... continue scrolling with decreasing velocity
                    var oListRef = jQuery.sap.domById(that.getId() + "-list");
                    var dt = 50;
                    var endVelocity = Math.abs(that._velocity / 10); // continue scrolling until the speed has decreased to a fraction (v/10 means
                    // 11 iterations with slowing-down factor 0.8)
                    that._iInertiaIntervalId = window.setInterval(function() {
                        that._velocity = that._velocity * 0.80;
                        var dx = that._velocity * dt;
                        oListRef.scrollLeft = oListRef.scrollLeft + dx;
                        if (Math.abs(that._velocity) < endVelocity) {
                            window.clearInterval(that._iInertiaIntervalId);
                            that._iInertiaIntervalId = undefined;
                        }
                    }, dt);

                } else if (that._bTouchNotMoved === true) { // touchstart and touchend without move is a click; trigger it directly to avoid the usual
                    // delay
                    that.onclick(evt);
                    evt.preventDefault();
                } else {
                    // touchend without corresponding start
                    // do nothing special
                }
                that._bTouchNotMoved = undefined;
                that._lastMoveTime = undefined;
            };

            this.ontouchstart = fnTouchStart;
            this.ontouchend = fnTouchEnd;
            this.ontouchmove = fnTouchMove;
        }

    };

    jd.ui.eid.control.NavigationBar.prototype.exit = function() {
        if (this._oItemNavigation) {
            this.removeDelegate(this._oItemNavigation);
            this._oItemNavigation.destroy();
            delete this._oItemNavigation;
        }

        // no super.exit() to call
    };

    jd.ui.eid.control.NavigationBar.prototype.onBeforeRendering = function() {
        // stop the periodic overflow checker
        if (this._checkOverflowIntervalId) {
            jQuery.sap.clearIntervalCall(this._checkOverflowIntervalId);
            this._checkOverflowIntervalId = null;
        }

        if (!!sap.ui.Device.browser.firefox) { // TODO: feature detection... not used yet because of performance implications (may involve creating
            // elements)
            this.$().unbind("DOMMouseScroll", this._handleScroll);
        } else {
            this.$().unbind("mousewheel", this._handleScroll);
        }

        var arrow = jQuery.sap.domById(this.getId() + "-arrow");
        this._iLastArrowPos = arrow ? parseInt(this._bRtl ? arrow.style.right : arrow.style.left, 10) : -100;
    };

    /**
     * Attaches to a themechange and recalculates the positions of the arrows in the NavigationBar
     */
    jd.ui.eid.control.NavigationBar.prototype.onThemeChanged = function() {
        if (this.getDomRef()) {
            // this._calculatePositions();
        }
    };

    jd.ui.eid.control.NavigationBar.prototype.onAfterRendering = function() {
        var sId = this.getId();
        var oDomRef = jQuery.sap.domById(sId);

        // start the periodic checking for overflow of the item area
        var oListDomRef = oDomRef.firstChild;
        var of_back = jQuery.sap.domById(sId + "-ofb");
        var of_fw = jQuery.sap.domById(sId + "-off");
        this._checkOverflowIntervalId = jQuery.sap.intervalCall(350, this, "_checkOverflow", [oListDomRef, of_back, of_fw]);

        // bind a scroll handler to the workset item area
        if (!!sap.ui.Device.browser.firefox) { // TODO: feature detection... not used yet because of performance implications (may involve creating
            // elements)
            jQuery(oDomRef).bind("DOMMouseScroll", jQuery.proxy(this._handleScroll, this));
        } else {
            jQuery(oDomRef).bind("mousewheel", jQuery.proxy(this._handleScroll, this));
        }

        // Wait for worksetItems resize animation to finish (when shell is rendererd) before calculating the bar length.
        var oControl = this;
        window.setTimeout(function() {
            oControl._calculatePositions();
        }, 500);

        this._updateItemNavigation();

        // Workaround for sporadic weird scrolling behavior in NavigationBar when there is
        // mobile content in the Shell.
        // TODO: We should get to the bottom of why this happens, but after 6 hours of debugging, I give up.
        // See for example CSS 0120061532 0002361191 2013 - HPAs had the same problems
        // This happens in the BC as well as GC theme
        var $NavBar = this.$();
        $NavBar.on("scroll", function() {
            $NavBar.children().scrollTop(0);
            $NavBar.scrollTop(0);
        });
    };

    jd.ui.eid.control.NavigationBar.prototype._updateItemNavigation = function() {
        var oDomRef = this.getDomRef();
        if (oDomRef) {
            // reinitialize the ItemNavigation after rendering
            var iSelectedDomIndex = -1;
            var sSelectedId = this.getSelectedItem();

            var $ItemRefs = jQuery(oDomRef).children().children("li").children().not(".jdUiEidNavBarDummyItem");
            $ItemRefs.each(function(index, element) {
                if (element.id == sSelectedId) {
                    iSelectedDomIndex = index;
                }
            });

            this._oItemNavigation.setRootDomRef(oDomRef);
            this._oItemNavigation.setItemDomRefs($ItemRefs.toArray());
            this._oItemNavigation.setSelectedIndex(iSelectedDomIndex);
        }
    };

    jd.ui.eid.control.NavigationBar.prototype.onsapspace = function(oEvent) {
        this._handleActivation(oEvent);
    };

    jd.ui.eid.control.NavigationBar.prototype.onclick = function(oEvent) {
        this._handleActivation(oEvent);
    };

    jd.ui.eid.control.NavigationBar.prototype._handleActivation = function(oEvent) {
        var sTargetId = oEvent.target.id;

        if (sTargetId) {
            var sId = this.getId();

            // For items: do not navigate away! Stay on the page and handle the click in-place. Right-click + "Open in new Tab" still works.
            // For scroll buttons: Prevent IE from firing beforeunload event -> see CSN 4378288 2012
            oEvent.preventDefault();

            if (sTargetId == sId + "-ofb") {
                // scroll back/left button
                this._scroll(-jd.ui.eid.control.NavigationBar.SCROLL_STEP, 500);

            } else if (sTargetId == sId + "-off") {
                // scroll forward/right button
                this._scroll(jd.ui.eid.control.NavigationBar.SCROLL_STEP, 500);
            } else if (sTargetId == sId + "-oflt" || sTargetId == sId + "-ofl") {
                // Overflow Button has been activated
                this._showOverflowMenu();
            } else {
                // should be one of the items - select it

                var item = sap.ui.getCore().byId(sTargetId);
                if (item && (sTargetId != this.getSelectedItem()) && (sap.ui.getCore().byId(sTargetId) instanceof jd.ui.eid.control.NavigationItem)) {
                    // select the item and fire the event
                    if (this.fireSelect({
                        item : item,
                        itemId : sTargetId
                    })) {
                        this.setAssociation("selectedItem", item, true); // avoid rerendering, animate
                        this._updateSelection(sTargetId);
                    }
                }
            }
        }
    };

    /**
     * Return the overflow Menu, creates it if it does not exist.
     * 
     * @returns {sap.ui.commons.Menu}
     */
    jd.ui.eid.control.NavigationBar.prototype._getOverflowMenu = function() {
        var oMenu = this.getAggregation("overflowMenu");
        if (!oMenu || this._menuInvalid) {
            // TODO: Check with new destroy-behavior: The Menu might not be there because it was already destroyed. In that case this might create a
            // memory leak.
            if (oMenu) {
                oMenu.destroyAggregation("items", true);
            } else {
                oMenu = new sap.ui.commons.Menu().addStyleClass("jdUiMnu");
            }

            var aItems = this._getCurrentItems();
            var that = this;
            var sSelectedId = this.getSelectedItem();

            for ( var i = 0; i < aItems.length; ++i) {
                var oNavItem = aItems[i];

                var oMenuItem = new sap.ui.commons.MenuItem(oNavItem.getId() + "-overflowItem", {
                    text : oNavItem.getText(),
                    visible : oNavItem.getVisible(),
                    // Like the normal NavigationBar Items, disabled items are shown and handled
                    // like enabled items. The application can check the item for its
                    // enabled-property
                    /* enabled : oNavItem.getEnabled(), */
                    icon : sSelectedId == oNavItem.getId() ? "sap-icon://accept" : null,
                    select : (function(oNavItem) {
                        return function(oEvent) {
                            that._handleActivation({
                                target : {
                                    id : oNavItem.getId()
                                },
                                preventDefault : function() { /* Ignore */
                                }
                            });
                        };
                    })(oNavItem)
                });
                oMenu.addAggregation("items", oMenuItem, true);
            }

            this.setAggregation("overflowMenu", oMenu, true);
            this._menuInvalid = false;
        }

        return oMenu;
    };

    /**
     * Returns the items added to the items aggregation, or (if empty) the items that are referred to in the associatedItems association.
     */
    jd.ui.eid.control.NavigationBar.prototype._getCurrentItems = function() {
        var aItems = this.getItems();
        if (aItems.length < 1) {
            aItems = this.getAssociatedItems();

            var oCore = sap.ui.getCore();
            for ( var i = 0; i < aItems.length; ++i) {
                aItems[i] = oCore.byId(aItems[i]);
            }
        }

        return aItems;
    };

    /**
     * Shows the menu items that do not fit into the navigation bar. Or in the case of overflow being set to MenuAndButtons: All items (since we
     * cannot know what is currently scrolled into view).
     */
    jd.ui.eid.control.NavigationBar.prototype._showOverflowMenu = function() {
        var oMenu = this._getOverflowMenu();
        var oTarget = jQuery.sap.byId(this.getId() + "-ofl").get(0);

        oMenu.open(true, // First item highlighted. Check whether this is the correct behavior
        oTarget, sap.ui.core.Popup.Dock.EndTop, sap.ui.core.Popup.Dock.CenterCenter, oTarget);
    };

    jd.ui.eid.control.NavigationBar.prototype._scrollItemIntoView = function(item) {
        if (!item) {
            return;
        }

        var li = jQuery(item.parentNode);
        var ul = li.parent();
        var targetPos = undefined;
        var bRtl = sap.ui.getCore().getConfiguration().getRTL();

        // special handling for first and last item to not only scroll them into view but to scroll to the very start/end
        var index = li.index() - 1; // -1 because of leading dummy item
        if (index == 0) {
            targetPos = bRtl ? (ul[0].scrollWidth - ul.innerWidth() + 20) : 0; // +20 to account for margins etc.
        } else if (index == li.siblings().length - 2) { // siblings() excludes the item itself, but (apart from the already subtracted dummy) also the
            // arrow => -2
            targetPos = bRtl ? 0 : (ul[0].scrollWidth - ul.innerWidth() + 20); // +20 to account for margins etc.
        } else {
            var liLeft = li.position().left;
            var ulScrollLeft = bRtl ? ul.scrollLeftRTL() : ul.scrollLeft();

            if (liLeft < 0) {
                // item cut at the left => scroll right to make it left-aligned
                targetPos = ulScrollLeft + liLeft;
            } else {
                var rightDistance = ul.innerWidth() - (liLeft + li.outerWidth(true)); // the distance from the right item edge to the end of the ul;
                // negative if the item is cut
                if (rightDistance < 0) {
                    targetPos = ulScrollLeft - rightDistance; // rightDistance is negative, add its amount to the current scroll amount
                    // but now it might be that we scroll so far to the left that the left part of the item is hidden, which may not happen!
                    targetPos = Math.min(targetPos, ulScrollLeft + liLeft);
                }
            }
        }

        if (targetPos !== undefined) {
            if (bRtl) {
                targetPos = jQuery.sap.denormalizeScrollLeftRTL(targetPos, ul.get(0)); // fix browser differences*/
            }
            ul.stop(true, true).animate({
                scrollLeft : targetPos
            }); // should be a string like "-50px"
        }
    };

    /**
     * Calculates the required position of the selection arrow to highlight the item with the given ID. If null is given, the position will be outside
     * the visible area.
     * 
     * If bRight is set, the distance to the *right* border will be returned (instead of the normal position from left), this can be used for RTL
     * mode.
     * 
     * @static
     * @private
     */
    jd.ui.eid.control.NavigationBar._getArrowTargetPos = function(sTargetItemId, arrowWidth, bRight) {
        var $Item = jQuery.sap.byId(sTargetItemId);
        if ($Item.length > 0) {
            var width = $Item.outerWidth(); // Math.min($Item.outerWidth(), jd.ui.eid.control.NavigationBar._MAX_ITEM_WIDTH);
            var leftDistance = Math.round($Item[0].offsetLeft + (width / 2) - (arrowWidth / 2));
            if (!bRight) {
                return leftDistance;
            } else {
                return $Item.parent().parent().innerWidth() - leftDistance - arrowWidth;
            }
        } else {
            return -100;
        }
    };

    /**
     * Handles a mouse scroll event, scrolling the items if possible.
     * 
     * @param oEvent
     * @private
     */
    jd.ui.eid.control.NavigationBar.prototype._handleScroll = function(oEvent) {
        if (oEvent.type == "DOMMouseScroll") { // Firefox
            var scrollAmount = oEvent.originalEvent.detail * 40; // in FF you get 3 ticks at once, *40 gives reasonable speed
            this._scroll(scrollAmount, 50); // scroll fast to avoid temporal overlap
        } else { // other browsers
            var scrollAmount = -oEvent.originalEvent.wheelDelta; // in IE you get 120 as basic amount, direction is inverted
            this._scroll(scrollAmount, 50); // scroll fast to avoid temporal overlap
        }
        oEvent.preventDefault(); // do not scroll the window (?)
    };

    /**
     * Scrolls the items if possible, using an animation.
     * 
     * @param iDelta
     *            how far to scroll
     * @param iDuration
     *            how long to scroll (ms)
     * @private
     */
    jd.ui.eid.control.NavigationBar.prototype._scroll = function(iDelta, iDuration) {
        var oDomRef = this.$()[0].firstChild;
        var iScrollLeft = oDomRef.scrollLeft;
        if (!!!sap.ui.Device.browser.internet_explorer && this._bRtl) {
            iDelta = -iDelta;
        } // RTL lives in the negative space
        var iScrollTarget = iScrollLeft + iDelta;
        jQuery(oDomRef).stop(true, true).animate({
            scrollLeft : iScrollTarget
        }, iDuration);
    };

    /**
     * Changes the state of the scroll arrows depending on whether they are required due to overflow.
     * 
     * @param oListDomRef
     *            the ul tag containing the items
     * @param of_back
     *            the backward scroll arrow
     * @param of_fw
     *            the forward scroll arrow
     * @private
     */
    jd.ui.eid.control.NavigationBar.prototype._checkOverflow = function(oListDomRef, of_back, of_fw) {
        if (oListDomRef) {
            var iScrollLeft = oListDomRef.scrollLeft;

            // check whether scrolling to the left is possible
            var bScrollBack = false;
            var bScrollForward = false;

            var realWidth = oListDomRef.scrollWidth;
            var availableWidth = oListDomRef.clientWidth;

            if (Math.abs(realWidth - availableWidth) == 1) { // Avoid rounding issues see CSN 1316630 2013
                realWidth = availableWidth;
            }

            if (!this._bRtl) { // normal LTR mode
                if (iScrollLeft > 0) {
                    bScrollBack = true;
                }
                if ((realWidth > availableWidth) && (iScrollLeft + availableWidth < realWidth)) {
                    bScrollForward = true;
                }

            } else { // RTL mode
                var $List = jQuery(oListDomRef);
                if ($List.scrollLeftRTL() > 0) {
                    bScrollForward = true;
                }
                if ($List.scrollRightRTL() > 0) {
                    bScrollBack = true;
                }
            }

            // only do DOM changes if the state changed to avoid periodic application of identical values
            if ((bScrollForward != this._bPreviousScrollForward) || (bScrollBack != this._bPreviousScrollBack)) {
                this._bPreviousScrollForward = bScrollForward;
                this._bPreviousScrollBack = bScrollBack;
                this.$().toggleClass("jdUiEidNavBarScrollBack", bScrollBack).toggleClass("jdUiEidNavBarScrollForward", bScrollForward);
            }
        }
    };

    /* API methods */

    /* overwritten association methods */

    jd.ui.eid.control.NavigationBar.prototype.setSelectedItem = function(vItem) {
        this.setAssociation("selectedItem", vItem, true); // avoid rerendering
        if (this.getDomRef()) {
            var sItemId = (!vItem || (typeof (vItem) == "string")) ? vItem : vItem.getId();
            this._updateSelection(sItemId); // animate selection
        }
    };

    /* overridden aggregation items */

    jd.ui.eid.control.NavigationBar.prototype.addItem = function(oItem) {
        this._menuInvalid = true;
        return this.addAggregation("items", oItem);
    };

    jd.ui.eid.control.NavigationBar.prototype.destroyItems = function() {
        this._menuInvalid = true;
        return this.destroyAggregation("items");
    };

    jd.ui.eid.control.NavigationBar.prototype.insertItem = function(oItem, iIndex) {
        this._menuInvalid = true;
        return this.insertAggregation("items", oItem, iIndex);
    };

    jd.ui.eid.control.NavigationBar.prototype.removeItem = function(oItem) {
        this._menuInvalid = true;
        return this.removeAggregation("items", oItem);
    };

    jd.ui.eid.control.NavigationBar.prototype.removeAllItems = function() {
        this._menuInvalid = true;
        return this.removeAllAggregation("items");
    };

    /* overridden association associatedItems */

    jd.ui.eid.control.NavigationBar.prototype.addAssociatedItem = function(vItemOrId) {
        this._menuInvalid = true;
        return this.addAssociation("associatedItems", vItemOrId);
    };

    jd.ui.eid.control.NavigationBar.prototype.removeAssociatedItem = function(vItemOrId) {
        this._menuInvalid = true;
        return this.removeAssociation("associatedItems", vItemOrId);
    };

    jd.ui.eid.control.NavigationBar.prototype.removeAllAssociatedItems = function() {
        this._menuInvalid = true;
        return this.removeAllAssociation("associatedItems");
    };

    /* API method implementations */

    jd.ui.eid.control.NavigationBar.prototype.setAssociatedItems = function(aItems /* bResetArrowPosition */) { // second parameter is currently not
        // in the public API
        jQuery.sap.assert(jQuery.isArray(aItems), "aItems must be an array");

        var oListDomRef = jQuery.sap.domById(this.getId() + "-list");

        // remove old items
        this.removeAllAssociation("associatedItems", true);

        // add new items
        for ( var i = 0; i < aItems.length; i++) {
            this.addAssociation("associatedItems", aItems[i], true);
        }

        // if already rendered, update the UI
        if (oListDomRef) {
            var $FocusRef = jQuery(oListDomRef).find(":focus");
            var focusId = ($FocusRef.length > 0) ? $FocusRef.prop("id") : null;

            if (arguments.length > 1 && typeof arguments[1] === "boolean") { // checking for the second, hidden parameter "bResetArrowPosition"
                this._iLastArrowPos = -100;
            } else {
                var arrow = jQuery.sap.domById(this.getId() + "-arrow");
                this._iLastArrowPos = parseInt(this._bRtl ? arrow.style.right : arrow.style.left, 10);
            }

            oListDomRef.innerHTML = "";
            var rm = sap.ui.getCore().createRenderManager();

            jd.ui.eid.control.NavigationBarRenderer.renderItems(rm, this);

            rm.flush(oListDomRef, true);
            rm.destroy();

            // restore focus
            var oNewFocusRef;
            if (focusId && (oNewFocusRef = jQuery.sap.domById(focusId))) {
                jQuery.sap.focus(oNewFocusRef);
            }

            this._updateSelection(this.getSelectedItem());

            // update the item navigation, as the item HTML has changed
            this._updateItemNavigation();
        }

        return this;
    };

    jd.ui.eid.control.NavigationBar.prototype.isSelectedItemValid = function() {
        var selId = this.getSelectedItem();
        if (!selId) {
            return false;
        } // no selection means no selected item out of those which are present

        var items = this.getItems();
        if (!items || items.length == 0) {
            items = this.getAssociatedItems();
            for ( var i = 0; i < items.length; i++) {
                if (items[i] == selId) {
                    return true;
                }
            }
        } else {
            for ( var i = 0; i < items.length; i++) {
                if (items[i].getId() == selId) {
                    return true;
                }
            }
        }
        return false;
    };
})();