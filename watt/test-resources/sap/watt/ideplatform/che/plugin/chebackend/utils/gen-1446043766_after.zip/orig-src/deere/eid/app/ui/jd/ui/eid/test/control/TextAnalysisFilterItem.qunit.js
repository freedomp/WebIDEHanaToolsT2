(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.TextAnalysisFilterItem");

    var oFilterItem = null;
    var oModel = null;
    var oDTCCodeTemplate = new sap.ui.core.Item({
        key : "{id}",
        text : "{code}"
    });
    var oData = {
        EvidencePackageDetails : {
            DTCFilters : {
                DTCCode : [{
                    id : 1,
                    code : "dtcCode1"
                }, {
                    id : 2,
                    code : "dtcCode2"
                }]
            }
        },
        FilterSelection : {
            TextAnalysis : {
                SearchMode : "Exact",
                SelectedValues : [2]
            },
        }
    };

    module("jd.ui.eid.control.TextAnalysisFilterItem", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(oData);
            oFilterItem = new jd.ui.eid.control.TextAnalysisFilterItem({
                subListItems : {
                    path : "/EvidencePackageDetails/DTCFilters/DTCCode",
                    template : oDTCCodeTemplate
                }
            });
            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    // *** TEST CASE #1 ***
    test("_clear() should set the selection property to an object with empty properties.", function() {
        oFilterItem.bindProperty('selection', '/FilterSelection/TextAnalysis');

        // Initial assertions
        equals(oFilterItem.getSelection(), oData.FilterSelection.TextAnalysis);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertions
        equal(oFilterItem.getSelection().SearchMode, "");
        equal(oFilterItem.getSelection().SelectedValues.length, 0);
    });

    // *** TEST CASE #2 ***
    test("_clear() should not call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oFilterItem._clear();

        // Final assertion
        ok(!spy.called);
    });

    // *** TEST CASE #3 ***
    test("addSubListItem() should add a new listitem to the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        var iOldCount = _subListBox.getItems().length;

        var oItem = new sap.ui.core.Item({
            key : "3",
            text : "test3Test"
        });

        oFilterItem.addSubListItem(oItem);
        var iNewCount = _subListBox.getItems().length;
        equal(iOldCount + 1, iNewCount);

    });

    // *** TEST CASE #4 ***
    test("destroySubListItems() should destroy all items of the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        oFilterItem.destroySubListItems();
        var aItems = _subListBox.getItems();
        deepEqual(aItems, []);
    });

    // *** TEST CASE #5 ***
    test("getSubListItems() should return all items from the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        var aItems = _subListBox.getItems();
        deepEqual(aItems, oFilterItem.getSubListItems());
    });

    // *** TEST CASE #6 ***
    test("indexOfSubListItem() should return the index of the item in the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        var oItem = new sap.ui.core.Item({
            key : "3",
            text : "test3Test"
        });
        _subListBox.addItem(oItem);
        var iIndex = _subListBox.indexOfItem(oItem);
        deepEqual(iIndex, oFilterItem.indexOfSubListItem(oItem));
    });

    // *** TEST CASE #7 ***
    test("insertSubListItem() should add a new item at a specfic index to the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");

        var oItem = new sap.ui.core.Item({
            key : "7",
            text : "test7Test"
        });

        oFilterItem.insertSubListItem(oItem, 2);
        var oItem2 = _subListBox.getItems()[2];
        deepEqual(oItem, oItem2);

    });

    // *** TEST CASE #8 ***
    test("insertSubListItem() should also call method _updateSubListCounterString", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, '_updateSubListCounterString');

        var oItem = new sap.ui.core.Item({
            key : "8",
            text : "test8Test"
        });

        // Initial assertion
        var callCount = spy.callCount;
        oFilterItem.insertSubListItem(oItem, 2);
        // Initial assertion
        equal(callCount + 1, spy.callCount);
    });

    // *** TEST CASE #9 ***
    test("removeAllSubListItems() should remove all items from the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        oFilterItem.removeAllSubListItems();
        var aItems = _subListBox.getItems();
        deepEqual(aItems, []);
    });

    // *** TEST CASE #10 ***
    test("removeSubListItem() should remove a specific item from the _subListBox aggregation", function() {
        var _subListBox = oFilterItem.getAggregation("_subListBox");
        var oItem = new sap.ui.core.Item({
            key : "10",
            text : "test10Test"
        });
        _subListBox.addItem(oItem);
        var iOldCount = _subListBox.getItems().length;
        oFilterItem.removeSubListItem(oItem);
        var iNewCount = _subListBox.getItems().length;
        equal(iOldCount - 1, iNewCount);
    });

    // *** TEST CASE #11 ***
    test("setSelection() should set the property selection", function() {
        oFilterItem.setProperty('selection', null);
        var oSelection = {
            SearchMode : "Exact",
            SelectedValues : ["2"]
        };
        oFilterItem.setSelection(oSelection);
        var oSelection2 = oFilterItem.getProperty('selection');
        deepEqual(oSelection, oSelection2);
    });

    // *** TEST CASE #12 ***
    test("setSelection() should set select an _listBox item by key", function() {
        oFilterItem.setProperty('selection', null);
        var oSelection = {
            SearchMode : "Exact",
            SelectedValues : ["2"]
        };
        oFilterItem.setSelection(oSelection);
        var oListBox = oFilterItem.getAggregation("_listBox");
        var sSelectedKey = oListBox.getSelectedKeys()[0];
        equal(oSelection.SearchMode, sSelectedKey);
    });

    // *** TEST CASE #13 ***
    test("setSelection() should select an _subListBox item by key", function() {
        oFilterItem.setProperty('selection', null);
        var oSelection = {
            SearchMode : "Exact",
            SelectedValues : ["1"]
        };
        oFilterItem.setSelection(oSelection);
        var oSubListBox = oFilterItem.getAggregation("_subListBox");
        var aSelectedKeys = oSubListBox.getSelectedKeys();
        deepEqual(oSelection.SelectedValues, aSelectedKeys);
    });

    // *** TEST CASE #14 ***
    test("_updateSubListCounterString() should change the subListCounter", function() {
        oFilterItem.setProperty("subListCounter", "(0/0)");
        var sSubListCounter = oFilterItem.getProperty("subListCounter");
        oFilterItem.bindProperty('selection', '/FilterSelection/TextAnalysis');
        oFilterItem._updateSubListCounterString();
        var sSubListCounter2 = oFilterItem.getProperty("subListCounter");
        notEqual(sSubListCounter, sSubListCounter2);
    });

    // *** TEST CASE #15 ***
    test("_updateSelection() should update the selection property by the selected listbox and sublistbox values", function() {
        oFilterItem.setProperty("selection", null);
        var aSelectedValues = ["Exact"];
        var aSelectedSubValues = [1];
        oFilterItem.getAggregation("_listBox").setSelectedKeys(aSelectedValues);
        oFilterItem.getAggregation("_subListBox").setSelectedKeys(aSelectedSubValues);
        oFilterItem._updateSelection();
        var oSelection = oFilterItem.getProperty("selection");
        equal(aSelectedValues[0], oSelection.SearchMode);
        deepEqual(aSelectedSubValues, oSelection.SelectedValues);
    });

    // *** TEST CASE #16 ***
    test("_updateSelection() should call _updateSubListCounterString()", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, '_updateSubListCounterString');

        // Initial assertion
        ok(!spy.called);

        oFilterItem._updateSelection();
        // Initial assertion
        ok(spy.called);
    });

    // *** TEST CASE #17 ***
    test("_updateSelection() should call fireValueChanged().", function() {
        // Register spy
        var spy = sinon.spy(oFilterItem, 'fireValueChanged');

        // Initial assertion
        ok(!spy.called);

        // Execute the business logic
        oFilterItem._updateSelection();

        // Final assertion
        ok(spy.called);
    });

})();