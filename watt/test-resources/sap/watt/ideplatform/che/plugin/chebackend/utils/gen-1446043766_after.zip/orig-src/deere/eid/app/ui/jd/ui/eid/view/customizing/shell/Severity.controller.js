(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.customizing.shell.BaseController");

    /**
     * @class The controller handles a table of 'severity rating & warning light' pairs retrieved from the backend that can be updated or deleted by
     *        the user and the user can add new pairs. Changing or adding a pair is done via a dialog (see
     *        <code>jd.ui.eid.fragment.dialog.customizing.AddEditSeverityDialog.xml</code>), where all values can be changed. Both fields are
     *        mandatory. The severity rating has to be numeric. Validation is done in {@link #.handleDialogOk}. The deletion of a row has to be
     *        confirmed by the user (see {@link #.handleDeleteRow}).
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.customizing.shell.Severity
     * @augments jd.ui.eid.view.customizing.shell.BaseController
     */
    sap.ui.controller("jd.ui.eid.view.customizing.shell.Severity", jQuery.extend(true, {}, jd.ui.eid.view.customizing.shell.BaseController, /** @lends jd.ui.eid.view.customizing.shell.Severity */
    {
        /* Configuration */

        _mConfig : {
            mFetchData : {
                sMethodName : "getSeverity"
            },
            mSendData : {
                sPath : "/SeverityValues",
                sMethodName : "updateSeverity",
                sSuccessTextKey : "SEVERITY_MAPPING_TABLE_MSG_SAVE_SUCCESSFUL"
            },
            mDialog : {
                sId : "AddEditSeverityDialog",
                sFragment : "jd.ui.eid.fragment.dialog.customizing.AddEditSeverityDialog",
                sContextPath : "/SeverityDialog"
            },
            mHelpDialog : {
                sLongTextKey : "SEVERITY_MAPPING_EXP_HELP_TEXT",
                sTitleTextKey : "SEVERITY_MAPPING_HED_HELP_DIALOG"
            },
            sTableId : "table"
        },

        /* View Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleEditRowHookBefore
         */
        handleEditRowHookBefore : function(oEvent) {
            // Flag to check if dialog has been called to create or update severity.
            this._bNewDialogFlag = false;

            // Set title for dialog box
            var oDialogBox = this.getDialogBox();
            oDialogBox.bindProperty("title", "i18n>SEVERITY_MAPPING_DETAILS_HED_UPDATE_DIALOG");
        },

        /**
         * This function inserts a new row on click of insert button.
         */
        handleInsertRow : function(oEvent) {
            // Flag to check if dialog has been called to create or update severity.
            this._bNewDialogFlag = true;
            var oDialogBox = this.getDialogBox();
            var oModel = sap.ui.getCore().getModel();
            // Copying object to new path for dialog binding
            oModel.setProperty("/SeverityDialog", {
                WarningLight : "",
                SeverityRating : "",
                Default : 0
            });

            oDialogBox.bindContext("/SeverityDialog");
            // Set title for dialog box
            oDialogBox.bindProperty("title", "i18n>SEVERITY_MAPPING_DETAILS_HED_NEW_DIALOG");
            oDialogBox.open();
        },

        /**
         * This function get the selected row and delete it from the table model.
         */
        handleDeleteRow : function() {
            // Get the selected row index
            var oTable = this._oView.byId("table");
            var iRowIndex = oTable.getSelectedIndex();
            // This shouldn't happen, but don't proceed if no row is selected
            if (iRowIndex == -1) {
                return;
            }
            var oContext = oTable.getContextByIndex(iRowIndex);
            // Function to confirm if user has opted to delete values.
            var that = this;
            var fnOnDeleteConfirmation = function(bConfirmed) {
                if (bConfirmed) {
                    // To get model data to delete row from model directly.
                    var oModel = oTable.getModel();
                    var oArrayData = oModel.getProperty("/SeverityValues");
                    var iArrayIndex = $.inArray(oContext.getProperty(), oArrayData);
                    if (iArrayIndex == -1) {
                        $.sap.log.error("The context of the row which was selected for deletion wasn't found in the model.", null,
                                'jd.ui.eid.view.customizing.shell.Severity');
                        return;
                    }
                    oArrayData.splice(iArrayIndex, 1);
                    // Setting back data to the model.
                    oModel.setProperty("/SeverityValues", oArrayData);

                    // Eventually update the table to show the proper row count (this would also happen automatically but with a short delay and we
                    // don't want that), as well as resetting the row selection.
                    oTable.setVisibleRowCount(oArrayData.length);
                    oTable.setSelectedIndex(-1);

                    // Also update the data loss manager
                    that._oDLM.setDirty(true);
                }
            };

            // Get confirmation from user before proceeding
            var oContext = oTable.getContextByIndex(oTable.getSelectedIndex());
            var sConfirmationMessage = jd.ui.eid.common.I18NHelper.getText("SEVERITY_MAPPING_TABLE_MSW_CONFIRM_DELETE", [
                    oContext.getProperty("WarningLight"), oContext.getProperty("SeverityRating")]);
            this.getNotificationCenter().confirm(sConfirmationMessage, fnOnDeleteConfirmation);

        },

        /**
         * Handles the row selection of the table and disables/enables the buttons in the toolbar.
         */
        handleRowSelection : function() {
            var oTable = this.byId("table");
            var iSelectedIndex = oTable.getSelectedIndex();
            var oContext = oTable.getContextByIndex(iSelectedIndex);
            var oDeleteButton = this.byId("deleteButton");

            if (oContext && oContext.getProperty('Default') != true && iSelectedIndex >= 0) {
                // The default may not be deleted by the user.
                oDeleteButton.setEnabled(true);
            } else {
                oDeleteButton.setEnabled(false);
            }
        },

        /* Dialog Handling */

        /**
         * @see jd.ui.eid.view.customizing.shell.BaseController#handleDialogBeforeOpenHook
         */
        handleDialogBeforeOpenHook : function() {
            // Detach all error tooltips from controls
            var oWarningLight = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "WarningLight");
            var oSeverityRating = sap.ui.core.Fragment.byId(this._mConfig.mDialog.sId, "SeverityRating");
            this.detachErrorTooltipFromControl(oWarningLight);
            this.detachErrorTooltipFromControl(oSeverityRating);
        },

        /**
         * This method sets back values to the given row.
         */
        handleDialogOk : function() {
            if (this.validateWarningLight() & this.validateRating()) {
                var oModel = sap.ui.getCore().getModel();
                if (this._bNewDialogFlag) {
                    // Get the selected row index
                    var oTable = this._oView.byId("table");
                    // To get model data to add row to the model directly.
                    var aArrayData = oModel.getProperty("/SeverityValues");
                    // To set index for last row to be added
                    var lastRowIndex = aArrayData.length;
                    // To get data from the model
                    var oData = oModel.getData();
                    // To create new row data
                    var oDialogValue = oModel.getProperty(this._mConfig.mDialog.sContextPath);

                    // Dirty workaround because if the user enters zero when
                    // creating a new entry, this will not be
                    // reflected in the model
                    if (!oDialogValue.SeverityRating || oDialogValue.SeverityRating == "0") {
                        oDialogValue.SeverityRating = "0";
                    }

                    oData.SeverityValues.push(jQuery.extend(true, {}, oDialogValue));

                    oModel.setData(oData);
                    oTable.setVisibleRowCount(lastRowIndex + 1);

                    // If a new item has been added, we need to update the data loss manager
                    this._oDLM.setDirty(true);
                } else {
                    // Compare the values of the dialog with the values of the table. Only if the values are not the same, we need to change the state
                    // of the data loss manager
                    if (!oModel.pathsEqual(this._sDialogPath, this._mConfig.mDialog.sContextPath)) {
                        this._oDLM.setDirty(true);
                    }

                    oModel.setProperty(this._sDialogPath, oModel.getProperty(this._mConfig.mDialog.sContextPath));
                }
                this._bNewDialogFlag = false;
                this._oDialog.close();
            }
        },

        /* Validation */

        /**
         * Validates the rating field of the dialog. The value is valid if is is not empty and numeric.
         * 
         * @return {boolean} True of the value is valid, false otherwise.
         */
        validateRating : function() {
            var oSeverityRatingField = sap.ui.core.Fragment.byId("AddEditSeverityDialog", "SeverityRating");
            return this.validateMandatoryNumericTextField(oSeverityRatingField, "SEVERITY_MAPPING_DETAILS_MSE_SEVERITY_RATING_REQUIRED",
                    "SEVERITY_MAPPING_DETAILS_MSE_SEVERITY_RATING_NOT_NUMERIC");
        },

        /**
         * Validates the warning light field of the dialog. The value is valid if it is not empty.
         * 
         * @return {boolean} True of the value is valid, false otherwise.
         */
        validateWarningLight : function() {
            var oWarningLightField = sap.ui.core.Fragment.byId("AddEditSeverityDialog", "WarningLight");
            return this.validateMandatoryTextField(oWarningLightField, "SEVERITY_MAPPING_DETAILS_MSE_WARNING_LIGHT_REQUIRED");
        },

        /* Formatters */

        formatWarningLightWithDefaultFlag : function(sWarningLight, bDefault) {
            if (bDefault) {
                return jd.ui.eid.common.I18NHelper.getText("SEVERITY_MAPPING_TABLE_CEL_DEFAULT_WARNING_LIGHT", [sWarningLight]);
            }
            return sWarningLight;
        }

    }));
})();