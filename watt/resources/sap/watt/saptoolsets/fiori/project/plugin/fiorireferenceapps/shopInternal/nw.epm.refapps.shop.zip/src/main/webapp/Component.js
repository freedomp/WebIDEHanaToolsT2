// define a root UI component that exposes the main view
jQuery.sap.declare("nw.epm.refapps.shop.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

// check for BSP environment and set reuse library path
(function() {
	var sPath = jQuery.sap.getModulePath("nw.epm.refapps.shop");
	if (sPath.indexOf("EPM_REF_SHOP") !== -1) {
		if (sPath.lastIndexOf("/") !== sPath.length - 1) {
			sPath += "/";
		}
		jQuery.sap.registerModulePath("nw.epm.refapps.lib.reuse", sPath + "../EPM_REF_LIB/nw/epm/refapps/lib/reuse/");
	}

}());
// extent of sap.ca.scfld.md.ComponentBase
sap.ca.scfld.md.ComponentBase.extend("nw.epm.refapps.shop.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name": "EPM Reference App - Shop",
		"version": "1.1.0-SNAPSHOT",
		"library": "nw.epm.refapps.shop",
		"includes": ["css/shopStyles.css"],
		"dependencies": {
			"libs": ["sap.m", "sap.me", "sap.ushell", "nw.epm.refapps.lib.reuse", "sap.ui.table", "sap.ui.comp"],
			"components": []
		},
		"config": {
			"resourceBundle": "i18n/i18n.properties",
			"titleResource": "shellTitle",
			"icon": "sap-icon://Fiori6/F0866",
			"favIcon": "icon/F0866_My_Shops.ico",
			"phone": "icon/launchicon/57_iPhone_Desktop_Launch.png",
			"phone@2": "icon/launchicon/114_iPhone-Retina_Web_Clip.png",
			"tablet": "icon/launchicon/72_iPad_Desktop_Launch.png",
			"tablet@2": "icon/launchicon/144_iPad_Retina_Web_Clip.png",
		    "serviceConfig": {
				"name": "EPM_REF_APPS_SHOP",
				"serviceUrl": "/sap/opu/odata/sap/EPM_REF_APPS_SHOP_SRV/"
			}
		},
		viewPath: "nw.epm.refapps.shop.view",
		fullScreenPageRoutes: {
			// Enter the routes to your full-screen pages here
			"ProductList": {
				"pattern": "",
				"view": "S2_ProductList"
			},
			"ProductDetails": {
				"pattern": "Product/{productId}",
				"view": "S3_ProductDetails"
			},
			"ShoppingCart": {
				"pattern": "ShoppingCart",
				"view": "S4_ShoppingCart"
			},
			"CheckOut": {
				"pattern": "CheckOut",
				"view": "S5_CheckOut"
			},
            "EmptyPage" : {
                "pattern" : "EmptyPage",
                "view" : "EmptyPage"
                },
			"catchAll": {
				"pattern": ":all*:",
				"view": "EmptyPage",
				"transition": "show"
			}
		}
	}),
	init: function() {
	},
	/**
	 * Initialize the application
	 *
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent: function() {
		var oViewData = {
			component: this
		};

		return sap.ui.view({
			viewName: "nw.epm.refapps.shop.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: oViewData
		});
	},
	defineRefAppShopBatchGroups: function(oDataModel) {
		// The method name is very specific to avoid conflicts with super classes.
		// The method centrally defines the batch groups because multiple views need them and deep link must be supported.
		oDataModel.setDeferredBatchGroups(["shoppingCart", "reviews"]);
		oDataModel.setChangeBatchGroups({
			"ShoppingCartItem": {
				batchGroupId: "shoppingCart",
				single: true
			},
			"ShoppingCart": {
				batchGroupId: "shoppingCart",
				single: false
			},
			"Review": {
				batchGroupId: "reviews",
				single: false
			}
		});
	}
});
