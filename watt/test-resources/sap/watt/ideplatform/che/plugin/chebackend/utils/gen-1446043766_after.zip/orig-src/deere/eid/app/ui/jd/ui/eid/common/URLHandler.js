(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.URLHandler");
    jd.ui.eid.require("jd.ui.eid.common.OverlayHelper");

    /**
     * @class
     * <p>
     * Helper Class for handling application URL parameters.
     * </p>
     * <p>
     * It offers two main methods:
     * <ul>
     * <li>{@link jd.ui.eid.common.URLHandler.EvidencePackage.generateURL} generates a URL which points to the current evidence package.</li>
     * <li>{@link jd.ui.eid.common.URLHandler.EvidencePackage.handleURLParameter} points an application to the evidence package view </li>
     * <ul>
     * </p>
     * @static
     * @name jd.ui.eid.common.URLHandler
     */
    jd.ui.eid.common.URLHandler = {};

    /**
     * @namespace URL handling which is evidence package-related.
     * @name jd.ui.eid.common.URLHandler.EvidencePackage
     */
    jd.ui.eid.common.URLHandler.EvidencePackage = {};

    /**
     * The name of the evidence package URL parameter
     */
    jd.ui.eid.common.URLHandler.EvidencePackage.param = "evidencePackage";

    /**
     * Generates an application URL that points to a particular evidence package.
     * 
     * @param {integer}
     *            iEvidencePackageID the ID of the evidence package
     * @param {string}
     *            [sApplicationURL] an optional URL to the current application
     * @return {string} a URL pointing to the evidence package
     */
    jd.ui.eid.common.URLHandler.EvidencePackage.generateURL = function(iEvidencePackageID, sApplicationURL) {

        var sURL = (typeof sApplicationURL === "undefined") ? window.location.href : sApplicationURL;

        // replace the parameter if it is already present in the current URL
        if (jQuery.sap.getUriParameters(sURL).get(jd.ui.eid.common.URLHandler.EvidencePackage.param)) {
            var reg = new RegExp("(" + jd.ui.eid.common.URLHandler.EvidencePackage.param + "=)[^&]*(&.*)?");
            sURL = sURL.replace(reg, "$1" + iEvidencePackageID + "$2");

            // concatenate the parameter otherwise
        } else {
            sURL += ((sURL.indexOf("?") == -1) ? "?" : "&") + jd.ui.eid.common.URLHandler.EvidencePackage.param + "=" + iEvidencePackageID;
        }

        // if we do not encode, JavaScript would cut off the parameters
        sURL = encodeURIComponent(sURL);
        return sURL;
    };

    /**
     * Points the application to a particular evidence package referenced by the current application URL.
     */
    jd.ui.eid.common.URLHandler.EvidencePackage.handleURLParameter = function() {
        var iEvidencePackageID = jQuery.sap.getUriParameters().get(jd.ui.eid.common.URLHandler.EvidencePackage.param);
        if (iEvidencePackageID) {
            var oEvidencePackageDetailsOverlay = jd.ui.eid.common.OverlayHelper.getEvidencePackageSummaryOverlay();
            oEvidencePackageDetailsOverlay.setContext(iEvidencePackageID);
            if (!oEvidencePackageDetailsOverlay.isOpen()) {
                oEvidencePackageDetailsOverlay.open();
            }
        }
    };
})();