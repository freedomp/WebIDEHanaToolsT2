(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.CollectionItem");
    jd.ui.eid.require("sap.ui.core.Item");

    /**
     * Constructor for a new CollectionItem.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>highlighted : boolean (default: false) true if the item should be highlighted, false otherwise.</li>
     * <li>secondaryText : string (default: '') the text displayed along with the item.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class This custom implementation of 'Item' is used for the 'items' aggregation of the {@link jd.ui.eid.control.Collection} element. This is
     *        used in the {@link jd.ui.eid.control.CollectionInspectorWithSummary} control.
     * 
     * @name jd.ui.eid.control.CollectionItem
     * @extends sap.ui.core.Item
     */
    sap.ui.core.Item.extend("jd.ui.eid.control.CollectionItem", /** @lends jd.ui.eid.control.CollectionItem */
    {
        metadata : {
            properties : {
                highlighted : {
                    type : "boolean",
                    defaultValue : false
                },
                secondaryText : {
                    type : "string",
                    defaultValue : ""
                }
            }
        }
    });
})();