sap.ui.define(["sap/ui/test/Opa5", "./Common"], function(Opa5, Common) {
	"use strict";

	return Opa5.createPageObjects({
		onPageS1: {
			baseClass : Common,

			actions : {
				iClickOnFooterButton : function(sI18nKey) {
					return this.waitFor({
						controlType: "sap.m.Button",
						matchers : new sap.ui.test.matchers.PropertyStrictEquals({
							name : "text", 
							value : this.getI18nText(sI18nKey)
						}),
						success: function(aButtons) {
							var oButton = aButtons[0];
							oButton.$().tap();
						},
						errorMessage: "Didn't find footer button with i18n key = " + sI18nKey

					});
				}
			},

			assertions : {
				theTableShouldContainData : function () {
					this.waitFor({
						id: "simpleSampleTable",
						viewName: "S1",
						success: function(oTable) {
							notStrictEqual(oTable.getItems().length, 0, "Table should contain some entries");
						},
						errorMessage: "Table not found"
					});
					return this;
				}
			}
		}
	});

});