(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.WarrantyClaimServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    /**
     * @class Warranty claim service facade.
     * @name jd.ui.eid.service.WarrantyClaimServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     * 
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.WarrantyClaimServiceFacade", /** @lends jd.ui.eid.service.WarrantyClaimServiceFacade */
    {
        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleListBindingChanged : function(oListBinding) {
            // This is invoked if the filtering/sorting on the UI table changes.
            // If the list binding is relevant, then get the updated list based on new
            // filtering/sorting etc. This information is available inside oListBinding.
            if (oListBinding.sPath == '/WarrantyClaimsByPrimePartList') {
                this.getWarrantyClaimsByPrimePartList(oListBinding);
            }
        },

        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleDataRequested : function(oListBinding) {
            // This is invoked when there is paging on the UI table
            // If the list binding is relevant, then get the updated list based on the new
            // binding information (oListBinding)
            if (oListBinding.sPath == '/WarrantyClaimsByPrimePartList') {
                this.getWarrantyClaimsByPrimePartList(oListBinding);
            }
        },

        /**
         * Get the list of Prime Parts containing Warranty Claims
         * 
         * @memberOf jd.ui.eid.service.WarrantyClaimServiceFacade
         * 
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control which shows the Prime Parts.
         * @param {object}
         *            oCustomFilter contains the Warranty Claim custom control filter values.
         * @param {string}
         *            oEvidencePackage contains the filter values of the evidence package and the list of selected DTC codes.
         * @param {string}
         *            sSearchTerm the search string above of the Prime Part table. If there is no search term, this can be an empty string or null.
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getWarrantyClaimsByPrimePartList : function(oBinding, oCustomFilter, oEvidencePackage, sSearchTerm, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "/xs/warranty/GetWarrantyClaimsByPrimePartList.xsjs";

            // Set test data file name
            var sModelDataFileName = "getWarrantyClaimsByPrimePartList_Response.json";

            // Prepare the custom payload for this service call
            var oArgs = {};
            oArgs.CustomFilter = oCustomFilter;
            oArgs.SearchTerm = sSearchTerm;
            oArgs.EvidencePackage = oEvidencePackage;

            // Prepare the callback. It accepts an object (JSON object of the server
            // response)
            // and returns an result object containing the records count and an array
            // of the records.
            var fnGetWarrantyClaimListData = function(oData) {
                return oData.Result.WarrantyClaimsByPrimePartList;
            };

            // Invoke records retrieval
            this._retrieveList(sServicePath, fnSuccess, fnError, fnGetWarrantyClaimListData, oBinding, oArgs, sModelDataFileName);
        },

        /**
         * Get the Prime Part Header and the list of Warranty Claims for a selected Prime Part
         * 
         * @memberOf jd.ui.eid.service.WarrantyClaimServiceFacade
         * 
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control which shows the header data of a Prime Part containing Warranty Claims.
         * @param {object}
         *            oCustomFilter contains the Warranty Claim custom control filter values.
         * @param {string}
         *            oEvidencePackage contains the filter values of the evidence package and the list of selected DTC codes.
         * @param {string}
         *            sSearchTerm the search string above of the Prime Part table. If there is no search term, this can be an empty string or null.
         * @param {boolean}
         *            bJDLinkActive If true only JDLinkActive machines are selected otherwise only inactive machines are selected.
         * @param {string}
         *            sPrimePartNumber the Prime Part string of the selected Prime Part.
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getWarrantyClaimPrimePart : function(oCustomFilter, oEvidencePackage, sSearchTerm, bJDLinkActive, sPrimePartNumber, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "/xs/warranty/GetWarrantyClaimPrimePart.xsjs";
            var sPrimePartModelPath = "/WarrantyClaimPrimePartHeader";
            var sWarrantyClaimDetailsModelPath = "/WarrantyClaimDetails";

            // Set test data file name
            var sModelDataFileName = "getWarrantyClaimPrimePart_Response.json";

            // Prepare the custom payload for this service call
            var oArgs = {};
            oArgs.CustomFilter = oCustomFilter;
            oArgs.SearchTerm = sSearchTerm;
            oArgs.EvidencePackage = oEvidencePackage;
            oArgs.JDLinkActive = bJDLinkActive;
            oArgs.PrimePartNumber = sPrimePartNumber;

            // Prepare the fnSuccess callback. It set's the values for the Warranty Claim details#
            var that = this;
            var _fnSuccess = function(oData) {
                var oModel = that.oModel;
                var oWarrantyClaimDetails = oData.Result.WarrantyClaimDetails;

                // Set model properties
                oModel.setProperty(sWarrantyClaimDetailsModelPath, oWarrantyClaimDetails);

                // call nested function
                if (fnSuccess) {
                    fnSuccess(oData);
                }
            };

            var fnGetData = function(oData) {
                // Iterate over the list to mark those which are already in the evidence package
                var oModel = that.oModel;

                var iWarrantyClaimsCount = oModel.getProperty("/EvidencePackageDetails/Header/WarrantyClaimList").length;
                if (iWarrantyClaimsCount > 0) {
                    var mWarrantyClaims = jd.ui.eid.model.EidModel.TransformationHelper.getWarrantyClaimMapFromEvidencePackageDetails();
                    var iMatches = 0;
                    $.each(oData.Result.WarrantyClaimPrimePartHeader.WarrantyClaimList, function(iIdx, mWarrantyClaim) {
                        if (mWarrantyClaims[mWarrantyClaim.WarrantyClaimSequenceNumber]) {
                            mWarrantyClaim._canBeAddedToEvidencePackage = false;
                            iMatches++;
                            if (iMatches == iWarrantyClaimsCount) {
                                return false; // break, we marked everything
                            }
                        }
                    });
                }

                return oData.Result.WarrantyClaimPrimePartHeader;
            };

            // Invoke records retrieval
            this._retrieveRecord(sServicePath, sPrimePartModelPath, oArgs, _fnSuccess, fnError, fnGetData, sModelDataFileName);
        },

        /**
         * Retrieve further details about a specific warranty claim
         * 
         * @memberOf jd.ui.eid.service.WarrantyClaimServiceFacade
         * 
         * @param {int}
         *            iWarrantyClaimSequenceNumber the Warranty Claim number
         * @param {boolean}
         *            bJDLinkActive If true only JDLinkActive machines are selected otherwise only inactive machines are selected.
         * @param {array}
         *            aDTCIDList List of DTC ids
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @public
         * 
         */
        getWarrantyClaimDetails : function(iWarrantyClaimSequenceNumber, bJDLinkActive, aDTCIDList, fnSuccess, fnError) {
            var sServicePath = "/xs/warranty/GetWarrantyClaimDetails.xsjs";
            var sModelPath = "/WarrantyClaimDetails";
            var oData = {
                WarrantyClaimList : [{
                    WarrantyClaimSequenceNumber : iWarrantyClaimSequenceNumber,
                    JDLinkActive : bJDLinkActive
                }],
                DTCIDList : aDTCIDList
            };

            var fnGetData = function(oData) {
                return oData.Result.WarrantyClaimDetails.Records[0];
            };

            var sModelFileName = "getWarrantyClaimDetails_Response.json";

            // Invoke record retrieval
            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName);
        }

    });

})();
