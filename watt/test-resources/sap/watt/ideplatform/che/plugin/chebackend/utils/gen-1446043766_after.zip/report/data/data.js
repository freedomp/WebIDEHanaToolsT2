var main_data = {
    "sum": [
        {
            "name": "total",
            "number": 1514
        },
        {
            "name": "xsjs",
            "number": 79,
            "detail": {
                ".xsjs": 37,
                ".xsjslib": 42
            }
        },
        {
            "name": "db",
            "number": 436,
            "detail": {
                ".hdbschema": 1,
                ".procedure": 139,
                ".hdbtable": 175,
                ".calculationview": 4,
                ".hdbstructure": 38,
                ".hdbsequence": 1,
                ".csv": 8,
                ".hdbti": 4,
                ".hdbview": 66
            }
        },
        {
            "name": "web",
            "number": 944,
            "detail": {
                ".txt": 2,
                ".xml": 221,
                ".html": 10,
                ".js": 484,
                ".png": 158,
                ".less": 66,
                ".css": 3
            }
        },
        {
            "name": "todo",
            "number": 39,
            "detail": {
                ".xsaccess": 2,
                ".hdbtextconfig": 1,
                ".hdbflowgraph": 1,
                ".json": 32,
                ".properties": 2,
                ".hdbtextbundle": 1
            }
        },
        {
            "name": "delete",
            "number": 11,
            "detail": {
                ".project": 3,
                ".xsapp": 1,
                ".xsprivileges": 1,
                ".hdbrole": 2,
                ".classpath": 1,
                ".db": 2,
                ".xssqlcc": 1
            }
        },
        {
            "name": "unknown",
            "detail": {
                ".sql": 4,
                ".MF": 1
            },
            "number": 5
        }
    ],
    "errors": {
        "number": 35,
        "list": [
            {
                "type": "ERROR",
                "message": [
                    "Object type {0} is currently not supported. Support is planned with a future release.",
                    "hdbtextconfig"
                ],
                "category": "UNSUPPORTED_FEATURE",
                "id": "UNSUPPORTED_FEATURE_3",
                "file": "orig-src/deere/eid/app/db/components/dtac/DTAC_TEXT_ANALYSIS.hdbtextconfig"
            },
            {
                "type": "ERROR",
                "message": [
                    "Object type {0} is currently not supported. Support is planned with a future release.",
                    "hdbflowgraph"
                ],
                "category": "UNSUPPORTED_FEATURE",
                "id": "UNSUPPORTED_FEATURE_3",
                "file": "orig-src/deere/eid/app/db/components/dtc/intern/APRIORI.hdbflowgraph"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails2.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/ApplyDTCFilter_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/CalculateMachineOptionCodesForDTC_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/GetEvidencePackageDetails_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getBlacklist.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseDetailsList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseDetails_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCDetailsList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCDetails_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCFilterDomainValues_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCKPIs_Response_Single.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDependentFilters_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEngineHourSegments_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageAnalysisData_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageList.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackagePINPopulationList.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackagePINPopulationList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageSummary_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getKPIs_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getKeyValueParameters_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getPersonalizationFilters.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getPlatformAndProductLine_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getSeverity_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getSingleKPIByCaptureTimeChart_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimDetailsList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimDetails_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimPrimePart_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimsByPrimePartList_Response.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                ],
                "category": "TODO",
                "id": "TODO_1",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/template.json"
            },
            {
                "type": "ERROR",
                "message": [
                    "You must change the privilege name to the scope name in {0}.",
                    "$.session.assertAppPrivilege"
                ],
                "file": "xsa-app/xsjs/lib/deere/eid/app/xs/util/lib/Authorization.xsjslib",
                "loc": [
                    {
                        "start": {
                            "line": 4,
                            "column": 2
                        },
                        "end": {
                            "line": 4,
                            "column": 41
                        }
                    }
                ],
                "category": "SECURITY",
                "id": "SECURITY_3",
                "mid": 1
            }
        ]
    },
    "warnings": {
        "number": 185,
        "list": [
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate file manually if needed."
                ],
                "category": "TODO",
                "id": "TODO_4",
                "file": "orig-src/deere/eid/app/db/data/app_tables/DELETE_ALL_EVIDENCE_PACKAGES.sql"
            },
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate file manually if needed."
                ],
                "category": "TODO",
                "id": "TODO_4",
                "file": "orig-src/deere/eid/app/db/data/app_tables/MOVE_TABLES.sql"
            },
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate file manually if needed."
                ],
                "category": "TODO",
                "id": "TODO_4",
                "file": "orig-src/deere/eid/app/db/data/app_tables/SEARCH_INDEX_STRUCTURES.sql"
            },
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate file manually if needed."
                ],
                "category": "TODO",
                "id": "TODO_4",
                "file": "orig-src/deere/eid/app/db/data/repl_tables/SEARCH_INDEX_STRUCTURES.sql"
            },
            {
                "type": "WARNING",
                "message": [
                    "Unknown file type. Migrate file manually if needed."
                ],
                "category": "TODO",
                "id": "TODO_4",
                "file": "orig-src/deere/eid/app/ui/META-INF/MANIFEST.MF"
            },
            {
                "type": "WARNING",
                "message": [
                    "The xsaccess file has been migrated to the new XS Advanced security concept which must be reviewed."
                ],
                "category": "SECURITY",
                "id": "SECURITY_2",
                "file": "orig-src/deere/eid/app/.xsaccess"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_ENGINE_HOURS_SEGMENTS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_KEY_VALUE_PARAMETERS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_KPI.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_SEVERITY_RATING.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_CASE_DETAILS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_CASE_NO.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_ENGINE_HOURS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_LIST.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_TAG_CLOUD.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTC_IDS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_TAG_CLOUD.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_DAY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_PINS_PER_ENGINE_HRS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BASE_PIN_POPULATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BRANCH_CODE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BRANCH_CODE_NAME.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BUILD_FACTORY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BUILD_FACTORY_NAME.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_CALC_KPIS_AND_TREND.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DESIGN_FACTORY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DESIGN_FACTORY_NAME.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_IDS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MACHINE_OPTIONS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MACH_OPTIONS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MASTER_DATA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_PIN_POPULATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_EMISSION_LEVEL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_ENGINE_HOURS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_FUNC_AREA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_DTC.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_DAY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_MACHINE_LOCATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_MODEL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_WEEK_WEEK_ENDING_DATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PLATFORM_PRODUCTLINE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_REL_AFFECTED_MACHS_PER_DTC_OCCURRENCE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_DTC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ITEM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ITEM_READ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_TAG_CLOUD_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_BLD_FCTRY_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_BRANCH_CODE_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_DSGN_FCTRY_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_EMISSION_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_FUNCTIONAL_AREA_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ITEM_READ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ITEM_WRITE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_MACH_LOC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_MODEL_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_PIN_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_INFO.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_MACHINE_OPTION_CODE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_MACHINE_OPTION_CODE_READ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARNTY_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_DTC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_ITEM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_ITEM_READ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_ANALYSIS_DATA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_HEAD.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_HEAD_READ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_LIST.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_POPULATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_DAYS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_WARRANTY_DTAC_COUNT.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_TOTAL_CLAIM_COST_BY_PRIMEPART.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_WEEK_WEEK_ENDING_DATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_DATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_MONTH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_WEEK.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WRNTY_CLAIMS_ANALYSIS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_BLACKLISTED_DTC.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER_DOMAIN_VALUES.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_ACTIVE_WARRANTY_CLAIM_NUMBER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_DTC_ANALYSIS_PER_MACHINE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_DTC_IDS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_VULCANO_CHART.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_VULCANO_CHART_ENG_HR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIMS_DETAIL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIMS_DETAILS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIM_NUMBER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIMS_DETAIL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST_PRIME_PART.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST_SEQ.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_LIST.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_SIMILARITY_SEARCH.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_DTC_COUNT_ENGINE_HOUR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_ENGINE_HOURS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/BINS_DTC.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/BLACKLIST_DTC.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EH_SEGMENTS_MAPPING.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/ENGINE_HOURS_SEGMENTS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_DTC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_ITEM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_TAG_CLOUD_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_BLD_FCTRY_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_BRANCH_CODE_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_DSGN_FCTRY_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_EMISSION_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_FUNCTIONAL_AREA_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_ITEM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_MACH_LOC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_MODEL_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_PIN_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_MACHINE_OPTION_CODES.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_DTC_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_ITEM.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WRNTY_ENGN_HOURS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EVIDENCE_PACKAGE_H.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/FUNCTIONAL_AREA_MASTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KEY_VALUE_PARAMETERS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KEY_VALUE_PARAMETERS_SYS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI_LIST.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI_TEXT.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_BRANCH_CODE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_BUILD_FACTORY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_DESIGN_FACTORY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_DOMAIN_VALUES.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_EMISSION_LEVEL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_ENGINE_HOURS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_FUNC_AREA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MACHINE_LOCATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MANUAL_PIN.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MODEL.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_STATE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/SEVERITY_RATING.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/SEVERITY_RATING_SYS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/WRNTY_ENGINE_HOURS_BUCKET.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/ACCT_PHYS_ADDR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/ACCT_RPT_INFO.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/DTC_MASTER.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/EXCLUDED_OPTIONS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MANAGED_USERS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MDAW_FACTORY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_ALERT_BASE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_MACHINE_EIA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_MACH_TRACE_LOG_DAY.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/NEW_FUNCAREA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/NEW_FUNCCODE.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/PI_CNFGR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_NOTES.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_ORGANIZATION.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_TICKET_HDR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_NAT_FIELDINFO.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_USERS.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_WORKGROUP.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/SS_FISCAL_CALENDAR.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/WRNTY_CLAIM_EIA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                ],
                "category": "HDI",
                "id": "HDI_3",
                "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/WRNTY_CLAIM_TEXT_EIA.hdbtable"
            },
            {
                "type": "WARNING",
                "message": [
                    "The xsaccess file has been migrated to the new XS Advanced security concept which must be reviewed."
                ],
                "category": "SECURITY",
                "id": "SECURITY_2",
                "file": "orig-src/deere/eid/app/test/.xsaccess"
            },
            {
                "type": "WARNING",
                "message": [
                    "The .properties file {0} found in the original sources is most likely a translation file. Check the file and copy it to the appropriate container.",
                    "i18n.properties"
                ],
                "category": "TRANSLATION",
                "id": "TRANSLATION_5",
                "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/text/i18n.properties"
            },
            {
                "type": "WARNING",
                "message": [
                    "The .properties file {0} found in the original sources is most likely a translation file. Check the file and copy it to the appropriate container.",
                    "i18n.properties"
                ],
                "category": "TRANSLATION",
                "id": "TRANSLATION_5",
                "file": "todo/src/deere/eid/app/ui/target/jd/ui/eid/asset/text/i18n.properties"
            },
            {
                "type": "WARNING",
                "message": [
                    "Role access privileges must be checked when using {0}.",
                    "$.db.getConnection"
                ],
                "file": "xsa-app/xsjs/lib/deere/eid/app/xs/util/lib/Connection.xsjslib",
                "loc": [
                    {
                        "start": {
                            "line": 7,
                            "column": 12
                        },
                        "end": {
                            "line": 7,
                            "column": 75
                        }
                    }
                ],
                "category": "SECURITY",
                "id": "SECURITY_4",
                "mid": 22
            }
        ]
    },
    "infos": {
        "number": 12,
        "list": [
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".project"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/.project"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".xsapp"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/.xsapp"
            },
            {
                "type": "INFO",
                "message": [
                    "Application privileges have been migrated to scopes in xs-security.json. Refer to security migration guide for more information"
                ],
                "category": "SECURITY",
                "id": "SECURITY_7",
                "file": "orig-src/deere/eid/app/.xsprivileges"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".hdbschema"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/catalog/schemas/EID.hdbschema"
            },
            {
                "type": "INFO",
                "message": [
                    "Security Concept has changed and new and different files will be generated. Refer to security step for more information"
                ],
                "category": "SECURITY",
                "id": "SECURITY_6",
                "file": "orig-src/deere/eid/app/security/roles/admin_ZZZZZ.hdbrole"
            },
            {
                "type": "INFO",
                "message": [
                    "Security Concept has changed and new and different files will be generated. Refer to security step for more information"
                ],
                "category": "SECURITY",
                "id": "SECURITY_6",
                "file": "orig-src/deere/eid/app/security/roles/user_ZZZZZ.hdbrole"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".project"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/test/.project"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".classpath"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/ui/.classpath"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".project"
                ],
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "orig-src/deere/eid/app/ui/.project"
            },
            {
                "type": "INFO",
                "message": [
                    "Copy the text propertey file(s) {0} (including translations) into the web or xsjs folder.",
                    "src/deere/eid/app/ui/target/jd/ui/eid/asset/text/uitexts.properties"
                ],
                "category": "TRANSLATION",
                "id": "TRANSLATION_4",
                "file": "todo/src/deere/eid/app/ui/target/jd/ui/eid/asset/text/uitexts.properties"
            },
            {
                "type": "INFO",
                "message": [
                    "xssqlcc files are no longer supported by XS Advanced. Refer to security migration chapter of the XS Migration guide."
                ],
                "category": "SECURITY",
                "id": "SECURITY_8",
                "file": "orig-src/deere/eid/app/xs/util/lib/EID_Connection.xssqlcc"
            },
            {
                "type": "INFO",
                "message": [
                    "You must review the security concept of your application. Refer to the security chapter in the XS Migraton guide."
                ],
                "category": "SECURITY",
                "id": "SECURITY_9"
            }
        ]
    },
    "steps": [
        {
            "priority": 4,
            "always-shown": true,
            "name": "Migration of Security Concept Required",
            "desc": "The security concept has changed with XS Advanced and is incompatible with XS Classic. Manual migration steps are required in order to complete the migration of this application to XS Advanced. For information read the section about the XS Advanced security concept and the security migration section in the XS Migration Guide.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#security"
            },
            "messages": {
                "ERROR": [
                    {
                        "type": "ERROR",
                        "message": [
                            "You must change the privilege name to the scope name in {0}.",
                            "$.session.assertAppPrivilege"
                        ],
                        "file": "xsa-app/xsjs/lib/deere/eid/app/xs/util/lib/Authorization.xsjslib",
                        "loc": [
                            {
                                "start": {
                                    "line": 4,
                                    "column": 2
                                },
                                "end": {
                                    "line": 4,
                                    "column": 41
                                }
                            }
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_3",
                        "mid": 1
                    }
                ],
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "The xsaccess file has been migrated to the new XS Advanced security concept which must be reviewed."
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_2",
                        "file": "orig-src/deere/eid/app/.xsaccess"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "The xsaccess file has been migrated to the new XS Advanced security concept which must be reviewed."
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_2",
                        "file": "orig-src/deere/eid/app/test/.xsaccess"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Role access privileges must be checked when using {0}.",
                            "$.db.getConnection"
                        ],
                        "file": "xsa-app/xsjs/lib/deere/eid/app/xs/util/lib/Connection.xsjslib",
                        "loc": [
                            {
                                "start": {
                                    "line": 7,
                                    "column": 12
                                },
                                "end": {
                                    "line": 7,
                                    "column": 75
                                }
                            }
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_4",
                        "mid": 22
                    }
                ],
                "INFO": [
                    {
                        "type": "INFO",
                        "message": [
                            "Application privileges have been migrated to scopes in xs-security.json. Refer to security migration guide for more information"
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_7",
                        "file": "orig-src/deere/eid/app/.xsprivileges"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "Security Concept has changed and new and different files will be generated. Refer to security step for more information"
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_6",
                        "file": "orig-src/deere/eid/app/security/roles/admin_ZZZZZ.hdbrole"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "Security Concept has changed and new and different files will be generated. Refer to security step for more information"
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_6",
                        "file": "orig-src/deere/eid/app/security/roles/user_ZZZZZ.hdbrole"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "xssqlcc files are no longer supported by XS Advanced. Refer to security migration chapter of the XS Migration guide."
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_8",
                        "file": "orig-src/deere/eid/app/xs/util/lib/EID_Connection.xssqlcc"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "You must review the security concept of your application. Refer to the security chapter in the XS Migraton guide."
                        ],
                        "category": "SECURITY",
                        "id": "SECURITY_9"
                    }
                ]
            },
            "list": [
                {
                    "text": "ERROR",
                    "value": 1
                },
                {
                    "text": "WARNING",
                    "value": 3
                },
                {
                    "text": "INFO",
                    "value": 5
                }
            ]
        },
        {
            "priority": 5,
            "name": "Currently Unsupported or Discontinued Features",
            "desc": "Some features have been discontinued. Manaual migration is required.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#unsupported-feature"
            },
            "messages": {
                "ERROR": [
                    {
                        "type": "ERROR",
                        "message": [
                            "Object type {0} is currently not supported. Support is planned with a future release.",
                            "hdbtextconfig"
                        ],
                        "category": "UNSUPPORTED_FEATURE",
                        "id": "UNSUPPORTED_FEATURE_3",
                        "file": "orig-src/deere/eid/app/db/components/dtac/DTAC_TEXT_ANALYSIS.hdbtextconfig"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Object type {0} is currently not supported. Support is planned with a future release.",
                            "hdbflowgraph"
                        ],
                        "category": "UNSUPPORTED_FEATURE",
                        "id": "UNSUPPORTED_FEATURE_3",
                        "file": "orig-src/deere/eid/app/db/components/dtc/intern/APRIORI.hdbflowgraph"
                    }
                ]
            },
            "list": [
                {
                    "text": "ERROR",
                    "value": 2
                }
            ]
        },
        {
            "priority": 6,
            "name": "Database Artifacts",
            "desc": "Migration of database artifacts has raised the following messages.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#database-artifacts"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_ENGINE_HOURS_SEGMENTS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_KEY_VALUE_PARAMETERS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_KPI.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/custom/temp_tables/TMP_SEVERITY_RATING.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_CASE_DETAILS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_CASE_NO.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_ENGINE_HOURS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_LIST.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTAC_TAG_CLOUD.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_DTC_IDS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtac/temp_tables/TMP_TAG_CLOUD.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_DAY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_MACHS_PER_CAPTIME_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_AFFECTED_PINS_PER_ENGINE_HRS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BASE_PIN_POPULATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BRANCH_CODE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BRANCH_CODE_NAME.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BUILD_FACTORY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_BUILD_FACTORY_NAME.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_CALC_KPIS_AND_TREND.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DESIGN_FACTORY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DESIGN_FACTORY_NAME.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_IDS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MACHINE_OPTIONS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MACH_OPTIONS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_MASTER_DATA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_DTC_PIN_POPULATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_EMISSION_LEVEL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_ENGINE_HOURS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_FUNC_AREA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_DTC.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_DAY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_KPI_PER_CAPTIME_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_MACHINE_LOCATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_MODEL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PINS_AND_DTC_OCC_BUILD_DATE_WEEK_WEEK_ENDING_DATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_PLATFORM_PRODUCTLINE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/dtc/temp_tables/TMP_REL_AFFECTED_MACHS_PER_DTC_OCCURRENCE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_DTC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ITEM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_ITEM_READ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTAC_TAG_CLOUD_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_BLD_FCTRY_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_BRANCH_CODE_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_DSGN_FCTRY_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_EMISSION_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_FUNCTIONAL_AREA_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ITEM_READ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_ITEM_WRITE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_MACH_LOC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_MODEL_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_DTC_PIN_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_INFO.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_MACHINE_OPTION_CODE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_MACHINE_OPTION_CODE_READ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARNTY_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_DTC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_ITEM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EP_WARRANTY_ITEM_READ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_ANALYSIS_DATA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_HEAD.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_HEAD_READ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_LIST.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_EVIDENCE_PACKAGE_POPULATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_DAYS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_DTC_PIN_COUNT_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_RUNNING_SUM_WARRANTY_DTAC_COUNT.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_TOTAL_CLAIM_COST_BY_PRIMEPART.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_BUILD_DATE_WEEK_WEEK_ENDING_DATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_DATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_MONTH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WARRANTY_COST_FAILURE_WEEK.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/evidence/temp_tables/TMP_WRNTY_CLAIMS_ANALYSIS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_BLACKLISTED_DTC.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER_DOMAIN_VALUES.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/personal/temp_tables/TMP_PERS_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_ACTIVE_WARRANTY_CLAIM_NUMBER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_DTC_ANALYSIS_PER_MACHINE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_DTC_IDS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_VULCANO_CHART.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_VULCANO_CHART_ENG_HR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIMS_DETAIL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIMS_DETAILS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WARRANTY_CLAIM_NUMBER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIMS_DETAIL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST_PRIME_PART.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_ACT_LIST_SEQ.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_LIST.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_CLAIM_SIMILARITY_SEARCH.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_DTC_COUNT_ENGINE_HOUR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/access/warranty/temp_tables/TMP_WRNTY_ENGINE_HOURS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/BINS_DTC.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/BLACKLIST_DTC.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EH_SEGMENTS_MAPPING.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/ENGINE_HOURS_SEGMENTS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_DTC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_ITEM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTAC_TAG_CLOUD_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_BLD_FCTRY_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_BRANCH_CODE_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_DSGN_FCTRY_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_EMISSION_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_FUNCTIONAL_AREA_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_ITEM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_MACH_LOC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_MODEL_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_DTC_PIN_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_MACHINE_OPTION_CODES.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_DTC_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WARRANTY_ITEM.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EP_WRNTY_ENGN_HOURS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/EVIDENCE_PACKAGE_H.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/FUNCTIONAL_AREA_MASTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KEY_VALUE_PARAMETERS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KEY_VALUE_PARAMETERS_SYS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI_LIST.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/KPI_TEXT.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_BRANCH_CODE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_BUILD_FACTORY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_DESIGN_FACTORY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_DOMAIN_VALUES.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_EMISSION_LEVEL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_ENGINE_HOURS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_FUNC_AREA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MACHINE_LOCATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MANUAL_PIN.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_MODEL.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/PERS_FILTER_STATE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/SEVERITY_RATING.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/SEVERITY_RATING_SYS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/app_tables/WRNTY_ENGINE_HOURS_BUCKET.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/ACCT_PHYS_ADDR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/ACCT_RPT_INFO.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/DTC_MASTER.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/EXCLUDED_OPTIONS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MANAGED_USERS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MDAW_FACTORY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_ALERT_BASE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_MACHINE_EIA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/MK_MACH_TRACE_LOG_DAY.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/NEW_FUNCAREA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/NEW_FUNCCODE.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/PI_CNFGR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_NOTES.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_ORGANIZATION.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QW_TICKET_HDR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_NAT_FIELDINFO.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_USERS.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/QX_WORKGROUP.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/SS_FISCAL_CALENDAR.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/WRNTY_CLAIM_EIA.hdbtable"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Comments on table columns are not yet supported. The hdbtable object has been migrated but the comment has been removed."
                        ],
                        "category": "HDI",
                        "id": "HDI_3",
                        "file": "xsa-app/db/src/deere/eid/app/db/data/repl_tables/WRNTY_CLAIM_TEXT_EIA.hdbtable"
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 175
                }
            ]
        },
        {
            "priority": 8,
            "name": "Translation",
            "desc": "hdbtextbundle files and possibly translations were found as part of the application. Some actions are necessary as outlined in the messages below.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#translation"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "The .properties file {0} found in the original sources is most likely a translation file. Check the file and copy it to the appropriate container.",
                            "i18n.properties"
                        ],
                        "category": "TRANSLATION",
                        "id": "TRANSLATION_5",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/text/i18n.properties"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "The .properties file {0} found in the original sources is most likely a translation file. Check the file and copy it to the appropriate container.",
                            "i18n.properties"
                        ],
                        "category": "TRANSLATION",
                        "id": "TRANSLATION_5",
                        "file": "todo/src/deere/eid/app/ui/target/jd/ui/eid/asset/text/i18n.properties"
                    }
                ],
                "INFO": [
                    {
                        "type": "INFO",
                        "message": [
                            "Copy the text propertey file(s) {0} (including translations) into the web or xsjs folder.",
                            "src/deere/eid/app/ui/target/jd/ui/eid/asset/text/uitexts.properties"
                        ],
                        "category": "TRANSLATION",
                        "id": "TRANSLATION_4",
                        "file": "todo/src/deere/eid/app/ui/target/jd/ui/eid/asset/text/uitexts.properties"
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 2
                },
                {
                    "text": "INFO",
                    "value": 1
                }
            ]
        },
        {
            "priority": 9,
            "name": "Unknown File Types or File Content",
            "desc": "The migration tool was not able to identify these file types. You must decide whether these objects are relevant, and copy them into the appropriate container directory if needed.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#todo"
            },
            "messages": {
                "ERROR": [
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/AM-01-10_EvidencePackageDetails2.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/ApplyDTCFilter_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/CalculateMachineOptionCodesForDTC_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/GetEvidencePackageDetails_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getBlacklist.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseDetailsList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseDetails_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTACCaseList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCDetailsList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCDetails_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCFilterDomainValues_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCKPIs_Response_Single.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDTCList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getDependentFilters_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEngineHourSegments_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageAnalysisData_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageList.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackagePINPopulationList.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackagePINPopulationList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getEvidencePackageSummary_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getKPIs_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getKeyValueParameters_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getPersonalizationFilters.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getPlatformAndProductLine_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getSeverity_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getSingleKPIByCaptureTimeChart_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimDetailsList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimDetails_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimPrimePart_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/getWarrantyClaimsByPrimePartList_Response.json"
                    },
                    {
                        "type": "ERROR",
                        "message": [
                            "Type of JSON file could not be determined. Copy the file manually either to the xsjs or web container folder."
                        ],
                        "category": "TODO",
                        "id": "TODO_1",
                        "file": "todo/src/deere/eid/app/ui/jd/ui/eid/asset/data/template.json"
                    }
                ],
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate file manually if needed."
                        ],
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "orig-src/deere/eid/app/db/data/app_tables/DELETE_ALL_EVIDENCE_PACKAGES.sql"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate file manually if needed."
                        ],
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "orig-src/deere/eid/app/db/data/app_tables/MOVE_TABLES.sql"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate file manually if needed."
                        ],
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "orig-src/deere/eid/app/db/data/app_tables/SEARCH_INDEX_STRUCTURES.sql"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate file manually if needed."
                        ],
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "orig-src/deere/eid/app/db/data/repl_tables/SEARCH_INDEX_STRUCTURES.sql"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Unknown file type. Migrate file manually if needed."
                        ],
                        "category": "TODO",
                        "id": "TODO_4",
                        "file": "orig-src/deere/eid/app/ui/META-INF/MANIFEST.MF"
                    }
                ]
            },
            "list": [
                {
                    "text": "ERROR",
                    "value": 32
                },
                {
                    "text": "WARNING",
                    "value": 5
                }
            ]
        },
        {
            "priority": 11,
            "name": "Objects Which Have Not Been Migrated",
            "desc": "The following objects have not been migrated because they are either not relevant or have been successfully migrated to another object type.",
            "link": {
                "info": "description",
                "url": "https://github.wdf.sap.corp/xs2/xs2-docs/wiki/XS%20Migration%20Steps#delete"
            },
            "messages": {
                "INFO": [
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".project"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/.project"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".xsapp"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/.xsapp"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".hdbschema"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/catalog/schemas/EID.hdbschema"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".project"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/test/.project"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".classpath"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/ui/.classpath"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".project"
                        ],
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "orig-src/deere/eid/app/ui/.project"
                    }
                ]
            },
            "list": [
                {
                    "text": "INFO",
                    "value": 6
                }
            ]
        }
    ],
    "system": {
        "protocol": "http",
        "host": "ld9223.wdf.sap.corp",
        "port": "8001",
        "user": "SYSTEM",
        "sid": "D09",
        "instance": 1,
        "halm_version": "1.4.9",
        "hana_version": "1.00.102.00.1441802864"
    },
    "task": {
        "dus": [
            {
                "name": "DEERE_EID_APP_SAP",
                "vendor": "deere.com",
                "version": "0.0.1"
            }
        ],
        "packages": [
            "deere.eid.app",
            "deere.eid.app.catalog",
            "deere.eid.app.catalog.schemas",
            "deere.eid.app.db",
            "deere.eid.app.db.access",
            "deere.eid.app.db.access.custom",
            "deere.eid.app.db.access.custom.temp_tables",
            "deere.eid.app.db.access.dtac",
            "deere.eid.app.db.access.dtac.temp_tables",
            "deere.eid.app.db.access.dtc",
            "deere.eid.app.db.access.dtc.filters",
            "deere.eid.app.db.access.dtc.temp_tables",
            "deere.eid.app.db.access.evidence",
            "deere.eid.app.db.access.evidence.temp_tables",
            "deere.eid.app.db.access.personal",
            "deere.eid.app.db.access.personal.temp_tables",
            "deere.eid.app.db.access.warranty",
            "deere.eid.app.db.access.warranty.temp_tables",
            "deere.eid.app.db.components",
            "deere.eid.app.db.components.custom",
            "deere.eid.app.db.components.custom.pub",
            "deere.eid.app.db.components.dtac",
            "deere.eid.app.db.components.dtac.intern",
            "deere.eid.app.db.components.dtac.pub",
            "deere.eid.app.db.components.dtc",
            "deere.eid.app.db.components.dtc.intern",
            "deere.eid.app.db.components.dtc.intern.charts",
            "deere.eid.app.db.components.dtc.intern.charts.affected_machs_ct",
            "deere.eid.app.db.components.dtc.intern.charts.affected_machs_eh",
            "deere.eid.app.db.components.dtc.intern.charts.DTC_Frequency",
            "deere.eid.app.db.components.dtc.intern.charts.eh_build_date",
            "deere.eid.app.db.components.dtc.intern.charts.KPI_ct",
            "deere.eid.app.db.components.dtc.intern.counts",
            "deere.eid.app.db.components.dtc.intern.framework",
            "deere.eid.app.db.components.dtc.intern.kpi_calculation",
            "deere.eid.app.db.components.dtc.intern.kpis",
            "deere.eid.app.db.components.dtc.intern.noise_reduction",
            "deere.eid.app.db.components.dtc.pub",
            "deere.eid.app.db.components.dtc.pub.charts",
            "deere.eid.app.db.components.dtc.pub.filters",
            "deere.eid.app.db.components.dtc.table_types",
            "deere.eid.app.db.components.evidence",
            "deere.eid.app.db.components.evidence.intern",
            "deere.eid.app.db.components.evidence.pub",
            "deere.eid.app.db.components.personal",
            "deere.eid.app.db.components.personal.pub",
            "deere.eid.app.db.components.warranty",
            "deere.eid.app.db.components.warranty.pub",
            "deere.eid.app.db.data",
            "deere.eid.app.db.data.app_data",
            "deere.eid.app.db.data.app_tables",
            "deere.eid.app.db.data.app_views",
            "deere.eid.app.db.data.repl_tables",
            "deere.eid.app.model",
            "deere.eid.app.security",
            "deere.eid.app.security.analytic_privileges",
            "deere.eid.app.security.roles",
            "deere.eid.app.test",
            "deere.eid.app.ui",
            "deere.eid.app.ui.customizing",
            "deere.eid.app.ui.jd",
            "deere.eid.app.ui.jd.ui",
            "deere.eid.app.ui.jd.ui.eid",
            "deere.eid.app.ui.jd.ui.eid.application",
            "deere.eid.app.ui.jd.ui.eid.application.customizing",
            "deere.eid.app.ui.jd.ui.eid.application.main",
            "deere.eid.app.ui.jd.ui.eid.application.print",
            "deere.eid.app.ui.jd.ui.eid.asset",
            "deere.eid.app.ui.jd.ui.eid.asset.data",
            "deere.eid.app.ui.jd.ui.eid.asset.img",
            "deere.eid.app.ui.jd.ui.eid.asset.less",
            "deere.eid.app.ui.jd.ui.eid.asset.less.application",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.commons",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.core",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.filter",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.table",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.ux3",
            "deere.eid.app.ui.jd.ui.eid.asset.less.control.viz",
            "deere.eid.app.ui.jd.ui.eid.asset.text",
            "deere.eid.app.ui.jd.ui.eid.common",
            "deere.eid.app.ui.jd.ui.eid.common.chart",
            "deere.eid.app.ui.jd.ui.eid.common.delegate",
            "deere.eid.app.ui.jd.ui.eid.common.formatter",
            "deere.eid.app.ui.jd.ui.eid.common.print",
            "deere.eid.app.ui.jd.ui.eid.common.validator",
            "deere.eid.app.ui.jd.ui.eid.control",
            "deere.eid.app.ui.jd.ui.eid.fragment",
            "deere.eid.app.ui.jd.ui.eid.fragment.chart",
            "deere.eid.app.ui.jd.ui.eid.fragment.chart.dtcdetails",
            "deere.eid.app.ui.jd.ui.eid.fragment.chart.evidencepackage",
            "deere.eid.app.ui.jd.ui.eid.fragment.dialog",
            "deere.eid.app.ui.jd.ui.eid.fragment.dialog.customizing",
            "deere.eid.app.ui.jd.ui.eid.fragment.dialog.main",
            "deere.eid.app.ui.jd.ui.eid.fragment.dialog.main.evidencepackage",
            "deere.eid.app.ui.jd.ui.eid.fragment.dtaccase",
            "deere.eid.app.ui.jd.ui.eid.fragment.dtaccase.details",
            "deere.eid.app.ui.jd.ui.eid.fragment.dtc",
            "deere.eid.app.ui.jd.ui.eid.fragment.dtc.details",
            "deere.eid.app.ui.jd.ui.eid.fragment.evidencepackage",
            "deere.eid.app.ui.jd.ui.eid.fragment.filter",
            "deere.eid.app.ui.jd.ui.eid.fragment.print",
            "deere.eid.app.ui.jd.ui.eid.fragment.quickview",
            "deere.eid.app.ui.jd.ui.eid.fragment.warrantyclaim",
            "deere.eid.app.ui.jd.ui.eid.fragment.warrantyclaim.details",
            "deere.eid.app.ui.jd.ui.eid.fragment.worksheet",
            "deere.eid.app.ui.jd.ui.eid.model",
            "deere.eid.app.ui.jd.ui.eid.service",
            "deere.eid.app.ui.jd.ui.eid.test",
            "deere.eid.app.ui.jd.ui.eid.test.application",
            "deere.eid.app.ui.jd.ui.eid.test.common",
            "deere.eid.app.ui.jd.ui.eid.test.common.formatter",
            "deere.eid.app.ui.jd.ui.eid.test.common.validator",
            "deere.eid.app.ui.jd.ui.eid.test.control",
            "deere.eid.app.ui.jd.ui.eid.test.model",
            "deere.eid.app.ui.jd.ui.eid.test.service",
            "deere.eid.app.ui.jd.ui.eid.test.view",
            "deere.eid.app.ui.jd.ui.eid.test.view.main",
            "deere.eid.app.ui.jd.ui.eid.test.view.main.worksheet",
            "deere.eid.app.ui.jd.ui.eid.view",
            "deere.eid.app.ui.jd.ui.eid.view.customizing",
            "deere.eid.app.ui.jd.ui.eid.view.customizing.shell",
            "deere.eid.app.ui.jd.ui.eid.view.main",
            "deere.eid.app.ui.jd.ui.eid.view.main.evidencepackage",
            "deere.eid.app.ui.jd.ui.eid.view.main.shared",
            "deere.eid.app.ui.jd.ui.eid.view.main.shell",
            "deere.eid.app.ui.jd.ui.eid.view.main.shell.personalization",
            "deere.eid.app.ui.jd.ui.eid.view.main.worksheet",
            "deere.eid.app.ui.jd.ui.eid.view.main.worksheet.discovery",
            "deere.eid.app.ui.jd.ui.eid.view.main.worksheet.evidence",
            "deere.eid.app.ui.jd.ui.eid.view.print",
            "deere.eid.app.ui.main",
            "deere.eid.app.ui.META-INF",
            "deere.eid.app.ui.print",
            "deere.eid.app.ui.target",
            "deere.eid.app.ui.target.jd",
            "deere.eid.app.ui.target.jd.ui",
            "deere.eid.app.ui.target.jd.ui.eid",
            "deere.eid.app.ui.target.jd.ui.eid.application",
            "deere.eid.app.ui.target.jd.ui.eid.application.customizing",
            "deere.eid.app.ui.target.jd.ui.eid.application.main",
            "deere.eid.app.ui.target.jd.ui.eid.application.print",
            "deere.eid.app.ui.target.jd.ui.eid.asset",
            "deere.eid.app.ui.target.jd.ui.eid.asset.css",
            "deere.eid.app.ui.target.jd.ui.eid.asset.css.application",
            "deere.eid.app.ui.target.jd.ui.eid.asset.img",
            "deere.eid.app.ui.target.jd.ui.eid.asset.text",
            "deere.eid.app.ui.target.jd.ui.eid.common",
            "deere.eid.app.ui.target.jd.ui.eid.common.chart",
            "deere.eid.app.ui.target.jd.ui.eid.common.delegate",
            "deere.eid.app.ui.target.jd.ui.eid.common.formatter",
            "deere.eid.app.ui.target.jd.ui.eid.common.print",
            "deere.eid.app.ui.target.jd.ui.eid.common.validator",
            "deere.eid.app.ui.target.jd.ui.eid.control",
            "deere.eid.app.ui.target.jd.ui.eid.fragment",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.chart",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.chart.dtcdetails",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.chart.evidencepackage",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dialog",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dialog.customizing",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dialog.main",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dialog.main.evidencepackage",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dtaccase",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dtaccase.details",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dtc",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.dtc.details",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.evidencepackage",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.filter",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.print",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.quickview",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.warrantyclaim",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.warrantyclaim.details",
            "deere.eid.app.ui.target.jd.ui.eid.fragment.worksheet",
            "deere.eid.app.ui.target.jd.ui.eid.model",
            "deere.eid.app.ui.target.jd.ui.eid.service",
            "deere.eid.app.ui.target.jd.ui.eid.view",
            "deere.eid.app.ui.target.jd.ui.eid.view.customizing",
            "deere.eid.app.ui.target.jd.ui.eid.view.customizing.shell",
            "deere.eid.app.ui.target.jd.ui.eid.view.main",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.evidencepackage",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.shared",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.shell",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.shell.personalization",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.worksheet",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.worksheet.discovery",
            "deere.eid.app.ui.target.jd.ui.eid.view.main.worksheet.evidence",
            "deere.eid.app.ui.target.jd.ui.eid.view.print",
            "deere.eid.app.ui.WEB-INF",
            "deere.eid.app.xs",
            "deere.eid.app.xs.custom",
            "deere.eid.app.xs.custom.lib",
            "deere.eid.app.xs.dtac",
            "deere.eid.app.xs.dtac.lib",
            "deere.eid.app.xs.dtc",
            "deere.eid.app.xs.dtc.filters",
            "deere.eid.app.xs.dtc.filters.lib",
            "deere.eid.app.xs.dtc.lib",
            "deere.eid.app.xs.evidence",
            "deere.eid.app.xs.evidence.lib",
            "deere.eid.app.xs.personal",
            "deere.eid.app.xs.personal.default_filters",
            "deere.eid.app.xs.personal.default_filters.lib",
            "deere.eid.app.xs.personal.dtc_blacklist",
            "deere.eid.app.xs.personal.dtc_blacklist.lib",
            "deere.eid.app.xs.util",
            "deere.eid.app.xs.util.lib",
            "deere.eid.app.xs.warranty",
            "deere.eid.app.xs.warranty.lib"
        ]
    },
    "project": {
        "name": "DEERE_EID_APP_SAP",
        "vendor": "deere.com",
        "version": "0.0.1",
        "description": ""
    },
    "cmdline": "--debug-files \"false\" --deploy-du-if-necessary \"true\" --validate \"false\" --ignore-download-errors \"false\" --X \"false\" --h \"false\" --view-migrate \"false\" --target-dir \"gen-1446043766\"",
    "isoTime": "2015-10-28T14:51:34.458Z",
    "mig-tool-version": "0.0.4"
};