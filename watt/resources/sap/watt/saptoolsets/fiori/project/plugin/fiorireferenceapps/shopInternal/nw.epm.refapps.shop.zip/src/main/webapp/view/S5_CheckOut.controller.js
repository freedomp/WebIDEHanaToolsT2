jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("nw.epm.refapps.lib.reuse.util.formatter");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("nw.epm.refapps.shop.view.S5_CheckOut", {
    /**
     * @memberOf nw.epm.refapps.shop.view.S5_CheckOut# - (used to enable outline view in Eclipse)
     */
    _oEventBus : null,
    _sIdentity : "nw.epm.refapps.shop",
    _oCheckOutTable : null,
    _fnRefreshBinding : null,

    onInit : function() {
        var oView = this.getView();
        // Use 'local' event bus of component for communication between views
        this._oEventBus = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(oView)).getEventBus();
        this._oCheckOutTable = this.byId("checkOutTable");
        this._fnRefreshBinding = jQuery.proxy(this.refreshBinding, this);

        oView.bindElement({
            path : "/ShoppingCarts(-1)",
            batchGroupId : "checkOut",
            parameters : {
                select : "FormattedCustomerName,FormattedAddress,Total,CurrencyCode,TotalQuantity"
            }
        });

        // Set the header and footer bar based on Scaffolding
        this.setHeaderFooterOptions(this._buildHFOptions());

        // Trigger a refresh to the shopping cart if the event is raised
        this._oEventBus.subscribe(this._sIdentity, "shoppingCartRefresh", this._fnRefreshBinding);

    },

    // Header and Footer buttons and Page title
    _buildHFOptions : function() {
        return {
            sI18NFullscreenTitle : "xtit.checkout",
            oHeaderBtnSettings : {
                sIcon : "sap-icon://cart",
                oTextBinding : {
                    elementPath : "/ShoppingCarts(-1)",
                    batchGroupId : "checkOut",
                    parameters : {
                        select : "TotalQuantity"
                    },
                    property : "TotalQuantity"
                },
                onBtnPressed : jQuery.proxy(this.onShoppingCartPressed, this)
            },
            oEditBtn : {
                // [KM]
                // ID is given to enable or disable the button depending on the user action
                sId : "BTNBook",
                sI18nBtnTxt : "xbut.buyNow",
                onBtnPressed : jQuery.proxy(this.onBuyNowPressed, this),
                bEnabled : true
            }
        };
    },

    // Navigate to the shopping cart screen
    onShoppingCartPressed : function() {
        this.oRouter.navTo("ShoppingCart", {}, false);
    },

    // Call a function import to submit the order
    onBuyNowPressed : function(oEvent) {
        // Disable the button so that the button cannot be clicked a second time
        this.setBtnEnabled("BTNBook", false);

        oEvent.getSource().getModel().callFunction("/BuyShoppingCart", {
            method : "POST",
            async : true,
            success : jQuery.proxy(this.onCartSrvSuccess, this),
            error : jQuery.proxy(this.onCartSrvError, this)
        });
    },

    // Refresh the view binding if the ShoppingCart was changed (for example, a new item was added)
    refreshBinding : function() {
        this.getHeaderBtn().getElementBinding().refresh();
        this._oCheckOutTable.getBinding("items").refresh();
    },

    // Service Error handling
    onCartSrvError : function(oResponse) {
        jQuery.sap.require("nw.epm.refapps.lib.reuse.util.messages");
        nw.epm.refapps.lib.reuse.util.messages.showErrorMessage(oResponse);
        this.setBtnEnabled("BTNBook", true);
    },

    // Go back to S2 and display a message toast that the shopping cart was ordered successfully
    onCartSrvSuccess : function() {
        jQuery.sap.require("sap.m.MessageToast");
        this.setBtnEnabled("BTNBook", true);
        this._oEventBus.publish(this._sIdentity, "shoppingCartRefresh");
        this.oRouter.navTo("ProductList", {}, false);
        sap.m.MessageToast.show(this.oApplicationFacade.getResourceBundle().getText("ymsg.checkOut"));
    }
});