(function() {
    "use strict";

    // Declare dependencies
    jd.ui.eid.require("jd.ui.eid.application.Application");
    jd.ui.eid.require("jd.ui.eid.model.EidModelListBinding");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");
    jd.ui.eid.require("jd.ui.eid.service.DTCBlacklistServiceFacade");

    // Prepare objects required for tests
    var oModel = new jd.ui.eid.model.EidModel({});
    sap.ui.getCore().setModel(oModel);
    var oListBinding = new jd.ui.eid.model.EidModelListBinding(oModel, "/DTCBlacklist");
    var oDTCBlacklistServiceFacade = new jd.ui.eid.service.DTCBlacklistServiceFacade("http://sap.com", "jd/ui/eid/asset/data/", oModel, true);

    // Module for getDTCBlacklist()
    module("jd.ui.eid.service.DTCBlacklistServiceFacade", {
        setup : function() {
            // Start spying on _retrieveList of BaseServiceFacade
            sinon.spy(oDTCBlacklistServiceFacade, "_retrieveList");
        },
        teardown : function() {
            // Stop spying on _retrieveList of BaseServiceFacade
            oDTCBlacklistServiceFacade._retrieveList.restore();
        }
    });

    // *** TEST CASE #1 ***
    test("getDTCBlacklist() should call the _retrieveList method with an empty object for custom payload, if no search term is provided", function() {
        // Placeholder to check for the request's custom payload
        var oCustomPayload;

        // Prepare other arguments for getDTCBlacklist()
        var sSearchTerm = null;

        // Test
        oDTCBlacklistServiceFacade.getDTCBlacklist(oListBinding, sSearchTerm, null, null);

        // Assertion
        oCustomPayload = oDTCBlacklistServiceFacade._retrieveList.getCall(0).args[5];
        equals(JSON.stringify(oCustomPayload), JSON.stringify({
            SearchTerm : ""
        }), "Empty object passed as custom payload when there is no search term.");
    });

    // *** TEST CASE #2 ***
    test("getDTCBlacklist() should call the _retrieveList method with an object with search term as attribute, when search term is provided",
            function() {
                // Placeholder to check for the request's custom payload
                var oCustomPayload;

                // Prepare other arguments for getDTCBlacklist()
                var sSearchTerm = "EIC";

                // Test
                oDTCBlacklistServiceFacade.getDTCBlacklist(oListBinding, sSearchTerm, null, null);

                // Assertion
                oCustomPayload = oDTCBlacklistServiceFacade._retrieveList.getCall(0).args[5];
                equals(JSON.stringify(oCustomPayload), JSON.stringify({
                    SearchTerm : sSearchTerm
                }), "An object with search term as attribute was passed as the custom payload");
            });
})();
