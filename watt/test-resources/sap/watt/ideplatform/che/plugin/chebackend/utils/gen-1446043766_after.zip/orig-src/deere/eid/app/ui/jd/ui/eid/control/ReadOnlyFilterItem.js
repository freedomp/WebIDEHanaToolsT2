(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.ReadOnlyFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");

    /**
     * @class The ReadOnlyFilterItem control provides read-only values. There is no user interaction with the control. The control can either display
     *        a single value via the text property or can display multiple values if the item aggregation is provided.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>noData : string (default: '') The text to display when no item is contained in the "items" aggregation is available.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>items : sap.ui.core.Item[] The items to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * 
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.ReadOnlyFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.ReadOnlyFilterItem", /** @lends jd.ui.eid.control.ReadOnlyFilterItem */
    {
        metadata : {
            properties : {
                noData : {
                    type : "string",
                    defaultValue : ""
                }
            },

            aggregations : {
                items : {
                    type : "sap.ui.core.Item",
                    singularName : "item",
                    multiple : true
                }
            }
        },

        /**
         * Initialize control and assign a custom style class.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);
            this.addStyleClass("jdUiEidReadOnlyFilterItem");
        },

        /**
         * Toggles the visibility of the filter item's content.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleCollapse : function(oEvent) {
            // Cannot be collapsed
        },

        /* Rendering */
        renderer : "jd.ui.eid.control.ReadOnlyFilterItemRenderer"
    });
})();