(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.common.formatter.WarrantyClaimFormatter");

    /**
     * @class
     * <p>
     * The Warranty Claim Summary View provides the detailed information about all Warranty Claims which have been added to the Evidence Package.
     * Moreover it also allows to remove a Warranty Claim from the list of selected Warranty Claims.
     * </p>
     * <p>
     * There are the following <strong>core methods</strong> of the WarrantyClaimList view:
     * <ul>
     * <li>{@link #.onInit} is called while opening the view. It registers the events fetchingData and dataFetched to the responsible event handlers.
     * Moreover it triggers a data fetch, to load all data from the backend.</li>
     * <li>{@link #.onExit} is called when the controller is destroyed. It unsubscribes the events fetchingData and dataFetched</li>
     * <li>{@link #.onAfterRendering} is called when the view has been rendered. It calls loadWarrantyClaimList to get the require data if it has not
     * been loaded already. </li>
     * <li>{@link #.loadWarrantyClaimList} is called to fetch the Warranty Claim details from the backend. </li>
     * <ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>handleEvidencePackageContextChanged is called when a new evidence package was loaded and new data is required.</li>
     * <li>handleModelFetchingData is called when the a new service request is triggered. It sets the view to busy state.</li>
     * <li>handleModelDataFetched is called after receiving the data from a service call. It disables the busy state of the view.</li>
     * <li>handleRemoveWarrantyClaim is called to remove Warranty Claim from the list of selected Warranty Claims.</li>
     * </ul>
     * </p>
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
     */

    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
    /** @lends jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary */
    {

        _oView : null,
        bRefresh : true,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        onInit : function() {
            // Get a reference to the view
            this._oView = this.getView();

            // Subscribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            oEventBus.subscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);
        },

        /**
         * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
         * This hook is the same one that SAPUI5 controls get after being rendered.
         * 
         * @memberOf jdui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        onAfterRendering : function() {
            if (this.bRefresh) {
                this.loadWarrantyClaimList();
                this.bRefresh = false;
            }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * 
         * @memberOf jdui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        onExit : function() {
            // Unsubcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFetched, this);
            oEventBus.unsubscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

            // Set properties to null
            this._oView = null;
        },

        /**
         * Handles the evidence package context change by resetting the refresh flag
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        handleEvidencePackageContextChanged : function() {
            this.bRefresh = true;
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for DTAC Case Details is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/WarrantyClaimDetailsList") {
                this._oView.setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for DTAC Case Details has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        handleModelDataFetched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/WarrantyClaimDetailsList") {
                this._oView.setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * This function is used to retrieve the list of details for all Warranty Claims in the Evidence Package
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        loadWarrantyClaimList : function() {
            var oModel = sap.ui.getCore().getModel();
            var oEvidencePackageDetailsHeader = oModel.getProperty("/EvidencePackageDetails/Header");
            var that = this;
            this.getServiceFacade("EvidencePackage").getWarrantyClaimDetailsList(oEvidencePackageDetailsHeader, null, function() {
                // Error handler, make sure that there are no old warranty claims sticking around in the list, so empty it.
                oModel.setProperty("/EvidencePackageDetails/WarrantyClaimDetailsList", []);
                that._onRequestFailed.apply(that, arguments);
            });
        },

        /**
         * This function is used to remove a Warranty Claim from the Evidence Package
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        handleRemoveWarrantyClaim : function(oEvent) {
            var mWarrantyClaim = oEvent.getSource().getBindingContext().getProperty();
            jd.ui.eid.common.BusinessProcessHelper.EvidencePackage.removeWarrantyClaim(mWarrantyClaim);
        },

        /**
         * Factory that creates a new Panel for each Warranty Claim.
         * 
         * @param {string}
         *            sId Unique ID passed by the framework to the factory
         * @param {sap.ui.model.Context}
         *            oContext The context for which a new Panel needs to be created
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        createWarrantyClaimSummaryPanel : function(sId, oContext) {
            // Use the Template fragment to create a Panel
            var oPanel = jd.ui.eid.xmlfragment(sId, "jd.ui.eid.fragment.evidencepackage.WarrantyClaimSummaryTemplate", this);

            // Based on the context, determine the path for this Warranty claim's filter selection.
            // Loop through /EvidencePackageDetails/Header/WarrantyClaimList to find the FilterSelection for the matching DTAC Case Number.
            var sContextPath = oContext.getPath();
            var sWarrantyClaimNumber = sap.ui.getCore().getModel().getProperty(sContextPath).WarrantyClaimNumber;
            var aWarrantyClaimList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/WarrantyClaimList");
            var iIndex;
            $.each(aWarrantyClaimList, function(i, oWarrantyClaim) {
                if (oWarrantyClaim.WarrantyClaimNumber == sWarrantyClaimNumber) {
                    iIndex = i;
                    return false;
                }
            });
            var sFilterSelectionPath = "/EvidencePackageDetails/Header/WarrantyClaimList/" + iIndex + "/WarrantyClaimFilterSelection";

            // Get the FilterArea and bind it's root path accordingly
            var oFilterArea = sap.ui.core.Fragment.byId(sId, "FilterArea");
            oFilterArea.setModel(sap.ui.getCore().getModel());
            oFilterArea.bindElement(sFilterSelectionPath);

            return oPanel;
        },

        /**
         * Event handler for the 'onBeforeSectionOpening' event raised by the Accordion just before the clicked section's content (itemTemplate) is
         * about to be made visible. The 'filter selection' in the warranty claim panel has a different binding path. This method makes sure that the
         * correct path is set on the filter selection (QuickView on the UI) before it is displayed.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event object
         * 
         * @memberOf jd.ui.eid.view.main.evidencepackage.WarrantyClaimSummary
         */
        handleOnBeforeAccordionSectionOpening : function(oEvent) {
            // Get the binding context of the Warranty Claim Summary template that is about to become visible to the user
            var oTemplate = sap.ui.core.Fragment.byId(this.createId("WarrantyClaimSummaryTemplate"),
                    "EvidencePackageWarrantyClaimDetailsMatrixLayout");
            var sContextPath = oTemplate.getBindingContext().getPath();

            // Based on the context, determine the path for this Warranty claim's filter selection.
            // Loop through /EvidencePackageDetails/Header/WarrantyClaimList to find the FilterSelection for the matching DTAC Case Number.
            var sWarrantyClaimNumber = sap.ui.getCore().getModel().getProperty(sContextPath).WarrantyClaimNumber;
            var aWarrantyClaimList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/WarrantyClaimList");
            var iIndex, sFilterSelectionPath;
            $.each(aWarrantyClaimList, function(i, oWarrantyClaim) {
                if (oWarrantyClaim.WarrantyClaimNumber == sWarrantyClaimNumber) {
                    iIndex = i;
                    return false;
                }
            });
            sFilterSelectionPath = "/EvidencePackageDetails/Header/WarrantyClaimList/" + iIndex + "/WarrantyClaimFilterSelection";

            // Get the FilterArea and bind its root path accordingly
            var oFilterArea = sap.ui.core.Fragment.byId(this.createId("WarrantyClaimSummaryTemplate"), "FilterArea");
            oFilterArea.bindElement(sFilterSelectionPath);
        }

    }));

})();