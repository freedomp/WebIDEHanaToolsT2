(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate");
    jd.ui.eid.require("jd.ui.eid.common.delegate.DTCFilterAreaDelegate");
    jd.ui.eid.require("jd.ui.eid.common.formatter.FilterAreaFormatter");

    /**
     * Constructor for a new DTCFilterAreaReadOnlyDelegate.
     * 
     * <ul>
     * <li>Events
     * <ul>
     * <li>editFilterArea : fired when the filter area is edited.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The DTCFilterAreaReadOnlyDelegate contains all necessary handlers of the date distance toolpopup with a valueListItem as an opener.
     * @extends jd.ui.eid.common.delegate.DTCFilterAreaDelegate
     * @name jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate
     */
    jd.ui.eid.common.delegate.DTCFilterAreaDelegate.extend("jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate", /** @lends jd.ui.eid.common.delegate.DTCFilterAreaReadOnlyDelegate */
    {
        metadata : {
            events : {
                editFilterArea : {},
            }
        },

        /**
         * The read-only filter area has no pop-up, so don't do anything.
         */
        initDTCCaptureTimeToolPopup : function() {
        },

        /**
         * The read-only filter area has no pop-up, so don't do anything.
         */
        initDTCFilterAreaActionToolPopup : function() {
        },

        /**
         * The read-only filter area has no pop-up, so don't do anything.
         */
        initNoiseReductionDateRangeToolPopup : function() {
        },

        /**
         * The read-only filter area has no pop-up, so don't do anything.
         */
        initEditModeControls : function() {
        },

        /**
         * Handles the editing of the filter area by propagating event The parameter "filterFragment" contains the fragment object where which event
         * was originally raised
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         */
        handleEditFilterArea : function(oEvent) {
            this.fireEditFilterArea({
                filterFragment : oEvent.getSource()
            });
        }
    });

})();