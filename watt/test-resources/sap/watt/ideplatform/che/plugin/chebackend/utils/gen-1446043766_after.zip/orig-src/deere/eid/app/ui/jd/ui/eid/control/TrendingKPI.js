(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TrendingKPI");

    /**
     * Constructor for a new TrendingKPI.
     * <ul>
     * <li>Aggregations
     * <ul>
     * <li>breadcrumbs : sap.ui.core.Item[] The breadcrumbs to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.TrendingKPI
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.TrendingKPI", /** @lends jd.ui.eid.control.TrendingKPI */
    {
        metadata : {
            properties : {
                text : {
                    type : "string",
                    defaultValue : ""
                }
            },
            aggregations : {
                image : {
                    type : "sap.ui.commons.Image",
                    multiple : false
                },
                textView : {
                    type : "sap.ui.commons.TextView",
                    multiple : false
                }
            }
        },

        /* Control Rendering */

        /**
         * Renders the control.
         * 
         * @param {sap.ui.core.RenderManager}
         *            oRm The RenderManager that can be used for writing to the render output buffer.
         * @param {jd.ui.eid.control.TextWithImage}
         *            oControl The control that should be rendered.
         */
        renderer : function(oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addClass("jdUiEidTrendingKPI");
            oRm.writeClasses();
            oRm.write(">");
            oRm.renderControl(oControl.getImage());
            oRm.renderControl(oControl.getTextView());
            oRm.write("</div>");
        }
    });
})();