(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TagCloudFilterItemRenderer");
    jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

    /**
     * Default renderer for control jd.ui.eid.control.TagCloudFilterItem.
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItemRenderer
     * @static
     * @name jd.ui.eid.control.TagCloudFilterItemRenderer
     */
    jd.ui.eid.control.TagCloudFilterItemRenderer = {};

    // Inherit base renderer
    $.extend(jd.ui.eid.control.TagCloudFilterItemRenderer, jd.ui.eid.control.FilterItemRenderer);

    /**
     * Hook into the content rendering.
     */
    jd.ui.eid.control.TagCloudFilterItemRenderer._renderContent = function(oRm, oControl) {
        oRm.renderControl(oControl.getAggregation("_breadcrumbNavigation"));
        oRm.renderControl(oControl.getAggregation("_tagCloud"));
    };

})();