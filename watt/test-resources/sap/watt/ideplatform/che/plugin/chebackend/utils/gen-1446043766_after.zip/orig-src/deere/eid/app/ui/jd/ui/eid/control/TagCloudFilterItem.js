(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.TagCloudFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.BreadcrumbNavigation");
    jd.ui.eid.require("jd.ui.eid.control.TagCloud");
    jd.ui.eid.require("jd.ui.eid.control.Tag");

    /**
     * The TagCloudFilterItem control provides a cloud of tags, which can be selected and than displayed in the breadcrumb.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>noData : string (default: '') Text to display if no tags are provided.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>tags : jd.ui.eid.control.Tag[] The tag cloud items to to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.TagCloudFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.TagCloudFilterItem", /** @lends jd.ui.eid.control.TagCloudFilterItem */
    {
        metadata : {
            properties : {
                noData : {
                    type : "string",
                    defaultValue : ''
                }
            },

            aggregations : {
                _breadcrumbNavigation : {
                    type : "jd.ui.eid.control.BreadcrumbNavigation",
                    multiple : false,
                    visiblity : "hidden"
                },
                _tagCloud : {
                    type : "jd.ui.eid.control.TagCloud",
                    multiple : false,
                    visibility : "hidden"
                },
                tags : {
                    type : "jd.ui.eid.control.Tag",
                    multiple : true,
                    singularName : "tag"
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            this.addStyleClass("jdUiEidTagCloudFilterItem");

            // Initialize breadcrumbNavigation
            var oBreadcrumbNavigation = new jd.ui.eid.control.BreadcrumbNavigation({
                change : [this._handleBreadCrumbNavigationChanged, this]
            });
            this.setAggregation("_breadcrumbNavigation", oBreadcrumbNavigation);

            // Initialize tag cloud
            var oTagCloud = new jd.ui.eid.control.TagCloud({
                select : [this._handleTagSelected, this]
            });
            this.setAggregation("_tagCloud", oTagCloud);

        },

        /* Internal Event Handlers */

        /**
         * This event handler adds a selected tagcloud item to the breadcrumb navigation.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleTagSelected : function(oEvent) {
            // Get text of clicked tag
            var mTag = oEvent.getParameter("tag");

            // Create a new breadcrumb for clicked tag
            var oBreadcrumb = new sap.ui.core.Item({
                text : mTag.Tag
            });

            // Add breadcrumb to breadcrumb navigation
            this.getAggregation("_breadcrumbNavigation").addBreadcrumb(oBreadcrumb);

            // Update model by reading all selected tags
            var aSelectedTags = this.getProperty("selection");
            aSelectedTags.push(mTag);

            // Set selection property directly to avoid setter logic
            this.setProperty("selection", aSelectedTags);
            this.setActive(true);

            this.fireValueChanged();
        },

        /**
         * This event handler removes breadcrumbs from the breadcrumb navigation.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleBreadCrumbNavigationChanged : function(oEvent) {
            // Get the selected breadcrumb
            var selectedBreadcrumbIndex = oEvent.getParameter("selectedBreadCrumbIndex");

            // Get the list of selected tags
            var aSelectedTags = this.getProperty("selection");

            // Remove all tags befind the selected breadcrumb index
            aSelectedTags.splice(selectedBreadcrumbIndex + 1, aSelectedTags.length);

            // Set selection property directly to avoid setter logic
            this.setProperty("selection", aSelectedTags);
            this.setActive(true);

            this.fireValueChanged();
        },

        /* Custom Getter & Setter */

        /**
         * @see jd.ui.eid.control.TagCloud#addTag
         */
        addTag : function(oTag) {
            this.getAggregation("_tagCloud").addTag(oTag);
            return this;
        },

        destroyTags : function() {
            this.getAggregation("_tagCloud").destroyTags();
            return this;
        },

        getTags : function() {
            return this.getAggregation("_tagCloud").getTags();
        },

        indexOfTag : function(oTag) {
            return this.getAggregation("_tagCloud").indexOfTag(oTag);
        },

        insertTag : function(oTag, iIndex) {
            this.getAggregation("_tagCloud").insertTag(oTag, iIndex);
            return this;
        },

        removeAllTags : function() {
            return this.getAggregation("_tagCloud").removeAllTags();
        },

        removeTag : function(oTag) {
            return this.getAggregation("_tagCloud").removeTag(oTag);
        },

        /**
         * Set the "No Data" text on the Tag Cloud
         * 
         * @param {String}
         *            sNoData String to display no data.
         * 
         */
        setNoData : function(sNoData) {
            return this.getAggregation("_tagCloud").setNoData(sNoData);
        },

        /**
         * Add default selection
         */
        setSelection : function(aValues) {
            this.setProperty('selection', aValues);
            // Reset the breadcrumb selection before updating
            this.getAggregation("_breadcrumbNavigation").removeAllBreadcrumbs();

            if (aValues !== undefined) {
                // Set the filteritem active flag to indicate that a selection was set
                this.setActive(aValues.length > 0);
                for ( var i = 0; i < aValues.length; i++) {
                    var oBreadcrumb = new sap.ui.core.Item({
                        text : aValues[i].Tag
                    });
                    this.getAggregation("_breadcrumbNavigation").addBreadcrumb(oBreadcrumb);
                }
            } else {
                this.setActive(false);
            }

            return this;
        },

        /* Control Logic */

        /**
         * @see jd.ui.eid.control.FilterItem
         */
        _clear : function() {
            var aCurrentSelection = this.getSelection();
            var aEmptySelection = [];
            if (!$.sap.equal(aCurrentSelection, aEmptySelection)) {
                this.getAggregation("_breadcrumbNavigation").removeAllBreadcrumbs();
                this.setSelection(aEmptySelection);
                // Remove the filteritem active flag to indicate that the selection was deleted
                return true;
            } else {
                return false;
            }
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.TagCloudFilterItemRenderer"

    });

})();