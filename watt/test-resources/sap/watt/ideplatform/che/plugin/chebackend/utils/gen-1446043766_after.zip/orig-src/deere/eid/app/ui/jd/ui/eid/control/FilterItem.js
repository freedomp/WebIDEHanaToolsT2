(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.FilterItem");

    /**
     * The FilterItem control is the base class of specific filter items. It provides functionality to collapse & expand its content. This is done by
     * using jQuery's .hide() and .show() methods. It provides a hook mechanism for clear. Subclasses can implement their own clear logic in the
     * _clear() method. It provides a hook mechanism for reset. Subclasses can implement their own reset logic in the _reset() method. The control
     * manages a selection indicator which is displayed along with the caption. It should indicate e.g. whether the filter is set or how many items
     * are set. The property has to be managed by subclasses. The properties selection and defaultSelection are meant for subclasses and not used by
     * this control. Subclasses should use these properties to maintain their current selection and the default selection which could e.g. be used
     * when the filter item is reset. The header of a filter item has some special UX requirements when the text overflows which cannot be implemented
     * with CSS only, so there is Javascript logic triggered in <code>onAfterRendering</code> to read the desired behavior.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>caption : string (default: '') The caption of the filter item.</li>
     * <li>clearLabel : string (default: '') The label of the clear control.</li>
     * <li>collapsed : boolean (default: false) True if the filter item should be collapsed, false otherwise.</li>
     * <li>collapseTooltip : string (default: '') The tooltip displayed on the collapse icon and the caption when the filter item is collapses.</li>
     * <li>defaultSelection : object (default: {}) The object representing the default selection.</li>
     * <li>expandTooltip : string (default: '') The tooltip displayed on the collapse icon and the caption when the filter item is expanded.</li>
     * <li>selection : object (default: {}) The object representing the current selection.</li>
     * <li>showSelectionIndicator : boolean (default: true) True of the selection indicator property should be displayed, false otherwise.</li>
     * <li>selectionIndicator : string (default: '') The text indicating the current selection, e.g. '2/3'.</li>
     * <li>visible : boolean (default: true) True if the filter item should be visible, false otherwise.</li>
     * </ul>
     * </li>
     * <li>Events
     * <ul>
     * <li>cleared : Raised when the filter item was cleared.</li>
     * <li>reset : Raised when the filter item was reset.</li>
     * <li>valueChanged : Raised when the filter changed its value.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends sap.ui.core.Control
     * @name jd.ui.eid.control.FilterItem
     */
    sap.ui.core.Control.extend("jd.ui.eid.control.FilterItem", /** @lends jd.ui.eid.control.FilterItem */
    {

        metadata : {
            properties : {
                active : {
                    type : "boolean",
                    defaultValue : false
                },
                caption : {
                    type : "string",
                    defaultValue : ""
                },
                clearLabel : {
                    type : "string",
                    defaultValue : ""
                },
                collapsed : {
                    type : "boolean",
                    defaultValue : false
                },
                collapseTooltip : {
                    type : "string",
                    defaultValue : ""
                },
                defaultSelection : {
                    type : "object",
                    defaultValue : {}
                },
                expandTooltip : {
                    type : "string",
                    defaultValue : ""
                },
                selection : {
                    type : "object",
                    defaultValue : {}
                },
                showSelectionIndicator : {
                    type : "boolean",
                    defaultValue : true
                },
                selectionIndicator : {
                    type : "string",
                    defaultValue : ""
                },
                visible : {
                    type : "boolean",
                    defaultValue : true
                }
            },
            aggregations : {
                _clear : {
                    type : "sap.ui.commons.Link",
                    multiple : false,
                    visibility : "hidden"
                },
                _help : {
                    type : "sap.ui.core.Control",
                    multiple : false,
                    visibility : "hidden"
                }
            },
            events : {
                cleared : {},
                reset : {},
                valueChanged : {}
            }
        },

        /**
         * Initialize the control and its internal aggregations.
         */
        init : function() {
            this.setAggregation("_clear", new sap.ui.commons.Link({
                press : [this._handleClear, this]
            }).addStyleClass("jdUiLnk "));
            this.setAggregation("_help", new sap.ui.commons.Image({
                src : "jd/ui/eid/asset/img/help_icon_green.png"
            }).addStyleClass("jdUiImg "));
        },

        /* Internal Event Handlers */

        /**
         * Calls the clear method of the control to clear the selection.
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the fired event.
         */
        _handleClear : function(oEvent) {
            this.clear();
        },

        /**
         * Toggles the visibility of the filter item's content.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleCollapse : function(oEvent) {
            // Update internal state / control property
            var bContentVisible = !this.getCollapsed();
            this.setCollapsed(bContentVisible);

            // Toggle visibility of the content part of the filter item.
            if (bContentVisible) {
                this.$().find('.jdUiEidFilterItemContent').show();
            } else {
                this.$().find('.jdUiEidFilterItemContent').hide();
            }
        },

        /* Custom Getter & Setter */

        setActive : function(bValue) {
            this.setProperty("active", bValue);
            if (bValue) {
                this.addStyleClass("jdUiEidFilterItemActive");
            } else {
                this.removeStyleClass("jdUiEidFilterItemActive");
            }
            return this;
        },

        /**
         * Custom setter for the clearLabel property, so that the value is propagated to the internal aggregation.
         * 
         * @param {string}
         *            sValue the label for the clear control.
         * @returns {jd.ui.eid.control.FilterArea} this.
         */
        setClearLabel : function(sValue) {
            this.setProperty("clearLabel", sValue);
            this.getAggregation("_clear").setText(sValue);
            return this;
        },

        /**
         * Sets the new tooltip for this object. The tooltip will be displayed only for the help control.
         * 
         * @param {string|sap.ui.core.TooltipBase}
         *            oTooltip the tooltip
         */
        setTooltip : function(oTooltip) {
            this.getAggregation("_help").setTooltip(oTooltip);
        },

        /**
         * Returns the tooltip for this element.
         * 
         * @returns {string|sap.ui.core.TooltipBase}
         */
        getTooltip : function() {
            this.getAggregation("_help").getTooltip();
        },

        /* Control Logic */

        /**
         * Clear the filter item and fire the clear event afterwards.
         */
        clear : function() {
            if (this._clear() === true) {
                this.fireCleared();
            }
        },

        /**
         * Hook method for sub classes. This method may not fire the cleared event.
         * 
         * @returns {boolean} true if the selection was changed, false if it was already set to default.
         */
        _clear : function() {
            return false;
        },

        /**
         * Resets the control to its default selection and fires the reset event afterwards.
         */
        reset : function() {
            this._reset();
            this.fireReset();
        },

        /**
         * Hook method for sub classes. This method may not fire the reset event.
         */
        _reset : function() {

        },

        /**
         * Adjusts the filter item's header after rendering. If the caption exceeds the available space, it will be displayed with an ellipsis.
         * However, the selection indicator and the tooltip for the description should still be visible and thus, dock right, next to the header items
         * (e.g. clear).
         */
        _adjustHeaderAfterRendering : function() {
            // Get references to the relevant elements
            var elTextWrapper = this.$().find('.jdUiEidFilterItemHeader .jdUiEidFilterItemHeaderTextWrapper')[0];
            var elCaption = this.$().find('.jdUiEidFilterItemHeader .jdUiEidFilterItemCaption')[0];
            var elDockRight = this.$().find('.jdUiEidFilterItemHeader .jdUiEidFilterItemHeaderDockRight')[0];

            // Do some base calculations
            // NB: In order for scrollWidth to work, the element may not have display:inline
            // assigned.
            var iMaxWidthOfCaption = elTextWrapper.offsetWidth - elDockRight.offsetWidth;// - 20;

            // If the maxWidth is zero, then the control is initially rendered, so we don't need to
            // do anything
            var $dockRight = $(elDockRight);
            var $caption = $(elCaption);
            if (iMaxWidthOfCaption != 0 && elCaption.scrollWidth > iMaxWidthOfCaption) {
                $(elTextWrapper).addClass("jdUiEidFilterItemHeaderTextWrapperOverflowing");
                // Swap the control order so that we can apply float:right to the div that should
                // dock right.
                $dockRight.insertBefore($caption);
            } else {
                $(elTextWrapper).removeClass("jdUiEidFilterItemHeaderTextWrapperOverflowing");
                $caption.insertBefore($dockRight);
                // $dockRight.insertAfter($caption);

            }
        },

        /* Control Rendering */

        /**
         * Attaches event handlers to DOM elements and triggers adjustment of the header.
         */
        onAfterRendering : function() {
            // Attach event handler
            this.$().find('.jdUiEidFilterItemCollapseIcon').bind("click", $.proxy(this._handleCollapse, this));
            this.$().find('.jdUiEidFilterItemCaption').bind("click", $.proxy(this._handleCollapse, this));
            this.$().find('.jdUiEidFilterItemHeaderTextWrapper').bind("mouseenter", $.proxy(this._adjustHeaderAfterRendering, this));
            this.$().find('.jdUiEidFilterItemHeaderTextWrapper').bind("mouseleave", $.proxy(this._adjustHeaderAfterRendering, this));

            this._adjustHeaderAfterRendering();
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onBeforeRendering : function() {
            // Detach event handlers
            this.$().find('.jdUiEidFilterItemCollapseIcon').unbind("click", this._handleCollapse);
            this.$().find('.jdUiEidFilterItemCaption').unbind("click", this._handleCollapse);
            this.$().find('.jdUiEidFilterItemHeaderTextWrapper').unbind("hover", this._adjustHeaderAfterRendering);
        },

        /**
         * Detaches event handlers from DOM elements.
         */
        onExit : function() {
            // Detach event handlers
            this.$().find('.jdUiEidFilterItemCollapseIcon').unbind("click", this._handleCollapse);
            this.$().find('.jdUiEidFilterItemCaption').unbind("click", this._handleCollapse);
            this.$().find('.jdUiEidFilterItemHeaderTextWrapper').unbind("hover", this._adjustHeaderAfterRendering);
        },

        renderer : "jd.ui.eid.control.FilterItemRenderer"

    });

})();