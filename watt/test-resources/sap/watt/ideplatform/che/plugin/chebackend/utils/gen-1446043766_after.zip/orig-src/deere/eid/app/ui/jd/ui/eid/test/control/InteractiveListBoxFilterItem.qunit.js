(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.InteractiveListBoxFilterItem");

    var oFilterItem = null;
    var oModel = null;
    var oData = {
        emptySelectedKeys : [],
        selectedKeys : [1, 2],
        defaultKeys : [2],
        objectKeys : [{
            surrogateKey : "1",
            additional : "one"
        }, {
            surrogateKey : "2",
            additional : "two"
        }, {
            surrogateKey : "3",
            additional : "three"
        }],
        domainValues : [{
            ID : 'a',
            Name : 'a'
        }, {
            ID : 'b',
            Name : 'b'
        }],
        booleanKeyTrue : true,
        booleanKeyFalse : false
    };

    module("jd.ui.eid.control.InteractiveListBoxFilterItem.prototype", {
        setup : function() {
            // We can use a regular JSON model for testing here.
            oModel = new sap.ui.model.json.JSONModel(jQuery.extend(true, {}, oData));
            oFilterItem = new jd.ui.eid.control.InteractiveListBoxFilterItem({
                items : [new sap.ui.core.Item({
                    key : 1,
                    text : "Item 1"
                }), new sap.ui.core.Item({
                    key : 2,
                    text : "Item 2"
                }), new sap.ui.core.Item({
                    key : 3,
                    text : "Item 3"
                })]
            });
            oFilterItem.setModel(oModel);
        },
        teardown : function() {
            oFilterItem = null;
            oModel = null;
        }
    });

    test("_getDomainValues() should return the array bound to the items aggregation.", function() {
        oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
            text : "{Name}"
        }));

        // Initial assertions
        equals(oFilterItem.getItems().length, oData.domainValues.length);

        // Execute the business logic
        var aDomainValues = oFilterItem._getDomainValues();

        // Final assertions
        deepEqual(aDomainValues, oData.domainValues);
    });

    test(
            "_getDomainValues() should return the array bound to the items aggregation if its an absolute path, even though the control has been bound to a different context.",
            function() {
                oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
                    text : "{Name}"
                }));
                oFilterItem.bindElement("/randomPath");

                // Initial assertions
                equals(oFilterItem.getItems().length, oData.domainValues.length);

                // Execute the business logic
                var aDomainValues = oFilterItem._getDomainValues();

                // Final assertions
                deepEqual(aDomainValues, oData.domainValues);
            });

    test("_addDomainValue() should add the provided string as an object with ID and Name properties to the domain values in the model.", function() {
        oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
            text : "{Name}"
        }));

        // Initial assertions
        equals(oFilterItem.getItems().length, oData.domainValues.length);

        var sItem = "newItem";
        oFilterItem._addDomainValue(sItem);

        equals(oModel.getData().domainValues.length, 3);
    });

    test("_removeDomainValue() should remove the item at the given index from the domain values in the model.", function() {
        oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
            text : "{Name}"
        }));

        // Initial assertions
        equals(oFilterItem.getItems().length, oData.domainValues.length);

        oFilterItem._removeDomainValue(0);

        equals(oModel.getData().domainValues.length, 1);
    });

    test("_updateDomainValue() should change the domain value at the given index to the given value in the model.", function() {
        oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
            text : "{Name}"
        }));

        // Initial assertions
        equals(oFilterItem.getItems().length, oData.domainValues.length);

        oFilterItem._updateDomainValue(0, "test");

        equals(oModel.getData().domainValues.length, 2);
        equals(oModel.getData().domainValues[0].ID, "test");
        equals(oModel.getData().domainValues[0].Name, "test");
    });

    test("_clearDomainValues() should set the domain values to an empty array in the model.", function() {
        oFilterItem.bindAggregation('items', '/domainValues', new sap.ui.core.Item({
            text : "{Name}"
        }));

        // Initial assertions
        equals(oFilterItem.getItems().length, oData.domainValues.length);

        oFilterItem._clearDomainValues();

        equals(oModel.getData().domainValues.length, 0);
    });

    test("_getSelection() should return the array bound to the selection property.", function() {
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Initial assertions
        equals(oFilterItem.getSelection().length, oData.selectedKeys.length);

        // Execute the business logic
        var aSelection = oFilterItem._getSelection();

        // Final assertions
        deepEqual(aSelection, oData.selectedKeys);
    });

    test(
            "_getSelection() should return the array bound to the selection property if its an absolute path, even though the control has been bound to a different context.",
            function() {
                oFilterItem.bindProperty('selection', '/selectedKeys');
                oFilterItem.bindElement('/randomPath');

                // Initial assertions
                equals(oFilterItem.getSelection().length, oData.selectedKeys.length);

                // Execute the business logic
                var aSelection = oFilterItem._getSelection();

                // Final assertions
                deepEqual(aSelection, oData.selectedKeys);
            });

    test("_updateSelection() should update the selection in the model.", function() {
        oFilterItem.bindProperty('selection', '/selectedKeys');

        // Initial assertions
        equals(oFilterItem.getSelection().length, oData.selectedKeys.length);
        deepEqual(oFilterItem.getSelection(), oData.selectedKeys);

        var aNewSelection = ["one", "two"];
        oFilterItem._updateSelection(aNewSelection);

        // Final assertions
        deepEqual(oModel.getProperty("/selectedKeys"), aNewSelection);
    });

    module("jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser", {
        setup : function() {

        },
        teardown : function() {
        }
    });

    test("_harmonizeSeparators() should not change the input string if not other separators are provided.", function() {
        var sIn = "test test2 test3";
        var sLeadingSeparator = " ";
        var aOtherSeparators = [];

        var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._harmonizeSeparators(sIn, sLeadingSeparator, aOtherSeparators);
        var sExp = sIn;

        deepEqual(sAct, sExp);
    });

    test("_harmonizeSeparators() should replace single occurences of other separators with the leading separator (single other separator provided).",
            function() {
                var sIn = "test test2;test3";
                var sLeadingSeparator = " ";
                var aOtherSeparators = [";"];

                var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._harmonizeSeparators(sIn, sLeadingSeparator,
                        aOtherSeparators);
                var sExp = "test test2 test3";

                deepEqual(sAct, sExp);
            });

    test("_harmonizeSeparators() should replace single occurences of other separators with the leading separator (many other separators provided).",
            function() {
                var sIn = "test test2;test3\ntest4";
                var sLeadingSeparator = " ";
                var aOtherSeparators = [";", "\n"];

                var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._harmonizeSeparators(sIn, sLeadingSeparator,
                        aOtherSeparators);
                var sExp = "test test2 test3 test4";

                deepEqual(sAct, sExp);
            });

    test(
            "_harmonizeSeparators() should replace multiple occurences of other separators with the leading separator (single other separator provided).",
            function() {
                var sIn = "test test2;;test3";
                var sLeadingSeparator = " ";
                var aOtherSeparators = [";"];

                var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._harmonizeSeparators(sIn, sLeadingSeparator,
                        aOtherSeparators);
                var sExp = "test test2  test3";

                deepEqual(sAct, sExp);
            });

    test(
            "_harmonizeSeparators() should replace multiple occurences of other separators with the leading separator (many other separators provided).",
            function() {
                var sIn = "test test2;\ntest3\n;test4";
                var sLeadingSeparator = " ";
                var aOtherSeparators = [";", "\n"];

                var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._harmonizeSeparators(sIn, sLeadingSeparator,
                        aOtherSeparators);
                var sExp = "test test2  test3  test4";

                deepEqual(sAct, sExp);
            });

    test("_trimSeparators() should preserve single occurences of the separator provided as parameter.", function() {
        var sIn = "test test2 test3";
        var sLeadingSeparator = " ";

        var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._trimSeparators(sIn, sLeadingSeparator);
        var sExp = sIn;

        deepEqual(sAct, sExp);
    });

    test("_trimSeparator() should transform multiple occurences of the separator provided as parameter to single occurences.", function() {
        var sIn = "test   test2      test3";
        var sLeadingSeparator = " ";

        var sAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser._trimSeparators(sIn, sLeadingSeparator);
        var sExp = "test test2 test3";

        deepEqual(sAct, sExp);
    });

    test("parse() should not split the string if no separator is provided.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [];
        var sIn = "test test2 test3";
        var aExp = ["test test2 test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should split a string at the separator if a single separator is provided.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [" "];
        var sIn = "test test2 test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should split a string at the separator if multiple separators are provided.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [" ", ";"];
        var sIn = "test test2;test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should split a string at the separator if multiple separators are provided and are repeated.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [" ", ";"];
        var sIn = "test   test2;;;;test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should split a string at the separator if multiple separators are provided and are repeated.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [";", " "];
        var sIn = "test   test2;test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should split a string at the separator if multiple separators are provided and are repeated.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = ["\n", " ", ";"];
        var sIn = "test   test2;test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should remove duplicates.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [","];
        var sIn = "test,test,test2,test3";
        var aExp = ["test", "test2", "test3"];
        var aAct = jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn);
        deepEqual(aAct, aExp);
    });

    test("parse() should change the iNumberOfDuplicates property of the optional parameter variable to zero if there are no duplicates.", function() {
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [","];
        var sIn = "test,test2,test3";
        var mParameters = {};
        jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn, mParameters);
        ok(mParameters.iNumberOfDuplicates === 0);
    });

    test(
            "parse() should change the iNumberOfDuplicates property of the optional parameter variable to the number of duplicates if there are duplicates.",
            function() {
                jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.Separators = [","];
                var sIn = "test,test,test2,test3";
                var mParameters = {};
                jd.ui.eid.control.InteractiveListBoxFilterItem.BatchInsertParser.parse(sIn, mParameters);
                ok(mParameters.iNumberOfDuplicates === 1);
            });

})();