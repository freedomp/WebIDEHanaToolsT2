(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");

    /**
     * @class
     * <p>
     * The view displays a list of PINs (i.e. machines) of the current evidence package.
     * </p>
     * <h2>Controls</h2>
     * <p>
     * The view consists only of a Table control with a search field in its toolbar.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @augments jd.ui.eid.view.BaseController
     * @name jd.ui.eid.view.main.evidencepackage.PINPopulationSummary
     */
    sap.ui.controller("jd.ui.eid.view.main.evidencepackage.PINPopulationSummary", jQuery.extend(true, {}, jd.ui.eid.view.BaseController, /** @lends jd.ui.eid.view.main.evidencepackage.PINPopulationSummary */
    {
        _oService : null,

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View before it
         * is displayed, to bind event handlers and do other one-time initialization.
         * 
         * @memberOf jdui.eid.view.main.evidencepackage.PINPopulationSummary
         */
        onInit : function() {
            // Subcribe to event bus
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.subscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.subscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
            oEventBus.subscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

            // Set refresh flag to get the data from the backend for the current evidence package
            this.bRefresh = true;

            // Get an instance of EvidencePackageServiceFacade
            this._oService = this.getServiceFacade("EvidencePackage");
            this._oService.attachRequestFailed(this._onRequestFailed);
        },

        /**
         * Called after UI has been rendered.
         */
        onAfterRendering : function() {
            // Get the PIN Population List
            if (this.bRefresh) {
                this.fetchPINPopulationList();
                this.bRefresh = false;
            }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         */
        onExit : function() {
            // Unsubscribe from event bus.
            var oEventBus = sap.ui.getCore().getEventBus();
            oEventBus.unsubscribe('EidModel', 'fetchingData', this.handleModelFetchingData, this);
            oEventBus.unsubscribe('EidModel', 'dataFetched', this.handleModelDataFeteched, this);
            oEventBus.unsubscribe('EvidencePackageView', 'contextChanged', this.handleEvidencePackageContextChanged, this);

            // Detach events
            this._oService.detachRequestFailed(this._onRequestFailed);

            // Set properties to null
            this._oService = null;
        },

        /**
         * Handles the evidence package context change by resetting the refresh flag
         * 
         * @memberOf jdui.eid.view.main.evidencepackage.PINPopulationSummary
         */
        handleEvidencePackageContextChanged : function() {
            this.bRefresh = true;
            // Also, clear the search field
            this.byId("searchField").setValue('');
        },

        /* SECTION - Event Bus Handling - START */

        /**
         * Handles the event fired when data for the PIN Population List is fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelFetchingData : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/PINPopulationList") {
                this.byId("PINPopulationList").setBusy(true);
            }
        },

        /**
         * Handles the event fired when data for the PIN Population list has been fetched.
         * 
         * @param {string}
         *            sChannelId the channel id.
         * @param {string}
         *            sEvent the event name.
         * @param {object}
         *            oData data passed along with the event.
         */
        handleModelDataFeteched : function(sChannelId, sEvent, oData) {
            if (oData.sPath == "/EvidencePackageDetails/PINPopulationList") {
                this.byId("PINPopulationList").setBusy(false);
            }
        },

        /* SECTION - Event Bus Handling - END */

        /**
         * Triggers a request to get the PIN Population List and update the model.
         * 
         * @memberOf jdui.eid.view.main.evidencepackage.PINPopulationSummary
         */
        fetchPINPopulationList : function() {
            // Get binding and search term from UI
            var oBinding = this.byId("PINPopulationList").getBinding();
            var sSearchTerm = this.byId("searchField").getValue();
            var oEvidencePackageHeader = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header");

            // Get the PIN population list
            this._oService.getEvidencePackagePINPopulationList(oBinding, sSearchTerm, oEvidencePackageHeader, null, this._onRequestFailed);
        },

        /**
         * Formatter for the 'JDLink Machine' column. Formats the boolean value returned by the backend (true/false) into string (Active, Inactive)
         * 
         * @param {Boolean}
         *            bJDLinkMachine The boolean value representing whether the PIN is JDLink active
         * @returns {String} Either "Active" or "Inactive", depending on the input
         */
        formatJDLinkMachineColumn : function(bJDLinkMachine) {
            if (bJDLinkMachine) {
                return jd.ui.eid.common.I18NHelper.getText("MACHINE_DETAILS_TXT_JDLINK_ACTIVE");
            } else {
                return jd.ui.eid.common.I18NHelper.getText("MACHINE_DETAILS_TXT_JDLINK_INACTIVE");
            }
        },

        /**
         * Formatter for the 'PIN count' in the table's toolbar
         * 
         * @param {Array}
         *            aPINList The PIN list
         * @returns {String} A formatted string representing the number of available PINs
         */
        formatPINCount : function(aPINList) {
            var iLength = 0;
            var oListBinding = this.byId("PINPopulationList").getBinding("rows");
            if (oListBinding) {
                iLength = jd.ui.eid.common.formatter.NumberFormatter.formatInteger(oListBinding.getLength());
            }
            return jd.ui.eid.common.I18NHelper.getNumberChoiceText(iLength, "MACHINE_TABLE_CAP_COUNT_MULTIPLE", "MACHINE_TABLE_CAP_COUNT_SINGLE");
        }
    }));
})();