(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.EvidencePackageFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.FilterAreaFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.MachineOptionFormatter");
    jd.ui.eid.require("jd.ui.eid.common.formatter.NumberFormatter");
    jd.ui.eid.require("jd.ui.eid.common.print.ChartRenderingPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.print.DataFetchPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.print.WaitPrintStep");
    jd.ui.eid.require("jd.ui.eid.common.print.PrintQueue");
    jd.ui.eid.require("jd.ui.eid.common.print.PrintStep");
    jd.ui.eid.require("jd.ui.eid.view.BaseController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCSummaryController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.DTCChartController");
    jd.ui.eid.require("jd.ui.eid.view.main.shared.EPSummaryChartController");

    /**
     * @class
     * <p>
     * The print view of the Evidence Package provides all its content in a printable format. The view consist of multiple sections based on the tabs
     * in the main application's Evidence Package view. Regular control's are mostly used to display the data and styled accordingly for printing.
     * </p>
     * <p>
     * A so-called {@link jd.ui.eid.common.print.PrintQueue} is used for any preparation in regard to printing. This involves:
     * <ul>
     * <li>Fetching of the data which is displayed.</li>
     * <li>Rendering of charts and manipulation so that they scale properly.</li>
     * <li>Rendering of the PIN population table, which is not done with a UI5 control as it would create too many objects in the background (e.g.
     * PropertyBindings) if many rows (10k+) are rendered.</li>
     * </ul>
     * The print queue is started in onAfterRendering.
     * </p>
     * <p>
     * The print queue <strong>hierarchy</strong> looks as follows:
     * <ul>
     * <li>Main Queue (<code>this.oPrintQueue</code>)
     * <ul>
     * <li>Data Fetch Queue (<code>this.oDataFetchQueue</code>) consisting of {@link jd.ui.eid.common.print.DataFetchPrintStep} steps.
     * <ul>
     * <li>Fetch summary (see {@link jd.ui.eid.service.EvidencePackageServiceFacade#getEvidencePackageSummary}).</li>
     * <li>Fetch DTC details list (see {@link jd.ui.eid.service.EvidencePackageServiceFacade#getDTCDetailsList}).</li>
     * <li>Fetch DTAC case details list (see {@link jd.ui.eid.service.EvidencePackageServiceFacade#getDTACCaseDetailsList}).</li>
     * <li>Fetch warranty claim details list (see {@link jd.ui.eid.service.EvidencePackageServiceFacade#getWarrantyClaimDetailsList}).</li>
     * <li>Fetch PIN population (see {@link jd.ui.eid.service.EvidencePackageServiceFacade#getEvidencePackagePINPopulationListAsRecord}).</li>
     * </ul>
     * </li>
     * <li>Wait step for the bindings to update (see {@link jd.ui.eid.comon.print.WaitPrintStep}).</li>
     * <li>Chart Print Queue (<code>this.oChartPrintQueue</code>) consisting of a {@link jd.ui.eid.common.print.ChartRenderingPrintStep} for each
     * chart in the print view (registered via {@link #.handleChartPrintContainerRegister}).</li>
     * </ul>
     * </li>
     * </ul>
     * </p>
     * <p>
     * The print queue <strong>is started</strong> via the event bus from the parent application (i.e. the application running in
     * <code>window.parent</code>, assuming the print view is running in an iframe.<br>
     * If the view is ready, the <code>requestInput</code> event is fired on channel <code>PrintEvidencePackage</code> from
     * {@link #.onAfterRendering}. The controller is then waiting for the <code>inputShared</code> event on the same channel, which is handled by
     * {@link #.handleMainApplicationInputShared} and passes the evidence package's header. Those header data, which are required by all evidence
     * package related service calls are then set as parameters of all DataFetchPrintSteps (see above) before the main queue is eventually started.
     * </p>
     * 
     * @extends sap.ui.core.mvc.Controller
     * @name jd.ui.eid.view.print.EvidencePackage
     */
    sap.ui.controller("jd.ui.eid.view.print.EvidencePackage", jQuery.extend(true, {}, jd.ui.eid.view.BaseController,
            jd.ui.eid.view.main.shared.DTCChartController, jd.ui.eid.view.main.shared.DTCSummaryController,
            jd.ui.eid.view.main.shared.EPSummaryChartController,
            /** @lends jd.ui.eid.view.print.EvidencePackage */
            {
                /* SECTION - View Life Cycle - START */

                /**
                 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to modify the View
                 * before it is displayed, to bind event handlers and do other one-time initialization.
                 */
                onInit : function() {
                    this._sEventBusChannelId = "PrintEvidencePackage";
                    this._oParentEventBus = this._getEventBusOfMainApplication();

                    // Config
                    this.mDTCChartControllerConfig._bIsSetOfCharts = true;
                    // The 'DTCSummaryController' merged with this controller provides the factory to render the DTC Summary for the print area. Since
                    // the same factory is also used for the Evidence Package Summary DTC area, we set a configuration parameter to let the factory
                    // know which fragment to instantiate. The provided fragment is different for the print view and the evidence package summary.
                    this.mDTCSummaryControllerConfig.sFactoryFragmentName = "jd.ui.eid.fragment.print.DTCSummaryTemplate";

                    // Subscribe to events from the main application's event bus
                    this._oParentEventBus.subscribe(this._sEventBusChannelId, "inputShared", this.handleMainApplicationInputShared, this);

                    this.sChartRenderAreaId = this.createId("hiddenPrintArea");

                    this.oPrintQueue = new jd.ui.eid.common.print.PrintQueue();
                    this.oPrintQueue.queue(this.oDataFetchQueue = new jd.ui.eid.common.print.PrintQueue()
                    // Evidence Package Summary
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getEvidencePackageSummary"
                    }))
                    // DTC Details
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getDTCDetailsList"
                    }))
                    // DTC KPIs
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getKPIsForDTCList"
                    }))
                    // DTAC Case Details
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getDTACCaseDetailsList"
                    }))
                    // Warranty Claim Details
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getWarrantyClaimDetailsList"
                    }))
                    // Machine Options are already in the Evidence Package Header
                    // PIN Population
                    .queue(new jd.ui.eid.common.print.DataFetchPrintStep({
                        facade : "EvidencePackage",
                        method : "getEvidencePackagePINPopulationListAsRecord"
                    }).setProcessCondition(function() {
                        if (sap.ui.getCore().getModel().getProperty("/PrintFilterOptions/showPINPopulationList")) {
                            return true;
                        }
                        return false;
                    }))) // < End of data fetch sub queue
                    // Wait step to give aggregation bindings some time to refresh
                    .queue(new jd.ui.eid.common.print.WaitPrintStep())
                    // Sub queue for charts
                    .queue(this.oChartPrintQueue = new jd.ui.eid.common.print.PrintQueue())
                    // Step for Machine Option Codes
                    .queue(new jd.ui.eid.common.print.MachineOptionTableRenderingPrintStep({
                        machineOptionTableRenderLayout : this.byId(this.createId("MachineOptionSummary"), "EvidencePackageMachineOptionSummary")
                    }).setProcessCondition(function() {
                        if (sap.ui.getCore().getModel().getProperty("/PrintFilterOptions/showMachineOptionCodeList")) {
                            return true;
                        } else {
                            return false;
                        }
                    }))
                    // Step for PINPopulation
                    .queue(new jd.ui.eid.common.print.PINPopulationTableRenderingPrintStep({
                        PINTableRenderAreaId : sap.ui.core.Fragment.createId(this.createId("PINPopulationSummary"), "PINPopulationPanelContent")
                    }))
                    // Attach event
                    .attachProcessed(this.handlePrintQueueProcessed, this);
                    this.mDTCSummaryControllerConfig.bShowChartLegends = true;

                    this.initEPSummaryChartsInFragment();

                    // Transform the 'Filter Selection...' Link + QuickView to make it print-friendly
                    this._transformFilterSelections();

                },

                /**
                 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be
                 * done here. This hook is the same one that SAPUI5 controls get after being rendered.
                 */
                onAfterRendering : function() {
                    var that = this;
                    // Start the print queue with a short delay.
                    setTimeout(function() {
                        that._oParentEventBus.publish(that._sEventBusChannelId, "requestInput");
                        // that.oPrintQueue.process();
                    }, 400);
                },

                /**
                 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
                 */
                onExit : function() {
                    this.oPrintQueue.destroy();
                    this.exitEPSummaryChartController();
                    // Unsubscribe from events from the main application's event bus
                    this._oParentEventBus.unsubscribe(this._sEventBusChannelId, "inputShared", this.handleMainApplicationInputShared, this);
                },

                /* SECTION - View Life Cycle - END */

                /* SECTION - Event Handlers from View - START */

                /**
                 * Handles the <code>register</code> event of ChartPrintContainer controls and creates a respective print step which is attached to
                 * the queue.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired by the ChartPrintContainer control.
                 */
                handleChartPrintContainerRegister : function(oEvent) {
                    var oChartPrintContainer = oEvent.getSource();
                    $.sap.log.debug("chart registered " + oChartPrintContainer.getId());
                    var oStep = new jd.ui.eid.common.print.ChartRenderingPrintStep({
                        chartPrintContainer : oChartPrintContainer,
                        chartRenderAreaId : this.sChartRenderAreaId
                    });
                    this.oChartPrintQueue.queue(oStep);
                },

                /* SECTION - Event Handlers from View - END */

                /* SECTION - Event Handlers of Print Steps - START */

                /**
                 * Handles the <code>processed</code> event of the main print queue. Sends the <code>ready</code> event to the event bus of the
                 * main application.
                 * 
                 * @param {sap.ui.base.Event}
                 *            oEvent the event fired by the print queue.
                 */
                handlePrintQueueProcessed : function(oEvent) {
                    this._oParentEventBus.publish(this._sEventBusChannelId, "ready");
                },

                /* SECTION - Event Handlers of Print Steps - END */

                /* SECTION - Communication with the Main Application - START */

                /**
                 * Handles the <code>inputShared</code> event sent from the main application. The payload contains the relevant data to start the
                 * print queue.
                 * 
                 * @param {string}
                 *            sChannelId the channel id.
                 * @param {string}
                 *            sEvent the event name.
                 * @param {object}
                 *            mData the parameter map.
                 */
                handleMainApplicationInputShared : function(sChannelId, sEvent, mData) {
                    var mEvidencePackageHeader = mData.EvidencePackageHeader;
                    var mPrintFilterOptions = mData.PrintFilterOptions;
                    var aKPIValues = mData.KPIValues;

                    sap.ui.getCore().getModel().setProperty("/EvidencePackageDetails/Header", mEvidencePackageHeader);
                    sap.ui.getCore().getModel().setProperty("/PrintFilterOptions", mPrintFilterOptions);
                    sap.ui.getCore().getModel().setProperty("/KPIValues", aKPIValues);

                    var aSteps = this.oDataFetchQueue.getSteps();
                    $.each(aSteps, function(iIdx, oStep) {
                        oStep.setParameters([mEvidencePackageHeader]);
                    });
                    this.oPrintQueue.process();
                },

                /* SECTION - Communication with the Main Application - END */

                /* SECTION - Utilities - START */

                /**
                 * Gets a reference to the event bus of the main application.
                 * 
                 * @returns {sap.ui.core.EventBus} the main application's event bus.
                 */
                _getEventBusOfMainApplication : function() {
                    if (window.parent !== window) {
                        // We run in an iframe, so let's return the parent's event bus
                        return window.parent.sap.ui.getCore().getEventBus();
                    } else {
                        $.sap.log.debug("The print application is not running in an iframe and cannot access the parent's event bus.");
                    }
                },

                /**
                 * The templates for DTAC Case and Warranty Claim have 'Filter Selection' displayed as a QuickView (visible on hovering over a link)
                 * in the main application. This method extracts the QuickView's content and places it in a Panel so that it is visible in the printed
                 * output.
                 */
                _transformFilterSelections : function() {
                    // DTAC Case
                    var oDTACCaseTemplateFilterLink = sap.ui.core.Fragment.byId(this.createId("DTACCaseSummary"), sap.ui.core.Fragment.createId(
                            "DTACCaseDetailsListPrintFragmentDTACCaseData", "filterSelectionLink"));
                    var oDTACCaseFilterTargetPanel = sap.ui.core.Fragment.byId(this.createId("DTACCaseSummary"), "DTACCaseFilterSelection");
                    this._copyTooltipContentToTarget(oDTACCaseTemplateFilterLink, oDTACCaseFilterTargetPanel);

                    // Warranty Claim
                    var oWarrantyClaimFilterLink = sap.ui.core.Fragment.byId(this.createId("WarrantyClaimSummary"), sap.ui.core.Fragment.createId(
                            "WarrantyClaimData", "filterSelectionLink"));
                    var oWarrantyClaimFilterTargetPanel = sap.ui.core.Fragment.byId(this.createId("WarrantyClaimSummary"),
                            "WarrantyClaimFilterSelection");
                    this._copyTooltipContentToTarget(oWarrantyClaimFilterLink, oWarrantyClaimFilterTargetPanel);

                    // Destroy the MatrixLayoutRow which contains the Link
                    this._destroyParentMatrixLayoutRow(oDTACCaseTemplateFilterLink);
                    this._destroyParentMatrixLayoutRow(oWarrantyClaimFilterLink);
                },

                /**
                 * Helper method that the _transformFilterSelections() method uses. Copies <i>oControl</i>'s tooltip (QuickView) content to the
                 * content of thecontrol supplied as <i>oTarget</i>
                 * 
                 * <p>
                 * The method makes the following assumptions :
                 * </p>
                 * <ul>
                 * <li><i>oControl</i> has a ux3.QuickView as its tooltip</li>
                 * <li>The QuickView has exactly one <i>jd.ui.control.ContentPane</i> as its content. The ContentPane's content is the filter
                 * selection.</li>
                 * <li><i>oTarget</i> is a Panel.</li>
                 * </ul>
                 * 
                 * @param oControl
                 *            {sap.ui.core.Control} The control's whose tooltip (QuickView) content will be copied into oTarget
                 * @param oTarget
                 *            {sap.ui.commons.Panel} The target Panel
                 */
                _copyTooltipContentToTarget : function(oControl, oTarget) {
                    // Get the oControl's tooltip's content. Tooltip is assumed to be a QuickView.
                    var oTooltipContent = oControl.getTooltip().getContent()[0].getContent()[0];

                    // Set this (the filter selection) to the target panel
                    oTarget.addContent(oTooltipContent);
                },

                /**
                 * Helper method that the _transformFilterSelections() method uses. Destroys the MatrixLayoutRow that contains <i>oControl</i>
                 * 
                 * @param oControl
                 *            {sap.ui.core.Control} The control whose parent (not necessarily immediate) <i>MatrixLayoutRow</i> is to be destroyed.
                 */
                _destroyParentMatrixLayoutRow : function(oControl) {
                    var oParent = oControl.getParent();
                    while (oParent) {
                        if (oParent.getMetadata().getName() === "sap.ui.commons.layout.MatrixLayoutRow") {
                            break;
                        }
                        oParent = oParent.getParent();
                    }
                    if (oParent) {
                        oParent.destroy();
                    }
                },

                /* SECTION - Utilities - END */

                formatEvidencePackageTitle : function(iEvidencePackageID) {
                    return jd.ui.eid.common.I18NHelper.getText("EVIDENCE_PACKAGE_DETAILS_PRINT_HED_PRINT_TITLE", [iEvidencePackageID]);
                }
            }));
})();