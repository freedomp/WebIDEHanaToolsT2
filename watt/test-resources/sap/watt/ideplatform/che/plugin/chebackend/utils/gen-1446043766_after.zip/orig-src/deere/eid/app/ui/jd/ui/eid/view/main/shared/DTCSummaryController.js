(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.view.main.shared.DTCSummaryController");
    jd.ui.eid.require("jd.ui.eid.common.chart.ChartHelper");
    jd.ui.eid.require("jd.ui.eid.common.formatter.DTCFormatter");

    /**
     * @class This controller can be merged into other sap.ui.mvc.Controller objects and provides utility functions for rendering the DTC Summary
     *        (like the factory for DTC Summary). This is used in evidence package details and print.
     * 
     * Example for merging:
     * 
     * <pre>
     * jQuery.sap.require(&quot;jd.ui.eid.view.main.shared.DTCSummaryController&quot;);
     * sap.ui.controller(&quot;view.ViewName&quot;, jQuery.extend(true, {}, jd.ui.eid.view.main.shared.DTCChartController, {
     * // here goes the usual view methods like createContent(), etc.
     * }));
     * </pre>
     * 
     * @static
     */

    jd.ui.eid.view.main.shared.DTCSummaryController = {
        mDTCSummaryControllerConfig : {
            sFactoryFragmentName : "",
            bShowChartLegends : null
        },

        /**
         * Factory that returns the Panel (containing details + charts) for each DTC. This is necessary, as each DTC can have a different
         * 'SelectedKPIID1' and 'SelectedKPIID2', and thus the binding path for the KPI charts (first two charts) is not fixed.
         * 
         * @param {string}
         *            sId the ID to be used for the returned Panel. This is provided by the framework.
         * @param {sap.ui.model.Context}
         *            oContext the context for the DTC for which a Panel needs to be created.
         */
        createDTCSummaryPanel : function(sId, oContext) {
            // Instantiate a panel for the current DTC
            var oDTCPanel = jd.ui.eid.xmlfragment(sId, this.mDTCSummaryControllerConfig.sFactoryFragmentName, this);

            // Get 'SelectedKPIID1' and 'SelectedKPIID2' for the current DTC. This info needs to be fetched from evidence package header > DTC Code
            // List
            var sDTCID = oContext.getProperty("DTCMasterData/DTCID");
            var sSelectedKPIID1, sSelectedKPIID2;
            var aDTCCodeList = sap.ui.getCore().getModel().getProperty("/EvidencePackageDetails/Header/DTCCodeList");
            $.each(aDTCCodeList, function(i, oDTCCode) {
                if (oDTCCode.DTCID == sDTCID) {
                    sSelectedKPIID1 = oDTCCode.SelectedKPIID1;
                    sSelectedKPIID2 = oDTCCode.SelectedKPIID2;
                    return false;
                }
            });
            // Use DTCChartController logic to initialize the charts.
            this.initDTCChartsInFragment(sId, sSelectedKPIID1, sSelectedKPIID2);
            this.setDTCChartsLegendVisibility(sId, true);

            return oDTCPanel;
        }

    };

})();