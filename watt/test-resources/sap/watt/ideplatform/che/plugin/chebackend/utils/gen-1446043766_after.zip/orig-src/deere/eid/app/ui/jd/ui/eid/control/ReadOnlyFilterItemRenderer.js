(function() {
  "use strict";

  jQuery.sap.declare("jd.ui.eid.control.ReadOnlyFilterItemRenderer");
  jd.ui.eid.require("jd.ui.eid.control.FilterItemRenderer");

  /**
   * Default renderer for control {@link jd.ui.eid.control.ReadOnlyFilterItem}.
   * 
   * @class Default renderer for control {@link jd.ui.eid.control.ReadOnlyFilterItem}.
   * @extends jd.ui.eid.control.FilterItemRenderer
   * @static
   * @name jd.ui.eid.control.ReadOnlyFilterItemRenderer
   */
  jd.ui.eid.control.ReadOnlyFilterItemRenderer = {};

  // Inherit base renderer
  $.extend(jd.ui.eid.control.ReadOnlyFilterItemRenderer,
      jd.ui.eid.control.FilterItemRenderer);

  /**
   * Hook into the content rendering and render either the item aggregation of provided or the
   * noData property otherwise.
   * @param {sap.ui.core.RenderManager} oRm The RenderManager that can be used for writing to the render output buffer.
   * @param {jd.ui.eid.control.ReadOnlyFilterItem} oControl The control that should be rendered.
   */
  jd.ui.eid.control.ReadOnlyFilterItemRenderer._renderContent =
      function(oRm, oControl) {
        var aItems = oControl.getAggregation('items');
        if (aItems && aItems.length > 0) {
          for ( var i = 0; i < aItems.length; i++) {
            var oItem = aItems[i];
            oRm.write("<div");
            oRm.writeElementData(oItem);
            oRm.addClass("jdUiEidReadOnlyFilterItemValue");
            oRm.writeClasses();
            oRm.write(">");
            oRm.writeEscaped(oItem.getText());
            oRm.write("</div>");
          }
        } else {
          oRm.write("<div");
          oRm.addClass("jdUiEidReadOnlyFilterItemValue");
          oRm.writeClasses();
          oRm.write(">");
          oRm.writeEscaped(oControl.getNoData());
          oRm.write("</div>");
        }
      };

  /**
   * @see jd.ui.eid.control.FilterItemRenderer
   */
  jd.ui.eid.control.ReadOnlyFilterItemRenderer.renderCollapseIcon =
      function(oRm, oControl) {
        // Overwrite, don't do anything here because the collapse icon shouldn't be displayed.
      };

  /**
   * @see jd.ui.eid.control.FilterItemRenderer
   */
  jd.ui.eid.control.ReadOnlyFilterItemRenderer.renderHeaderItems =
      function(oRm, oControl) {
        // Overwrite, don't do anything here because the collapse icon shouldn't be displayed.
      };

})();