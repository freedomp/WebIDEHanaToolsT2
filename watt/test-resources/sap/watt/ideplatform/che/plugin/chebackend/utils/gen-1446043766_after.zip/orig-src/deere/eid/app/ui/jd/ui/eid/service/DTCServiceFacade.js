(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.service.DTCServiceFacade");
    jd.ui.eid.require("jd.ui.eid.service.BaseServiceFacade");

    /**
     * @class The DTC service facade provides functionality to retrieve a list of DTCs or an individual DTC. There are so-called
     *        <em>expensive properties</em> (i.e. affected PINs and KPIs) which do not come along with the details service. This is because in most
     *        cases, they are already available from where the details view is opened (e.g. dashboard table/chart, DTC list) and in that case, those
     *        expensive properties can simply be copied. However, there are also scenarios when those expensive properties are not available from the
     *        context (e.g. evidence package summary). For that case, there is an additional method provided to fetch the expensive properties. (see
     *        {@link #.getDTCKPIs}).
     * 
     * @name jd.ui.eid.service.DTCServiceFacade
     * @extends jd.ui.eid.service.BaseServiceFacade
     */
    jd.ui.eid.service.BaseServiceFacade.extend("jd.ui.eid.service.DTCServiceFacade", /** @lends jd.ui.eid.service.DTCServiceFacade */
    {
        _oLastGetDTCListRequest : null,
        _oLastGetTop10DTCsRequest : null,

        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleListBindingChanged : function(oListBinding) {
            // This is invoked if the filtering/sorting on the UI table changes.
            // If the list binding is relevant, then get the updated DTC list based on new
            // filtering/sorting etc. This information is available inside oListBinding.
            if (oListBinding.sPath == '/DTCList') {
                this.getDTCList(oListBinding);
            }
        },

        /**
         * @see {@link jd.ui.eid.service.BaseServiceFacade}
         */
        _handleDataRequested : function(oListBinding) {
            // This is invoked when there is paging on the UI table
            // If the list binding is relevant, then get the updated DTC list based on the new
            // binding information (oListBinding)
            if (oListBinding.sPath == '/DTCList') {
                this.getDTCList(oListBinding);
            }
        },

        /**
         * Aborts the latest request for GetDTCList and GetTop10DTCs.
         * 
         * @see jd.ui.eid.service.DTCServiceFacade#getDTCList
         * @see jd.ui.eid.service.DTCServiceFacade#getTop10DTCs
         */
        abortPendingDTCRequests : function() {
            if (this._oLastGetDTCListRequest) {
                this._oLastGetDTCListRequest.abort();
                this._oLastGetDTCListRequest = null;
            }
            if (this._oLastGetTop10DTCsRequest) {
                this._oLastGetTop10DTCsRequest.abort();
                this._oLastGetTop10DTCsRequest = null;
            }
        },

        /**
         * Get the list of DTCs for table based on a set of filter settings.
         * 
         * @memberOf jd.ui.eid.service.DTCServiceFacade
         * @param {jd.ui.eid.model.EidModelListBinding}
         *            oBinding the binding used by the UI control
         * @param {string}
         *            sSelectedKPIID the selected KPI
         * @param {string}
         *            sSearchTerm the search string. If there is no search term, this can be an empty string or null
         * @param {function}
         *            fnSuccess the callback that is executed when the service call is successful
         * @param {function}
         *            fnError the callback that is executed when the service call results in an error
         * 
         * @public
         */
        getDTCList : function(oBinding, oCustomFilter, sSelectedKPIID, sSearchTerm, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/dtc/GetDTCList.xsjs";

            // Set test data file name
            var sModelDataFileName = "getDTCList_Response.json";

            // Prepare the custom pay load for this service call
            var oArgs = {};
            oArgs.SearchTerm = sSearchTerm;
            oArgs.CustomFilter = oCustomFilter;
            oArgs.SelectedKPIID = sSelectedKPIID;

            // Prepare the fnGetListData callback. It accepts an object (custom part of server's
            // response)
            // and returns the array of DTCs within this object.
            var that = this;
            var fnGetListData = function(oData) {
                // Iterate over the list to mark those which are already in the evidence package
                var iDTCCount = that.oModel.getProperty("/EvidencePackageDetails/Header/DTCCodeList").length;
                if (iDTCCount > 0) {
                    var mDTCs = jd.ui.eid.model.EidModel.TransformationHelper.getDTCMapFromEvidencePackageDetails();
                    var iMatches = 0;
                    $.each(oData.Result.DTCList.Records, function(iIdx, mDTC) {
                        if (mDTCs[mDTC.DTCID]) {
                            mDTC._canBeAddedToEvidencePackage = false;
                            iMatches++;
                            if (iMatches == iDTCCount) {
                                return false; // break, we marked everything
                            }
                        }
                    });
                }

                // Update pin population
                that.oModel.setProperty("/DTCFilters/PINPopulation", oData.Result.PINPopulation);
                var iEvidencePackagePopulation = that.oModel.getProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation");
                if (iEvidencePackagePopulation !== oData.Result.PINPopulation) {
                    that.oModel.setProperty("/EvidencePackageDetails/_DTCFilters/PINPopulation", oData.Result.PINPopulation);
                }

                return oData.Result.DTCList;
            };

            // Invoke _retrieveList
            this._oLastGetDTCListRequest = this._retrieveList(sServicePath, fnSuccess, fnError, fnGetListData, oBinding, oArgs, sModelDataFileName);
        },

        /**
         * Gets the top 10 DTCs. These DTCs are displayed on the dashboard.
         * 
         * @param {object}
         *            oCustomFilter the filters from the filter area.
         * @param {string}
         *            sSelectedKPIID the selected KPI
         * @param {function}
         *            [fnSuccess] the callback that is executed when the service call is successful
         * @param {function}
         *            [fnError] the callback that is executed when the service call results in an error
         */
        getTop10DTCs : function(oCustomFilter, sSelectedKPIID, fnSuccess, fnError) {
            // Set service path
            var sServicePath = "xs/dtc/GetTop10DTCs.xsjs";

            // Set test data file name
            var sModelDataFileName = "getDTCList_Response.json";

            // Prepare the custom pay load for this service call
            var oArgs = {};
            oArgs.CustomFilter = oCustomFilter;
            oArgs.SelectedKPIID = sSelectedKPIID;

            // Prepare the fnGetListData callback.
            /*
             * Although the Top 10 DTCs have unique DTCIDs, but the data series could have identical DTC Codes, this will cause problem in Chart
             * rendering, because the DTC Code will be used as X-axis dimension and it requires the uniqueness of DTC codes. This function will modify
             * the DTC codes in Top 10 DTCs data model in such a way that for DTCCode which already exists, a string of space characters will be
             * appended to make it unique, the length of appended space characters depends on the occurrence of that DTC Code. Example: Input=
             * [{DTCCode: "a"},{DTCCode: "b"},{DTCCode: "a"},{DTCCode: "a"}] --> Output=[{DTCCode: "a"},{DTCCode: "b"},{DTCCode: "a "},{DTCCode: "a
             * "}]
             */
            var fnGetData = function(oData) {
                var aTop10DTCs = oData.Result.Top10DTCs;
                var aDTCCode = [];
                var sDTCCode;
                for ( var i = 0; i < aTop10DTCs.Records.length; i++) {
                    sDTCCode = aTop10DTCs.Records[i].DTCCode;
                    if (!aDTCCode[sDTCCode]) {
                        aDTCCode[sDTCCode] = sDTCCode;
                    } else {
                        aTop10DTCs.Records[i].DTCCode = aDTCCode[sDTCCode] + " ";
                        aDTCCode[sDTCCode] = aTop10DTCs.Records[i].DTCCode;
                    }
                }
                return aTop10DTCs;
            };

            this._oLastGetTop10DTCsRequest = this._retrieveRecord(sServicePath, "/Top10DTCs", oArgs, fnSuccess, fnError, fnGetData,
                    sModelDataFileName);
        },

        _replaceModelWithUniqueDTCCode : function() {
            var aRecords = sap.ui.getCore().getModel().getProperty('/Top10DTCs/Records');
            var aDTCCode = [];
            var sDTCCode;
            for ( var i = 0; i < aRecords.length; i++) {
                sDTCCode = aRecords[i].DTCCode;
                if (!aDTCCode[sDTCCode]) {
                    aDTCCode[sDTCCode] = sDTCCode;
                } else {
                    aRecords[i].DTCCode = aDTCCode[sDTCCode] + " ";
                    aDTCCode[sDTCCode] = aRecords[i].DTCCode;
                }
            }

            sap.ui.getCore().getModel().setProperty('/Top10DTCs/Records', aRecords);
        },

        /**
         * Get chart data and DTC master data for a selected DTC
         * 
         * @memberOf jd.ui.eid.service.DTCServiceFacade
         * 
         * @param {object}
         *            oCustomFilter the filter values from the filter tree
         * @param {string}
         *            sSelectedDTCID the selected DTC to get DTC details for
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @param {object}
         *            [mParameters] an optional parameter map
         * @param {string}
         *            [mParameters.sAlternateTargetPath] an alternate target path to write the retrieved data to.
         */
        getDTCDetails : function(oCustomFilter, sSelectedDTCID, fnSuccess, fnError, mParameters) {
            // convert DTCID to integer
            var iSelectedDTCID = parseInt(sSelectedDTCID);

            var sServicePath = "xs/dtc/DTC_Details.xsjs";
            var sModelPath = mParameters && mParameters.sAlternateTargetPath ? mParameters.sAlternateTargetPath : "/DTCDetails";
            var oData = {
                CustomFilter : oCustomFilter,
                DTCCodeList : [iSelectedDTCID]
            };

            var fnGetData = function(oData) {
                // Merge the backup data back into the data received from the backend.
                jd.ui.eid.model.EidModel.TransformationHelper.applyExpensiveDTCDetailsFromBuffer(sModelPath);
                return oData.Result.DTCDetails[0];
            };

            var sModelFileName = "getDTCDetails_Response.json";

            this._retrieveRecord(sServicePath, sModelPath, oData, fnSuccess, fnError, fnGetData, sModelFileName, false);

        },

        /**
         * Get the so-called expensive properties such as affected PINs and KPIs for the given DTC.
         * 
         * @memberOf jd.ui.eid.service.DTCServiceFacade
         * 
         * @param {object}
         *            oCustomFilter the filter values from the filter tree
         * @param {string}
         *            sSelectedDTCID the selected DTC to get DTC details for
         * @param {function}
         *            fnSuccess callback that is executed when the service call is successful.
         * @param {function}
         *            fnError callback that is executed when the service call results in an error.
         * @param {object}
         *            [mParameters] an optional parameter map
         * @param {string}
         *            [mParameters.sAlternateTargetPath] an alternate target path to write the retrieved data to.
         */
        getDTCKPIs : function(oCustomFilter, iDTCID, fnSuccess, fnError, mParameters) {
            var sServicePath = "xs/dtc/GetDTCKPIs.xsjs";
            var sModelRookPath = mParameters && mParameters.sAlternateTargetPath ? mParameters.sAlternateTargetPath : "/DTCDetails";
            var mData = {
                CustomFilter : oCustomFilter,
                DTCIDList : [parseInt(iDTCID)]
            };

            var that = this;
            var fnGetData = function(oData) {
                // Also, set the affected pins property
                that.oModel.setProperty(sModelRookPath + "/DTCMasterData/AffectedPINs", oData.Result.DTCMap[iDTCID].AffectedPINs);
                return oData.Result.DTCMap[iDTCID].KPIs;
            };

            var sModelFileName = "getDTCKPIs_Response_Single.json";
            this._retrieveRecord(sServicePath, sModelRookPath + "/DTCMasterData/KPIs", mData, fnSuccess, fnError, fnGetData, sModelFileName, false);
        }

    });

})();
