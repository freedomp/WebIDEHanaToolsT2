(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.common.DataLossManager");

    /**
     * Constructor for a new DataLossManager.
     * <ul>
     * <li>Properties
     * <ul>
     * <li>dirty : boolean (default: false) True if the DLM has unsaved data, false otherwise.</li>
     * </ul>
     * </li>
     * <li>Associations
     * <ul>
     * <li>control : sap.ui.core.Control the control to which the DLM is attached to.
     * <li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>children : jd.ui.eid.DataLossManager[] all logical child DLMs.</li>
     * <li>messages : sap.ui.core.Message[] the messages attached to the DLM.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @param {string}
     *            [sId] id for the new control, generated automatically if no id is given
     * @param {object}
     *            [mSettings] initial settings for the new control
     * 
     * @class
     * <p>
     * The data loss manager provides a mechanism to manage data loss scenarios (e.g. a popup dialog when the user closes the browser or when
     * switching to a different tab). Data loss managers (DLMs) form a hierarchy and are attached to a control through custom data (except for the
     * root DLM which is not attached to a control but serves as the DLM for the entire application). Several methods are provided to navigate along
     * the hierarchy or to find the DLM for a particular control (e.g., if the control itself doesn't have a DLM attached, the next parent control
     * with a DLM attached is responsible). Each DLM can be flagged as dirty (i.e. it has unsaved data). Controllers are responsible for implementing
     * data loss handling.
     * </p>
     * <p>
     * There are two <strong>core methods</strong> of the data loss manager:
     * <ul>
     * <li>{@link #.notifyOrNavigate} is usually called from a controller after the respective handlers have been registered (see below). It either
     * publishes an event via the event bus of the UI5 core (see below, this could for example then trigger a dialog) or calls the navigation handler
     * to do the navigation.</li>
     * <li>{@link #.handleUserDecision} is usually called after a user has been notified about a pending data loss and has taken an action (e.g.
     * save, don't save, or cancel).</li>
     * </ul>
     * </p>
     * <p>
     * There are multiple <strong>handlers</strong> that are called at different points in time:
     * <ul>
     * <li>beforeNotification is called if a DLM is dirty and before the event dataLossPending event is sent via the event bus.</li>
     * <li>navigatioHandler is called, if the DLM is clean, if the user decides to continue without saving or after the pending changes have been
     * saved based on the user's decision.</li>
     * <li>saveHandler is called, if the user decides to save the pending changes. The save handler receives the navigationHandler as the first
     * parameter and should call that function if save was successful.</li>
     * <li>cancelHandler is called if the user decides to cancel (i.e. stay on the page).</li>
     * </ul>
     * </p>
     * <p>
     * An <strong>event</strong> is published via the event bus of the UI5 core if there are unsaved changes and {@link #.notifyOrNavigate} is
     * called. The channel is <code>DataLossManager</code>, the event is <code>dataLossPending</code>, and the data passed along with the event
     * is a reference to the current DLM (property <code>oDataLossManager</code>. The handler of that event should ask the user what to do with the
     * unsaved data and based on the user's input, call {@link #.handleUserDecision} with the respective parameter.
     * </p>
     * @extends sap.ui.base.ManagedObject
     * @name jd.ui.eid.common.DataLossManager
     */
    sap.ui.base.ManagedObject.extend("jd.ui.eid.common.DataLossManager", /** @lends jd.ui.eid.common.DataLossManager */
    {
        metadata : {
            properties : {
                dirty : {
                    type : "boolean",
                    defaultValue : false
                }
            },
            associations : {
                control : {
                    type : "sap.ui.core.Control",
                    multiple : false
                }
            },
            aggregations : {
                children : {
                    type : "jd.ui.eid.common.DataLossManager",
                    multiple : true,
                    singularName : "child"
                },
                messages : {
                    type : "sap.ui.core.Message",
                    multiple : true,
                    singularName : "message"
                }
            }
        },

        /**
         * The key used to attach a DLM to a control's custom data.
         * 
         * @private
         */
        _CTRL_CUSTOM_DATA_KEY : "dlm",

        /**
         * Called when the object is destroyed.
         */
        destroy : function() {
            // Remove reference from custom data
            if (this._getControl()) {
                this._getControl().data(this._CTRL_CUSTOM_DATA_KEY, null);
            }

            // Set properties to null
            this._fnCancelHandler = null;
            this._fnNavigationHandler = null;
            this._fnSaveHandler = null;

            sap.ui.base.ManagedObject.prototype.destroy.apply(this, arguments);
        },

        /**
         * Checks this and all child instances for the dirty property.
         * 
         * @returns {boolean} True if the dirty property of this or any child DLM instance is true, false otherwise.
         */
        isDirty : function() {
            if (this.getDirty()) {
                return true;
            }

            // This instance isn't flagged, so let's check all child DLMs
            var iLength = this.getChildren().length;
            for ( var i = 0; i < iLength; i++) {
                var oChild = this.getChildren()[i];
                if (oChild.isDirty()) {
                    return true;
                }
            }

            // When we've gotten so far, then there hasn't been any unsaved data.
            return false;
        },

        /**
         * Gets the control object of the control association.
         * 
         * @returns {sap.ui.core.Control} the control object of the control association.
         */
        _getControl : function() {
            return sap.ui.getCore().byId(this.getControl());
        },

        /**
         * Sets the control aggregation.
         * 
         * @param {sap.ui.core.Control}
         *            oControl
         * @returns {jd.ui.eid.common.DataLossManager} <code>this</code> for method chaining.
         */
        setControl : function(oControl) {
            this.setAssociation("control", oControl);
            oControl.data(this._CTRL_CUSTOM_DATA_KEY, this);
            return this;
        },

        /**
         * Returns whether the data loss manager is root or not.
         * 
         * @returns {boolean} True if the instance is root, false otherwise.
         */
        isRoot : function() {
            return !this.getControl();
        },

        /**
         * Internal reference to the BeforeNotification handler
         */
        _fnBeforeNotificationHandler : null,

        /**
         * Sets the BeforeNotification handler function.
         * 
         * @param {function}
         *            fnBeforeNotificationHandler the BeforeNotification handler function.
         * @returns {jd.ui.eid.common.DataLossManager} this for method chaining.
         */
        setBeforeNotificationHandler : function(fnBeforeNotificationHandler) {
            this._fnBeforeNotificationHandler = fnBeforeNotificationHandler;
            return this;
        },

        /**
         * Gets the BeforeNotification handler function.
         * 
         * @returns {function} the BeforeNotification handler function.
         */
        getBeforeNotificationHandler : function() {
            return this._fnBeforeNotificationHandler;
        },

        /**
         * Internal reference to the Cancel handler.
         */
        _fnCancelHandler : null,

        /**
         * Sets the Cancel handler function.
         * 
         * @param {function}
         *            fnCancelHandler the Cancel handler function.
         * @returns {jd.ui.eid.common.DataLossManager} this for method chaining.
         */
        setCancelHandler : function(fnCancelHandler) {
            this._fnCancelHandler = fnCancelHandler;
            return this;
        },

        /**
         * Gets the Cancel handler function.
         * 
         * @returns {function} the Cancel handler function.
         */
        getCancelHandler : function() {
            return this._fnCancelHandler;
        },

        /**
         * Internal reference to the navigation handler.
         */
        _fnNavigationHandler : null,

        /**
         * Sets the navigation handler function.
         * 
         * @param {function}
         *            fnNavigationHandler the navigation handler function.
         * @returns {jd.ui.eid.common.DataLossManager} this for method chaining.
         */
        setNavigationHandler : function(fnNavigationHandler) {
            this._fnNavigationHandler = fnNavigationHandler;
        },

        /**
         * Gets the navigation handler function.
         * 
         * @returns {function} the navigation handler function.
         */
        getNavigationHandler : function() {
            return this._fnNavigationHandler;
        },

        /**
         * Internal reference to the save handler.
         */
        _fnSaveHandler : null,

        /**
         * Sets the save handler function.
         * 
         * @param {function}
         *            fnSaveHandler the save handler function.
         * @returns {jd.ui.eid.common.DataLossManager} this for method chaining.
         */
        setSaveHandler : function(fnSaveHandler) {
            this._fnSaveHandler = fnSaveHandler;
        },

        /**
         * Gets the save handler function.
         * 
         * @returns {function} the save handler function.
         */
        getSaveHandler : function() {
            return this._fnSaveHandler;
        },

        /**
         * Raises the dataLossPending event via the event bus if the DLM is dirty or calls the navigation handler otherwise.
         */
        notifyOrNavigate : function() {
            if (this.isDirty()) {
                if (this._fnBeforeNotificationHandler) {
                    this._fnBeforeNotificationHandler();
                }
                sap.ui.getCore().getEventBus().publish("DataLossManager", "dataLossPending", {
                    oDataLossManager : this
                });
            } else {
                if (this._fnNavigationHandler) {
                    this._fnNavigationHandler();
                }
            }
        },

        /**
         * Processes a decision by the user to either save and continue (i.e. navigate), continue without saving, or cancel (stay).
         * 
         * @param {jd.ui.eid.common.DataLossManager.UserDecision}
         *            iChoice The user's decision.
         */
        handleUserDecision : function(iChoice) {
            if (iChoice == jd.ui.eid.common.DataLossManager.UserDecision.SaveAndContinue) {
                if (this._fnSaveHandler) {
                    this._fnSaveHandler(this._fnNavigationHandler);
                } else if (this._fnNavigationHandler) {
                    this._fnNavigationHandler();
                }
            } else if (iChoice == jd.ui.eid.common.DataLossManager.UserDecision.ContinueWithoutSaving) {
                if (this._fnNavigationHandler) {
                    this._fnNavigationHandler();
                }
            } else {
                if (this._fnCancelHandler) {
                    this._fnCancelHandler();
                }
            }
        },

        /**
         * Resets the data loss manager and its children so that {@link isDirty} returns false.
         */
        reset : function() {
            // Reset itself
            this.setDirty(false);
            this.destroyAggregation("messages");

            // ... and all its children
            var iLength = this.getChildren().length;
            for ( var i = 0; i < iLength; i++) {
                var oChild = this.getChildren()[i];
                oChild.reset();
            }
        },

        /**
         * Gets a concatenated string of all assigned messages.
         * 
         * @returns {string} concatenated string of the message aggregation.
         */
        getConcatenatedMessages : function() {
            var sMessages = null;
            var aMessages = this.getMessages();
            $.each(aMessages, function(iIdx, oMessage) {
                if (sMessages) {
                    sMessages += "\n";
                }
                sMessages += oMessage.getText();
            });

            return sMessages;
        },

        /**
         * Add a sole message by removing all previous messages first.
         * 
         * @param {sap.ui.core.Message}
         *            oMessage the message to add as the sole message.
         * @returns {jd.ui.eid.common.DataLossManager} this for method chaining.
         */
        addSoleMessage : function(oMessage) {
            this.destroyMessages();
            this.addMessage(oMessage);
            return this;
        }
    });

    /* Static properties and methods */

    /**
     * Singleton pointer for the root instance.
     * 
     * @private
     */
    var instance = null;

    /**
     * Returns the root DLM instance (singleton).
     * 
     * @static
     * @returns {jd.ui.eid.common.DataLossManager} the root data loss manager.
     */
    jd.ui.eid.common.DataLossManager.getRootInstance = function() {
        if (instance == null) {
            instance = new jd.ui.eid.common.DataLossManager();
            // Hide the constructor so the returned objected can't be new'd...
            instance.constructor = null;
        }
        return instance;
    };

    /**
     * Returns the DLM instance of the control, of the next parent control, or the root DLM instance.
     * 
     * @static
     * @returns {jd.ui.eid.common.DataLossManager} a data loss manager.
     */
    jd.ui.eid.common.DataLossManager.getInstanceForControl = function(oControl) {
        var oDataLossManager = null;
        do {
            if (oControl.data(jd.ui.eid.common.DataLossManager.prototype._CTRL_CUSTOM_DATA_KEY)) {
                oDataLossManager = oControl.data(jd.ui.eid.common.DataLossManager.prototype._CTRL_CUSTOM_DATA_KEY);
            } else {
                oControl = oControl.getParent();
            }
        } while (oDataLossManager == null && oControl instanceof sap.ui.core.Element);

        if (!oDataLossManager) {
            oDataLossManager = jd.ui.eid.common.DataLossManager.getRootInstance();
        }
        return oDataLossManager;
    };

    /**
     * Returns the DLM instance of the control if available.
     * 
     * @static
     * @returns {jd.ui.eid.common.DataLossManager|null} the data loss manager.
     */
    jd.ui.eid.common.DataLossManager.getImmediateInstanceForControl = function(oControl) {
        var oDataLossManager = null;
        if (oControl && oControl.data(jd.ui.eid.common.DataLossManager.prototype._CTRL_CUSTOM_DATA_KEY)) {
            oDataLossManager = oControl.data(jd.ui.eid.common.DataLossManager.prototype._CTRL_CUSTOM_DATA_KEY);
        }
        return oDataLossManager;
    };

    /**
     * Creates a new data loss context for the given control by creating a new DLM instance and attaching it to the control. The DLM instance will be
     * added to the DLM hierarchy.
     * 
     * @static
     * @param {sap.ui.core.Control}
     *            oControl the control for which a new DLM context should be created.
     * @returns {jd.ui.eid.common.DataLossManager} the newly created data loss manager.
     */
    jd.ui.eid.common.DataLossManager.createDataLossContextForControl = function(oControl) {
        var oParentDLM = jd.ui.eid.common.DataLossManager.getInstanceForControl(oControl);
        var oDLM = new jd.ui.eid.common.DataLossManager({
            control : oControl
        });
        oParentDLM.addChild(oDLM);
        return oDLM;
    };

    /**
     * @namespace Enumartion for user choices.
     */
    jd.ui.eid.common.DataLossManager.UserDecision = {
        SaveAndContinue : 0,
        ContinueWithoutSaving : 1,
        Cancel : 2
    };

})();