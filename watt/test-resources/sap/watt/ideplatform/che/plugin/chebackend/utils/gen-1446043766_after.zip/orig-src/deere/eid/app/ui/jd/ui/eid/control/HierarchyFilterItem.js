(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.HierarchyFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");
    jd.ui.eid.require("jd.ui.eid.control.ExactBrowser");
    jd.ui.eid.require("jd.ui.eid.control.CloseIconWrapper");

    /**
     * Constructor for a new HierachyFilterItem.
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>allowMultiSelect : boolean (default: false) should multiple selectionsbe allowed?</li>
     * <li>externalTopLevelKeyName: string (default: "") The key to use in the external selection property, for the first level</li>
     * <li>externalSecondLevelKeyName: string (default: "") The key to use in the external selection property, for the second level </li>
     * <li>noSelectionText: string (default: "") Text shown when no selection is active.</li>
     * <li>readOnly: boolean (default: false) Read-Only Mode (Popup never opens, selection displayed gray) </li>
     * <li>selection : object (default: {}) The array object holding the selected item tree.</li>
     * <li>topCaption : string (default: "") The caption that should be displayed at the top of the exactbrowser.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>items : sap.ui.ux3.ExactAttribute[] The ExactAttributes to display.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class The HierarchyFilterItem control provides list of possible values which can be selected.<br>
     *        Known Limitations:
     *        <ul>
     *        <li>Only two levels of attributes are supported. </li>
     *        <li> The 'name'-Properties of the items have to be unique on each level. </li>
     *        <li>Hierarchy Filter Item assumes that whatever is displayed as text property of the exact attribute is the key maintained in the
     *        external* properties (as there's no such thing as a key property on the exact attribute). To change that, we could introduce custom data
     *        key e.g.</li>
     *        </ul>
     * 
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.HierarchyFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.HierarchyFilterItem",
    /** @lends jd.ui.eid.control.HierarchyFilterItem */
    {
        metadata : {
            properties : {
                allowMultiSelect : {
                    type : "boolean",
                    defaultValue : true
                },
                externalTopLevelKeyName : {
                    type : "string",
                    defaultValue : ""
                },
                externalSecondLevelKeyName : {
                    type : "string",
                    defaultValue : ""
                },
                noSelectionText : {
                    type : "string",
                    defaultValue : ""
                },
                readOnly : {
                    type : "boolean",
                    defaultValue : false
                },
                topCaption : {
                    type : "string",
                    defaultValue : ""
                },
                _internalSelection : {
                    type : "object",
                    defaultValue : {}
                }
            },
            aggregations : {
                items : {
                    type : "sap.ui.ux3.ExactAttribute",
                    multiple : true
                },
                _selectionDisplay : {
                    type : "sap.ui.commons.layout.VerticalLayout",
                    multiple : false
                },
                _popup : {
                    type : "sap.ui.ux3.ToolPopup",
                    multiple : false
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the style class here so that we don't have to do any unnecessary
            // overwrites in the renderer
            this.addStyleClass("jdUiEidHierarchyFilterItem");

            // this is displayed when no selection is active
            this.oNoSelectionDisplay = new sap.ui.commons.Label({
                text : this.getNoSelectionText()
            });
            this.oNoSelectionDisplay.addStyleClass("jdUiEidHierarchyFilterItemSelection_0");

            // this is the area where the selection is displayed
            this.oSelectionDisplay = new sap.ui.commons.layout.VerticalLayout({
                width : "100%",
            });
            this.oSelectionDisplay.addStyleClass("jdUiEidHierarchyFilterItemOpener");
            this.setAggregation("_selectionDisplay", this.oSelectionDisplay);

            // hidden root item allows to hide ExactBrowser "top
            // list" (see
            // showTopList property)
            this.oHiddenRootItem = new sap.ui.ux3.ExactAttribute({
                text : "<DummyRootItem>"
            });
            this.oHiddenRootItem.setSelected(true);

            this.oExactBrowser = new jd.ui.eid.control.ExactBrowser({
                listHeight : 200,
                showTopList : false,
                enableSave : false,
                enableListClose : false,
                attributes : [this.oHiddenRootItem],
                attributeSelected : [this._handleSelect, this],
            });

            // adds a close button
            this.oExactBrowserWrapper = new jd.ui.eid.control.CloseIconWrapper({
                content : [this.oExactBrowser],
                closeClicked : [this._onExactBrowserCloseClicked, this]
            });

            this.oPopup = new sap.ui.ux3.ToolPopup({
                autoClose : true,
                opener : this.oSelectionDisplay,
                content : this.oExactBrowserWrapper,
                inverted : false,
                // width : "auto"
                maxWidth : "550px"
            }).addStyleClass("jdUiUx3TP jdUiEidTPSlim");

            this.oPopup.setPosition(sap.ui.core.Popup.Dock.BeginTop, sap.ui.core.Popup.Dock.EndTop, this.getAggregation("_selectionDisplay"), "0 -5",
                    "none");
            var that = this;
            this.oSelectionDisplay.attachBrowserEvent("click", function() {
                if (that.getReadOnly()) {
                    return; // Don't open a popup if readonly mode
                }
                if (that.oPopup.isOpen()) {
                    that.oPopup.close();
                } else {
                    that.oPopup.open();
                }
            });
            this.setAggregation("_popup", this.oPopup);

            // set initial state
            this.setReadOnly(this.getReadOnly());
        },

        /**
         * Set the control to read-only mode (popup never opens, selection display not clickable)
         * 
         * @param {boolean}
         *            bReadOnly enable read-only mode?
         */
        setReadOnly : function(bReadOnly) {
            this.setProperty("readOnly", bReadOnly);

            if (bReadOnly) {
                this.oPopup.close();
                this.oSelectionDisplay.removeStyleClass("sapUiLnk");
                this.oSelectionDisplay.addStyleClass("jdUiEidReadOnlyFilterItemValue");
            } else {
                this.oSelectionDisplay.addStyleClass("sapUiLnk");
                this.oSelectionDisplay.removeStyleClass("jdUiEidReadOnlyFilterItemValue");
            }

        },

        /**
         * Sets the active property.
         * 
         * @param {boolean}
         *            bValue true if control is active, false otherwise.
         * @returns {jd.ui.eid.control.HierarchyFilterItem} this for method chaining.
         */
        setActive : function(bValue) {
            if (this.getReadOnly()) {
                bValue = false;
            }
            jd.ui.eid.control.FilterItem.prototype.setActive.apply(this, [bValue]);
            // If the filter item is read only, then we don't want to maintain the active state.
            return this;
        },

        /**
         * Toggles the visibility of the filter item's content.
         * 
         * @param {jQuery.Event}
         *            oEvent the fired event.
         */
        _handleCollapse : function(oEvent) {
            // Don't collapse if readonly
            if (!this.getReadOnly()) {
                jd.ui.eid.control.FilterItem.prototype._handleCollapse.apply(this, arguments);
            }
        },

        /**
         * Converts the external selection array to the internal selection tree.
         * 
         * @param {array}
         *            aExternalSelection
         * @returns {object}
         */
        _convertExternalSelectionToInternalSelection : function(aExternalSelection) {
            if (!aExternalSelection) {
                return {};
            }

            var oInternalSelection = {};
            var sExternalTopLevelKeyName = this.getExternalTopLevelKeyName();
            var sExternalSecondLevelKeyName = this.getExternalSecondLevelKeyName();
            for ( var iTopLevel = 0; iTopLevel < aExternalSelection.length; ++iTopLevel) {
                var oTopLevel = aExternalSelection[iTopLevel];
                var oSecondLevelSelection = {};
                if (oTopLevel[sExternalSecondLevelKeyName] && oTopLevel[sExternalSecondLevelKeyName].length) {
                    for ( var iSecondLevel = 0; iSecondLevel < oTopLevel[sExternalSecondLevelKeyName].length; ++iSecondLevel) {
                        oSecondLevelSelection[oTopLevel[sExternalSecondLevelKeyName][iSecondLevel]] = {};
                    }
                }
                oInternalSelection[oTopLevel[sExternalTopLevelKeyName]] = oSecondLevelSelection;
            }

            $.sap.log.debug("converted internal selection to external selection: " + JSON.stringify(oInternalSelection), null,
                    "jd.ui.eid.control.HierarchyFilterItem");
            return oInternalSelection;
        },

        /**
         * Converts the internal selection tree to the external selection array.
         * 
         * @param {object}
         *            oInternalSelection
         * @returns {Array}
         */
        _convertInternalSelectionToExternalSelection : function(oInternalSelection) {
            if (!oInternalSelection) {
                return [];
            }

            var aExternalSelection = [];
            var sExternalTopLevelKeyName = this.getExternalTopLevelKeyName();
            var sExternalSecondLevelKeyName = this.getExternalSecondLevelKeyName();
            for ( var sTopLevelKey in oInternalSelection) {
                var oExternalSelectionItem = {};
                oExternalSelectionItem[sExternalTopLevelKeyName] = sTopLevelKey;
                oExternalSelectionItem[sExternalSecondLevelKeyName] = [];
                for ( var sSecondLevelKey in oInternalSelection[sTopLevelKey]) {
                    oExternalSelectionItem[sExternalSecondLevelKeyName].push(sSecondLevelKey);
                }
                aExternalSelection.push(oExternalSelectionItem);
            }
            $.sap.log.debug("converted internal selection to external selection: " + JSON.stringify(oInternalSelection), null,
                    "jd.ui.eid.control.HierarchyFilterItem");
            return aExternalSelection;
        },

        /**
         * Set new selection.
         * 
         * Format: <br> [{ <ExternalTopLevelKeyName> : "TopLevelId1",<br>
         * <ExternalSecondLevelKeyName> : ["SecondLevelId1", "SecondLevelId2"] }]</br>
         * 
         * @param {array}
         *            aSelection array with the selected keys
         */
        setSelection : function(aSelection) {
            $.sap.log.debug("setSelection: " + JSON.stringify(aSelection), null, "jd.ui.eid.control.HierarchyFilterItem");
            $.sap.log.debug("items: " + this.getItems().length, null, "jd.ui.eid.control.HierarchyFilterItem");
            this.setProperty("selection", aSelection, true);

            if ($.sap.equal(aSelection, {})) {
                this.setActive(false);
            } else {
                this.setActive(true);
            }
            // this._updateInternalSelection();
            this._tmp.push(aSelection);
            this._sel = aSelection;
            this._markSelectedAttributes(this._convertExternalSelectionToInternalSelection(aSelection));
            this._updateSelectionDisplay();
            return this;
        },
        _tmp : [],

        /**
         * Set new selection (internal)
         * 
         * @param {object}
         *            oSelection object tree with the selected keys
         * @param {sap.ui.ux3.ExactAttribute}
         *            [oRootItem] default is the root attribute
         * @returns this object for chaining
         */
        _markSelectedAttributes : function(oSelection, oRootItem) {
            $.sap.log.debug("marking selected attributes...", null, "jd.ui.eid.control.HierarchyFilterItem");
            // setProperty() is done in _updateSelectionDisplay()
            var bRootCall = (oRootItem === undefined);
            if (bRootCall) {
                oRootItem = this.oHiddenRootItem;
            }
            // recursively select those ExactAttributes
            // referenced in the selection
            // object
            for ( var i = 0; i < oRootItem.getAttributes().length; ++i) {
                var oCurrentAttribute = oRootItem.getAttributes()[i];
                var vCurrentAttributeKey = oCurrentAttribute.getText();
                var bSelected = oSelection.hasOwnProperty(vCurrentAttributeKey);
                if (bSelected) {
                    $.sap.log.debug("... " + vCurrentAttributeKey + " is selected.", null, "jd.ui.eid.control.HierarchyFilterItem");
                } else {
                    $.sap.log.debug("... " + vCurrentAttributeKey + " is not selected.", null, "jd.ui.eid.control.HierarchyFilterItem");
                }
                if (oCurrentAttribute.getSelected() != bSelected) {
                    oCurrentAttribute.setSelected(bSelected);
                }

                // recursive call to (de)select child attributes deselection also
                // has to be done if this attribute is not selected, thus {}
                this._markSelectedAttributes(bSelected ? oSelection[vCurrentAttributeKey] : {}, oCurrentAttribute);
            }

            if (bRootCall) {
                // setProperty() and update selection display
                // this._updateSelectionDisplay();
            }

            return this;
        },

        /**
         * update text to show when no selection is active
         * 
         * @param {string}
         *            vNoSelectionText new text to display when no selection is active
         */
        setNoSelectionText : function(vNoSelectionText) {
            this.oNoSelectionDisplay.setText(vNoSelectionText);
            this.setProperty("noSelectionText", vNoSelectionText);
            return this;
        },

        /**
         * close popup when collapse inside the ExactBrowser is clicked
         * 
         * @param {sap.ui.core.Event}
         *            oEvent
         */
        _onExactBrowserCloseClicked : function(oEvent) {
            this.oPopup.close(0);
        },

        /**
         * see {@link jd.ui.eid.Control.FilterItem#_clear}
         */
        _clear : function() {
            var oCurrentSelection = this.getSelection();
            var oEmptySelection = {};
            if (!$.sap.equal(oCurrentSelection, oEmptySelection)) {
                this.setSelection(oEmptySelection);
                return true;
            } else {
                return false;
            }
        },

        /**
         * see {@link jd.ui.eid.Control.FilterItem#_reset}
         */
        _reset : function() {
            this.setSelection([]);
        },

        /*
         * delegate our items aggregation to the ExactBrowser
         */
        /**
         * @see sap.ui.ux3.ExactAttribute.addAttribute( )
         */
        addItem : function(oItem) {
            this.oHiddenRootItem.addAttribute(oItem);
            return this;
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.destroyAttributes( )
         */
        destroyItems : function() {
            this.oHiddenRootItem.destroyAttributes();
            return this;
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.getAttributes( )
         */
        getItems : function() {
            return this.oHiddenRootItem.getAttributes();
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.indexOfAttribute( )
         */
        indexOfItem : function(oItem) {
            return this.oHiddenRootItem.indexOfAttribute(oItem);
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.insertAttribute( )
         */
        insertItem : function(oItem, iIndex) {
            this.oHiddenRootItem.insertAttribute(oItem, iIndex);
            return this;
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.removeAllAttributes( )
         */
        removeAllItems : function() {
            return this.oHiddenRootItem.removeAllAttributes();
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.removeAttribute( )
         */
        removeItem : function(vItem) {
            return this.oHiddenRootItem.removeAttribute(vItem);
        },

        /**
         * @see sap.ui.ux3.ExactAttribute.setTopCaption( )
         */
        setTopCaption : function(sTopCaption) {
            this.oHiddenRootItem.setText(sTopCaption);
            this.setProperty("topCaption", sTopCaption);
            return this;
        },

        /* Internal Event Handlers */

        /**
         * Updates the list of selected values
         */
        _updateSelectionDisplay : function() {
            // rebuild display of selected values
            var oLayout = this.getAggregation("_selectionDisplay");
            oLayout.removeAllContent();
            this._addChildSelectionDisplays(oLayout, this.oHiddenRootItem, 0);

            // display "no selection" text if no selection is active
            if (oLayout.getContent().length === 0) {
                this.setActive(false);
                oLayout.addContent(this._getNoSelectionDisplay());
            } else {
                this.setActive(true);
            }

        },

        /**
         * return the Control that should be shown when no selection is active
         * 
         * @returns {sap.ui.commons.Label}
         */
        _getNoSelectionDisplay : function() {
            return this.oNoSelectionDisplay;
        },

        /**
         * Adds the sap.ui.commons.Link controls representing the child attributes of oAttributeParent recursively to oLayout.
         * 
         * @param {sap.ui.ux3.VerticalLayout}
         *            oLayout add to this layout
         * @param {sap.ui.ux3.ExactAttribute}
         *            oAttribute add this attribute and its children
         * @param {Number}
         *            [iDepth] current nesting depth
         * @returns {Number} number of selected children
         */
        _addChildSelectionDisplays : function(oLayout, oAttribute, iDepth) {
            $.sap.log.debug("add child selection displays on level " + iDepth + "...", null, "jd.ui.eid.control.HierarchyFilterItem");
            // save current position for later insert
            var iPosition = oLayout.getContent().length;

            // count children and add respective Links to the layout
            var iAddedChildren = 0;
            for ( var i = 0; i < oAttribute.getAttributes().length; ++i) {
                iAddedChildren += this._addChildSelectionDisplays(oLayout, oAttribute.getAttributes()[i], iDepth + 1);
            }

            // selected leaf node
            var bSelectedLeafNode = oAttribute.getAttributes().length === 0 && oAttribute.getSelected();
            // inner node with selected leaves
            var bInnerNodeWithSelectedLeaves = iAddedChildren > 0;
            // hiddenRootItem should not be shown
            var bIsNotHiddenRoot = oAttribute !== this.oHiddenRootItem;

            if (bIsNotHiddenRoot && bSelectedLeafNode) {
                $.sap.log.debug("... attribute " + oAttribute.getText() + " is selected leaf node", null, "jd.ui.eid.control.HierarchyFilterItem");
            }

            if (bIsNotHiddenRoot && bInnerNodeWithSelectedLeaves) {
                $.sap.log.debug("... attribute " + oAttribute.getText() + " is inner node with selected leaves", null,
                        "jd.ui.eid.control.HierarchyFilterItem");
            }

            // Was: if (bIsNotHiddenRoot && (bInnerNodeWithSelectedLeaves || bSelectedLeafNode)) {
            if (bIsNotHiddenRoot && oAttribute.getSelected()) {
                // count added node
                ++iAddedChildren;

                // add Link for oAttribute
                var oMyLink = new sap.ui.commons.Label({
                    text : oAttribute.getText()
                });
                oMyLink.addStyleClass("jdUiEidHierarchyFilterItemSelection_" + (iDepth - 1));

                // insert oMyLink in front of the children
                oLayout.insertContent(oMyLink, iPosition);
            }

            return iAddedChildren;
        },

        /**
         * Handles selection events of the ExactBrowser contained. Updates the selection display and the "_internalSelection" property
         * 
         * @param {sap.ui.core.Event}
         *            oEvent
         */
        _handleSelect : function(oEvent) {
            // the newly selected or deselected attribute
            var oNewAttribute = oEvent.getParameter("attribute");
            var aAllAttributes = oEvent.getParameter("allAttributes");

            // multiselection not allowed and a new item is
            // selected (getSelected() == true) -> deselect non-ancestors in the
            // tree
            if (!this.getAllowMultiSelect() && oNewAttribute.getSelected()) {

                // collect ancestors of the newly selected attribute
                var aAncestors = [];
                var oAncestor = oNewAttribute;
                while (oAncestor instanceof sap.ui.ux3.ExactAttribute) {
                    aAncestors.push(oAncestor);
                    oAncestor = oAncestor.getParent();
                }

                // deselect non-ancestors
                for ( var i = 0; i < aAllAttributes.length; ++i) {
                    var oAttribute = aAllAttributes[i];
                    var bIsAncestorOfCurrentSelection = aAncestors.indexOf(oAttribute) !== -1;

                    // oAttribute is in another branch of the tree, set to
                    // non-selected
                    if (!bIsAncestorOfCurrentSelection) {
                        this.oExactBrowser.disableAnimationsForNextRendering();
                        oAttribute.setSelected(false);
                        // triggers exactbrowser rerender() call, disables
                        // animations not wanted in this special case (hide one
                        // list, display another -> creates flickering otherwise)
                        this.oExactBrowser.invalidate();
                    }
                }
            }

            if (!this.getAllowMultiSelect() && oNewAttribute.getParent() != this.oHiddenRootItem && aAllAttributes.length >= 3) {
                // Including counting the hidden root attribute, all required attributes (from the two dimensions) have been selected. And the
                // selected attribute is not on the first (visible) level. So for UX reasons, let's close the popup (multi select isn't
                // allowed, so there's no reason to keep it open)
                this.oPopup.close();
            }

            // update selection display
            // this._updateSelectionDisplay();
            this.setProperty("selection", this._convertInternalSelectionToExternalSelection(this._getInternalSelectionObject()), true);
            this._updateSelectionDisplay();

            // Fire only if all values have been set?!
            this.fireValueChanged();
        },

        /**
         * Get object describing the selection tree.<br>
         * Example:<br>
         * <code>
         * {
         *   "Level1SelectionA" : {
         *     "Level2Selection" : {}
         *   },
         *   "Level1SelectionB" : {}
         * } 
         * </code>
         * 
         * @param {sap.ui.ux3.ExactAttribute}
         *            [oRootAttribute] the root attribute for which the selection should be returned
         * @returns {object} oResult: tree containing the IDs of all selected ExactAttributes
         */
        _getInternalSelectionObject : function(oRootAttribute) {
            if (oRootAttribute === undefined) {
                oRootAttribute = this.oHiddenRootItem;
            }
            var oResult = {};
            for ( var i = 0; i < oRootAttribute.getAttributes().length; ++i) {
                var oChildAttribute = oRootAttribute.getAttributes()[i];
                if (oChildAttribute.getSelected()) {
                    // insert recursive child information
                    oResult[oChildAttribute.getText()] = this._getInternalSelectionObject(oChildAttribute);
                }
            }
            return oResult;
        },

        onAfterRendering : function() {
            // Invoke base onAfterRendering (because e.g event handler for collapse icon is attached there)
            jd.ui.eid.control.FilterItem.prototype.onAfterRendering.apply(this);

            /*
            if (this.getBinding("selection")) {
                this.getBinding("selection").refresh(true);
            }
            */
            $.sap.log.debug("onAfterRendering", null, "jd.ui.eid.control.HierarchyFilterItem");
        },

        renderer : "jd.ui.eid.control.HierarchyFilterItemRenderer"
    });
})();