(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.control.CheckBoxFilterItem");

    var oFilterItem = null;

    module("jd.ui.eid.control.CheckBoxFilterItem", {
        setup : function() {
            oFilterItem = new jd.ui.eid.control.CheckBoxFilterItem();
        },
        teardown : function() {
            oFilterItem = null;
        }
    });

    test("_clear() should set checked property to false.", function() {
        oFilterItem.setChecked(true);

        // Initial assertions
        ok(oFilterItem.getChecked());

        // Execute the business logic
        oFilterItem._clear();

        // Final assertions
        ok(!oFilterItem.getChecked());
    });

    test("_handleChange() should set the checked property to false if it was true.", function() {
        oFilterItem.setChecked(true);

        // Initial assertions
        ok(oFilterItem.getChecked());

        // Execute the business logic
        oFilterItem._handleChange(null);

        // Final assertions
        ok(!oFilterItem.getChecked());
    });

    test("_handleChange() should set the checked property to true if it was false.", function() {
        oFilterItem.setChecked(false);

        // Initial assertions
        ok(!oFilterItem.getChecked());

        // Execute the business logic
        oFilterItem._handleChange(null);

        // Final assertions
        ok(oFilterItem.getChecked());
    });

    test("_handleChange() should fire the valueChanged event.", function() {
        oFilterItem.setChecked(false);
        var spy = sinon.spy();
        oFilterItem.attachValueChanged(spy);

        // Initial assertions
        ok(!oFilterItem.getChecked());

        // Execute the business logic
        oFilterItem._handleChange(null);

        // Final assertions
        ok(spy.calledOnce);
    });

})();