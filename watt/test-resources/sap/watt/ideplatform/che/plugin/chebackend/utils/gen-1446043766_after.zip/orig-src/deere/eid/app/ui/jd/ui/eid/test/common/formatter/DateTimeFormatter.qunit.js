(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.model.EidModel");

    module("jd.ui.eid.common.formatter.DateTimeFormatter", {
        setup : function() {
            var oApp = jd.ui.eid.application.Application.getInstance();
            oApp.setParameters(jd.ui.eid.application.main.ApplicationParameters);
            oApp._initModels();
        },
        teardown : function() {
        }
    });

    test("formatTimeBinUseTimeUnit, TimeUnit= days", function() {

        var oModel = new sap.ui.model.json.JSONModel();
        var oData = {
            myPath : {
                TimeUnit : "days",
                Records : []
            },
        };
        oModel.setData(oData);
        var oContext = {};
        var oModelContext = new sap.ui.model.Context(oModel, "/myPath/Records", oContext);

        // Set the date value which should be tested
        var sDate = "2013/03/03";

        // Manually convert the sDate value to the expected result
        var oLocale = new sap.ui.core.Locale(jd.ui.eid.common.DateHelper.getLocale());
        var sFormattedDate = sap.ui.core.format.DateFormat.getDateInstance({
            style : "medium"
        }, oLocale).format(new Date("2013", "02", "03"));

        // Get the result value
        var sResult = jd.ui.eid.common.formatter.DateTimeFormatter.formatTimeBinUseTimeUnit(sDate, oModelContext);

        // Check if the expected result matches the current result
        equals(sFormattedDate, sResult);
    });

    test("formatTimeBinUseTimeUnit, TimeUnit= weeks", function() {

        var oModel = new sap.ui.model.json.JSONModel();
        var oData = {
            myPath : {
                TimeUnit : "weeks",
                Records : []
            },
        };
        oModel.setData(oData);
        var oContext = {};
        var oModelContext = new sap.ui.model.Context(oModel, "/myPath/Records", oContext);
        var sResult = jd.ui.eid.common.formatter.DateTimeFormatter.formatTimeBinUseTimeUnit("2013/03", oModelContext);
        equals('CW 2013/03', sResult);
    });

    test("formatTimeBinUseTimeUnit, TimeUnit= months", function() {
        // I18n model
        var oI18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl : "jd/ui/eid/asset/text/i18n.properties"
        });
        sap.ui.getCore().setModel(oI18nModel, 'i18n');

        var oModel = new sap.ui.model.json.JSONModel();
        var oData = {
            myPath : {
                TimeUnit : "months",
                Records : []
            },
        };

        oModel.setData(oData);
        var oContext = {};
        var oModelContext = new sap.ui.model.Context(oModel, "/myPath/Records", oContext);
        var sResult = "";
        var fFormat = jd.ui.eid.common.formatter.DateTimeFormatter.formatTimeBinUseTimeUnit;

        sResult = fFormat("2013/01", oModelContext);
        equals('2013/Jan', sResult);
        sResult = fFormat("2013/02", oModelContext);
        equals('2013/Feb', sResult);
        sResult = fFormat("2013/03", oModelContext);
        equals('2013/Mar', sResult);
        sResult = fFormat("2013/04", oModelContext);
        equals('2013/Apr', sResult);
        sResult = fFormat("2013/05", oModelContext);
        equals('2013/May', sResult);
        sResult = fFormat("2013/06", oModelContext);
        equals('2013/Jun', sResult);
        sResult = fFormat("2013/07", oModelContext);
        equals('2013/Jly', sResult);
        sResult = fFormat("2013/08", oModelContext);
        equals('2013/Aug', sResult);
        sResult = fFormat("2013/09", oModelContext);
        equals('2013/Sep', sResult);
        sResult = fFormat("2013/10", oModelContext);
        equals('2013/Oct', sResult);
        sResult = fFormat("2013/11", oModelContext);
        equals('2013/Nov', sResult);
        sResult = fFormat("2013/12", oModelContext);
        equals('2013/Dec', sResult);
    });

})();