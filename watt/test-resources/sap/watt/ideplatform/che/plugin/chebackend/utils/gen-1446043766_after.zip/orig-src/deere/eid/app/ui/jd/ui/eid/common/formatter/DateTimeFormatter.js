(function() {
    "use strict";
    jQuery.sap.declare("jd.ui.eid.common.formatter.DateTimeFormatter");
    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    /**
     * @class
     * <p>
     * The DateTimeFormatter utility class provides functionality to format different date-related information.
     * </p>
     * <p>
     * When formatting time bins for charts, the format is as follows:
     * <ul>
     * <li>days : the format is JSON date (<code>yyyy-mm-dd...</code>).</li>
     * <li>weeks : the format is <code>yyyy/ww</code>.</li>
     * <li>fiscal weeks : the format is JSON date (<code>yyyy-mm-dd...</code>, week ending).</li>
     * <li>months : the format is <code>yyyy/mm</code>.</li>
     * </ul>
     * </p>
     * @static
     * @name jd.ui.eid.common.formatter.DateTimeFormatter
     */
    jd.ui.eid.common.formatter.DateTimeFormatter = {};

    /**
     * Namespace for units.
     * 
     * @ignore
     */
    jd.ui.eid.common.formatter.DateTimeFormatter.Unit = {
        day : "day",
        week : "week",
        weeks : "weeks",
        month : "month",
        months : "months"
    };

    /**
     * Returns the time unit for the given context. This is used in chart formatters where the context is passed as the last object. The methods tries
     * to find the TimeUnit property for the current Records property. The following assumption is made about the model structure:
     * 
     * <pre>
     * {
     *     ChartData : {
     *         TimeUnit : &quot;weeks&quot;,
     *         Records: [...]
     *     }
     * }
     * </pre>
     * 
     * @param {sap.ui.model.Context}
     *            current Context
     * @return {string} the time unit
     */
    jd.ui.eid.common.formatter.DateTimeFormatter._getTimeUnit = function(oContext) {
        var sTimeUnit = null;
        // the path of oContext is /path/[n]/Records/[n],
        var sPath = oContext.getPath();
        var iIndexOfRecordsInString = sPath.indexOf("Records");

        // the TimeUnit is located in /path/[n]/TimeUnit
        var sTimeUnitPath = oContext.getPath().slice(0, iIndexOfRecordsInString) + "TimeUnit";
        sTimeUnit = oContext.getModel().getProperty(sTimeUnitPath);
        return sTimeUnit;
    };

    /**
     * Formats a time bin. For days, it returned the date. For weeks, it returns week-year combination. For months, it returns the actual month (e.g.
     * Jan 2013).
     * 
     * @param {string}
     *            sDate Date.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted time bin.
     */
    jd.ui.eid.common.formatter.DateTimeFormatter.formatTimeBinUseTimeUnit = function(sDate, oContext) {
        if (oContext) {
            var sTimeUnit = jd.ui.eid.common.formatter.DateTimeFormatter._getTimeUnit(oContext);
            if (sTimeUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.months) {
                // input format: yyyy/mm
                return jd.ui.eid.common.formatter.DateTimeFormatter._formatYearMonth(sDate, "COMMON_FORMATTER_TXT_YEAR_MONTH");
            } else if (sTimeUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.weeks) {
                // input format: yyyy/ww
                return jd.ui.eid.common.formatter.DateTimeFormatter._formatYearWeek(sDate, "COMMON_FORMATTER_TXT_YEAR_WEEK");
            } else {
                // input format : yyyy/mm/dd
                return jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(sDate);
            }
        } else {
            return "";
        }
    };

    /**
     * Formats a fiscal time bin. For days, it returned the date. For weeks, it returns the date of the last day of the fiscal week. For months, it
     * returns the actual month (e.g. Jan 2013).
     * 
     * @param {string}
     *            sDate Date.
     * @param {sap.ui.model.Context}
     *            oContext the context of the bin.
     * @returns {string} formatted time bin.
     */
    jd.ui.eid.common.formatter.DateTimeFormatter.formatFiscalTimeBinUseTimeUnit = function(sDate, oContext) {
        if (oContext) {
            var sTimeUnit = jd.ui.eid.common.formatter.DateTimeFormatter._getTimeUnit(oContext);
            if (sTimeUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.months) {
                // input format: yyyy/mm
                return jd.ui.eid.common.formatter.DateTimeFormatter._formatYearMonth(sDate, "COMMON_FORMATTER_TXT_FISCAL_YEAR_MONTH");
            } else {
                // either weeks or days, the input format for either one is: yyyy/mm/dd
                return jd.ui.eid.common.DateHelper.JSONDateToFormattedDate(sDate);
            }
        } else {
            return "";
        }
    };

    jd.ui.eid.common.formatter.DateTimeFormatter._aMonths = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JLY", "AUG", "SEP", "OCT", "NOV", "DEC"];

    /**
     * Gets the short name for the given month. For example "JAN" or "FEB".
     * 
     * @param {integer}
     *            iMonth the month (between 1 and 12).
     * @returns {string} the short name of the month.
     * @private
     */
    jd.ui.eid.common.formatter.DateTimeFormatter._getShortMonthName = function(iMonth) {
        if (iMonth > 12 || iMonth < 1) {
            return "";
        }
        var iIndex = iMonth - 1;
        var sTextKey = "COMMON_FORMATTER_TXT_MONTH_" + this._aMonths[iIndex];
        return jd.ui.eid.common.I18NHelper.getText(sTextKey);
    };

    /**
     * Formats a slashed date (<code>yyyy/mm/dd</code>) to a formatted date (see {@link jd.ui.eid.common.DateHelper DateHelper}).
     * 
     * @param {string}
     *            sDate the date in format <code>yyyy/mm/dd</code>.
     * @returns {string} a formatted date.
     * @private
     */
    jd.ui.eid.common.formatter.DateTimeFormatter._formatSlashedDateToFormattedDate = function(sDate) {
        var iPos = sDate.indexOf('/');
        var sYear = sDate.slice(0, iPos);
        var iPos2 = sDate.indexOf('/', iPos + 1);
        var sMonth = sDate.slice(iPos + 1, iPos2);
        var sDay = sDate.slice(iPos2 + 1);
        var sHyphenizedDate = sYear + "-" + (sMonth.length == 1 ? "0" + sMonth : sMonth) + "-" + (sDay.length == 1 ? "0" + sDay : sDay);
        return jd.ui.eid.common.DateHelper.hyphenizedDateToFormattedDate(sHyphenizedDate);
    };

    /**
     * Formats a year-month string (<code>yyyy/mm</code>).
     * 
     * @param {string}
     *            sDate string with format <code>yyyy/mm</code>.
     * @param {string}
     *            sTextKey the text key with placeholders for year and month.
     * @returns {string} a formatted string based on <code>sTextKey</code>.
     */
    jd.ui.eid.common.formatter.DateTimeFormatter._formatYearMonth = function(sDate, sTextKey) {
        var iPos = sDate.indexOf('/');
        var sYear = sDate.slice(0, iPos);
        var iMonth = parseInt(sDate.slice(iPos + 1));
        var sMonth = jd.ui.eid.common.formatter.DateTimeFormatter._getShortMonthName(iMonth);
        return jd.ui.eid.common.I18NHelper.getText(sTextKey, [sYear, sMonth]);
    };

    /**
     * Formats a calendar week string of format <code>yyyy/ww</code>.
     * 
     * @param {string}
     *            sDate string with format <code>yyyy/ww</code>.
     * @param {string}
     *            sTextKey the text key with placeholders for year and week.
     * @returns {string} a formatted string based on <code>sTextKey</code>.
     */
    jd.ui.eid.common.formatter.DateTimeFormatter._formatYearWeek = function(sDate, sTextKey) {
        var iPos = sDate.indexOf('/');
        var sYear = sDate.slice(0, iPos);
        var sWeek = sDate.slice(iPos + 1);
        return jd.ui.eid.common.I18NHelper.getText(sTextKey, [sYear, sWeek]);
    };

    /**
     * Formatter for the text of the custom date distance list item.
     * 
     * @param {int}
     *            iValue Numberic distance.
     * @param {string}
     *            sUnit Unit of distance.
     * @return {string} text of the custom date distance list item
     * 
     */
    jd.ui.eid.common.formatter.DateTimeFormatter.formatDateDistanceValueListItemText = function(iValue, sUnit) {
        var sValue = "";

        if (sUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.day) {
            sValue = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iValue, "DATE_DISTANCE_LST_DATE_DISTANCE_DAY_MULTIPLE",
                    "DATE_DISTANCE_LST_DATE_DISTANCE_DAY_SINGLE");
        } else if (sUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.week) {
            sValue = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iValue, "DATE_DISTANCE_LST_DATE_DISTANCE_WEEK_MULTIPLE",
                    "DATE_DISTANCE_LST_DATE_DISTANCE_WEEK_SINGLE");
        } else if (sUnit == jd.ui.eid.common.formatter.DateTimeFormatter.Unit.month) {
            sValue = jd.ui.eid.common.I18NHelper.getNumberChoiceText(iValue, "DATE_DISTANCE_LST_DATE_DISTANCE_MONTH_MULTIPLE",
                    "DATE_DISTANCE_LST_DATE_DISTANCE_MONTH_SINGLE");
        }

        return sValue;
    };

    /**
     * Formatter for the text of the custom date range list item.
     * 
     * @param {string}
     *            from date of the date range in the format yyyymmdd.
     * @param {string}
     *            to date of the date range in the format yyyymmdd.
     * @return {string} text of the custom date date range list item
     * 
     */
    jd.ui.eid.common.formatter.DateTimeFormatter.formatDateRangeValueListItemText = function(fromDate, toDate) {
        var sStartDate = jd.ui.eid.common.DateHelper.yyyymmddToHyphenizedDate(fromDate);
        var sEndDate = jd.ui.eid.common.DateHelper.yyyymmddToHyphenizedDate(toDate);
        return jd.ui.eid.common.I18NHelper.getText('DATE_RANGE_FORMAT_TXT_RANGE', [sStartDate, sEndDate]);
    };

})();