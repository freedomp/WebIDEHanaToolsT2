(function() {
    "use strict";

    jd.ui.eid.require("jd.ui.eid.common.I18NHelper");

    module("jd.ui.eid.common.I18NHelper", {
        setup : function() {
            var oI18nModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl : "jd/ui/eid/asset/text/i18n.properties"
            });
            sap.ui.getCore().setModel(oI18nModel, 'i18n');
        },
        teardown : function() {
            sap.ui.getCore().setModel(null, 'i18n');
        }
    });

    test("getNumberChoiceText() should return the value of the third key if all keys are provided and the value is '0'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('none', jd.ui.eid.common.I18NHelper.getNumberChoiceText(0, 'PLURAL', 'SINGULAR', 'NONE'));
    });

    test("getNumberChoiceText() should return the value of the second key if all keys are provided and the value is '1'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('singular', jd.ui.eid.common.I18NHelper.getNumberChoiceText(1, 'PLURAL', 'SINGULAR', 'NONE'));
    });

    test("getNumberChoiceText() should return the value of the second key if all keys are provided and the value is '-1'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('singular', jd.ui.eid.common.I18NHelper.getNumberChoiceText(-1, 'PLURAL', 'SINGULAR', 'NONE'));
    });

    test("getNumberChoiceText() should return the value of the first key if all keys are provided and the value is '2'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('plural', jd.ui.eid.common.I18NHelper.getNumberChoiceText(2, 'PLURAL', 'SINGULAR', 'NONE'));
    });

    test("getNumberChoiceText() should return the value of the first key if two keys are provided and the value is '0'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('plural', jd.ui.eid.common.I18NHelper.getNumberChoiceText(0, 'PLURAL', 'SINGULAR'));
    });

    test("getNumberChoiceText() should return the value of the second key if two keys are provided and the value is '1'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('singular', jd.ui.eid.common.I18NHelper.getNumberChoiceText(1, 'PLURAL', 'SINGULAR'));
    });

    test("getNumberChoiceText() should return the value of the first key if two keys are provided and the value is '2'.", function() {
        _mockModelForNumberChoice(sap.ui.getCore().getModel('i18n'));
        equals('plural', jd.ui.eid.common.I18NHelper.getNumberChoiceText(2, 'PLURAL', 'SINGULAR'));
    });

    /**
     * Mocks the resource bundle's getText method with three different text keys: <code>PLURAL</code>, <code>SINGULAR</code>, and
     * <code>NONE</code>.
     * 
     * @private
     * @param {sap.ui.model.resource.ResourceModel}
     *            oModel the resource model
     */
    function _mockModelForNumberChoice(oModel) {
        oModel.ResourceBundle.getText = function(sTextKey, aParams) {
            if (sTextKey == 'PLURAL') {
                return 'plural';
            } else if (sTextKey == 'SINGULAR') {
                return 'singular';
            } else if (sTextKey == 'NONE') {
                return 'none';
            } else {
                return 'n/a';
            }
        };
    };

})();