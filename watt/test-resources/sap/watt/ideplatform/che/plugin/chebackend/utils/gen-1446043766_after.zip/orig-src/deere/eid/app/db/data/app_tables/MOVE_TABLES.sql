
--------------------------------------------------------------------------------------------------------------------
-- Replicated Tables 
--------------------------------------------------------------------------------------------------------------------

ALTER TABLE "EID"."deere.etl.eid.catalog.tables::MK_MACHINE_EIA" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_NATIVE_PIN_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::MK_ALERT_BASE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::FUNCTIONAL_AREA_MASTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::MK_MACH_TRACE_LOG_DAY" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."deere.etl.eid.catalog.tables::DTC_MASTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."$TA_WARNING_LIGHT_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."$TA_DTC_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."$TA_L1_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TELEMATICS"."$TA_L2_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_ACCT"."deere.etl.eid.catalog.tables::ACCT_PHYS_ADDR" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_TIME"."deere.etl.common.catalog.tables::SS_FISCAL_CALENDAR" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "DATA_DS_PRODUCT"."deere.etl.eid.catalog.tables::PI_CNFGR" MOVE TO 'zdxpea1:30003' PHYSICAL;

-- the tables for Warranty Claims and DTAC Cases are located on a different node (where the similarity search is executed)
ALTER TABLE "EID"."deere.etl.eid.catalog.tables::WRNTY_CLAIM_EIA" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_PRIME_PART_DSC_INDEX" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_PRIME_PART_DTL_TXT_INDEX" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_PRIME_PART_NUM_INDEX" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::NEW_FUNCAREA" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_TICKET_HDR" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_TICKET_TXT" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QX_WORKGROUP" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_FIELDINFO" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QW_ORGANIZATION" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."$TA_QW_PROBLEM_INDEX" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QX_NAT_FIELDINFO" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::NEW_FUNCCODE" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."$TA_QW_NOTES_INDEX" MOVE TO 'zdxpea4:30003' PHYSICAL;
ALTER TABLE "DATA_DS_DTAC"."deere.etl.eid.catalog.tables::QX_USERS" MOVE TO 'zdxpea4:30003' PHYSICAL;


------------------------------------------------------------------------------------------------------------------------------
-- Application Specific Tables -> all on same node, co-located with major replicated tables (MK_MACHINE_EIA and MK_ALERT_BASE)
------------------------------------------------------------------------------------------------------------------------------

ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_ENGN_HOURS_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::KPI_TEXT" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_DTC_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_ITEM" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_PIN_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_PACKAGE_NAME_TEST_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_BRANCH_CODE_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::KEY_VALUE_PARAMETERS_SYS" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::BINS_DTC" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_MACHINE_LOCATION" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_FILTER_STATE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_BUILD_FACTORY" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."$TA_PACKAGE_DESC_TEST_INDEX" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EVIDENCE_PACKAGE_H" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_EMISSION_LEVEL" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_ITEM" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EH_SEGMENTS_MAPPING" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_MACH_LOC_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_ENGN_HOURS_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::BLACKLIST_DTC" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_ENGINE_HOURS" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_MACHINE_OPTION_CODES" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_FILTER_STATE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_DSGN_FCTRY_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_DESIGN_FACTORY" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::KPI" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_ITEM" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_TAG_CLOUD_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_FUNCTIONAL_AREA_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_BRANCH_CODE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_MODEL" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::SEVERITY_RATING" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_BLD_FCTRY_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_MANUAL_PIN" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_STATE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_WARRANTY_DTC_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::KEY_VALUE_PARAMETERS" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_DOMAIN_VALUES" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTAC_FILTER_STATE" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::PERS_FILTER_FUNC_AREA" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_MODEL_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::KPI_LIST" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::WRNTY_ENGINE_HOURS_BUCKET" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_DTC_EMISSION_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::EP_WRNTY_ENGN_HOURS_FILTER" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::ENGINE_HOURS_SEGMENTS" MOVE TO 'zdxpea1:30003' PHYSICAL;
ALTER TABLE "EID"."deere.eid.app.db.data.app_tables::SEVERITY_RATING_SYS" MOVE TO 'zdxpea1:30003' PHYSICAL;

