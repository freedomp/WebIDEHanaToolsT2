SAP internal development: SAP Fiori Reference Application to demonstrate implementation of reuse-components across applications

For documentation on Fiori Reference Apps, see
https://wiki.wdf.sap.corp/wiki/display/refapps/Fiori+Reference+Applications+Home