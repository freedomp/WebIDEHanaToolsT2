(function() {
    "use strict";

    jQuery.sap.declare("jd.ui.eid.control.DateDistanceFilterItem");
    jd.ui.eid.require("jd.ui.eid.control.FilterItem");
    jd.ui.eid.require("jd.ui.eid.control.ValueListItem");
    jd.ui.eid.require("jd.ui.eid.control.ListBox");
    jd.ui.eid.require("jd.ui.eid.common.DateHelper");
    jd.ui.eid.require("jd.ui.eid.common.NotificationCenter");

    /**
     * The DateDistanceFilterItem control provides a list of possible values which can be selected to determine a date distance for the data
     * 
     * <ul>
     * <li>Properties
     * <ul>
     * <li>defaultCustomDateRangeLabel : string This property defines the label of the custom date range filter.</li>
     * <li>defaultCustomDistanceLabel : string This property defines the label of the custom distance filter.</li>
     * <li>enabledAllListItems: boolean This property defines whether all items should be enabled or just the custom date range item.</li>
     * <li>enabled : boolean (default: true) This property defines whether the filteritem is enabled or not.</li>
     * </ul>
     * </li>
     * <li>Aggregations
     * <ul>
     * <li>customDateRangeItem : jd.ui.eid.control.ValueListItem The custom date range item.</li>
     * <li>customDistanceItem : jd.ui.eid.control.ValueListItem The custom distance item.</li>
     * <li>items : jd.ui.eid.control.ValueListItem[] All static date distance filter items.</li>
     * </ul>
     * </li>
     * </ul>
     * 
     * @class
     * @extends jd.ui.eid.control.FilterItem
     * @name jd.ui.eid.control.DateDistanceFilterItem
     */
    jd.ui.eid.control.FilterItem.extend("jd.ui.eid.control.DateDistanceFilterItem", /** @lends jd.ui.eid.control.DateDistanceFilterItem */
    {
        metadata : {
            properties : {
                defaultCustomDateRangeLabel : {
                    type : "string"
                },
                defaultCustomDistanceLabel : {
                    type : "string"
                },
                enabledAllListItems : {
                    type : "boolean",
                    defaultValue : false
                },
                enabled : {
                    type : "boolean",
                    defaultValue : true
                }
            },
            aggregations : {
                customDateRangeItem : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                },
                customDistanceItem : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : false
                },
                items : {
                    type : "jd.ui.eid.control.ValueListItem",
                    multiple : true,
                    singularName : "item"
                }
            }
        },

        /**
         * Initialize the control.
         */
        init : function() {
            jd.ui.eid.control.FilterItem.prototype.init.apply(this, arguments);

            // Add the listbox style class here so that we don't have to do any unnecessary
            // overwrites in
            // the renderer
            this.addStyleClass("jdUiEidListBoxFilterItem");
            this.addStyleClass("jdUiEidDateDistanceFilterItem");

            // Set constancts
            this.AbsoluteType = "Absolute";
            this.RelativeType = "Relative";
        },

        /*
         * Internal Event Handlers
         */

        /**
         * 
         * Handler of CustomDateRange-valueChanged event: Update the internal state and fire valueChanged event
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeValueChanged : function(oEvent) {
            var oSelection = $.extend(true, {}, this.getProperty("selection"));
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");

            // Get new dates from custom date range item
            var sFromDate = oCustomDateRangeItem.getValue().from;
            var sToDate = oCustomDateRangeItem.getValue().to;

            // Update the text value of the list item
            oCustomDateRangeItem.setText(this.formatDateRangeValueListItemText(sFromDate, sToDate));

            // Format new date to JSON string
            var sFromJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sFromDate);
            var sToJSONDate = jd.ui.eid.common.DateHelper.YyyymmddToJSONDate(sToDate);

            // Check whether the values changed
            var bChanged = false;
            if (oSelection.Type != this.AbsoluteType || sFromJSONDate != oSelection.CustomStartDate || sToJSONDate != oSelection.CustomEndDate) {
                bChanged = true;
                oSelection.Type = this.AbsoluteType;
                oSelection.CustomStartDate = sFromJSONDate;
                oSelection.CustomEndDate = sToJSONDate;
            }

            // Update the selection
            this.setProperty("selection", oSelection);

            // If values actually changed, fire the 'valueChanged' event
            if (bChanged) {
                this.fireValueChanged();
            }
        },

        /**
         * 
         * Handler of CustomDateRange-select event: Unmark all items & mark custom date range item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDateRangeSelected : function(oEvent) {
            this._clearAllItemSelection();
            this.getAggregation("customDateRangeItem").setSelected(true);
        },

        /**
         * 
         * Handler of CustomDistance-valueChange event: Change the label of the custom distance item and fire valueChanged event
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDistanceValueChanged : function(oEvent) {
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Get values of tool pop-up
            var iDuration = oCustomDistanceItem.getValue().duration; // Get the numeric distance
            // value
            var sUnit = oCustomDistanceItem.getValue().unit; // Get the selected distance unit
            // (i.e. days, weeks, months)

            // Update the text value of the list item
            oCustomDistanceItem.setText(this.formatDateDistanceValueListItemText(iDuration, sUnit));

            // Update datamodel
            var oSelection = $.extend(true, {}, this.getProperty("selection"));
            oSelection.Type = this.RelativeType;

            // Set the internal state
            oSelection.CustomDuration = parseInt(iDuration);
            oSelection.CustomUnit = sUnit;
            oSelection.Duration = null;
            oSelection.Unit = "";

            this.setProperty("selection", oSelection);
            this.fireValueChanged();
        },

        /**
         * 
         * Handler of CustomDistance-select event: Unmark all items & mark custom distance item
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleCustomDistanceSelected : function(oEvent) {
            this._clearAllItemSelection();
            this.getAggregation("customDistanceItem").setSelected(true);
        },

        /**
         * 
         * Select event handler of static ValueListItem: Fire valueChanged event if a static date distance item has been selected
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event.
         * 
         */
        _handleItemSelected : function(oEvent) {
            var bSelected = oEvent.getSource().getSelected(); // Get the last selection state of
            // the clicked item
            this._clearAllItemSelection(); // Unmark all items
            oEvent.getSource().setSelected(!bSelected); // Revert the selection of clicked item

            // Check selection state
            if (oEvent.getSource().getSelected()) {
                // Update datamodel if selected
                var oSelection = $.extend(true, {}, this.getProperty("selection"));
                oSelection.Type = this.RelativeType;
                oSelection.Duration = oEvent.getSource().getValue().duration;
                oSelection.Unit = oEvent.getSource().getValue().unit;
                this.setProperty("selection", oSelection);
            } else {
                // Reset the selection property
                var oSelection = $.extend(true, {}, this.getProperty("selection"));
                oSelection.Type = "";
                this.setProperty("selection", oSelection);
            }

            this.fireValueChanged();
        },

        /**
         * This function sets the custom date range list item.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oCustomDateRangeItem The custom date range list item.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining
         */
        setCustomDateRangeItem : function(oCustomDateRangeItem) {
            this.setAggregation("customDateRangeItem", oCustomDateRangeItem);
            oCustomDateRangeItem.attachValueChanged($.proxy(this._handleCustomDateRangeValueChanged, this));
            oCustomDateRangeItem.attachSelect($.proxy(this._handleCustomDateRangeSelected, this));
            oCustomDateRangeItem.attachToolPopupCanceled($.proxy(this._handleCustomDateRangeToolPopupCanceled, this));
            return this;
        },

        /**
         * This function sets the custom distance list item.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oCustomDistanceItem The custom distance list item.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        setCustomDistanceItem : function(oCustomDistanceItem) {
            this.setAggregation("customDistanceItem", oCustomDistanceItem);
            oCustomDistanceItem.attachValueChanged($.proxy(this._handleCustomDistanceValueChanged, this));
            oCustomDistanceItem.attachSelect($.proxy(this._handleCustomDistanceSelected, this));
            oCustomDistanceItem.attachToolPopupCanceled($.proxy(this._handleCustomDistanceToolPopupCanceled, this));
            return this;
        },

        /**
         * This function adds the static date distance list item to the items aggregation.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        addItem : function(oItem) {
            // Set the selection event handler
            oItem.attachSelect($.proxy(this._handleItemSelected, this));

            // Add item to the list
            this.addAggregation("items", oItem);

            return this;
        },

        /**
         * This function inserts another static date distance list item to the items aggregation at a fix position.
         * 
         * @param {jd.ui.eid.control.ValueListItem}
         *            oItem The date distance list items.
         * @param {int}
         *            iIndex The position in the aggregation.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        insertItem : function(oItem, iIndex) {
            // Set the selection event handler
            oItem.attachSelect($.proxy(this._handleItemSelected, this));

            // Add item to the list
            this.insertAggregation("items", oItem, iIndex);

            return this;
        },

        /*
         * Further custom Getter/Setter - functions
         */

        /**
         * Enables all list items otherwise this function only enables the custom date range list item and disable all others.
         * 
         * @param {boolean}
         *            bEnabled true to enable all list items and false if just the custom date range item should be enabled.
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining.
         */
        setEnabledAllListItems : function(bEnabled) {
            // Just switch the enabled state of each item if the whole DateDistanceFilterItem is enabled
            if (this.getEnabled()) {
                // Enable/Disable the custom distance item
                this.getAggregation("customDistanceItem").setEnabled(bEnabled);

                // Enable/Disable all static items
                var aItems = this.getAggregation("items");
                for ( var i = 0; i < aItems.length; i++) {
                    aItems[i].setEnabled(bEnabled);
                }

                // Close all toolPopup of the custom items if opened
                if (!bEnabled) {
                    // Get the aggregations
                    var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
                    var oCustomDistanceItem = this.getAggregation("customDistanceItem");

                    // Check whether the date range popup is open
                    if (oCustomDateRangeItem.getToolPopup().isOpen()) {
                        oCustomDateRangeItem.getToolPopup().close(0);
                    }

                    // Check whether the distance popup is open
                    if (oCustomDistanceItem.getToolPopup().isOpen()) {
                        oCustomDistanceItem.getToolPopup().close(0);
                    }
                }

                // Get the current filter selection
                var oSelection = $.extend(true, {}, this.getProperty("selection"));

                // Synchronize the model regarding the enabled/disabled state of the list items
                if (!bEnabled) {
                    // Store the old values of the filter item
                    this.oLastSelection = $.extend(true, {}, oSelection);

                    // Reset the datamodel
                    if (oSelection.Type == this.RelativeType) {
                        oSelection.Type = "";
                    }
                } else // If all items are enabled
                {
                    // Set old values of the filter item if nothing changed during deactivation of items
                    if (this.oLastSelection != null) {
                        if (oSelection.StartDate != this.oLastSelection.StartDate) {
                            this.oLastSelection.StartDate = oSelection.StartDate;
                            this.oLastSelection.Type = this.AbsoluteType;
                        }

                        if (oSelection.EndDate != this.oLastSelection.EndDate) {
                            this.oLastSelection.EndDate = oSelection.EndDate;
                            this.oLastSelection.Type = this.AbsoluteType;
                        }

                        $.extend(oSelection, this.oLastSelection);
                        this.oLastSelection = null;
                    }
                }

                // Notify the listeners about the changed values
                this.setProperty("selection", oSelection);
                this.fireValueChanged();
            }

            return this;
        },

        /**
         * Deselect all items
         */
        _clearAllItemSelection : function() {
            // Clear selection of custom date range item
            this.getAggregation("customDateRangeItem").setSelected(false);

            // Clear selection of custom distance item
            this.getAggregation("customDistanceItem").setSelected(false);

            // Clear selection of all static items
            var aItems = this.getAggregation("items");
            for ( var i = 0; i < aItems.length; i++) {
                aItems[i].setSelected(false);
            }
        },

        /**
         * Handler for the CustomDateRange-canceled event : Refresh the binding to force a re-render so that the display matches the selection state
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event
         */
        _handleCustomDateRangeToolPopupCanceled : function() {
            this.getBinding("selection").refresh(true);
        },

        /**
         * Handler for the CustomDateDistance-canceled event : Refresh the binding to force a re-render so that the display matches the selection
         * state
         * 
         * @param {sap.ui.base.Event}
         *            oEvent the event
         */
        _handleCustomDistanceToolPopupCanceled : function() {
            this.getBinding("selection").refresh(true);
        },

        /**
         * Reset the filteritem selection
         */
        _resetSelection : function() {
            this._clearAllItemSelection();

            // Reset the custom date range
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");

            // Check whether the date range popup is open
            if (oCustomDateRangeItem.getToolPopup().isOpen()) {
                oCustomDateRangeItem.getToolPopup().close(0);
            }

            // Reset the date range item text
            oCustomDateRangeItem.setText(this.getDefaultCustomDateRangeLabel());

            // Reset the custom date range value
            oCustomDateRangeItem.setValue({
                from : "",
                to : ""
            });

            // Get the custom distance
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Check whether the distance popup is open
            if (oCustomDistanceItem.getToolPopup().isOpen()) {
                oCustomDistanceItem.getToolPopup().close(0);
            }

            // Reset the label of the custom distance
            oCustomDistanceItem.setText(this.getDefaultCustomDistanceLabel());

            // Reset the input & unit field
            oCustomDistanceItem.setValue({
                duration : null,
                unit : ""
            });
        },

        /*
         * Overridden methods of FilterItem class
         */

        /**
         * @see jd.ui.eid.control.FilterItem#_clear
         */
        _clear : function() {
            var oCurrentSelection = this.getProperty("selection");
            var oEmptySelection = {};
            oEmptySelection.Type = "";
            oEmptySelection.Unit = "";
            oEmptySelection.CustomStartDate = "";
            oEmptySelection.CustomEndDate = "";
            oEmptySelection.CustomDuration = -1;
            oEmptySelection.CustomUnit = "";
            oEmptySelection.Duration = -1;

            if (!$.sap.equal(oCurrentSelection, oEmptySelection)) {
                this._resetSelection();

                // Reset the internal state
                this.setSelection(oEmptySelection);

                // Remove the filteritem active flag to indicate that the selection was deleted
                this.setActive(false);

                return true;
            } else {
                return false;
            }
        },

        /**
         * Set the default selection
         * 
         * @param {object}
         *            oSelection Selection object
         * @param {string}
         *            oSelection.Type Constant which indicates whether a date distance (Relative) or date range (Absolute) was selected
         * @param {string}
         *            oSelection.CustomStartDate Start date of the custom date range
         * @param {string}
         *            oSelection.CustomEndDate End date of the custom date range
         * @param {int}
         *            oSelection.CustomDuration Duration of the custom date distance
         * @param {string}
         *            oSelection.CustomUnit Indicates the unit of the custom date distance (day/week/month)
         * @param {int}
         *            oSelection.Duration Duration of the static date distance
         */
        setSelection : function(oSelection) {
            this.setProperty("selection", oSelection);

            // Get the custom list items
            var oCustomDateRangeItem = this.getAggregation("customDateRangeItem");
            var oCustomDistanceItem = this.getAggregation("customDistanceItem");

            // Default values of custom items
            var oCustomDateRangeValue = {
                from : "",
                to : ""
            };
            var oCustomDistanceValue = {
                duration : null,
                unit : ""
            };

            this._resetSelection();

            // Check whether the "creationDate" property has been set in the model
            var bActive = false;
            if (oSelection) {

                // Check if a custom distance was set
                if (oSelection.CustomStartDate && oSelection.CustomEndDate) {
                    // Get from/to datepicker formatted values if type is Absolute
                    oCustomDateRangeValue.from = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.CustomStartDate);
                    oCustomDateRangeValue.to = jd.ui.eid.common.DateHelper.JSONDateToYyyymmdd(oSelection.CustomEndDate);

                    // Set label of custom date range item by daterange selection
                    oCustomDateRangeItem.setText(this.formatDateRangeValueListItemText(oCustomDateRangeValue.from, oCustomDateRangeValue.to));
                }

                // Check if a custom date range was set
                if (oSelection.CustomDuration && oSelection.CustomDuration >= 0) {
                    // Get the unit and duration in days
                    var sUnit = oSelection.CustomUnit;
                    var iDuration = oSelection.CustomDuration;

                    // Set value to date distance list item
                    oCustomDistanceValue.duration = iDuration;
                    oCustomDistanceValue.unit = sUnit;

                    // Set the text of the date distance list item
                    oCustomDistanceItem.setText(this.formatDateDistanceValueListItemText(iDuration, sUnit));
                }

                /*
                 * Search for the right list item to select: If type="Absolute" -> select custom date range If type="Relative" and custom=true ->
                 * select custom date distance If type="Relative" and custom=false -> select static date distance list item
                 */
                if (oSelection.Type == this.AbsoluteType) {
                    bActive = true;
                    oCustomDateRangeItem.setSelected(true);
                } else if (oSelection.Type == this.RelativeType) {
                    if (oSelection.Duration != null) {
                        // Search for the right static distance item
                        var aItems = this.getItems();
                        for ( var i = 0; i < aItems.length; i++) {
                            var oItem = aItems[i];
                            if (oSelection.Duration == oItem.getValue().duration && oSelection.Unit == oItem.getValue().unit) {
                                bActive = true;
                                oItem.setSelected(true);
                            }
                        }
                    } else if (oSelection.CustomDuration != -1) {
                        bActive = true;
                        oCustomDistanceItem.setSelected(true);
                    }
                }

            }

            // Initialize the value attributes of all custom list items
            oCustomDateRangeItem.setValue(oCustomDateRangeValue);
            oCustomDistanceItem.setValue(oCustomDistanceValue);

            // Set the filteritem active flag to indicate that a selection was set
            this.setActive(bActive);

            return this;
        },

        /**
         * Formates the text of the custom date distance list item
         * 
         * @param {function}
         *            Function which formates the text of the date distance valueListItem.
         * 
         */
        setDateDistanceValueListItemTextFormatter : function(fnFormatDateDistanceValueListItemText) {
            this.formatDateDistanceValueListItemText = fnFormatDateDistanceValueListItemText;
        },

        /**
         * Formates the text of the custom date range list item
         * 
         * @param {function}
         *            Function which formates the text of the date distance valueListItem.
         */
        setDateRangeValueListItemTextFormatter : function(fnFormatDateRangeValueListItemText) {
            this.formatDateRangeValueListItemText = fnFormatDateRangeValueListItemText;
        },

        /**
         * Sets the enabled/disabled state
         * 
         * @param {boolean}
         *            bEnabled new value for property enabled
         * @returns {jd.ui.eid.control.DateDistanceFilterItem} This for method chaining
         */
        setEnabled : function(bEnabled) {
            var bOldEnabled = this.getProperty("enabled");

            if (bOldEnabled != bEnabled) {
                this.setProperty("enabled", bEnabled);
                // this.getAggregation("customDateRangeItem").setEnabled(bEnabled);
                this.getAggregation("customDistanceItem").setEnabled(bEnabled);
                var aItems = this.getAggregation("items");
                for ( var i = 0; i < aItems.length; i++) {
                    aItems[i].setEnabled(bEnabled);
                }
            }

            return this;
        },

        /* Rendering */

        renderer : "jd.ui.eid.control.DateDistanceFilterItemRenderer"

    });

})();